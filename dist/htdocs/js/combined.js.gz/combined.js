var locales=[{"code": "de-DE","desc": "Deutsch"},{"code": "en-US","desc": "English"},{"code": "ko-KR","desc": "한국어"}];
var phrases={
	"%{name} added to queue":{
		"de-DE":"%{name} hinzugefügt",
		"ko-KR":"순서에 %{name} 추가함"
	},
	"%{name} added to queue position %{to}":{
		"de-DE":"%{name} an Warteschlangenposition %{to} hinzugefügt",
		"ko-KR":"%{to} 순서 위치에 %{name} 추가함"
	},
	"A queue longer than 1 song in length is required to crop":{
		"de-DE":"Die Warteschlange muss länger als 1 Lied sein um sie abzuschneiden",
		"ko-KR":"남기려면 순서에 한 곡이상이어야 함"
	},
	"About":{
		"de-DE":"Über myMPD",
		"ko-KR":"myMPD에 대하여"
	},
	"Action":{
		"de-DE":"Aktion",
		"ko-KR":"기능"
	},
	"Add":{
		"de-DE":"Hinzufügen",
		"ko-KR":"추가"
	},
	"Add after current playing song":{
		"de-DE":"Nach aktuellem Lied hinzufügen",
		"ko-KR":"지금 연주 중인 곡 다음에 추가"
	},
	"Add all to playlist":{
		"de-DE":"Alles zu einer Wiedergabeliste hinzufügen",
		"ko-KR":"연주목록에 모두 추가"
	},
	"Add all to queue":{
		"de-DE":"Alles zur Warteschlange hinzufügen",
		"ko-KR":"순서에 모두 추가"
	},
	"Add bookmark":{
		"de-DE":"Lesezeichen hinzufügen",
		"ko-KR":"즐겨찾기 추가"
	},
	"Add random":{
		"de-DE":"Zufällig hinzufügen",
		"ko-KR":"무작위 추가"
	},
	"Add randrom":{
		"de-DE":"Zufällig",
		"ko-KR":"무작위 추가"
	},
	"Add stream":{
		"de-DE":"Stream hinzufügen",
		"ko-KR":"스트림 추가"
	},
	"Add to home screen":{
		"de-DE":"Zum Startbildschirm hinzufügen",
		"ko-KR":"홈 화면에 추가"
	},
	"Add to playlist":{
		"de-DE":"Zu einer Wiedergabeliste hinzufügen",
		"ko-KR":"연주목록에 추가"
	},
	"Add to queue":{
		"de-DE":"Zu Warteschlange hinzufügen",
		"ko-KR":"순서에 추가"
	},
	"Added %{uri} to playlist %{playlist}":{
		"de-DE":"%{uri} zu Wiedergabeliste %{playlist} hinzugefügt",
		"ko-KR":"%{uri}의 %{playlist} 연주목록 추가에 실패함"
	},
	"Added all songs":{
		"de-DE":"Alle Lieder hinzugefügt",
		"ko-KR":"모든 곡을 추가함"
	},
	"Added all songs from database selection to %{playlist}":{
		"de-DE":"Alle Lieder der Auswahl zu %{playlist} hinzugefügt",
		"ko-KR":"데이터베이스의 모든 곡을 %{playlist}에 추가함"
	},
	"Added all songs from search to %{playlist}":{
		"de-DE":"Alle Lieder der Suche zu %{playlist} hinzugefügt",
		"ko-KR":"찾기의 모든 곡을 %{playlist}에 추가함"
	},
	"Added stream %{streamUri} to queue":{
		"de-DE":"Stream %{streamUri} zu Warteschlange hinzugefügt",
		"ko-KR":"%{streamUri} 스트림을 순서에 추가함"
	},
	"Adding playlist to queue failed":{
		"de-DE":"Wiedergabeliste konnte nicht zur Warteschlange hinzugefügt werden",
		"ko-KR":"순서의 연주목록 추가에 실패함"
	},
	"Adding random songs to queue failed":{
		"de-DE":"Zufällige Lieder konnten nicht zur Warteschlange hinzugefügt werden",
		"ko-KR":"무작위 곡의 순서 추가에 실패함"
	},
	"Adding song to playlist failed":{
		"de-DE":"Lied konnte nicht zur Wiedergabeliste hinzugefügt werden",
		"ko-KR":"연주목록의 곡 추가에 실패함"
	},
	"Adding song to queue failed":{
		"de-DE":"Lied konnte nicht zur Warteschlange hinzugefügt werden",
		"ko-KR":"순서의 곡 추가에 실패함"
	},
	"Advanced search is disabled":{
		"de-DE":"Erweiterte Suche ist deaktiviert",
		"ko-KR":"상세 찾기 사용 안 함"
	},
	"Album":{
		"de-DE":"Album",
		"ko-KR":"음반"
	},
	"AlbumArtist":{
		"de-DE":"Album Interpret",
		"ko-KR":"음반 연주가"
	},
	"Albumart":{
		"de-DE":"Albumcover",
		"ko-KR":"음반표지"
	},
	"Albums":{
		"de-DE":"Alben",
		"ko-KR":"음반"
	},
	"Any Tag":{
		"de-DE":"Alle Tags",
		"ko-KR":"모든 태그"
	},
	"Append item to playlist":{
		"de-DE":"Ausgewähltes Element zu einer Wiedergabeliste hinzufügen",
		"ko-KR":"연주목록에 항목 추가"
	},
	"Append item to queue":{
		"de-DE":"Ausgewähltes Element an Warteschlange anhängen",
		"ko-KR":"순서에 항목 추가"
	},
	"Append to queue":{
		"de-DE":"An Warteschlange anhängen",
		"ko-KR":"순서에 추가"
	},
	"Apply":{
		"de-DE":"Anwenden",
		"ko-KR":"적용"
	},
	"Applying settings":{
		"de-DE":"Einstellungen werden angewendet",
		"ko-KR":"설정 적용"
	},
	"Artist":{
		"de-DE":"Künstler",
		"ko-KR":"연주가"
	},
	"Artists":{
		"de-DE":"Interpreten",
		"ko-KR":"연주가"
	},
	"Author":{
		"de-DE":"Autor",
		"ko-KR":"저자"
	},
	"Autodetect":{
		"de-DE":"Automatisch",
		"ko-KR":"자동 감지"
	},
	"Autoplay":{
		"de-DE":"Automatische Wiedergabe",
		"ko-KR":"자동 연주"
	},
	"Background":{
		"de-DE":"Hintergrund",
		"ko-KR":"배경"
	},
	"Begin to play failed":{
		"de-DE":"Wiedergabe konnte nicht gestart werden",
		"ko-KR":"연주 시작에 실패함"
	},
	"Bookmark URI":{
		"de-DE":"Lesezeichen URL",
		"ko-KR":"즐겨찾기 주소"
	},
	"Bookmark name":{
		"de-DE":"Name",
		"ko-KR":"즐겨찾기 이름"
	},
	"Bookmarks":{
		"de-DE":"Lesezeichen",
		"ko-KR":"즐겨찾기"
	},
	"Browse":{
		"de-DE":"Durchsuchen",
		"ko-KR":"열기"
	},
	"Browser default":{
		"de-DE":"Browsereinstellung",
		"ko-KR":"기본 열기"
	},
	"CSS filter":{
		"de-DE":"CSS Filter",
		"ko-KR":"CSS 필터"
	},
	"Calculate":{
		"de-DE":"Berechne Fingerabdruck",
		"ko-KR":"계산"
	},
	"Can not execute cmd %{cmd}":{
		"de-DE":"Kann Systembefehl %{cmd} nicht ausführen",
		"ko-KR":"%{cmd} 명령어를 실행할 수 없음"
	},
	"Can not parse settings":{
		"de-DE":"Einstellungen können nicht geladen werden",
		"ko-KR":"설정을 분석할 수 없음"
	},
	"Can not parse smart playlist file":{
		"de-DE":"Intelligente Wiedergabeliste konnte nicht geparsed werden",
		"ko-KR":"스마트 연주목록 파일을 분석할 수 없음"
	},
	"Can not read smart playlist file":{
		"de-DE":"Intelligente Wiedergabeliste konnte nicht eingelesen werden",
		"ko-KR":"스마트 연주목록 파일을 읽을 수 없음"
	},
	"Can not start playing":{
		"de-DE":"Wiedergabe kann nicht gestartet werden",
		"ko-KR":"연주를 시작할 수 없음"
	},
	"Can't access music directory":{
		"de-DE":"Musik Verzeichnis ist nicht verfügbar",
		"ko-KR":"음원 디렉터리에 접근할 수 없음"
	},
	"Cancel":{
		"de-DE":"Abbrechen",
		"ko-KR":"취소"
	},
	"Certificate":{
		"de-DE":"Zertifikat",
		"ko-KR":"인증"
	},
	"Clear playlist":{
		"de-DE":"Playlist leeren",
		"ko-KR":"연주목록 비우기"
	},
	"Clear queue":{
		"de-DE":"Warteschlange leeren",
		"ko-KR":"순서 비우기"
	},
	"Clearing playlist failed":{
		"de-DE":"Wiedergabeliste konnte nicht geleert werden",
		"ko-KR":"연주목록 비우기에 실패함"
	},
	"Clearing queue failed":{
		"de-DE":"Warteschlange konnte nicht geleert werden",
		"ko-KR":"순서 지우기에 실패함"
	},
	"Close":{
		"de-DE":"Schließen",
		"ko-KR":"닫기"
	},
	"Composer":{
		"de-DE":"Komponist",
		"ko-KR":"작곡가"
	},
	"Connect to websocket":{
		"de-DE":"Websocketverbindung wird hergestellt",
		"ko-KR":"웹소켓에 연결"
	},
	"Connected to MPD":{
		"de-DE":"Verbindung zu MPD hergestellt",
		"ko-KR":"MPD로 연결됨"
	},
	"Connected to myMPD":{
		"de-DE":"Verbindung zu myMPD hergestellt",
		"ko-KR":"myMPD로 연결됨"
	},
	"Connecting to stream...":{
		"de-DE":"Verbinde...",
		"ko-KR":"스트림에 연결 중..."
	},
	"Connection":{
		"de-DE":"Verbindung",
		"ko-KR":"연결"
	},
	"Consume":{
		"de-DE":"Konsumieren",
		"ko-KR":"써버리기"
	},
	"Create Playlist":{
		"de-DE":"Neue Wiedergabeliste erstellen",
		"ko-KR":"연주목록 만들기"
	},
	"Crop queue":{
		"de-DE":"Warteschlange abschneiden",
		"ko-KR":"순서 남기기"
	},
	"Crossfade":{
		"de-DE":"Crossfade",
		"ko-KR":"크로스페이드"
	},
	"DB play time":{
		"de-DE":"Datenbank Wiedergabedauer",
		"ko-KR":"DB 연주 시간"
	},
	"DB updated":{
		"de-DE":"Datenbank zuletzt aktualisiert",
		"ko-KR":"DB 업데이트됨"
	},
	"Database":{
		"de-DE":"Datenbank",
		"ko-KR":"데이터 베이스"
	},
	"Database statistics":{
		"de-DE":"Datenbank Statistiken",
		"ko-KR":"데이터베이스 통계"
	},
	"Database successfully updated":{
		"de-DE":"Datenbank erfolgreich aktualisiert",
		"ko-KR":"데이터베이스 업데이트됨"
	},
	"Database update finished":{
		"de-DE":"Datenbankaktualisierung beendet",
		"ko-KR":"데이터베이스 업데이트 마침"
	},
	"Database update started":{
		"de-DE":"Datenbankaktualisierung gestartet",
		"ko-KR":"데이터베이스 업데이트 시작됨"
	},
	"Date":{
		"de-DE":"Datum",
		"ko-KR":"날짜"
	},
	"Days":{
		"de-DE":"Tage",
		"en-US":"Days",
		"ko-KR":"일"
	},
	"Delete":{
		"de-DE":"Löschen",
		"ko-KR":"지우기"
	},
	"Delete playlist":{
		"de-DE":"Wiedergabeliste löschen",
		"ko-KR":"연주목록 지우기"
	},
	"Deleting bookmark failed":{
		"de-DE":"Lesezeichen konnte nicht gelöscht werden",
		"ko-KR":"즐겨찾기 지우기에 실패함"
	},
	"Deleting playlist failed":{
		"de-DE":"Wiedergabeliste konnte nicht gelöscht werden",
		"ko-KR":"연주목록 지우기에 실패함"
	},
	"Deleting smart playlist failed":{
		"de-DE":"Intelligente Wiedergabeliste konnte nicht gelöscht werden",
		"ko-KR":"스마트 연주목록 지우기에 실패함"
	},
	"Dependent on the size of your music collection this can take a while":{
		"de-DE":"Der Aktualisierungsvorgang kann einige Zeit in Anspruch nehmen",
		"ko-KR":"음원 크기에 따라 시간이 걸릴 수 있습니다"
	},
	"Disabling output failed":{
		"de-DE":"Musikausgabegerät konnte nicht deaktiviert werden",
		"ko-KR":"출력 사용 안 함에 실패함"
	},
	"Dislike song":{
		"de-DE":"Schlechtes Lied",
		"ko-KR":"곡 좋아하지 않음"
	},
	"Download":{
		"de-DE":"Herunterladen",
		"ko-KR":"내려받기"
	},
	"Duration":{
		"de-DE":"Länge",
		"ko-KR":"길이"
	},
	"Edit playlist":{
		"de-DE":"Wiegergabeliste bearbeiten",
		"ko-KR":"연주목록 편집"
	},
	"Edit smart playlist":{
		"de-DE":"Intelligente Wiedergabeliste bearbeiten",
		"ko-KR":"스마트 연주목록 편집"
	},
	"Empty list":{
		"de-DE":"Leere Liste",
		"ko-KR":"목록 비우기"
	},
	"Empty playlist":{
		"de-DE":"Leere Wiedergabeliste",
		"ko-KR":"연주목록 비우기"
	},
	"Empty queue":{
		"de-DE":"Leere Warteschlange",
		"ko-KR":"순서 비우기"
	},
	"Enabling output failed":{
		"de-DE":"Musikausgabegeräte konnte nicht aktiviert werden",
		"ko-KR":"출력 사용에 실패함"
	},
	"Error":{
		"de-DE":"Fehler",
		"ko-KR":"오류"
	},
	"Failed to execute cmd %{cmd}":{
		"de-DE":"Fehler beim Ausführen des Systembefehls %{cmd}",
		"ko-KR":"%{cmd} 명령어 실행에 실패함"
	},
	"Failed to open bookmarks file":{
		"de-DE":"Lesezeichen Datei konnte nicht geöffnet werden",
		"ko-KR":"즐겨찾기 파일 열기에 실패함"
	},
	"Failed to save playlist":{
		"de-DE":"Wiedergabeliste konnte nicht gespeichert werden",
		"ko-KR":"연주목록 저장에 실패함"
	},
	"Failed to send love message to channel":{
		"de-DE":"Lieblingslied Nachricht konnte nicht gesendet werden",
		"ko-KR":"채널에 애청곡 메시지 보내기 실패함"
	},
	"Failed to set like":{
		"de-DE":"Wertung konnte nicht gesetzt werden",
		"ko-KR":"좋아요 설정 실패함"
	},
	"Failed to set mpd state %{state}":{
		"de-DE":"Setzen des MPD Status %{state} fehlgeschlagen",
		"ko-KR":"MPD 상태 %{state} 설정에 실패함"
	},
	"Failed to set myMPD state %{state}":{
		"de-DE":"myMPD Option %{state} konnte nicht gespeichert werden",
		"ko-KR":"myMPD 상태 %{state} 저장할 수 없음"
	},
	"Fetch MPD settings":{
		"de-DE":"Lade MPD Einstellungen",
		"ko-KR":"MPD 설정 가져오기"
	},
	"Fetch myMPD settings":{
		"de-DE":"Lade myMPD Einstellungen",
		"ko-KR":"myMPD 설정 가져오기"
	},
	"Filename":{
		"de-DE":"Dateiname",
		"ko-KR":"파일 이름"
	},
	"Filesystem":{
		"de-DE":"Dateisystem",
		"ko-KR":"파일 시스템"
	},
	"Fingerprint":{
		"de-DE":"Fingerabdruck",
		"ko-KR":"지문"
	},
	"Focus search":{
		"de-DE":"Gehe zur Suche",
		"ko-KR":"찾기로 가기"
	},
	"Focus table":{
		"de-DE":"In Tabelle navigieren",
		"ko-KR":"목록에서 찾기"
	},
	"From":{
		"de-DE":"Von",
		"ko-KR":"원래"
	},
	"General":{
		"de-DE":"Allgemein",
		"ko-KR":"일반"
	},
	"Genre":{
		"de-DE":"Genre",
		"ko-KR":"장르"
	},
	"Goto browse database":{
		"de-DE":"Gehe zu Datenbank durchsuchen",
		"ko-KR":"데이터베이스 열기로 가기"
	},
	"Goto browse filesystem":{
		"de-DE":"Gehe zu Dateisystem",
		"ko-KR":"파일 시스템 열기로 가기"
	},
	"Goto browse playlists":{
		"de-DE":"Gehe zu Wiedergabelisten",
		"ko-KR":"연주목록 열기로 가기"
	},
	"Goto last played":{
		"de-DE":"Gehe zu Zuletzt gespielt",
		"ko-KR":"앞선 연주로 가기"
	},
	"Goto playback":{
		"de-DE":"Gehe zu Wiedergabe",
		"ko-KR":"연주로 가기"
	},
	"Goto previous song failed":{
		"de-DE":"Zurück zum vorigen Lied fehlgeschlagen",
		"ko-KR":"이전 곡으로 가기에 실패함"
	},
	"Goto queue":{
		"de-DE":"Gehe zu Warteschlange",
		"ko-KR":"순서로 가기"
	},
	"Goto search":{
		"de-DE":"Fehe zur Suche",
		"ko-KR":"찾기로 가기"
	},
	"Homepage":{
		"de-DE":"Homepage",
		"ko-KR":"홈페이지"
	},
	"Hours":{
		"de-DE":"Std",
		"en-US":"Hrs",
		"ko-KR":"시간"
	},
	"Initializing myMPD":{
		"de-DE":"Initialisiere myMPD",
		"ko-KR":"myMPD 초기화"
	},
	"Invalid CSS filter":{
		"de-DE":"Ungültiger CSS Filter",
		"ko-KR":"틀린 CSS 필터"
	},
	"Invalid MPD host":{
		"de-DE":"Ungültiger MPD Host",
		"ko-KR":"틀린 MPD 호스트"
	},
	"Invalid MPD password":{
		"de-DE":"Ungültiges MPD Passwort",
		"ko-KR":"틀린 MPD 비밀번호"
	},
	"Invalid MPD port":{
		"de-DE":"Ungültiger MPD Port",
		"ko-KR":"틀린 MPD 포트"
	},
	"Invalid URI":{
		"de-DE":"Ungültige URL",
		"ko-KR":"틀린 주소"
	},
	"Invalid channel name":{
		"de-DE":"Ungültiger Channel name",
		"ko-KR":"틀린 채널 이름"
	},
	"Invalid color":{
		"de-DE":"Ungültige Farbe",
		"ko-KR":"틀린 색상"
	},
	"Invalid filename":{
		"de-DE":"Ungültiger Dateiname",
		"ko-KR":"틀린 파일 이름"
	},
	"Invalid filename for coverimage_name":{
		"de-DE":"Ungültiger Dateiname für Albumcover Name",
		"ko-KR":"음반표지의 파일 이름 틀림"
	},
	"Invalid jukebox mode":{
		"de-DE":"Ungültiger Jukebox Modus",
		"ko-KR":"뮤직박스 모드 틀림"
	},
	"Invalid message":{
		"de-DE":"Ungültige Zeichen in Nachricht",
		"ko-KR":"틀린 메시지"
	},
	"Invalid music directory":{
		"de-DE":"Ungültiges Musikverzeichnis",
		"ko-KR":"틀린 음원 디렉터리"
	},
	"Invalid size":{
		"de-DE":"Ungültige Größe",
		"ko-KR":"틀린 크기"
	},
	"Invalid type":{
		"de-DE":"Ungültiger Typ",
		"ko-KR":"틀린 형식"
	},
	"JavaScript is disabled":{
		"de-DE":"JavaScript ist deaktiviert",
		"ko-KR":"자바스크립트 사용 안 함"
	},
	"Jukebox":{
		"de-DE":"Jukebox",
		"ko-KR":"뮤직박스"
	},
	"Jukebox mode":{
		"de-DE":"Jukebox Modus",
		"ko-KR":"뮤직박스 모드"
	},
	"Keep queue length":{
		"de-DE":"Warteschlangenlänge",
		"ko-KR":"순서 길이 유지"
	},
	"Last modified":{
		"de-DE":"Zuletzt geändert",
		"ko-KR":"앞서 수정함"
	},
	"Last played":{
		"de-DE":"Zuletzt gespielt",
		"ko-KR":"앞서 연주함"
	},
	"Last played list count":{
		"de-DE":"Anzahl zuletzt gespielte Lieder",
		"ko-KR":"앞선 연주 목록 개수"
	},
	"Last skipped":{
		"de-DE":"Zuletzt übersprungen",
		"ko-KR":"앞서 건너뜀"
	},
	"LastPlayed":{
		"de-DE":"Zuletzt gespielt",
		"ko-KR":"앞서 연주함"
	},
	"Libmpdclient version":{
		"de-DE":"Libmpdclient Version",
		"ko-KR":"Libmpdclient 버전"
	},
	"Like":{
		"de-DE":"Wertung",
		"ko-KR":"좋아요"
	},
	"Like song":{
		"de-DE":"Gutes Lied",
		"ko-KR":"곡 좋아요"
	},
	"Local playback":{
		"de-DE":"Lokale Wiedergabe",
		"ko-KR":"로컬 연주"
	},
	"Locale":{
		"de-DE":"Sprache",
		"ko-KR":"언어"
	},
	"Love song":{
		"de-DE":"Lieblingslied",
		"ko-KR":"애청곡"
	},
	"MPD channel":{
		"de-DE":"MPD Channel",
		"ko-KR":"MPD 채널"
	},
	"MPD channel not found":{
		"de-DE":"MPD Channel nicht gefunden",
		"ko-KR":"MPD 채널 없음"
	},
	"MPD connection":{
		"de-DE":"MPD Verbindung",
		"ko-KR":"MPD 연결"
	},
	"MPD connection error: %{error}":{
		"de-DE":"MPD Verbindungsfehler: %{error}",
		"ko-KR":"MPD 연결 오류: %{error}"
	},
	"MPD disconnected":{
		"de-DE":"MPD nicht verbunden",
		"ko-KR":"MPD 연결 끊어짐"
	},
	"MPD host":{
		"de-DE":"MPD Host",
		"ko-KR":"MPD 호스트"
	},
	"MPD password":{
		"de-DE":"MPD Passwort",
		"ko-KR":"MPD 비밀번호"
	},
	"MPD port":{
		"de-DE":"MPD Port",
		"ko-KR":"MPD 포트"
	},
	"MPD stickers are disabled":{
		"de-DE":"MPD Sticker sind deaktiviert",
		"ko-KR":"MPD 스티커 사용 안 함"
	},
	"Max. songs":{
		"de-DE":"Max. Lieder",
		"ko-KR":"최대 곡"
	},
	"Message":{
		"de-DE":"Nachricht",
		"ko-KR":"메시지"
	},
	"Minutes":{
		"de-DE":"Min",
		"en-US":"Min",
		"ko-KR":"분"
	},
	"Mixramp DB":{
		"de-DE":"Mixramp DB",
		"ko-KR":"Mixramp DB"
	},
	"Mixramp delay":{
		"de-DE":"Mixramp Verzögerung",
		"ko-KR":"Mixramp 지연"
	},
	"Moving track in playlist failed":{
		"de-DE":"Lied konnte in der Wiedergabeliste nicht verschoben werden",
		"ko-KR":"연주목록의 곡 옮기기에 실패함"
	},
	"Moving track in queue failed":{
		"de-DE":"Lied konnte in der Warteschlange nicht verschoben werden",
		"ko-KR":"순서의 곡 옮기기에 실패함"
	},
	"Music directory":{
		"de-DE":"Musikverzeichnis",
		"ko-KR":"음원 디렉터리"
	},
	"Music directory not found":{
		"de-DE":"Musikverzeichnis nicht gefunden",
		"ko-KR":"음원 디렉터리 없음"
	},
	"Must be a number":{
		"de-DE":"Muss eine Zahl sein",
		"ko-KR":"숫자여야 함"
	},
	"Must be a number and greater than zero":{
		"de-DE":"Muss eine Zahl größer als 0 sein",
		"ko-KR":"0보다 큰 숫자여야 함"
	},
	"Must be a number smaller or equal 200":{
		"de-DE":"Muss eine Zahl kleinergleich 200 sein",
		"ko-KR":"200이하의 숫자여야 함"
	},
	"Name":{
		"de-DE":"Name",
		"ko-KR":"이름"
	},
	"New playlist":{
		"de-DE":"Neue Wiedergabeliste",
		"ko-KR":"새 연주목록"
	},
	"Next page":{
		"de-DE":"Nächste Seite",
		"ko-KR":"다음 페이지"
	},
	"Next song":{
		"de-DE":"Nächstes Lied",
		"ko-KR":"다음 곡"
	},
	"No bookmarks found":{
		"de-DE":"Keine Lesezeichen gefunden",
		"ko-KR":"즐겨찾기를 찾을 수 없음"
	},
	"No playlists found":{
		"de-DE":"Keine Wiedergabelisten gefunden",
		"ko-KR":"연주목록 찾을 수 없음"
	},
	"No response for cmd_id %{cmdId}":{
		"de-DE":"Keine Rückmeldung für cmd_id %{cmdId}",
		"ko-KR":"%{cmdId} 명령어 ID에 반응 없음"
	},
	"No results, please refine your search":{
		"de-DE":"Keine Ergebnisse, bitte passe die Suche an",
		"ko-KR":"결과 없음, 맞게 찾아야 함"
	},
	"None":{
		"de-DE":"Keines",
		"ko-KR":"없음"
	},
	"Notifications":{
		"de-DE":"Hinweise",
		"ko-KR":"알림"
	},
	"Num entries":{
		"de-DE":"%{smart_count} Eintrag |||| %{smart_count} Einträge",
		"en-US":"%{smart_count} Entry |||| %{smart_count} Entries",
		"ko-KR":"%{smart_count} 항목 |||| %{smart_count} 항목"
	},
	"Num playlists":{
		"de-DE":"%{smart_count} Wiedergabeliste |||| %{smart_count} Wiedergabelisten",
		"en-US":"%{smart_count} Playlist |||| %{smart_count} Playlists",
		"ko-KR":"%{smart_count} 연주목록 |||| %{smart_count} 연주목록"
	},
	"Num songs":{
		"de-DE":"%{smart_count} Lied |||| %{smart_count} Lieder",
		"en-US":"%{smart_count} Song |||| %{smart_count} Songs",
		"ko-KR":"%{smart_count} 곡 |||| %{smart_count} 곡"
	},
	"Off":{
		"de-DE":"deaktiviert",
		"ko-KR":"끄기"
	},
	"On page notifications":{
		"de-DE":"Integrierte Hinweise",
		"ko-KR":"페이지에 알림"
	},
	"Open about":{
		"de-DE":"Öffne Über myMPD",
		"ko-KR":"myMPD에 대하여 열기"
	},
	"Open local player":{
		"de-DE":"Lokale Wiedergabe",
		"ko-KR":"로컬 연주기 열기"
	},
	"Open main menu":{
		"de-DE":"Öffne Hauptmenü",
		"ko-KR":"주 메뉴로 가기"
	},
	"Open settings":{
		"de-DE":"Einstellungen",
		"ko-KR":"설정 열기"
	},
	"Open song details":{
		"de-DE":"Lieddetails",
		"ko-KR":"곡 정보 열기"
	},
	"Open volume menu":{
		"de-DE":"Öffne Lautstärkemenü",
		"ko-KR":"음량 메뉴 열기"
	},
	"Pagination":{
		"de-DE":"Seitenumbruch",
		"ko-KR":"페이지 매기기"
	},
	"Performer":{
		"de-DE":"Aufführender",
		"ko-KR":"연주자"
	},
	"Play count":{
		"de-DE":"Wie oft gespielt",
		"ko-KR":"연주 횟수"
	},
	"Play time":{
		"de-DE":"Wiedergabedauer",
		"ko-KR":"연주 시간"
	},
	"Playback":{
		"de-DE":"Wiedergabe",
		"ko-KR":"연주"
	},
	"Playback statistics":{
		"de-DE":"Wiedergabestatistiken",
		"ko-KR":"연주 통계"
	},
	"Playlist":{
		"de-DE":"Wiedergabeliste",
		"ko-KR":"연주목록"
	},
	"Playlist name":{
		"de-DE":"Wiedergabelistenname",
		"ko-KR":"연주목록 이름"
	},
	"Playlists":{
		"de-DE":"Wiedergabelisten",
		"ko-KR":"연주목록"
	},
	"Playlists are disabled":{
		"de-DE":"Wiedergabelisten sind deaktiviert",
		"ko-KR":"연주목록 사용 안 함"
	},
	"Please choose playlist":{
		"de-DE":"Bitte Wiedergabeliste auswählen",
		"ko-KR":"연주목록을 선택합니다"
	},
	"Please wait, myMPD is initializing...":{
		"de-DE":"Einen Moment noch, myMPD lädt...",
		"ko-KR":"myMPD 초기화 하는 중..."
	},
	"Port":{
		"de-DE":"Port",
		"ko-KR":"포트"
	},
	"Pos":{
		"de-DE":"Pos",
		"ko-KR":"위치"
	},
	"Previous page":{
		"de-DE":"Vorige Seite",
		"ko-KR":"이전 페이지"
	},
	"Previous song":{
		"de-DE":"Voriges Lied",
		"ko-KR":"이전 곡"
	},
	"Protocol version":{
		"de-DE":"Protokoll Version",
		"ko-KR":"프로토콜 버전"
	},
	"Quantity":{
		"de-DE":"Anzahl",
		"ko-KR":"갯수"
	},
	"Queue":{
		"de-DE":"Warteschlange",
		"ko-KR":"순서"
	},
	"Queue replaced with %{name}":{
		"de-DE":"Warteschlange mit %{name} ersetzt",
		"ko-KR":"%{name} 순서 바꿈"
	},
	"Random":{
		"de-DE":"Zufall",
		"ko-KR":"무작위"
	},
	"Remove":{
		"de-DE":"Entfernen",
		"ko-KR":"지우기"
	},
	"Remove all downwards":{
		"de-DE":"Aller Lieder darunter entfernen",
		"ko-KR":"아래로 지우기"
	},
	"Remove all upwards":{
		"de-DE":"Alle Lieder darüber entfernen",
		"ko-KR":"위로 지우기"
	},
	"Remove item from queue":{
		"de-DE":"Ausgewähltes Element aus Warteschlange entfernen",
		"ko-KR":"순서에서 항목 지우기"
	},
	"Removing track from playlist failed":{
		"de-DE":"Lied konnte nicht von Wiedergabeliste entfernt werden",
		"ko-KR":"연주목록의 곡 지우기에 실패함"
	},
	"Removing track from queue failed":{
		"de-DE":"Lied konnte nicht aus der Warteschlange entfernt werden",
		"ko-KR":"순서의 곡 지우기에 실패함"
	},
	"Removing track range from queue failed":{
		"de-DE":"Leder konnten nicht aus der Warteschlange entfernt werden",
		"ko-KR":"순서의 곡 범위 지우기에 실패함"
	},
	"Rename playlist":{
		"de-DE":"Wiedergabeliste umbenennen",
		"ko-KR":"연주목록 이름 바꾸기"
	},
	"Renaming playlist failed":{
		"de-DE":"Wiedergabeliste konnte nicht umbenannt werden",
		"ko-KR":"연주목록 이름 바꾸기에 실패함"
	},
	"Repeat":{
		"de-DE":"Wiederholen",
		"ko-KR":"다시"
	},
	"Replace queue":{
		"de-DE":"Warteschlange ersetzen",
		"ko-KR":"순서 바꾸기"
	},
	"Replace queue with item":{
		"de-DE":"Warteschlange mit ausgewähltem Element ersetzen",
		"ko-KR":"순서에 항목 대체"
	},
	"Replaygain":{
		"de-DE":"Lautstärkeanpassung",
		"ko-KR":"리플레이게인"
	},
	"Rescan database":{
		"de-DE":"Datenbank neu einlesen",
		"ko-KR":"데이터베이스 다시 검색"
	},
	"Reset":{
		"de-DE":"Zurücksetzen",
		"ko-KR":"다시 설정"
	},
	"Save":{
		"de-DE":"Speichern",
		"ko-KR":"저장"
	},
	"Save as smart playlist":{
		"de-DE":"Als intelligente Wiedergabeliste speichern",
		"ko-KR":"스마트 연주목록 저장"
	},
	"Save bookmark":{
		"de-DE":"Lesezeichen speichern",
		"ko-KR":"즐겨찾기 저장"
	},
	"Save queue":{
		"de-DE":"Warteschlange speichern",
		"ko-KR":"순서 저장"
	},
	"Save smart playlist":{
		"de-DE":"Intelligente Wiedergabeliste sichern",
		"ko-KR":"스마트 연주목록 저장"
	},
	"Saved smart playlist %{name}":{
		"de-DE":"Intelligente Wiedergabeliste %{name} gespeichert",
		"ko-KR":"%{name} 스마트 연주목록 저장함"
	},
	"Saving bookmark failed":{
		"de-DE":"Lesezeichen konnte nicht gespeichert werden",
		"ko-KR":"즐겨찾기 저장에 실패함"
	},
	"Saving queue as playlist failed":{
		"de-DE":"Warteschlange konnte nicht als Wiedergabeliste gespeichert werden",
		"ko-KR":"순서의 연주목록 저장에 실패함"
	},
	"Scrobbled love":{
		"de-DE":"Lieblingslied wurde gescrobbelt",
		"ko-KR":"애청곡 추천"
	},
	"Scrobbler Integration":{
		"de-DE":"Scrobbler Intergration",
		"ko-KR":"추천 통합"
	},
	"Search":{
		"de-DE":"Suchen",
		"ko-KR":"찾기"
	},
	"Search queue":{
		"de-DE":"Warteschlange durchsuchen",
		"ko-KR":"순서 찾기"
	},
	"Searching...":{
		"de-DE":"Suche...",
		"ko-KR":"찾는 중..."
	},
	"Seconds":{
		"de-DE":"Sek",
		"en-US":"Sec",
		"ko-KR":"초"
	},
	"Seeking song failed":{
		"de-DE":"Abspielposition konnte nicht geändert werden",
		"ko-KR":"곡 찾기에 실패함"
	},
	"Select tag to search":{
		"de-DE":"Tag zum Suchen auswählen",
		"ko-KR":"찾을 태그 선택"
	},
	"Send love message":{
		"de-DE":"Sende Lieblingslied",
		"ko-KR":"애청 메시지 보내기"
	},
	"Set playing track failed":{
		"de-DE":"Lied konnte nicht abgespielt werden",
		"ko-KR":"연주곡 설정에 실패함"
	},
	"Setting volume failed":{
		"de-DE":"Lautstärke konnte nicht geändert werden",
		"ko-KR":"음량 설정 실패함"
	},
	"Settings":{
		"de-DE":"Einstellungen",
		"ko-KR":"설정"
	},
	"Shortcut":{
		"de-DE":"Tastenkürzel",
		"ko-KR":"단축키"
	},
	"Shortcuts":{
		"de-DE":"Tastenkombinationen",
		"ko-KR":"단축키"
	},
	"Shuffle queue":{
		"de-DE":"Warteschlange mischen",
		"ko-KR":"순서 뒤섞기"
	},
	"Shuffling queue failed":{
		"de-DE":"Warteschlange konnte nicht gemischt werden",
		"ko-KR":"순서 뒤섞기 실패함"
	},
	"Single":{
		"de-DE":"Nur ein Lied",
		"ko-KR":"한 곡만"
	},
	"Size":{
		"de-DE":"Größe",
		"ko-KR":"크기"
	},
	"Size in px":{
		"de-DE":"Größe in PX",
		"ko-KR":"픽셀 크기"
	},
	"Skip count":{
		"de-DE":"Wie oft übersprungen",
		"ko-KR":"건너뛴 횟수"
	},
	"Skip to next song failed":{
		"de-DE":"Weiter zum nächsten Lied fehlgeschlagen",
		"ko-KR":"다음 곡으로 가기에 실패함"
	},
	"Smart playlist":{
		"de-DE":"Intelligente Wiedergabeliste",
		"ko-KR":"스마트 연주목록"
	},
	"Smart playlist %{playlist} updated":{
		"de-DE":"Intelligente Wiedergabeliste %{playlist} aktualisiert",
		"ko-KR":"%{playlist} 스마트 연주목록 업데이트됨"
	},
	"Smart playlists":{
		"de-DE":"Intelligente Wiedergabelisten",
		"ko-KR":"스마트 연주목록"
	},
	"Smart playlists updated":{
		"de-DE":"Intelligente Wiedergabelisten aktualisiert",
		"ko-KR":"스마트 연주목록 업데이트됨"
	},
	"Solid color":{
		"de-DE":"Farbe",
		"ko-KR":"꽉 찬 색상"
	},
	"Song":{
		"de-DE":"Lied",
		"ko-KR":"곡"
	},
	"Song details":{
		"de-DE":"Lieddetails",
		"ko-KR":"곡 정보"
	},
	"Songs":{
		"de-DE":"Lieder",
		"ko-KR":"곡"
	},
	"Specify":{
		"de-DE":"Manuell",
		"ko-KR":"지정"
	},
	"Statistics":{
		"de-DE":"Statistiken",
		"ko-KR":"통계"
	},
	"Sticker":{
		"de-DE":"Sticker",
		"ko-KR":"스티커"
	},
	"Stickers are disabled":{
		"de-DE":"Sticker sind deaktiviert",
		"ko-KR":"스티커 사용 안 함"
	},
	"Stop playing":{
		"de-DE":"Stop",
		"ko-KR":"정지"
	},
	"Stop playing failed":{
		"de-DE":"Wiedergabe konnte nicht beendet werden",
		"ko-KR":"연주 정지에 실패함"
	},
	"Stream URI":{
		"de-DE":"Stream URL",
		"ko-KR":"스트림 주소"
	},
	"Successfully execute cmd %{cmd}":{
		"de-DE":"Systembefehl %{cmd} erfolgreich ausgeführt",
		"ko-KR":"%{cmd} 명령어 실행함"
	},
	"Sucessfully added random songs to queue":{
		"de-DE":"Zufällige Lieder wurden zur Warteschlange hinzugefügt",
		"ko-KR":"무작위 곡을 순서에 추가함"
	},
	"Sucessfully renamed playlist":{
		"de-DE":"Wiedergabeliste erfolgreich umbenannt",
		"ko-KR":"연주목록 이름 바꿈"
	},
	"System command not defined":{
		"de-DE":"Systembefehl nicht definiert",
		"ko-KR":"시스템 명령어 정의 안됨"
	},
	"System commands":{
		"de-DE":"Systembefehle",
		"ko-KR":"시스템 명령어"
	},
	"System commands are disabled":{
		"de-DE":"Systembefehle sind deaktiviert",
		"ko-KR":"시스템 명령어 사용 안 함"
	},
	"Tag":{
		"de-DE":"Tag",
		"ko-KR":"태그"
	},
	"Tags to browse":{
		"de-DE":"Tags für die Datenbankanzeige",
		"ko-KR":"열 태그"
	},
	"Tags to search":{
		"de-DE":"Tags für die Suche",
		"ko-KR":"찾을 태그"
	},
	"Tags to use":{
		"de-DE":"Genutzte Tags",
		"ko-KR":"쓸 태그"
	},
	"Theme":{
		"de-DE":"Design",
		"ko-KR":"테마"
	},
	"Timerange (days)":{
		"de-DE":"Tage",
		"ko-KR":"시간 범위 (날짜)"
	},
	"Title":{
		"de-DE":"Titel",
		"ko-KR":"제목"
	},
	"To":{
		"de-DE":"Zu",
		"ko-KR":"바꿈"
	},
	"To top":{
		"de-DE":"Nach oben",
		"ko-KR":"위로"
	},
	"Toggle play / pause":{
		"de-DE":"Play / Pause",
		"ko-KR":"연주 / 잠시 멈춤"
	},
	"Track":{
		"de-DE":"Liednummer",
		"ko-KR":"트랙"
	},
	"Type":{
		"de-DE":"Typ",
		"ko-KR":"형식"
	},
	"URI":{
		"de-DE":"URL",
		"ko-KR":"주소"
	},
	"Unknown request":{
		"de-DE":"Unbekannter Befehl",
		"ko-KR":"알 수 없는 요구"
	},
	"Unknown smart playlist type":{
		"de-DE":"Unbekannter intelligenter Wiedergabenlisten Typ",
		"ko-KR":"스마트 연주목록 형식을 알 수 없음"
	},
	"Update":{
		"de-DE":"Aktualisieren",
		"ko-KR":"업데이트"
	},
	"Update database":{
		"de-DE":"Datenbank aktualisieren",
		"ko-KR":"데이터베이스 업데이트"
	},
	"Update smart playlist":{
		"de-DE":"Intelligente Wiedergabeliste aktualisieren",
		"ko-KR":"스마트 연주목록 업데이트"
	},
	"Update smart playlists":{
		"de-DE":"Intelligente Wiedergabelisten aktualisieren",
		"ko-KR":"스마트 연주목록 업데이트"
	},
	"Updating MPD database":{
		"de-DE":"MPD Datenbank wird aktualisiert",
		"ko-KR":"MPD 데이터베이스 업데이트 중"
	},
	"Uptime":{
		"de-DE":"Uptime",
		"ko-KR":"가동 시간"
	},
	"Version":{
		"de-DE":"Version",
		"ko-KR":"버전"
	},
	"View playlist":{
		"de-DE":"Wiedergabeliste anzeigen",
		"ko-KR":"연주목록 보기"
	},
	"Volume":{
		"de-DE":"Lautstärke",
		"ko-KR":"음량"
	},
	"Volume down":{
		"de-DE":"Lauter",
		"ko-KR":"소리 작게"
	},
	"Volume up":{
		"de-DE":"Leiser",
		"ko-KR":"소리 크게"
	},
	"Volumecontrol disabled":{
		"de-DE":"Lautstärkeregelung deaktiviert",
		"ko-KR":"음량 조절 안 함"
	},
	"Web notifications":{
		"de-DE":"Systemhinweise",
		"ko-KR":"웹 알림"
	},
	"Websocket connection failed":{
		"de-DE":"Websocket Verbindung fehlgeschlagen",
		"ko-KR":"웹소켓 연결 실패함"
	},
	"Websocket connection failed, trying to reconnect":{
		"de-DE":"Websocket Verbindung fehlgeschlagen, versuche neue Verbindung",
		"ko-KR":"웹소켓 연결 실패함, 다시 시도 중"
	},
	"You need to be playing to crop the playlist":{
		"de-DE":"Wiedergabe muss gestartet sein um die Warteschlange abzuschneiden",
		"ko-KR":"연주목록에 남기려면 연주 중이어야 함"
	},
	"contains":{
		"de-DE":"enthält",
		"ko-KR":"내용"
	},
	"folder.jpg":{
		"de-DE":"folder.jpg",
		"ko-KR":"folder.jpg"
	},
	"http://uri.to/stream.mp3":{
		"de-DE":"http://url.zum/stream.mp3",
		"ko-KR":"http://주소/stream.mp3"
	},
	"jukebox_queue_length to big, setting it to maximum value of 999":{
		"de-DE":"Jukebox Warteschlangenlänge zu groß, setze Wert auf Maxiumum von 999",
		"ko-KR":"뮤직박스가 너무 커서 최대 크기인 999로 설정함"
	},
	"myMPD CA":{
		"de-DE":"myMPD Stammzertifikat",
		"ko-KR":"myMPD 인증서"
	},
	"myMPD installed as app":{
		"de-DE":"myMPD wurde als App installiert",
		"ko-KR":"myMPD가 앱으로 설치됨"
	},
	"never":{
		"de-DE":"noch nie",
		"ko-KR":"안 함"
	},
	"queue":{
		"de-DE":"Warteschlange",
		"ko-KR":"순서"
	}};
var keymap={ArrowLeft:{cmd:"clickPrev",options:[],desc:"Previous song",key:"keyboard_arrow_left"},ArrowRight:{cmd:"clickNext",options:[],desc:"Next song",key:"keyboard_arrow_right"}," ":{cmd:"clickPlay",options:[],desc:"Toggle play / pause",key:"space_bar"},s:{cmd:"clickStop",options:[],desc:"Stop playing"},"-":{cmd:"chVolume",options:[-5],desc:"Volume down"},"+":{cmd:"chVolume",options:[5],desc:"Volume up"},c:{cmd:"MPD_API_QUEUE_CLEAR",options:[],desc:"Clear queue"},u:{cmd:"updateDB",options:[],
desc:"Update database"},r:{cmd:"rescanDB",options:[],desc:"Rescan database"},p:{cmd:"updateSmartPlaylists",options:[],desc:"Update smart playlists",req:"featSmartpls"},a:{cmd:"showAddToPlaylist",options:["stream"],desc:"Add stream"},t:{cmd:"openModal",options:["modalSettings"],desc:"Open settings"},i:{cmd:"clickTitle",options:[],desc:"Open song details"},l:{cmd:"openDropdown",options:["dropdownLocalPlayer"],desc:"Open local player"},1:{cmd:"appGoto",options:["Playback"],desc:"Goto playback"},2:{cmd:"appGoto",
options:["Queue","Current"],desc:"Goto queue"},3:{cmd:"appGoto",options:["Queue","LastPlayed"],desc:"Goto last played"},4:{cmd:"appGoto",options:["Browse","Database"],desc:"Goto browse database",req:"featTags"},5:{cmd:"appGoto",options:["Browse","Playlists"],desc:"Goto browse playlists",req:"featPlaylists"},6:{cmd:"appGoto",options:["Browse","Filesystem"],desc:"Goto browse filesystem"},7:{cmd:"appGoto",options:["Search"],desc:"Goto search"},m:{cmd:"openDropdown",options:["dropdownMainMenu"],desc:"Open main menu"},
v:{cmd:"openDropdown",options:["dropdownVolumeMenu"],desc:"Open volume menu"},S:{cmd:"MPD_API_QUEUE_SHUFFLE",options:[],desc:"Shuffle queue"},C:{cmd:"MPD_API_QUEUE_CROP",options:[],desc:"Crop queue"},"?":{cmd:"openModal",options:["modalAbout"],desc:"Open about"},"/":{cmd:"focusSearch",options:[],desc:"Focus search"},n:{cmd:"focusTable",options:[],desc:"Focus table"},q:{cmd:"queueSelectedItem",options:[!0],desc:"Append item to queue"},Q:{cmd:"queueSelectedItem",options:[!1],desc:"Replace queue with item"},
d:{cmd:"dequeueSelectedItem",options:[],desc:"Remove item from queue"},x:{cmd:"addSelectedItemToPlaylist",options:[],desc:"Append item to playlist"}};
(function(x,e){"function"===typeof define&&define.amd?define([],e):"object"===typeof module&&module.exports?module.exports=e():(e=e(),x.Alert=e.Alert,x.Button=e.Button,x.Collapse=e.Collapse,x.Dropdown=e.Dropdown,x.Modal=e.Modal,x.Popover=e.Popover,x.Tab=e.Tab)})(this,function(){var x="undefined"!==typeof global?global:this||window,e=document,B=e.documentElement,R=x.BSN={},v=R.supports=[],V="onmouseleave"in e?["mouseenter","mouseleave"]:["mouseover","mouseout"],fa=/\b(top|bottom|left|right)+/,S=0,
C="WebkitTransition"in B.style||"transition"in B.style,ha="WebkitTransition"in B.style?"webkitTransitionEnd":"transitionend",ia="WebkitDuration"in B.style?"webkitTransitionDuration":"transitionDuration",J=function(a){a.focus?a.focus():a.setActive()},z=function(a,c){a.classList.add(c)},u=function(a,c){a.classList.remove(c)},n=function(a,c){return a.classList.contains(c)},F=function(a,c){return[].slice.call(a.getElementsByClassName(c))},q=function(a,c){c=c?c:e;return"object"===typeof a?a:c.querySelector(a)},
I=function(a,c){var f=c.charAt(0),b=c.substr(1);if("."===f)for(;a&&a!==e;a=a.parentNode){if(null!==q(c,a.parentNode)&&n(a,b))return a}else if("#"===f)for(;a&&a!==e;a=a.parentNode)if(a.id===b)return a;return!1},y=function(a,c,f,b){a.addEventListener(c,f,b||!1)},D=function(a,c,f,b){a.removeEventListener(c,f,b||!1)},W=function(a,c,f,b){y(a,c,function m(e){f(e);D(a,c,m,b)},b)},T=function(){var a=!1;try{var c=Object.defineProperty({},"passive",{get:function(){a=!0}});W(x,"testPassive",null,c)}catch(f){}return a}()?
{passive:!0}:!1,U=function(a){a=C?x.getComputedStyle(a)[ia]:0;a=parseFloat(a);return a="number"!==typeof a||isNaN(a)?0:1E3*a},G=function(a,c){var f=0;U(a)?W(a,ha,function(a){!f&&c(a);f=1}):setTimeout(function(){!f&&c();f=1},17)},w=function(a,c,f){a=new CustomEvent(a+".bs."+c);a.relatedTarget=f;this.dispatchEvent(a)};R.version="2.0.27";var X=function(a){a=q(a);var c=this,f=I(a,".alert"),b=function(b){f=I(b.target,".alert");(a=q('[data-dismiss="alert"]',f))&&f&&(a===b.target||a.contains(b.target))&&
c.close()},e=function(){w.call(f,"closed","alert");D(a,"click",b);f.parentNode.removeChild(f)};this.close=function(){f&&a&&n(f,"show")&&(w.call(f,"close","alert"),u(f,"show"),f&&(n(f,"fade")?G(f,e):e()))};"Alert"in a||y(a,"click",b);a.Alert=c};v.push(["Alert",X,'[data-dismiss="alert"]']);var Y=function(a){a=q(a);var c=!1,f=function(a){32===(a.which||a.keyCode)&&a.target===e.activeElement&&g(a)},b=function(a){32===(a.which||a.keyCode)&&a.preventDefault()},g=function(b){var e="LABEL"===b.target.tagName?
b.target:"LABEL"===b.target.parentNode.tagName?b.target.parentNode:null;if(e){b=F(b.target.parentNode,"btn");var d=e.getElementsByTagName("INPUT")[0];if(d){"checkbox"===d.type&&(d.checked?(u(e,"active"),d.getAttribute("checked"),d.removeAttribute("checked"),d.checked=!1):(z(e,"active"),d.getAttribute("checked"),d.setAttribute("checked","checked"),d.checked=!0),c||(c=!0,w.call(d,"change","button"),w.call(a,"change","button")));if("radio"===d.type&&!c&&!d.checked){z(e,"active");d.setAttribute("checked",
"checked");d.checked=!0;w.call(d,"change","button");w.call(a,"change","button");c=!0;d=0;for(var f=b.length;d<f;d++){var r=b[d],g=r.getElementsByTagName("INPUT")[0];r!==e&&n(r,"active")&&(u(r,"active"),g.removeAttribute("checked"),g.checked=!1,w.call(g,"change","button"))}}setTimeout(function(){c=!1},50)}}};"Button"in a||(y(a,"click",g),q("[tabindex]",a)&&y(a,"keyup",f),y(a,"keydown",b));f=F(a,"btn");b=f.length;for(var h=0;h<b;h++)!n(f[h],"active")&&q("input:checked",f[h])&&z(f[h],"active");a.Button=
this};v.push(["Button",Y,'[data-toggle="buttons"]']);var Z=function(a,c){a=q(a);c=c||{};var e=null,b=null,g=this,h=a.getAttribute("data-parent"),m,p,d=function(a,b){w.call(a,"show","collapse");a.isAnimating=!0;z(a,"collapsing");u(a,"collapse");a.style.height=a.scrollHeight+"px";G(a,function(){a.isAnimating=!1;a.setAttribute("aria-expanded","true");b.setAttribute("aria-expanded","true");u(a,"collapsing");z(a,"collapse");z(a,"show");a.style.height="";w.call(a,"shown","collapse")})},k=function(a,b){w.call(a,
"hide","collapse");a.isAnimating=!0;a.style.height=a.scrollHeight+"px";u(a,"collapse");u(a,"show");z(a,"collapsing");a.offsetWidth;a.style.height="0px";G(a,function(){a.isAnimating=!1;a.setAttribute("aria-expanded","false");b.setAttribute("aria-expanded","false");u(a,"collapsing");z(a,"collapse");a.style.height="";w.call(a,"hidden","collapse")})};this.toggle=function(a){a.preventDefault();n(b,"show")?g.hide():g.show()};this.hide=function(){b.isAnimating||(k(b,a),z(a,"collapsed"))};this.show=function(){e&&
(p=(m=q(".collapse.show",e))&&(q('[data-target="#'+m.id+'"]',e)||q('[href="#'+m.id+'"]',e)));if(!b.isAnimating||m&&!m.isAnimating)p&&m!==b&&(k(m,p),z(p,"collapsed")),d(b,a),u(a,"collapsed")};"Collapse"in a||y(a,"click",g.toggle);b=function(){var b=a.href&&a.getAttribute("href"),c=a.getAttribute("data-target");return(b=b||c&&"#"===c.charAt(0)&&c)&&q(b)}();b.isAnimating=!1;e=q(c.parent)||h&&I(a,h);a.Collapse=g};v.push(["Collapse",Z,'[data-toggle="collapse"]']);var aa=function(a,c){a=q(a);this.persist=
!0===c||"true"===a.getAttribute("data-persist")||!1;var f=this,b=a.parentNode,g=null,h=q(".dropdown-menu",b),m=function(){for(var a=h.children,b=[],c=0;c<a.length;c++){if(a[c].children.length)for(var e=0;e<a[c].children.length;e++)"A"===a[c].children[e].tagName&&b.push(a[c].children[e]);"A"===a[c].tagName&&b.push(a[c])}return b}(),p=function(a){(a.href&&"#"===a.href.slice(-1)||a.parentNode&&a.parentNode.href&&"#"===a.parentNode.href.slice(-1))&&this.preventDefault()},d=function(){var b=a.open?y:D;
b(e,"click",k);b(e,"keydown",x);b(e,"keyup",l);b(e,"focus",k,!0)},k=function(b){var c=b.target,e=c&&(c.getAttribute("data-toggle")||c.parentNode&&"getAttribute"in c.parentNode&&c.parentNode.getAttribute("data-toggle"));if("focus"!==b.type||c!==a&&c!==h&&!h.contains(c))if(c!==h&&!h.contains(c)||!f.persist&&!e)g=c===a||a.contains(c)?a:null,A(),p.call(b,c)},r=function(b){g=a;H();p.call(b,b.target)},x=function(a){var b=a.which||a.keyCode;38!==b&&40!==b||a.preventDefault()},l=function(b){b=b.which||b.keyCode;
var c=e.activeElement,d=m.indexOf(c),l=c===a,n=h.contains(c);if((c=c.parentNode===h||c.parentNode.parentNode===h)||l){do if(d=l?0:38===b?1<d?d-1:0:40===b?d<m.length-1?d+1:d:d,0===d||d===m.length-1)break;while(!m[d].offsetHeight);m[d]&&J(m[d])}(m.length&&c||!m.length&&(n||l)||!n)&&a.open&&27===b&&(f.toggle(),g=null)},H=function(){w.call(b,"show","dropdown",g);z(h,"show");z(b,"show");a.setAttribute("aria-expanded",!0);w.call(b,"shown","dropdown",g);a.open=!0;D(a,"click",r);setTimeout(function(){J(h.getElementsByTagName("INPUT")[0]||
a);d()},1)},A=function(){w.call(b,"hide","dropdown",g);u(h,"show");u(b,"show");a.setAttribute("aria-expanded",!1);w.call(b,"hidden","dropdown",g);a.open=!1;d();J(a);setTimeout(function(){y(a,"click",r)},1)};a.open=!1;this.toggle=function(){n(b,"show")&&a.open?A():H()};"Dropdown"in a||(!1 in h&&h.setAttribute("tabindex","0"),y(a,"click",r));a.Dropdown=f};v.push(["Dropdown",aa,'[data-toggle="dropdown"]']);var ba=function(a,c){a=q(a);var f=a.getAttribute("data-target")||a.getAttribute("href");f=q(f);
var b=n(a,"modal")?a:f;n(a,"modal")&&(a=null);if(b){c=c||{};this.keyboard=!1===c.keyboard||"false"===b.getAttribute("data-keyboard")?!1:!0;this.backdrop="static"===c.backdrop||"static"===b.getAttribute("data-backdrop")?"static":!0;this.backdrop=!1===c.backdrop||"false"===b.getAttribute("data-backdrop")?!1:this.backdrop;this.animation=n(b,"fade")?!0:!1;this.content=c.content;b.isAnimating=!1;var g=this,h=null,m,p,d,k,r,E=F(B,"fixed-top").concat(F(B,"fixed-bottom")),l=function(){var a=x.getComputedStyle(e.body);
a=parseInt(a.paddingRight,10);if(m&&(e.body.style.paddingRight=a+p+"px",b.style.paddingRight=p+"px",E.length))for(var c=0;c<E.length;c++)a=x.getComputedStyle(E[c]).paddingRight,E[c].style.paddingRight=parseInt(a)+p+"px"},H=function(){var a=e.body.clientWidth,b=B.getBoundingClientRect();m=a<(x.innerWidth||b.right-Math.abs(b.left));a=e.createElement("div");a.className="modal-scrollbar-measure";e.body.appendChild(a);b=a.offsetWidth-a.clientWidth;e.body.removeChild(a);p=b},A=function(){var a=e.createElement("div");
d=q(".modal-backdrop");null===d&&(a.setAttribute("class","modal-backdrop"+(g.animation?" fade":"")),d=a,e.body.appendChild(d));S=1},t=function(){(d=q(".modal-backdrop"))&&null!==d&&"object"===typeof d&&(S=0,e.body.removeChild(d),d=null)},L=function(){J(b);b.isAnimating=!1;w.call(b,"shown","modal",h);y(x,"resize",g.update,T);y(b,"click",M);y(e,"keydown",N)},v=function(){b.style.display="";a&&J(a);w.call(b,"hidden","modal");if(!F(e,"modal show")[0]){e.body.style.paddingRight="";b.style.paddingRight=
"";if(E.length)for(var c=0;c<E.length;c++)E[c].style.paddingRight="";u(e.body,"modal-open");d&&n(d,"fade")?(u(d,"show"),G(d,t)):t();D(x,"resize",g.update,T);D(b,"click",M);D(e,"keydown",N)}b.isAnimating=!1};c=function(c){if(!b.isAnimating){var e=c.target;e=e.hasAttribute("data-target")||e.hasAttribute("href")?e:e.parentNode;e!==a||n(b,"show")||(h=b.modalTrigger=a,g.show(),c.preventDefault())}};var N=function(a){b.isAnimating||g.keyboard&&27==a.which&&n(b,"show")&&g.hide()},M=function(a){if(!b.isAnimating){var c=
a.target;n(b,"show")&&("modal"===c.parentNode.getAttribute("data-dismiss")||"modal"===c.getAttribute("data-dismiss")||c===b&&"static"!==g.backdrop)&&(g.hide(),h=null,a.preventDefault())}};this.toggle=function(){n(b,"show")?this.hide():this.show()};this.show=function(){n(b,"show")||b.isAnimating||(clearTimeout(r),r=setTimeout(function(){b.isAnimating=!0;w.call(b,"show","modal",h);var a=F(e,"modal show")[0];a&&a!==b&&("modalTrigger"in a&&a.modalTrigger.Modal.hide(),"Modal"in a&&a.Modal.hide());g.backdrop&&
(S||d||A());d&&!n(d,"show")&&(d.offsetWidth,k=U(d),z(d,"show"));setTimeout(function(){b.style.display="block";H();l();z(e.body,"modal-open");z(b,"show");b.setAttribute("aria-hidden",!1);n(b,"fade")?G(b,L):L()},C&&d&&k?k:1)},1))};this.hide=function(){!b.isAnimating&&n(b,"show")&&(clearTimeout(r),r=setTimeout(function(){b.isAnimating=!0;w.call(b,"hide","modal");k=(d=q(".modal-backdrop"))&&U(d);u(b,"show");b.setAttribute("aria-hidden",!0);setTimeout(function(){n(b,"fade")?G(b,v):v()},C&&d&&k?k:2)},2))};
this.setContent=function(a){q(".modal-content",b).innerHTML=a};this.update=function(){n(b,"show")&&(H(),l())};!a||"Modal"in a||y(a,"click",c);g.content&&g.setContent(g.content);a?(a.Modal=g,b.modalTrigger=a):b.Modal=g}};v.push(["Modal",ba,'[data-toggle="modal"]']);var ca=function(a,c){a=q(a);c=c||{};var f=a.getAttribute("data-trigger"),b=a.getAttribute("data-animation"),g=a.getAttribute("data-placement"),h=a.getAttribute("data-dismissible"),m=a.getAttribute("data-delay"),p=a.getAttribute("data-container"),
d=q(c.container);p=q(p);var k=I(a,".modal"),r=I(a,".fixed-top"),E=I(a,".fixed-bottom");this.template=c.template?c.template:null;this.trigger=c.trigger?c.trigger:f||"hover";this.animation=c.animation&&"fade"!==c.animation?c.animation:b||"fade";this.placement=c.placement?c.placement:g||"top";this.delay=parseInt(c.delay||m)||200;this.dismissible=c.dismissible||"true"===h?!0:!1;this.container=d?d:p?p:r?r:E?E:k?k:e.body;var l=this,H=c.title||a.getAttribute("data-title")||null,A=c.content||a.getAttribute("data-content")||
null;if(A||this.template){var t=null,v=0,F=this.placement,N=function(a){null!==t&&a.target===q(".close",t)&&l.hide()},M=function(b){"click"!=l.trigger&&"focus"!=l.trigger||l.dismissible||b(a,"blur",l.hide);l.dismissible&&b(e,"click",N);b(x,"resize",l.hide,T)},J=function(){M(y);w.call(a,"shown","popover")},C=function(){M(D);l.container.removeChild(t);t=v=null;w.call(a,"hidden","popover")};this.toggle=function(){null===t?l.show():l.hide()};this.show=function(){clearTimeout(v);v=setTimeout(function(){if(null===
t){F=l.placement;H=c.title||a.getAttribute("data-title");A=(A=c.content||a.getAttribute("data-content"))?A.trim():null;t=e.createElement("div");var b=e.createElement("div");b.setAttribute("class","arrow");t.appendChild(b);null!==A&&null===l.template?(t.setAttribute("role","tooltip"),null!==H&&(b=e.createElement("h3"),b.setAttribute("class","popover-header"),b.innerHTML=l.dismissible?H+'<button type="button" class="close">\u00d7</button>':H,t.appendChild(b)),b=e.createElement("div"),b.setAttribute("class",
"popover-body"),b.innerHTML=l.dismissible&&null===H?A+'<button type="button" class="close">\u00d7</button>':A,t.appendChild(b)):(b=e.createElement("div"),l.template=l.template.trim(),b.innerHTML=l.template,t.innerHTML=b.firstChild.innerHTML);l.container.appendChild(t);t.style.display="block";t.setAttribute("class","popover bs-popover-"+F+" "+l.animation);b=t;var d=F,f=l.container,g=b.offsetWidth,h=b.offsetHeight,m=B.clientWidth||e.body.clientWidth,r=B.clientHeight||e.body.clientHeight,k=a.getBoundingClientRect();
f=f===e.body?{y:x.pageYOffset||B.scrollTop,x:x.pageXOffset||B.scrollLeft}:{x:f.offsetLeft+f.scrollLeft,y:f.offsetTop+f.scrollTop};var p=k.right-k.left,u=k.bottom-k.top,v=n(b,"popover"),y=q(".arrow",b),E=0>k.top+u/2-h/2,N=0>k.left+p/2-g/2,M=k.left+g/2+p/2>=m,D=k.top+h/2+u/2>=r;var K=0>k.top-h;var C=0>k.left-g;r=k.top+h+u>=r;var I=k.left+g+p>=m;d=("left"===d||"right"===d)&&C&&I?"top":d;d="top"===d&&K?"bottom":d;d="bottom"===d&&r?"top":d;d="left"===d&&C?"right":d;d="right"===d&&I?"left":d;-1===b.className.indexOf(d)&&
(b.className=b.className.replace(fa,d));K=y.offsetWidth;C=y.offsetHeight;if("left"===d||"right"===d){var L="left"===d?k.left+f.x-g-(v?K:0):k.left+f.x+p;if(E){var O=k.top+f.y;var P=u/2-K}else D?(O=k.top+f.y-h+u,P=h-u/2-K):(O=k.top+f.y-h/2+u/2,P=h/2-(v?.9*C:C/2))}else if("top"===d||"bottom"===d)if(O="top"===d?k.top+f.y-h-(v?C:0):k.top+f.y+u,N){L=0;var Q=k.left+p/2-K}else M?(L=m-1.01*g,Q=g-(m-k.left)+p/2-K/2):(L=k.left+f.x-g/2+p/2,Q=g/2-K/2);b.style.top=O+"px";b.style.left=L+"px";P&&(y.style.top=P+"px");
Q&&(y.style.left=Q+"px");!n(t,"show")&&z(t,"show");w.call(a,"show","popover");l.animation?G(t,J):J()}},20)};this.hide=function(){clearTimeout(v);v=setTimeout(function(){t&&null!==t&&n(t,"show")&&(w.call(a,"hide","popover"),u(t,"show"),l.animation?G(t,C):C())},l.delay)};"Popover"in a||("hover"===l.trigger?(y(a,V[0],l.show),l.dismissible||y(a,V[1],l.hide)):"click"!=l.trigger&&"focus"!=l.trigger||y(a,l.trigger,l.toggle));a.Popover=l}};v.push(["Popover",ca,'[data-toggle="popover"]']);var da=function(a,
c){a=q(a);var e=a.getAttribute("data-height");c=c||{};this.height=C?c.height||"true"===e:!1;var b=this,g,h=I(a,".nav"),m=!1,p=h&&q(".dropdown-toggle",h),d,k,r,v,l,x,A=function(){m.style.height="";u(m,"collapsing");h.isAnimating=!1},t=function(){m?l?A():setTimeout(function(){m.style.height=x+"px";m.offsetWidth;G(m,A)},50):h.isAnimating=!1;w.call(g,"shown","tab",d)},B=function(){m&&(k.style["float"]="left",r.style["float"]="left",v=k.scrollHeight);z(r,"active");w.call(g,"show","tab",d);u(k,"active");
w.call(d,"hidden","tab",g);m&&(x=r.scrollHeight,l=x===v,z(m,"collapsing"),m.style.height=v+"px",m.offsetHeight,k.style["float"]="",r.style["float"]="");n(r,"fade")?setTimeout(function(){z(r,"show");G(r,t)},20):t()};if(h){h.isAnimating=!1;var D=function(){var a=F(h,"active"),b;1!==a.length||n(a[0].parentNode,"dropdown")?1<a.length&&(b=a[a.length-1]):b=a[0];return b};c=function(a){a.preventDefault();g=a.currentTarget;h.isAnimating||n(g,"active")||b.show()};this.show=function(){g=g||a;r=q(g.getAttribute("href"));
d=D();k=q(D().getAttribute("href"));h.isAnimating=!0;u(d,"active");d.setAttribute("aria-selected","false");z(g,"active");g.setAttribute("aria-selected","true");p&&(n(a.parentNode,"dropdown-menu")?n(p,"active")||z(p,"active"):n(p,"active")&&u(p,"active"));w.call(d,"hide","tab",g);n(k,"fade")?(u(k,"show"),G(k,B)):B()};"Tab"in a||y(a,"click",c);b.height&&(m=q(D().getAttribute("href")).parentNode);a.Tab=b}};v.push(["Tab",da,'[data-toggle="tab"]']);var ea=R.initCallback=function(a){a=a||e;for(var c=0,
f=v.length;c<f;c++)for(var b=v[c][1],g=a.querySelectorAll(v[c][2]),h=0,m=g.length;h<m;h++)new b(g[h])};e.body?ea():y(e,"DOMContentLoaded",function(){ea()});return{Alert:X,Button:Y,Collapse:Z,Dropdown:aa,Modal:ba,Popover:ca,Tab:da}});
var $jscomp=$jscomp||{};$jscomp.scope={};$jscomp.ASSUME_ES5=!1;$jscomp.ASSUME_NO_NATIVE_MAP=!1;$jscomp.ASSUME_NO_NATIVE_SET=!1;$jscomp.defineProperty=$jscomp.ASSUME_ES5||"function"==typeof Object.defineProperties?Object.defineProperty:function(a,b,c){a!=Array.prototype&&a!=Object.prototype&&(a[b]=c.value)};$jscomp.getGlobal=function(a){return"undefined"!=typeof window&&window===a?a:"undefined"!=typeof global&&null!=global?global:a};$jscomp.global=$jscomp.getGlobal(this);$jscomp.SYMBOL_PREFIX="jscomp_symbol_";
$jscomp.initSymbol=function(){$jscomp.initSymbol=function(){};$jscomp.global.Symbol||($jscomp.global.Symbol=$jscomp.Symbol)};$jscomp.Symbol=function(){var a=0;return function(b){return $jscomp.SYMBOL_PREFIX+(b||"")+a++}}();
$jscomp.initSymbolIterator=function(){$jscomp.initSymbol();var a=$jscomp.global.Symbol.iterator;a||(a=$jscomp.global.Symbol.iterator=$jscomp.global.Symbol("iterator"));"function"!=typeof Array.prototype[a]&&$jscomp.defineProperty(Array.prototype,a,{configurable:!0,writable:!0,value:function(){return $jscomp.arrayIterator(this)}});$jscomp.initSymbolIterator=function(){}};$jscomp.arrayIterator=function(a){var b=0;return $jscomp.iteratorPrototype(function(){return b<a.length?{done:!1,value:a[b++]}:{done:!0}})};
$jscomp.iteratorPrototype=function(a){$jscomp.initSymbolIterator();a={next:a};a[$jscomp.global.Symbol.iterator]=function(){return this};return a};$jscomp.makeIterator=function(a){$jscomp.initSymbolIterator();$jscomp.initSymbol();$jscomp.initSymbolIterator();var b=a[Symbol.iterator];return b?b.call(a):$jscomp.arrayIterator(a)};
$jscomp.polyfill=function(a,b,c,d){if(b){c=$jscomp.global;a=a.split(".");for(d=0;d<a.length-1;d++){var f=a[d];f in c||(c[f]={});c=c[f]}a=a[a.length-1];d=c[a];b=b(d);b!=d&&null!=b&&$jscomp.defineProperty(c,a,{configurable:!0,writable:!0,value:b})}};$jscomp.FORCE_POLYFILL_PROMISE=!1;
$jscomp.polyfill("Promise",function(a){function b(){this.batch_=null}function c(a){return a instanceof f?a:new f(function(b,c){b(a)})}if(a&&!$jscomp.FORCE_POLYFILL_PROMISE)return a;b.prototype.asyncExecute=function(a){null==this.batch_&&(this.batch_=[],this.asyncExecuteBatch_());this.batch_.push(a);return this};b.prototype.asyncExecuteBatch_=function(){var a=this;this.asyncExecuteFunction(function(){a.executeBatch_()})};var d=$jscomp.global.setTimeout;b.prototype.asyncExecuteFunction=function(a){d(a,
0)};b.prototype.executeBatch_=function(){for(;this.batch_&&this.batch_.length;){var a=this.batch_;this.batch_=[];for(var b=0;b<a.length;++b){var c=a[b];a[b]=null;try{c()}catch(m){this.asyncThrow_(m)}}}this.batch_=null};b.prototype.asyncThrow_=function(a){this.asyncExecuteFunction(function(){throw a;})};var f=function(a){this.state_=0;this.result_=void 0;this.onSettledCallbacks_=[];var b=this.createResolveAndReject_();try{a(b.resolve,b.reject)}catch(k){b.reject(k)}};f.prototype.createResolveAndReject_=
function(){function a(a){return function(d){c||(c=!0,a.call(b,d))}}var b=this,c=!1;return{resolve:a(this.resolveTo_),reject:a(this.reject_)}};f.prototype.resolveTo_=function(a){if(a===this)this.reject_(new TypeError("A Promise cannot resolve to itself"));else if(a instanceof f)this.settleSameAsPromise_(a);else{a:switch(typeof a){case "object":var b=null!=a;break a;case "function":b=!0;break a;default:b=!1}b?this.resolveToNonPromiseObj_(a):this.fulfill_(a)}};f.prototype.resolveToNonPromiseObj_=function(a){var b=
void 0;try{b=a.then}catch(k){this.reject_(k);return}"function"==typeof b?this.settleSameAsThenable_(b,a):this.fulfill_(a)};f.prototype.reject_=function(a){this.settle_(2,a)};f.prototype.fulfill_=function(a){this.settle_(1,a)};f.prototype.settle_=function(a,b){if(0!=this.state_)throw Error("Cannot settle("+a+", "+b+"): Promise already settled in state"+this.state_);this.state_=a;this.result_=b;this.executeOnSettledCallbacks_()};f.prototype.executeOnSettledCallbacks_=function(){if(null!=this.onSettledCallbacks_){for(var a=
0;a<this.onSettledCallbacks_.length;++a)g.asyncExecute(this.onSettledCallbacks_[a]);this.onSettledCallbacks_=null}};var g=new b;f.prototype.settleSameAsPromise_=function(a){var b=this.createResolveAndReject_();a.callWhenSettled_(b.resolve,b.reject)};f.prototype.settleSameAsThenable_=function(a,b){var c=this.createResolveAndReject_();try{a.call(b,c.resolve,c.reject)}catch(m){c.reject(m)}};f.prototype.then=function(a,b){function c(a,b){return"function"==typeof a?function(b){try{d(a(b))}catch(q){g(q)}}:
b}var d,g,h=new f(function(a,b){d=a;g=b});this.callWhenSettled_(c(a,d),c(b,g));return h};f.prototype.catch=function(a){return this.then(void 0,a)};f.prototype.callWhenSettled_=function(a,b){function c(){switch(d.state_){case 1:a(d.result_);break;case 2:b(d.result_);break;default:throw Error("Unexpected state: "+d.state_);}}var d=this;null==this.onSettledCallbacks_?g.asyncExecute(c):this.onSettledCallbacks_.push(c)};f.resolve=c;f.reject=function(a){return new f(function(b,c){c(a)})};f.race=function(a){return new f(function(b,
d){for(var f=$jscomp.makeIterator(a),g=f.next();!g.done;g=f.next())c(g.value).callWhenSettled_(b,d)})};f.all=function(a){var b=$jscomp.makeIterator(a),d=b.next();return d.done?c([]):new f(function(a,f){function g(b){return function(c){h[b]=c;l--;0==l&&a(h)}}var h=[],l=0;do h.push(void 0),l++,c(d.value).callWhenSettled_(g(h.length-1),f),d=b.next();while(!d.done)})};return f},"es6","es3");$jscomp.underscoreProtoCanBeSet=function(){var a={a:!0},b={};try{return b.__proto__=a,b.a}catch(c){}return!1};
$jscomp.setPrototypeOf="function"==typeof Object.setPrototypeOf?Object.setPrototypeOf:$jscomp.underscoreProtoCanBeSet()?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null;$jscomp.generator={};$jscomp.generator.ensureIteratorResultIsObject_=function(a){if(!(a instanceof Object))throw new TypeError("Iterator result "+a+" is not an object");};
$jscomp.generator.Context=function(){this.isRunning_=!1;this.yieldAllIterator_=null;this.yieldResult=void 0;this.nextAddress=1;this.finallyAddress_=this.catchAddress_=0;this.finallyContexts_=this.abruptCompletion_=null};$jscomp.generator.Context.prototype.start_=function(){if(this.isRunning_)throw new TypeError("Generator is already running");this.isRunning_=!0};$jscomp.generator.Context.prototype.stop_=function(){this.isRunning_=!1};
$jscomp.generator.Context.prototype.jumpToErrorHandler_=function(){this.nextAddress=this.catchAddress_||this.finallyAddress_};$jscomp.generator.Context.prototype.next_=function(a){this.yieldResult=a};$jscomp.generator.Context.prototype.throw_=function(a){this.abruptCompletion_={exception:a,isException:!0};this.jumpToErrorHandler_()};$jscomp.generator.Context.prototype.return=function(a){this.abruptCompletion_={return:a};this.nextAddress=this.finallyAddress_};
$jscomp.generator.Context.prototype.jumpThroughFinallyBlocks=function(a){this.abruptCompletion_={jumpTo:a};this.nextAddress=this.finallyAddress_};$jscomp.generator.Context.prototype.yield=function(a,b){this.nextAddress=b;return{value:a}};$jscomp.generator.Context.prototype.yieldAll=function(a,b){a=$jscomp.makeIterator(a);var c=a.next();$jscomp.generator.ensureIteratorResultIsObject_(c);if(c.done)this.yieldResult=c.value,this.nextAddress=b;else return this.yieldAllIterator_=a,this.yield(c.value,b)};
$jscomp.generator.Context.prototype.jumpTo=function(a){this.nextAddress=a};$jscomp.generator.Context.prototype.jumpToEnd=function(){this.nextAddress=0};$jscomp.generator.Context.prototype.setCatchFinallyBlocks=function(a,b){this.catchAddress_=a;void 0!=b&&(this.finallyAddress_=b)};$jscomp.generator.Context.prototype.setFinallyBlock=function(a){this.catchAddress_=0;this.finallyAddress_=a||0};$jscomp.generator.Context.prototype.leaveTryBlock=function(a,b){this.nextAddress=a;this.catchAddress_=b||0};
$jscomp.generator.Context.prototype.enterCatchBlock=function(a){this.catchAddress_=a||0;a=this.abruptCompletion_.exception;this.abruptCompletion_=null;return a};$jscomp.generator.Context.prototype.enterFinallyBlock=function(a,b,c){c?this.finallyContexts_[c]=this.abruptCompletion_:this.finallyContexts_=[this.abruptCompletion_];this.catchAddress_=a||0;this.finallyAddress_=b||0};
$jscomp.generator.Context.prototype.leaveFinallyBlock=function(a,b){b=this.finallyContexts_.splice(b||0)[0];if(b=this.abruptCompletion_=this.abruptCompletion_||b){if(b.isException)return this.jumpToErrorHandler_();void 0!=b.jumpTo&&this.finallyAddress_<b.jumpTo?(this.nextAddress=b.jumpTo,this.abruptCompletion_=null):this.nextAddress=this.finallyAddress_}else this.nextAddress=a};$jscomp.generator.Context.prototype.forIn=function(a){return new $jscomp.generator.Context.PropertyIterator(a)};
$jscomp.generator.Context.PropertyIterator=function(a){this.object_=a;this.properties_=[];for(var b in a)this.properties_.push(b);this.properties_.reverse()};$jscomp.generator.Context.PropertyIterator.prototype.getNext=function(){for(;0<this.properties_.length;){var a=this.properties_.pop();if(a in this.object_)return a}return null};$jscomp.generator.Engine_=function(a){this.context_=new $jscomp.generator.Context;this.program_=a};
$jscomp.generator.Engine_.prototype.next_=function(a){this.context_.start_();if(this.context_.yieldAllIterator_)return this.yieldAllStep_(this.context_.yieldAllIterator_.next,a,this.context_.next_);this.context_.next_(a);return this.nextStep_()};
$jscomp.generator.Engine_.prototype.return_=function(a){this.context_.start_();var b=this.context_.yieldAllIterator_;if(b)return this.yieldAllStep_("return"in b?b["return"]:function(a){return{value:a,done:!0}},a,this.context_.return);this.context_.return(a);return this.nextStep_()};
$jscomp.generator.Engine_.prototype.throw_=function(a){this.context_.start_();if(this.context_.yieldAllIterator_)return this.yieldAllStep_(this.context_.yieldAllIterator_["throw"],a,this.context_.next_);this.context_.throw_(a);return this.nextStep_()};
$jscomp.generator.Engine_.prototype.yieldAllStep_=function(a,b,c){try{var d=a.call(this.context_.yieldAllIterator_,b);$jscomp.generator.ensureIteratorResultIsObject_(d);if(!d.done)return this.context_.stop_(),d;var f=d.value}catch(g){return this.context_.yieldAllIterator_=null,this.context_.throw_(g),this.nextStep_()}this.context_.yieldAllIterator_=null;c.call(this.context_,f);return this.nextStep_()};
$jscomp.generator.Engine_.prototype.nextStep_=function(){for(;this.context_.nextAddress;)try{var a=this.program_(this.context_);if(a)return this.context_.stop_(),{value:a.value,done:!1}}catch(b){this.context_.yieldResult=void 0,this.context_.throw_(b)}this.context_.stop_();if(this.context_.abruptCompletion_){a=this.context_.abruptCompletion_;this.context_.abruptCompletion_=null;if(a.isException)throw a.exception;return{value:a.return,done:!0}}return{value:void 0,done:!0}};
$jscomp.generator.Generator_=function(a){this.next=function(b){return a.next_(b)};this.throw=function(b){return a.throw_(b)};this.return=function(b){return a.return_(b)};$jscomp.initSymbolIterator();$jscomp.initSymbol();$jscomp.initSymbolIterator();this[Symbol.iterator]=function(){return this}};$jscomp.generator.createGenerator=function(a,b){b=new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(b));$jscomp.setPrototypeOf&&$jscomp.setPrototypeOf(b,a.prototype);return b};
$jscomp.asyncExecutePromiseGenerator=function(a){function b(b){return a.next(b)}function c(b){return a.throw(b)}return new Promise(function(d,f){function g(a){a.done?d(a.value):Promise.resolve(a.value).then(b,c).then(g,f)}g(a.next())})};$jscomp.asyncExecutePromiseGeneratorFunction=function(a){return $jscomp.asyncExecutePromiseGenerator(a())};$jscomp.asyncExecutePromiseGeneratorProgram=function(a){return $jscomp.asyncExecutePromiseGenerator(new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(a)))};
$jscomp.arrayFromIterator=function(a){for(var b,c=[];!(b=a.next()).done;)c.push(b.value);return c};$jscomp.arrayFromIterable=function(a){return a instanceof Array?a:$jscomp.arrayFromIterator($jscomp.makeIterator(a))};$jscomp.polyfill("Object.is",function(a){return a?a:function(a,c){return a===c?0!==a||1/a===1/c:a!==a&&c!==c}},"es6","es3");
$jscomp.polyfill("Array.prototype.includes",function(a){return a?a:function(a,c){var b=this;b instanceof String&&(b=String(b));var f=b.length;c=c||0;for(0>c&&(c=Math.max(c+f,0));c<f;c++){var g=b[c];if(g===a||Object.is(g,a))return!0}return!1}},"es7","es3");
$jscomp.checkStringArgs=function(a,b,c){if(null==a)throw new TypeError("The 'this' value for String.prototype."+c+" must not be null or undefined");if(b instanceof RegExp)throw new TypeError("First argument to String.prototype."+c+" must not be a regular expression");return a+""};$jscomp.polyfill("String.prototype.includes",function(a){return a?a:function(a,c){return-1!==$jscomp.checkStringArgs(this,a,"includes").indexOf(a,c||0)}},"es6","es3");
$jscomp.polyfill("String.prototype.repeat",function(a){return a?a:function(a){var b=$jscomp.checkStringArgs(this,null,"repeat");if(0>a||1342177279<a)throw new RangeError("Invalid count value");a|=0;for(var d="";a;)if(a&1&&(d+=b),a>>>=1)b+=b;return d}},"es6","es3");$jscomp.owns=function(a,b){return Object.prototype.hasOwnProperty.call(a,b)};
$jscomp.assign="function"==typeof Object.assign?Object.assign:function(a,b){for(var c=1;c<arguments.length;c++){var d=arguments[c];if(d)for(var f in d)$jscomp.owns(d,f)&&(a[f]=d[f])}return a};$jscomp.polyfill("Object.assign",function(a){return a||$jscomp.assign},"es6","es3");
$jscomp.iteratorFromArray=function(a,b){$jscomp.initSymbolIterator();a instanceof String&&(a+="");var c=0,d={next:function(){if(c<a.length){var f=c++;return{value:b(f,a[f]),done:!1}}d.next=function(){return{done:!0,value:void 0}};return d.next()}};d[Symbol.iterator]=function(){return d};return d};$jscomp.polyfill("Array.prototype.values",function(a){return a?a:function(){return $jscomp.iteratorFromArray(this,function(a,c){return c})}},"es8","es3");
var socket=null,lastSong="",lastSongObj={},lastState,currentSong={},playstate="",settingsLock=!1,settingsParsed="false",settingsNew={},settings={loglevel:2},alertTimeout=null,progressTimer=null,deferredPrompt,dragEl,playlistEl,websocketConnected=!1,websocketTimer=null,appInited=!1,subdir="",uiEnabled=!0,locale=navigator.language||navigator.userLanguage,app={apps:{Playback:{state:"0/-/-/",scrollPos:0},Queue:{active:"Current",tabs:{Current:{state:"0/any/-/",scrollPos:0},LastPlayed:{state:"0/any/-/",
scrollPos:0}}},Browse:{active:"Database",tabs:{Filesystem:{state:"0/-/-/",scrollPos:0},Playlists:{active:"All",views:{All:{state:"0/-/-/",scrollPos:0},Detail:{state:"0/-/-/",scrollPos:0}}},Database:{active:"AlbumArtist",views:{}}}},Search:{state:"0/any/-/",scrollPos:0}},current:{app:"Playback",tab:void 0,view:void 0,page:0,filter:"",search:"",sort:"",scrollPos:0},last:{app:void 0,tab:void 0,view:void 0,filter:"",search:"",sort:"",scrollPos:0}},domCache={};domCache.navbarBottomBtns=document.getElementById("navbar-bottom").getElementsByTagName("div");
domCache.navbarBottomBtnsLen=domCache.navbarBottomBtns.length;domCache.cardHeaderBrowse=document.getElementById("cardHeaderBrowse").getElementsByTagName("a");domCache.cardHeaderBrowseLen=domCache.cardHeaderBrowse.length;domCache.cardHeaderQueue=document.getElementById("cardHeaderQueue").getElementsByTagName("a");domCache.cardHeaderQueueLen=domCache.cardHeaderQueue.length;domCache.counter=document.getElementById("counter");domCache.volumePrct=document.getElementById("volumePrct");
domCache.volumeControl=document.getElementById("volumeControl");domCache.volumeMenu=document.getElementById("volumeMenu");domCache.btnsPlay=document.getElementsByClassName("btnPlay");domCache.btnsPlayLen=domCache.btnsPlay.length;domCache.btnPrev=document.getElementById("btnPrev");domCache.btnNext=document.getElementById("btnNext");domCache.progressBar=document.getElementById("progressBar");domCache.volumeBar=document.getElementById("volumeBar");domCache.outputs=document.getElementById("outputs");
domCache.btnAdd=document.getElementById("nav-add2homescreen");domCache.currentCover=document.getElementById("currentCover");domCache.currentTitle=document.getElementById("currentTitle");domCache.btnVoteUp=document.getElementById("btnVoteUp");domCache.btnVoteDown=document.getElementById("btnVoteDown");domCache.badgeQueueItems=document.getElementById("badgeQueueItems");domCache.searchstr=document.getElementById("searchstr");domCache.searchCrumb=document.getElementById("searchCrumb");
var modalConnection=new Modal(document.getElementById("modalConnection")),modalSettings=new Modal(document.getElementById("modalSettings")),modalAbout=new Modal(document.getElementById("modalAbout")),modalSaveQueue=new Modal(document.getElementById("modalSaveQueue")),modalAddToQueue=new Modal(document.getElementById("modalAddToQueue")),modalSongDetails=new Modal(document.getElementById("modalSongDetails")),modalAddToPlaylist=new Modal(document.getElementById("modalAddToPlaylist")),modalRenamePlaylist=
new Modal(document.getElementById("modalRenamePlaylist")),modalUpdateDB=new Modal(document.getElementById("modalUpdateDB")),modalSaveSmartPlaylist=new Modal(document.getElementById("modalSaveSmartPlaylist")),modalDeletePlaylist=new Modal(document.getElementById("modalDeletePlaylist")),modalSaveBookmark=new Modal(document.getElementById("modalSaveBookmark")),dropdownMainMenu,dropdownVolumeMenu=new Dropdown(document.getElementById("volumeMenu")),dropdownBookmarks=new Dropdown(document.getElementById("BrowseFilesystemBookmark")),
dropdownLocalPlayer=new Dropdown(document.getElementById("localPlaybackMenu")),collapseDBupdate=new Collapse(document.getElementById("navDBupdate")),collapseSyscmds=new Collapse(document.getElementById("navSyscmds"));
function appPrepare(a){if(app.current.app!=app.last.app||app.current.tab!=app.last.tab||app.current.view!=app.last.view){for(var b=0;b<domCache.navbarBottomBtnsLen;b++)domCache.navbarBottomBtns[b].classList.remove("active");document.getElementById("cardPlayback").classList.add("hide");document.getElementById("cardQueue").classList.add("hide");document.getElementById("cardBrowse").classList.add("hide");document.getElementById("cardSearch").classList.add("hide");for(b=0;b<domCache.cardHeaderBrowseLen;b++)domCache.cardHeaderBrowse[b].classList.remove("active");
for(b=0;b<domCache.cardHeaderQueueLen;b++)domCache.cardHeaderQueue[b].classList.remove("active");document.getElementById("cardQueueCurrent").classList.add("hide");document.getElementById("cardQueueLastPlayed").classList.add("hide");document.getElementById("cardBrowsePlaylists").classList.add("hide");document.getElementById("cardBrowseDatabase").classList.add("hide");document.getElementById("cardBrowseFilesystem").classList.add("hide");document.getElementById("card"+app.current.app).classList.remove("hide");
document.getElementById("nav"+app.current.app)&&document.getElementById("nav"+app.current.app).classList.add("active");void 0!=app.current.tab&&(document.getElementById("card"+app.current.app+app.current.tab).classList.remove("hide"),document.getElementById("card"+app.current.app+"Nav"+app.current.tab).classList.add("active"));scrollTo(a)}(a=document.getElementById(app.current.app+(void 0==app.current.tab?"":app.current.tab)+(void 0==app.current.view?"":app.current.view)+"List"))&&a.classList.add("opacity05")}
function appGoto(a,b,c,d){var f=document.body.scrollTop?document.body.scrollTop:document.documentElement.scrollTop;void 0!=app.apps[app.current.app].scrollPos?app.apps[app.current.app].scrollPos=f:void 0!=app.apps[app.current.app].tabs[app.current.tab].scrollPos?app.apps[app.current.app].tabs[app.current.tab].scrollPos=f:void 0!=app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos&&(app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos=f);app.apps[a].tabs?
(void 0==b&&(b=app.apps[a].active),app.apps[a].tabs[b].views?(void 0==c&&(c=app.apps[a].tabs[b].active),a="/"+a+"/"+b+"/"+c+"!"+(void 0==d?app.apps[a].tabs[b].views[c].state:d)):a="/"+a+"/"+b+"!"+(void 0==d?app.apps[a].tabs[b].state:d)):a="/"+a+"!"+(void 0==d?app.apps[a].state:d);location.hash=a}
function appRoute(){if("false"==settingsParsed)appInitStart();else{var a;if(a=decodeURI(location.hash).match(/^#\/(\w+)\/?(\w+)?\/?(\w+)?!((\d+)\/([^\/]+)\/([^\/]+)\/(.*))$/)){app.current.app=a[1];app.current.tab=a[2];app.current.view=a[3];app.apps[app.current.app].state?(app.apps[app.current.app].state=a[4],app.current.scrollPos=app.apps[app.current.app].scrollPos):app.apps[app.current.app].tabs[app.current.tab].state?(app.apps[app.current.app].tabs[app.current.tab].state=a[4],app.apps[app.current.app].active=
app.current.tab,app.current.scrollPos=app.apps[app.current.app].tabs[app.current.tab].scrollPos):app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].state&&(app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].state=a[4],app.apps[app.current.app].active=app.current.tab,app.apps[app.current.app].tabs[app.current.tab].active=app.current.view,app.current.scrollPos=app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos);app.current.page=
parseInt(a[5]);app.current.filter=a[6];app.current.sort=a[7];app.current.search=a[8];appPrepare(app.current.scrollPos);if("Playback"==app.current.app)sendAPI({cmd:"MPD_API_PLAYER_CURRENT_SONG"},songChange);else if("Queue"==app.current.app&&"Current"==app.current.tab)selectTag("searchqueuetags","searchqueuetagsdesc",app.current.filter),getQueue();else if("Queue"==app.current.app&&"LastPlayed"==app.current.tab)sendAPI({cmd:"MPD_API_QUEUE_LAST_PLAYED",data:{offset:app.current.page,cols:settings.colsQueueLastPlayed}},
parseLastPlayed);else if("Browse"==app.current.app&&"Playlists"==app.current.tab&&"All"==app.current.view)sendAPI({cmd:"MPD_API_PLAYLIST_LIST",data:{offset:app.current.page,filter:app.current.filter}},parsePlaylists),doSetFilterLetter("BrowsePlaylistsFilter");else if("Browse"==app.current.app&&"Playlists"==app.current.tab&&"Detail"==app.current.view)sendAPI({cmd:"MPD_API_PLAYLIST_CONTENT_LIST",data:{offset:app.current.page,filter:app.current.filter,uri:app.current.search,cols:settings.colsBrowsePlaylistsDetail}},
parsePlaylists),doSetFilterLetter("BrowsePlaylistsFilter");else if("Browse"==app.current.app&&"Database"==app.current.tab)""!=app.current.search?(sendAPI({cmd:"MPD_API_DATABASE_TAG_ALBUM_LIST",data:{offset:app.current.page,filter:app.current.filter,search:app.current.search,tag:app.current.view}},parseListDBtags),doSetFilterLetter("BrowseDatabaseFilter")):(sendAPI({cmd:"MPD_API_DATABASE_TAG_LIST",data:{offset:app.current.page,filter:app.current.filter,tag:app.current.view}},parseListDBtags),doSetFilterLetter("BrowseDatabaseFilter"),
selectTag("BrowseDatabaseByTagDropdown","btnBrowseDatabaseByTag",app.current.view));else if("Browse"==app.current.app&&"Filesystem"==app.current.tab){sendAPI({cmd:"MPD_API_DATABASE_FILESYSTEM_LIST",data:{offset:app.current.page,path:app.current.search?app.current.search:"/",filter:app.current.filter,cols:settings.colsBrowseFilesystem}},parseFilesystem);app.current.search?(document.getElementById("BrowseFilesystemAddAllSongs").removeAttribute("disabled"),document.getElementById("BrowseFilesystemAddAllSongsBtn").removeAttribute("disabled")):
(document.getElementById("BrowseFilesystemAddAllSongs").setAttribute("disabled","disabled"),document.getElementById("BrowseFilesystemAddAllSongsBtn").setAttribute("disabled","disabled"));var b='<li class="breadcrumb-item"><a data-uri="" class="material-icons">home</a></li>',c=app.current.search.split("/"),d=c.length,f="";for(a=0;a<d;a++){if(d-1==a){b+='<li class="breadcrumb-item active">'+e(c[a])+"</li>";break}f+=c[a];b+='<li class="breadcrumb-item"><a class="text-body" href="#" data-uri="'+encodeURI(f)+
'">'+e(c[a])+"</a></li>";f+="/"}document.getElementById("BrowseBreadcrumb").innerHTML=b;doSetFilterLetter("BrowseFilesystemFilter")}else if("Search"==app.current.app){domCache.searchstr.focus();if(settings.featAdvsearch){b="";c=app.current.search.substring(1,app.current.search.length-1).split(" AND ");for(a=0;a<c.length-1;a++)d=c[a].substring(1,c[a].length-1),b+='<button data-filter="'+encodeURI(d)+'" class="btn btn-light mr-2">'+e(d)+'<span class="ml-2 badge badge-secondary">&times</span></button>';
domCache.searchCrumb.innerHTML=b;""==domCache.searchstr.value&&1<=c.length&&(a=c[c.length-1].substring(1,c[c.length-1].length-1),b=a.substring(a.indexOf("'")+1,a.length-1),domCache.searchstr.value!=b&&(domCache.searchCrumb.innerHTML+='<button data-filter="'+encodeURI(a)+'" class="btn btn-light mr-2">'+e(a)+'<span href="#" class="ml-2 badge badge-secondary">&times;</span></button>'),a=a.substring(a.indexOf(" ")+1),a=a.substring(0,a.indexOf(" ")),""==a&&(a="contains"),document.getElementById("searchMatch").value=
a)}else""==domCache.searchstr.value&&""!=app.current.search&&(domCache.searchstr.value=app.current.search);app.last.app!=app.current.app&&""!=app.current.search&&(a=settings["cols"+app.current.app].length,a--,document.getElementById("SearchList").getElementsByTagName("tbody")[0].innerHTML='<tr><td><span class="material-icons">search</span></td><td colspan="'+a+'">'+t("Searching...")+"</td></tr>");2<=domCache.searchstr.value.length||0<domCache.searchCrumb.children.length?settings.featAdvsearch?(a=
app.current.sort,b=!1,"-"==a?(a=settings.tags.includes("Title")?"Title":"-",document.getElementById("SearchList").setAttribute("data-sort",a)):0==a.indexOf("-")&&(b=!0,a=a.substring(1)),sendAPI({cmd:"MPD_API_DATABASE_SEARCH_ADV",data:{plist:"",offset:app.current.page,sort:a,sortdesc:b,expression:app.current.search,cols:settings.colsSearch}},parseSearch)):sendAPI({cmd:"MPD_API_DATABASE_SEARCH",data:{plist:"",offset:app.current.page,filter:app.current.filter,searchstr:app.current.search,cols:settings.colsSearch}},
parseSearch):(document.getElementById("SearchList").getElementsByTagName("tbody")[0].innerHTML="",document.getElementById("searchAddAllSongs").setAttribute("disabled","disabled"),document.getElementById("searchAddAllSongsBtn").setAttribute("disabled","disabled"),document.getElementById("panel-heading-search").innerText="",document.getElementById("cardFooterSearch").innerText="",document.getElementById("SearchList").classList.remove("opacity05"),setPagination(0,0));selectTag("searchtags","searchtagsdesc",
app.current.filter)}else appGoto("Playback");app.last.app=app.current.app;app.last.tab=app.current.tab;app.last.view=app.current.view}else appGoto("Playback")}}function showAppInitAlert(a){document.getElementById("splashScreenAlert").innerHTML='<a id="appReloadBtn" class="btn btn-danger text-light clickable">Reload</a><p class="text-danger">'+t(a)+"</p>";document.getElementById("appReloadBtn").addEventListener("click",function(){location.reload()},!1)}
function appInitStart(){subdir=window.location.pathname.replace("/index.html","").replace(/\/$/,"");for(var a='<option value="default" data-phrase="Browser default"></option>',b=0;b<locales.length;b++)a+='<option value="'+e(locales[b].code)+'">'+e(locales[b].desc)+" ("+e(locales[b].code)+")</option>";document.getElementById("selectLocale").innerHTML=a;i18nHtml(document.getElementById("splashScreenAlert"));a=document.getElementsByTagName("script")[0].src.replace(/^.*[\/]/,"");"serviceWorker"in navigator&&
"https"==document.URL.substring(0,5)&&"localhost"!=window.location.hostname&&"combined.js"==a&&window.addEventListener("load",function(){navigator.serviceWorker.register("/sw.js",{scope:"/"}).then(function(a){logInfo("ServiceWorker registration successful.");a.update()},function(a){logError("ServiceWorker registration failed: "+a)})});appInited=!1;document.getElementById("splashScreen").classList.remove("hide");document.getElementsByTagName("body")[0].classList.add("overflow-hidden");document.getElementById("splashScreenAlert").innerText=
t("Fetch myMPD settings");getSettings(!0);appInitWait()}
function appInitWait(){setTimeout(function(){if("true"==settingsParsed&&1==websocketConnected)document.getElementById("splashScreenAlert").innerText=t("Applying settings"),document.getElementById("splashScreen").classList.add("hide-fade"),setTimeout(function(){document.getElementById("splashScreen").classList.add("hide");document.getElementById("splashScreen").classList.remove("hide-fade");document.getElementsByTagName("body")[0].classList.remove("overflow-hidden")},500),appInit(),appInited=!0;else{if("true"==
settingsParsed)document.getElementById("splashScreenAlert").innerText=t("Connect to websocket"),webSocketConnect();else if("error"==settingsParsed)return;appInitWait()}},500)}
function appInit(){document.getElementById("btnChVolumeDown").addEventListener("click",function(a){a.stopPropagation()},!1);document.getElementById("btnChVolumeUp").addEventListener("click",function(a){a.stopPropagation()},!1);domCache.volumeBar.addEventListener("click",function(a){a.stopPropagation()},!1);domCache.volumeBar.addEventListener("change",function(a){sendAPI({cmd:"MPD_API_PLAYER_VOLUME_SET",data:{volume:domCache.volumeBar.value}})},!1);domCache.progressBar.value=0;domCache.progressBar.addEventListener("change",
function(a){currentSong&&0<=currentSong.currentSongId&&sendAPI({cmd:"MPD_API_PLAYER_SEEK",data:{songid:currentSong.currentSongId,seek:Math.ceil(domCache.progressBar.value/1E3*currentSong.totalTime)}})},!1);for(var a=document.querySelectorAll(".subMenu"),b=a.length,c=0;c<b;c++)a[c].addEventListener("click",function(a){a.stopPropagation();a.preventDefault();a=this.getElementsByTagName("span")[0];a.innerText="keyboard_arrow_right"==a.innerText?"keyboard_arrow_down":"keyboard_arrow_right"},!1);document.getElementById("volumeMenu").parentNode.addEventListener("show.bs.dropdown",
function(){sendAPI({cmd:"MPD_API_PLAYER_OUTPUT_LIST"},parseOutputs)});document.getElementById("BrowseFilesystemBookmark").parentNode.addEventListener("show.bs.dropdown",function(){sendAPI({cmd:"MYMPD_API_BOOKMARK_LIST",data:{offset:0}},parseBookmarks)});document.getElementById("modalAbout").addEventListener("shown.bs.modal",function(){sendAPI({cmd:"MPD_API_DATABASE_STATS"},parseStats);var a="",b;for(b in keymap)if(void 0==keymap[b].req||1==settings[keymap[b].req])a+='<tr><td><div class="key'+(keymap[b].key&&
1<keymap[b].key.length?" material-icons material-icons-small":"")+'">'+(void 0!=keymap[b].key?keymap[b].key:b)+"</div></td><td>"+t(keymap[b].desc)+"</td></tr>";document.getElementById("tbodyShortcuts").innerHTML=a});document.getElementById("modalAddToPlaylist").addEventListener("shown.bs.modal",function(){document.getElementById("addStreamFrm").classList.contains("hide")?document.getElementById("addToPlaylistPlaylist").focus():(document.getElementById("streamUrl").focus(),document.getElementById("streamUrl").value=
"")});document.getElementById("modalAddToQueue").addEventListener("shown.bs.modal",function(){document.getElementById("inputAddToQueueQuantity").classList.remove("is-invalid");settings.featPlaylists&&(playlistEl="selectAddToQueuePlaylist",sendAPI({cmd:"MPD_API_PLAYLIST_LIST",data:{offset:0,filter:"-"}},getAllPlaylists))});document.getElementById("modalUpdateDB").addEventListener("hidden.bs.modal",function(){document.getElementById("updateDBprogress").classList.remove("updateDBprogressAnimate")});
document.getElementById("modalSaveQueue").addEventListener("shown.bs.modal",function(){var a=document.getElementById("saveQueueName");a.focus();a.value="";a.classList.remove("is-invalid")});document.getElementById("modalSettings").addEventListener("shown.bs.modal",function(){getSettings();document.getElementById("inputCrossfade").classList.remove("is-invalid");document.getElementById("inputMixrampdb").classList.remove("is-invalid");document.getElementById("inputMixrampdelay").classList.remove("is-invalid")});
document.getElementById("modalConnection").addEventListener("shown.bs.modal",function(){getSettings();document.getElementById("inputMpdHost").classList.remove("is-invalid");document.getElementById("inputMpdPort").classList.remove("is-invalid");document.getElementById("inputMpdPass").classList.remove("is-invalid")});document.getElementById("selectJukeboxMode").addEventListener("change",function(){var a=this.options[this.selectedIndex].value;0==a?(document.getElementById("inputJukeboxQueueLength").setAttribute("disabled",
"disabled"),document.getElementById("selectJukeboxPlaylist").setAttribute("disabled","disabled")):2==a?(document.getElementById("inputJukeboxQueueLength").setAttribute("disabled","disabled"),document.getElementById("selectJukeboxPlaylist").setAttribute("disabled","disabled"),document.getElementById("selectJukeboxPlaylist").value="Database"):1==a&&(document.getElementById("inputJukeboxQueueLength").removeAttribute("disabled"),document.getElementById("selectJukeboxPlaylist").removeAttribute("disabled"))});
document.getElementById("selectAddToQueueMode").addEventListener("change",function(){var a=this.options[this.selectedIndex].value;2==a?(document.getElementById("inputAddToQueueQuantity").setAttribute("disabled","disabled"),document.getElementById("selectAddToQueuePlaylist").setAttribute("disabled","disabled"),document.getElementById("selectAddToQueuePlaylist").value="Database"):1==a&&(document.getElementById("inputAddToQueueQuantity").removeAttribute("disabled"),document.getElementById("selectAddToQueuePlaylist").removeAttribute("disabled"))});
document.getElementById("addToPlaylistPlaylist").addEventListener("change",function(a){"new"==this.options[this.selectedIndex].value?(document.getElementById("addToPlaylistNewPlaylistDiv").classList.remove("hide"),document.getElementById("addToPlaylistNewPlaylist").focus()):document.getElementById("addToPlaylistNewPlaylistDiv").classList.add("hide")},!1);document.getElementById("selectMusicDirectory").addEventListener("change",function(a){"auto"==this.options[this.selectedIndex].value?(document.getElementById("inputMusicDirectory").value=
settings.musicDirectoryValue,document.getElementById("inputMusicDirectory").setAttribute("readonly","readonly")):"none"==this.options[this.selectedIndex].value?(document.getElementById("inputMusicDirectory").value="",document.getElementById("inputMusicDirectory").setAttribute("readonly","readonly")):(document.getElementById("inputMusicDirectory").value="",document.getElementById("inputMusicDirectory").removeAttribute("readonly"))},!1);addFilterLetter("BrowseFilesystemFilterLetters");addFilterLetter("BrowseDatabaseFilterLetters");
addFilterLetter("BrowsePlaylistsFilterLetters");document.getElementById("syscmds").addEventListener("click",function(a){"A"==a.target.nodeName&&parseCmd(a,a.target.getAttribute("data-href"))},!1);a=document.querySelectorAll("[data-href]");b=a.length;for(c=0;c<b;c++)a[c].classList.add("clickable"),1!=(a[c].parentNode.classList.contains("noInitChilds")?!0:!1)&&a[c].addEventListener("click",function(a){parseCmd(a,this.getAttribute("data-href"))},!1);a=document.getElementsByClassName("pages");b=a.length;
for(c=0;c<b;c++)a[c].addEventListener("click",function(a){"BUTTON"==a.target.nodeName&&gotoPage(a.target.getAttribute("data-page"))},!1);document.getElementById("cardPlaybackTags").addEventListener("click",function(a){"H4"==a.target.nodeName&&gotoBrowse(a.target)},!1);document.getElementById("BrowseBreadcrumb").addEventListener("click",function(a){"A"==a.target.nodeName&&(a.preventDefault(),appGoto("Browse","Filesystem",void 0,"0/"+app.current.filter+"/"+app.current.sort+"/"+decodeURI(a.target.getAttribute("data-uri"))))},
!1);document.getElementById("modalSongDetails").getElementsByTagName("tbody")[0].addEventListener("click",function(a){if("A"==a.target.nodeName)if("calcFingerprint"==a.target.id){sendAPI({cmd:"MPD_API_DATABASE_FINGERPRINT",data:{uri:decodeURI(a.target.getAttribute("data-uri"))}},parseFingerprint);a.preventDefault();var b=a.target.parentNode,c=document.createElement("div");c.classList.add("spinner-border","spinner-border-sm");a.target.classList.add("hide");b.appendChild(c)}else void 0!=a.target.parentNode.getAttribute("data-tag")&&
(modalSongDetails.hide(),a.preventDefault(),gotoBrowse(a.target));else"BUTTON"==a.target.nodeName&&a.target.getAttribute("data-href")&&parseCmd(a,a.target.getAttribute("data-href"))},!1);document.getElementById("outputs").addEventListener("click",function(a){"BUTTON"==a.target.nodeName&&(a.stopPropagation(),sendAPI({cmd:"MPD_API_PLAYER_TOGGLE_OUTPUT",data:{output:a.target.getAttribute("data-output-id"),state:a.target.classList.contains("active")?0:1}}),toggleBtn(a.target.id))},!1);document.getElementById("QueueCurrentList").addEventListener("click",
function(a){"TD"==a.target.nodeName?sendAPI({cmd:"MPD_API_PLAYER_PLAY_TRACK",data:{track:a.target.parentNode.getAttribute("data-trackid")}}):"A"==a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("QueueLastPlayedList").addEventListener("click",function(a){"A"==a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("BrowseFilesystemList").addEventListener("click",function(a){if("TD"==a.target.nodeName)switch(a.target.parentNode.getAttribute("data-type")){case "parentDir":case "dir":appGoto("Browse",
"Filesystem",void 0,"0/"+app.current.filter+"/"+app.current.sort+"/"+decodeURI(a.target.parentNode.getAttribute("data-uri")));break;case "song":appendQueue("song",decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name"));break;case "plist":appendQueue("plist",decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name"))}else"A"==a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("BrowseFilesystemBookmarks").addEventListener("click",
function(a){if("A"==a.target.nodeName){var b=a.target.parentNode.parentNode.getAttribute("data-id"),c=a.target.parentNode.parentNode.getAttribute("data-type"),d=decodeURI(a.target.parentNode.parentNode.getAttribute("data-uri")),l=a.target.parentNode.parentNode.firstChild.innerText,k=a.target.getAttribute("data-href");"delete"==k?(sendAPI({cmd:"MYMPD_API_BOOKMARK_RM",data:{id:b}},function(){sendAPI({cmd:"MYMPD_API_BOOKMARK_LIST",data:{offset:0}},parseBookmarks)}),a.preventDefault(),a.stopPropagation()):
"edit"==k?showBookmarkSave(b,l,d,c):"goto"==k&&appGoto("Browse","Filesystem",null,"0/-/-/"+d)}},!1);document.getElementById("BrowsePlaylistsAllList").addEventListener("click",function(a){"TD"==a.target.nodeName?appendQueue("plist",decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name")):"A"==a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("BrowsePlaylistsDetailList").addEventListener("click",function(a){"TD"==a.target.nodeName?appendQueue("plist",
decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name")):"A"==a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("BrowseDatabaseTagList").addEventListener("click",function(a){"TD"==a.target.nodeName&&appGoto("Browse","Database",app.current.view,"0/-/-/"+a.target.parentNode.getAttribute("data-uri"))},!1);document.getElementById("SearchList").addEventListener("click",function(a){"TD"==a.target.nodeName?appendQueue("song",decodeURI(a.target.parentNode.getAttribute("data-uri")),
a.target.parentNode.getAttribute("data-name")):"A"==a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("BrowseFilesystemAddAllSongsDropdown").addEventListener("click",function(a){"BUTTON"==a.target.nodeName&&("Add all to queue"==a.target.getAttribute("data-phrase")?addAllFromBrowse():"Add all to playlist"==a.target.getAttribute("data-phrase")&&showAddToPlaylist(app.current.search))},!1);document.getElementById("searchAddAllSongsDropdown").addEventListener("click",function(a){"BUTTON"==
a.target.nodeName&&("Add all to queue"==a.target.getAttribute("data-phrase")?addAllFromSearchPlist("queue"):"Add all to playlist"==a.target.getAttribute("data-phrase")?showAddToPlaylist("SEARCH"):"Save as smart playlist"==a.target.getAttribute("data-phrase")&&saveSearchAsSmartPlaylist())},!1);document.getElementById("BrowseDatabaseAddAllSongsDropdown").addEventListener("click",function(a){"BUTTON"==a.target.nodeName&&("Add all to queue"==a.target.getAttribute("data-phrase")?addAllFromBrowseDatabasePlist("queue"):
"Add all to playlist"==a.target.getAttribute("data-phrase")&&showAddToPlaylist("DATABASE"))},!1);document.getElementById("searchtags").addEventListener("click",function(a){"BUTTON"==a.target.nodeName&&(app.current.filter=a.target.getAttribute("data-tag"),search(domCache.searchstr.value))},!1);document.getElementById("searchqueuestr").addEventListener("keyup",function(a){"Escape"==a.key?this.blur():appGoto(app.current.app,app.current.tab,app.current.view,"0/"+app.current.filter+"/"+app.current.sort+
"/"+this.value)},!1);document.getElementById("searchqueuetags").addEventListener("click",function(a){"BUTTON"==a.target.nodeName&&appGoto(app.current.app,app.current.tab,app.current.view,app.current.page+"/"+a.target.getAttribute("data-tag")+"/"+app.current.sort+"/"+app.current.search)},!1);a="QueueCurrentColsDropdown BrowseFilesystemColsDropdown SearchColsDropdown BrowsePlaylistsDetailColsDropdown BrowseDatabaseColsDropdown PlaybackColsDropdown QueueLastPlayedColsDropdown".split(" ");for(c=0;c<a.length;c++)document.getElementById(a[c]).addEventListener("click",
function(a){"INPUT"==a.target.nodeName&&a.stopPropagation()},!1);document.getElementById("search").addEventListener("submit",function(){return!1},!1);document.getElementById("searchqueue").addEventListener("submit",function(){return!1},!1);domCache.searchstr.addEventListener("keyup",function(a){if("Escape"==a.key)this.blur();else if("Enter"==a.key&&settings.featAdvsearch)if(""!=this.value){a=document.getElementById("searchMatch");var b=document.createElement("button");b.classList.add("btn","btn-light",
"mr-2");b.setAttribute("data-filter",encodeURI(app.current.filter+" "+a.options[a.selectedIndex].value+" '"+this.value+"'"));b.innerHTML=app.current.filter+" "+a.options[a.selectedIndex].value+" '"+e(this.value)+'\'<span class="ml-2 badge badge-secondary">&times;</span>';this.value="";domCache.searchCrumb.appendChild(b)}else search(this.value);else search(this.value)},!1);domCache.searchCrumb.addEventListener("click",function(a){a.preventDefault();a.stopPropagation();if("SPAN"==a.target.nodeName)a.target.parentNode.remove(),
search("");else if("BUTTON"==a.target.nodeName){var b=decodeURI(a.target.getAttribute("data-filter"));domCache.searchstr.value=b.substring(b.indexOf("'")+1,b.length-1);var c=b.substring(0,b.indexOf(" "));selectTag("searchtags","searchtagsdesc",c);b=b.substring(b.indexOf(" ")+1);b=b.substring(0,b.indexOf(" "));document.getElementById("searchMatch").value=b;a.target.remove();search(domCache.searchstr.value)}},!1);document.getElementById("searchMatch").addEventListener("change",function(a){search(domCache.searchstr.value)},
!1);document.getElementById("SearchList").getElementsByTagName("tr")[0].addEventListener("click",function(a){if(settings.featAdvsearch&&"TH"==a.target.nodeName){var b=a.target.getAttribute("data-col");if("Duration"!=b){var c=app.current.sort,d=!0;if(c==b||c=="-"+b)0==c.indexOf("-")?(d=!0,b=c.substring(1)):d=!1;0==d?(c="-"+b,d=!0):(d=!1,c=b);for(var l=document.getElementById("SearchList").getElementsByClassName("sort-dir"),k=0;k<l.length;k++)l[k].remove();app.current.sort=c;a.target.innerHTML=b+'<span class="sort-dir material-icons pull-right">'+
(1==d?"arrow_drop_up":"arrow_drop_down")+"</span>";appGoto(app.current.app,app.current.tab,app.current.view,app.current.page+"/"+app.current.filter+"/"+app.current.sort+"/"+app.current.search)}}},!1);document.getElementById("BrowseDatabaseByTagDropdown").addEventListener("click",function(a){"BUTTON"==a.target.nodeName&&appGoto(app.current.app,app.current.tab,a.target.getAttribute("data-tag"),"0/"+app.current.filter+"/"+app.current.sort+"/"+app.current.search)},!1);document.getElementsByTagName("body")[0].addEventListener("click",
function(a){hideMenu()},!1);dragAndDropTable("QueueCurrentList");dragAndDropTable("BrowsePlaylistsDetailList");dragAndDropTableHeader("QueueCurrent");dragAndDropTableHeader("QueueLastPlayed");dragAndDropTableHeader("Search");dragAndDropTableHeader("BrowseFilesystem");dragAndDropTableHeader("BrowsePlaylistsDetail");window.addEventListener("hashchange",appRoute,!1);window.addEventListener("focus",function(){sendAPI({cmd:"MPD_API_PLAYER_STATE"},parseState)},!1);document.addEventListener("keydown",function(a){if("INPUT"!=
a.target.tagName&&"SELECT"!=a.target.tagName&&!a.ctrlKey&&!a.altKey){var b=keymap[a.key];b&&"function"===typeof window[b.cmd]&&(void 0==keymap[a.key].req||1==settings[keymap[a.key].req])&&parseCmd(a,b)}},!1);a=document.getElementsByTagName("table");for(c=0;c<a.length;c++)a[c].setAttribute("tabindex",0),a[c].addEventListener("keydown",function(a){navigateTable(this,a.key)},!1);window.addEventListener("beforeinstallprompt",function(a){a.preventDefault();deferredPrompt=a});window.addEventListener("beforeinstallprompt",
function(a){a.preventDefault();deferredPrompt=a;domCache.btnAdd.classList.remove("hide")});domCache.btnAdd.addEventListener("click",function(a){domCache.btnAdd.classList.add("hide");deferredPrompt.prompt();deferredPrompt.userChoice.then(function(a){"accepted"===a.outcome?logVerbose("User accepted the A2HS prompt"):logVerbose("User dismissed the A2HS prompt");deferredPrompt=null})});window.addEventListener("appinstalled",function(a){logInfo("myMPD installed as app");showNotification(t("myMPD installed as app"),
"","","success")});window.addEventListener("beforeunload",function(){null!=websocketTimer&&(clearTimeout(websocketTimer),websocketTimer=null);socket.onclose=function(){};null!=socket&&(socket.close(),socket=null);websocketConnected=!1});document.getElementById("localPlayer").addEventListener("canplay",function(){document.getElementById("alertLocalPlayback").classList.add("hide");1==settings.featLocalplayer&&1==settings.localplayerAutoplay&&localplayerPlay()})}
function localplayerPlay(){var a;return $jscomp.asyncExecutePromiseGeneratorProgram(function(b){if(1==b.nextAddress){a=document.getElementById("localPlayer");if(!a.paused)return b.jumpTo(0);b.setCatchFinallyBlocks(3);return b.yield(a.play(),5)}if(3!=b.nextAddress)return b.leaveTryBlock(0);b.enterCatchBlock();showNotification(t("Local playback"),t("Can not start playing"),"","error");b.jumpToEnd()})}
function focusTable(a,b){null==b&&(b=document.getElementById(app.current.app+(null!=app.current.tab?app.current.tab:"")+(null!=app.current.view?app.current.view:"")+"List"),null==b&&(b=document.getElementById(app.current.app+app.current.tab+"TagList")),"Browse"!=app.current.app||"Database"!=app.current.tab||document.getElementById("BrowseDatabaseAlbumList").classList.contains("hide")||(b=document.getElementById("BrowseDatabaseAlbumList").getElementsByTagName("table")[0]));if(null!=b){var c=b.getElementsByClassName("selected");
if(void 0==a)0==c.length?(a=b.getElementsByTagName("tbody")[0].rows[0],a.focus(),a.classList.add("selected")):c[0].focus();else{c&&0<c.length&&c[0].classList.remove("selected");c=b.getElementsByTagName("tbody")[0].rows;var d=c.length;d<a&&(a=0);d>a&&(c[a].focus(),c[a].classList.add("selected"))}"BrowseFilesystemList"==b.id&&(a=b.getElementsByTagName("tbody")[0],"parentDir"!=a.rows[0].getAttribute("data-type")&&""!=app.current.search&&(b=b.getElementsByTagName("thead")[0].rows[0].cells.length,c=app.current.search.replace(/\/?([^\/]+)$/,
""),a=a.insertRow(0),a.setAttribute("data-type","parentDir"),a.setAttribute("tabindex",0),a.setAttribute("data-uri",encodeURI(c)),a.innerHTML='<td colspan="'+b+'">..</td>'));scrollFocusIntoView()}}function scrollFocusIntoView(){var a=document.activeElement,b=a.getBoundingClientRect().top;a=a.offsetHeight;74>b?window.scrollBy(0,-74):b+a>window.innerHeight-74&&window.scrollBy(0,74)}
function navigateTable(a,b){if(a=document.activeElement){var c=null,d=!1;"ArrowDown"==b?(c=a.nextElementSibling,d=!0):"ArrowUp"==b?(c=a.previousElementSibling,d=!0):" "==b?(b=a.lastChild.firstChild,"A"==b.nodeName&&b.click(),d=!0):"Enter"==b?(a.firstChild.click(),d=!0):"Escape"==b?(a.blur(),a.classList.remove("selected"),d=!0):"Browse"!=app.current.app||"Database"!=app.current.tab||document.getElementById("BrowseDatabaseAlbumList").classList.contains("hide")||"n"!=b&&"p"!=b||(b=document.getElementById("BrowseDatabaseAlbumList").getElementsByTagName("table"),
b=Array.prototype.slice.call(b),d="TR"==document.activeElement.nodeName?b.indexOf(document.activeElement.parentNode.parentNode):b.indexOf(document.activeElement),d="p"==event.key?1<d?d-1:0:"n"==event.key?d<b.length-1?"TR"==document.activeElement.nodeName?d+1:d:d:d,0<b[d].getElementsByTagName("tbody")[0].rows.length?c=b[d].getElementsByTagName("tbody")[0].rows[0]:(b[d].focus(),scrollFocusIntoView()),d=!0);1==d&&(event.preventDefault(),event.stopPropagation());c&&(a.classList.remove("selected"),c.classList.add("selected"),
c.focus(),scrollFocusIntoView())}}function parseCmd(a,b){a.preventDefault();a=b;"string"==typeof b&&(a=JSON.parse(b));if("function"===typeof window[a.cmd])switch(a.cmd){case "sendAPI":sendAPI.apply(null,$jscomp.arrayFromIterable(a.options));break;default:window[a.cmd].apply(null,$jscomp.arrayFromIterable(a.options))}}
function search(a){if(settings.featAdvsearch){for(var b="(",c=domCache.searchCrumb.children,d=0;d<c.length;d++)b+="("+decodeURI(c[d].getAttribute("data-filter"))+")",""!=a&&(b+=" AND ");""!=a?(c=document.getElementById("searchMatch"),b+="("+app.current.filter+" "+c.options[c.selectedIndex].value+" '"+a+"'))"):b+=")";2>=b.length&&(b="");appGoto("Search",void 0,void 0,"0/"+app.current.filter+"/"+app.current.sort+"/"+encodeURI(b))}else appGoto("Search",void 0,void 0,"0/"+app.current.filter+"/"+app.current.sort+
"/"+a)}
function dragAndDropTable(a){var b=document.getElementById(a).getElementsByTagName("tbody")[0];b.addEventListener("dragstart",function(a){"TR"==a.target.nodeName&&(a.target.classList.add("opacity05"),a.dataTransfer.setDragImage(a.target,0,0),a.dataTransfer.effectAllowed="move",a.dataTransfer.setData("Text",a.target.getAttribute("id")),dragEl=a.target.cloneNode(!0))},!1);b.addEventListener("dragleave",function(a){a.preventDefault();if("TR"==dragEl.nodeName){var b=a.target;"TD"==a.target.nodeName&&(b=
a.target.parentNode);"TR"==b.nodeName&&b.classList.remove("dragover")}},!1);b.addEventListener("dragover",function(a){a.preventDefault();if("TR"==dragEl.nodeName){for(var c=b.getElementsByClassName("dragover"),f=c.length,g=0;g<f;g++)c[g].classList.remove("dragover");c=a.target;"TD"==a.target.nodeName&&(c=a.target.parentNode);"TR"==c.nodeName&&c.classList.add("dragover");a.dataTransfer.dropEffect="move"}},!1);b.addEventListener("dragend",function(a){a.preventDefault();if("TR"==dragEl.nodeName){for(var c=
b.getElementsByClassName("dragover"),f=c.length,g=0;g<f;g++)c[g].classList.remove("dragover");document.getElementById(a.dataTransfer.getData("Text"))&&document.getElementById(a.dataTransfer.getData("Text")).classList.remove("opacity05")}},!1);b.addEventListener("drop",function(c){c.stopPropagation();c.preventDefault();if("TR"==dragEl.nodeName){var d=c.target;"TD"==c.target.nodeName&&(d=c.target.parentNode);var f=document.getElementById(c.dataTransfer.getData("Text")).getAttribute("data-songpos"),
g=d.getAttribute("data-songpos");document.getElementById(c.dataTransfer.getData("Text")).remove();dragEl.classList.remove("opacity05");b.insertBefore(dragEl,d);c=b.getElementsByClassName("dragover");d=c.length;for(var h=0;h<d;h++)c[h].classList.remove("dragover");document.getElementById(a).classList.add("opacity05");"Queue"==app.current.app&&"Current"==app.current.tab?sendAPI({cmd:"MPD_API_QUEUE_MOVE_TRACK",data:{from:f,to:g}}):"Browse"==app.current.app&&"Playlists"==app.current.tab&&"Detail"==app.current.view&&
playlistMoveTrack(f,g)}},!1)}
function dragAndDropTableHeader(a){if(document.getElementById(a+"List"))var b=document.getElementById(a+"List").getElementsByTagName("tr")[0];else b=a.getElementsByTagName("tr")[0],a="BrowseDatabase";b.addEventListener("dragstart",function(a){"TH"==a.target.nodeName&&(a.target.classList.add("opacity05"),a.dataTransfer.setDragImage(a.target,0,0),a.dataTransfer.effectAllowed="move",a.dataTransfer.setData("Text",a.target.getAttribute("data-col")),dragEl=a.target.cloneNode(!0))},!1);b.addEventListener("dragleave",
function(a){a.preventDefault();"TH"==dragEl.nodeName&&"TH"==a.target.nodeName&&a.target.classList.remove("dragover-th")},!1);b.addEventListener("dragover",function(a){a.preventDefault();if("TH"==dragEl.nodeName){for(var c=b.getElementsByClassName("dragover-th"),f=c.length,g=0;g<f;g++)c[g].classList.remove("dragover-th");"TH"==a.target.nodeName&&a.target.classList.add("dragover-th");a.dataTransfer.dropEffect="move"}},!1);b.addEventListener("dragend",function(a){a.preventDefault();if("TH"==dragEl.nodeName){for(var c=
b.getElementsByClassName("dragover-th"),f=c.length,g=0;g<f;g++)c[g].classList.remove("dragover-th");this.querySelector("[data-col="+a.dataTransfer.getData("Text")+"]")&&this.querySelector("[data-col="+a.dataTransfer.getData("Text")+"]").classList.remove("opacity05")}},!1);b.addEventListener("drop",function(c){c.stopPropagation();c.preventDefault();if("TH"==dragEl.nodeName){this.querySelector("[data-col="+c.dataTransfer.getData("Text")+"]").remove();dragEl.classList.remove("opacity05");b.insertBefore(dragEl,
c.target);c=b.getElementsByClassName("dragover-th");for(var d=c.length,f=0;f<d;f++)c[f].classList.remove("dragover-th");document.getElementById(a+"List")?(document.getElementById(a+"List").classList.add("opacity05"),saveCols(a)):saveCols(a,this.parentNode.parentNode)}},!1)}function playlistMoveTrack(a,b){sendAPI({cmd:"MPD_API_PLAYLIST_MOVE_TRACK",data:{plist:app.current.search,from:a,to:b}})}
function setElsState(a,b){a=document.getElementsByTagName(a);for(var c=a.length,d=0;d<c;d++)"disabled"==b?!a[d].classList.contains("alwaysEnabled")&&a[d].getAttribute("disabled")&&(a[d].setAttribute("disabled","disabled"),a[d].classList.add("disabled")):a[d].classList.contains("disabled")&&(a[d].removeAttribute("disabled"),a[d].classList.remove("disabled"))}
function toggleUI(){var a="disabled";1==websocketConnected&&1==settings.mpdConnected&&(a="enabled");var b="disabled"==a?!1:!0;b!=uiEnabled&&(setElsState("a",a),setElsState("input",a),setElsState("button",a),uiEnabled=b);1==settings.mpdConnected?toggleAlert("alertMpdState",!1,""):toggleAlert("alertMpdState",!0,t("MPD disconnected"));1==websocketConnected?toggleAlert("alertMympdState",!1,""):toggleAlert("alertMympdState",!0,t("Websocket connection failed"))}
function webSocketConnect(){if(null!=socket)logInfo("Socket already connected");else{var a=getWsUrl();socket=new WebSocket(a);logInfo("Connecting to "+a);try{socket.onopen=function(){logInfo("Websocket is connected");websocketConnected=!0;null!=websocketTimer&&(clearTimeout(websocketTimer),websocketTimer=null)},socket.onmessage=function(b){try{var c=JSON.parse(b.data);logDebug("Websocket notification: "+c.type)}catch(d){logError("Invalid JSON data received: "+b.data)}switch(c.type){case "welcome":websocketConnected=
!0;showNotification(t("Connected to myMPD")+": "+a,"","","success");appRoute();sendAPI({cmd:"MPD_API_PLAYER_STATE"},parseState,!0);break;case "update_state":parseState(c);break;case "mpd_disconnected":progressTimer&&clearTimeout(progressTimer);getSettings(!0);break;case "mpd_connected":showNotification(t("Connected to MPD"),"","","success");sendAPI({cmd:"MPD_API_PLAYER_STATE"},parseState);getSettings(!0);break;case "update_queue":"Queue"===app.current.app&&getQueue();parseUpdateQueue(c);break;case "update_options":getSettings();
break;case "update_outputs":sendAPI({cmd:"MPD_API_PLAYER_OUTPUT_LIST"},parseOutputs);break;case "update_started":updateDBstarted(!1);break;case "update_database":case "update_finished":updateDBfinished(c.type);break;case "update_volume":parseVolume(c);break;case "update_stored_playlist":"Browse"==app.current.app&&"Playlists"==app.current.tab&&"All"==app.current.view?sendAPI({cmd:"MPD_API_PLAYLIST_LIST",data:{offset:app.current.page,filter:app.current.filter}},parsePlaylists):"Browse"==app.current.app&&
"Playlists"==app.current.tab&&"Detail"==app.current.view&&sendAPI({cmd:"MPD_API_PLAYLIST_CONTENT_LIST",data:{offset:app.current.page,filter:app.current.filter,uri:app.current.search,cols:settings.colsBrowsePlaylistsDetail}},parsePlaylists);break;case "update_lastplayed":"Queue"==app.current.app&&"LastPlayed"==app.current.tab&&sendAPI({cmd:"MPD_API_QUEUE_LAST_PLAYED",data:{offset:app.current.page,cols:settings.colsQueueLastPlayed}},parseLastPlayed);break;case "error":document.getElementById("alertMpdState").classList.contains("hide")&&
showNotification(t(c.data),"","","danger")}},socket.onclose=function(){logError("Websocket is disconnected");websocketConnected=!1;1==appInited?(toggleUI(),progressTimer&&clearTimeout(progressTimer)):(showAppInitAlert(t("Websocket connection failed")),logError("Websocket connection failed."));null!=websocketTimer&&(clearTimeout(websocketTimer),websocketTimer=null);websocketTimer=setTimeout(function(){logInfo("Reconnecting websocket");toggleAlert("alertMympdState",!0,t("Websocket connection failed, trying to reconnect")+
'&nbsp;&nbsp;<div class="spinner-border spinner-border-sm"></div>');webSocketConnect()},3E3);socket=null}}catch(b){logError(b)}}}function getWsUrl(){var a=window.location.hostname,b=window.location.protocol,c=window.location.port;return("https:"==b?"wss://":"ws://")+a+(""!=c?":"+c:"")+subdir+"/ws/"}
function parseStats(a){document.getElementById("mpdstats_artists").innerText=a.data.artists;document.getElementById("mpdstats_albums").innerText=a.data.albums;document.getElementById("mpdstats_songs").innerText=a.data.songs;document.getElementById("mpdstats_dbPlaytime").innerText=beautifyDuration(a.data.dbPlaytime);document.getElementById("mpdstats_playtime").innerText=beautifyDuration(a.data.playtime);document.getElementById("mpdstats_uptime").innerText=beautifyDuration(a.data.uptime);document.getElementById("mpdstats_dbUpdated").innerText=
localeDate(a.data.dbUpdated);document.getElementById("mympdVersion").innerText=a.data.mympdVersion;document.getElementById("mpdInfo_version").innerText=a.data.mpdVersion;document.getElementById("mpdInfo_libmpdclientVersion").innerText=a.data.libmpdclientVersion}function toggleBtn(a,b){if(a=document.getElementById(a)){if(void 0==b)b=a.classList.contains("active")?!1:!0;else if(0==b||1==b)b=1==b?!0:!1;1==b?a.classList.add("active"):a.classList.remove("active")}}
function toggleBtnChk(a,b){if(a=document.getElementById(a)){if(void 0==b)b=a.classList.contains("active")?!1:!0;else if(0==b||1==b)b=1==b?!0:!1;1==b?(a.classList.add("active"),a.innerText="check"):(a.classList.remove("active"),a.innerText="radio_button_unchecked")}}
function filterCols(a){var b=settings.tags.slice();0==settings.featTags&&b.push("Title");b.push("Duration");"colsQueueCurrent"==a||"colsBrowsePlaylistsDetail"==a||"colsQueueLastPlayed"==a?b.push("Pos"):"colsBrowseFilesystem"==a&&b.push("Type");"colsQueueLastPlayed"==a&&b.push("LastPlayed");for(var c=[],d=0;d<settings[a].length;d++)b.includes(settings[a][d])&&c.push(settings[a][d]);settings[a]=c}function smartCount(a){return 0==a?1:1==a?0:1}
function t(a,b,c){var d=void 0;isNaN(b)&&(c=b);phrases[a]&&(d=phrases[a][locale],void 0==d&&("en-US"!=locale&&logDebug('Phrase "'+a+'" for locale '+locale+" not found"),d=phrases[a]["en-US"]));void 0==d&&(d=a);0==isNaN(b)&&(a=d.split(" |||| "),1<a.length&&(d=a[smartCount(b)]),d=d.replace("%{smart_count}",b));null!=c&&(d=d.replace(/%\{(\w+)\}/g,function(a,b){return c[b]}));return d}
function i18nHtml(a){for(var b=[["data-phrase","innerText"],["data-title-phrase","title"],["data-placeholder-phrase","placeholder"]],c=0;c<b.length;c++)for(var d=a.querySelectorAll("["+b[c][0]+"]"),f=d.length,g=0;g<f;g++)d[g][b[c][1]]=t(d[g].getAttribute(b[c][0]))}
function parseSettings(){locale="default"==settings.locale?navigator.language||navigator.userLanguage:settings.locale;1==settings.mpdConnected&&parseMPDSettings();0!=settings.mpdHost.indexOf("/")?document.getElementById("mpdInfo_host").innerText=settings.mpdHost+":"+settings.mpdPort:document.getElementById("mpdInfo_host").innerText=settings.mpdHost;document.getElementById("inputMpdHost").value=settings.mpdHost;document.getElementById("inputMpdPort").value=settings.mpdPort;document.getElementById("inputMpdPass").value=
settings.mpdPass;var a=document.getElementById("btnNotifyWeb");notificationsSupported()?settings.notificationWeb?(toggleBtnChk("btnNotifyWeb",settings.notificationWeb),Notification.requestPermission(function(a){"permission"in Notification||(Notification.permission=a);"granted"===a?toggleBtnChk("btnNotifyWeb",!0):(toggleBtnChk("btnNotifyWeb",!1),settings.notificationWeb=!0)})):toggleBtnChk("btnNotifyWeb",!1):(a.setAttribute("disabled","disabled"),toggleBtnChk("btnNotifyWeb",!1));toggleBtnChk("btnNotifyPage",
settings.notificationPage);toggleBtnChk("btnBgCover",settings.bgCover);document.getElementById("inputBgColor").value=settings.bgColor;document.getElementById("inputBgCssFilter").value=settings.bgCssFilter;toggleBtnChk("btnFeatLocalplayer",settings.featLocalplayer);toggleBtnChk("btnLocalplayerAutoplay",settings.localplayerAutoplay);""==settings.streamUrl?(document.getElementById("selectStreamMode").value="port",document.getElementById("inputStreamUrl").value=settings.streamPort):(document.getElementById("selectStreamMode").value=
"url",document.getElementById("inputStreamUrl").value=settings.streamUrl);toggleBtnChk("btnCoverimage",settings.coverimage);document.getElementById("inputCoverimageName").value=settings.coverimageName;document.getElementById("inputCoverimageSize").value=settings.coverimageSize;document.getElementById("selectLocale").value=settings.locale;document.documentElement.style.setProperty("--mympd-coverimagesize",settings.coverimageSize+"px");document.documentElement.style.setProperty("--mympd-backgroundcolor",
settings.bgColor);document.documentElement.style.setProperty("--mympd-backgroundfilter",settings.bgCssFilter);toggleBtnChk("btnLoveEnable",settings.love);document.getElementById("inputLoveChannel").value=settings.loveChannel;document.getElementById("inputLoveMessage").value=settings.loveMessage;document.getElementById("inputMaxElementsPerPage").value=settings.maxElementsPerPage;toggleBtnChk("btnStickers",settings.stickers);document.getElementById("inputLastPlayedCount").value=settings.lastPlayedCount;
toggleBtnChk("btnSmartpls",settings.smartpls);for(var b=["featLocalplayer","featSyscmds","featMixramp","featCacert"],c=0;c<b.length;c++){var d=document.getElementsByClassName(b[c]),f=d.length,g=1==settings[b[c]]?"":"none";for(a=0;a<f;a++)d[a].style.display=g}if(settings.featSyscmds){b="";c=settings.syscmdList.length;if(0<c)for(b=4<c?"":'<div class="dropdown-divider"></div>',a=0;a<c;a++)b="HR"==settings.syscmdList[a]?b+'<div class="dropdown-divider"></div>':b+('<a class="dropdown-item text-light bg-dark alwaysEnabled" href="#" data-href=\'{"cmd": "execSyscmd", "options": ["'+
e(settings.syscmdList[a])+"\"]}'>"+e(settings.syscmdList[a])+"</a>");document.getElementById("syscmds").innerHTML=b;4<c?(document.getElementById("navSyscmds").classList.remove("hide"),document.getElementById("syscmds").classList.add("collapse","menu-indent")):(document.getElementById("navSyscmds").classList.add("hide"),document.getElementById("syscmds").classList.remove("collapse","menu-indent"))}else document.getElementById("syscmds").innerHTML="";dropdownMainMenu=new Dropdown(document.getElementById("mainMenu"));
document.getElementById("selectJukeboxMode").value=settings.jukeboxMode;document.getElementById("inputJukeboxQueueLength").value=settings.jukeboxQueueLength;0==settings.jukeboxMode?(document.getElementById("inputJukeboxQueueLength").setAttribute("disabled","disabled"),document.getElementById("selectJukeboxPlaylist").setAttribute("disabled","disabled")):2==settings.jukeboxMode?(document.getElementById("inputJukeboxQueueLength").setAttribute("disabled","disabled"),document.getElementById("selectJukeboxPlaylist").setAttribute("disabled",
"disabled"),document.getElementById("selectJukeboxPlaylist").value="Database"):1==settings.jukeboxMode&&(document.getElementById("inputJukeboxQueueLength").removeAttribute("disabled"),document.getElementById("selectJukeboxPlaylist").removeAttribute("disabled"));1==settings.featLocalplayer&&(""==settings.streamUrl?(settings.mpdstream="http://",null!=settings.mpdHost.match(/^127\./)||"localhost"==settings.mpdHost||null!=settings.mpdHost.match(/^\//)?settings.mpdstream+=window.location.hostname:settings.mpdstream+=
settings.mpdHost,settings.mpdstream+=":"+settings.streamPort+"/"):settings.mpdstream=settings.streamUrl,a=document.getElementById("localPlayer"),a.src!=settings.mpdstream&&(a.pause(),document.getElementById("alertLocalPlayback").classList.remove("hide"),a.src=settings.mpdstream,a.load()));"auto"==settings.musicDirectory?(document.getElementById("selectMusicDirectory").value=settings.musicDirectory,document.getElementById("inputMusicDirectory").value=settings.musicDirectoryValue,document.getElementById("inputMusicDirectory").setAttribute("readonly",
"readonly")):"none"==settings.musicDirectory?(document.getElementById("selectMusicDirectory").value=settings.musicDirectory,document.getElementById("inputMusicDirectory").value="",document.getElementById("inputMusicDirectory").setAttribute("readonly","readonly")):(document.getElementById("selectMusicDirectory").value="custom",document.getElementById("inputMusicDirectory").value=settings.musicDirectoryValue,document.getElementById("inputMusicDirectory").removeAttribute("readonly"));"Queue"==app.current.app&&
"Current"==app.current.tab?getQueue():"Queue"==app.current.app&&"LastPlayed"==app.current.tab?appRoute():"Search"==app.current.app?appRoute():"Browse"==app.current.app&&"Filesystem"==app.current.tab?appRoute():"Browse"==app.current.app&&"Playlists"==app.current.tab&&"Detail"==app.current.view?appRoute():"Browse"==app.current.app&&"Database"==app.current.tab&&""!=app.current.search&&appRoute();i18nHtml(document.getElementsByTagName("body")[0]);settingsParsed="true"}
function parseMPDSettings(){toggleBtnChk("btnRandom",settings.random);toggleBtnChk("btnConsume",settings.consume);toggleBtnChk("btnSingle",settings.single);toggleBtnChk("btnRepeat",settings.repeat);toggleBtnChk("btnAutoPlay",settings.autoPlay);void 0!=settings.crossfade?(document.getElementById("inputCrossfade").removeAttribute("disabled"),document.getElementById("inputCrossfade").value=settings.crossfade):document.getElementById("inputCrossfade").setAttribute("disabled","disabled");void 0!=settings.mixrampdb?
(document.getElementById("inputMixrampdb").removeAttribute("disabled"),document.getElementById("inputMixrampdb").value=settings.mixrampdb):document.getElementById("inputMixrampdb").setAttribute("disabled","disabled");void 0!=settings.mixrampdelay?(document.getElementById("inputMixrampdelay").removeAttribute("disabled"),document.getElementById("inputMixrampdelay").value=settings.mixrampdelay):document.getElementById("inputMixrampdelay").setAttribute("disabled","disabled");document.getElementById("selectReplaygain").value=
settings.replaygain;for(var a="featStickers featSmartpls featPlaylists featTags featCoverimage featAdvsearch featLove".split(" "),b=0;b<a.length;b++){var c=document.getElementsByClassName(a[b]),d=c.length,f=1==settings[a[b]]?"":"none";"featCoverimage"==a[b]&&0==settings.coverimage&&(f="none");for(var g=0;g<d;g++)c[g].style.display=f}0==settings.featPlaylists&&1==settings.smartpls?document.getElementById("warnSmartpls").classList.remove("hide"):document.getElementById("warnSmartpls").classList.add("hide");
0==settings.featStickers&&1==settings.stickers?document.getElementById("warnStickers").classList.remove("hide"):document.getElementById("warnStickers").classList.add("hide");0==settings.featLove&&1==settings.love?document.getElementById("warnScrobbler").classList.remove("hide"):document.getElementById("warnScrobbler").classList.add("hide");0==settings.featLibrary&&1==settings.coverimage?document.getElementById("warnAlbumart").classList.remove("hide"):document.getElementById("warnAlbumart").classList.add("hide");
""==settings.musicDirectoryValue&&"none"!=settings.musicDirectory?document.getElementById("warnMusicDirectory").classList.remove("hide"):document.getElementById("warnMusicDirectory").classList.add("hide");1==settings.bgCover&&1==settings.featCoverimage&&1==settings.coverimage?lastSongObj.data&&-1<lastSongObj.data.cover.indexOf("coverimage-")?clearBackgroundImage():lastSongObj.data?setBackgroundImage(lastSongObj.data.cover):clearBackgroundImage():clearBackgroundImage();if(0==settings.featTags)app.apps.Browse.active=
"Filesystem",app.apps.Search.state="0/filename/-/",app.apps.Queue.state="0/filename/-/",settings.colsQueueCurrent=["Pos","Title","Duration"],settings.colsQueueLastPlayed=["Pos","Title","LastPlayed"],settings.colsSearch=["Title","Duration"],settings.colsBrowseFilesystem=["Type","Title","Duration"],settings.colsBrowseDatabase=["Track","Title","Duration"],settings.colsPlayback=[];else{a="";for(g=0;g<settings.colsPlayback.length;g++)a+='<div id="current'+settings.colsPlayback[g]+'" data-tag="'+settings.colsPlayback[g]+
'" data-name="'+encodeURI(lastSongObj.data?lastSongObj.data[settings.colsPlayback[g]]:"")+'"><small>'+t(settings.colsPlayback[g])+"</small><h4",settings.browsetags.includes(settings.colsPlayback[g])&&(a+=' class="clickable"'),a+=">"+(lastSongObj.data?e(lastSongObj.data[settings.colsPlayback[g]]):"")+"</h4></div>";document.getElementById("cardPlaybackTags").innerHTML=a}!settings.tags.includes("AlbumArtist")&&settings.featTags&&(settings.tags.includes("Artist")?app.apps.Browse.tabs.Database.active=
"Artist":app.apps.Browse.tabs.Database.active=settings.tags[0]);settings.tags.includes("Title")&&(app.apps.Search.state="0/any/Title/");settings.featPlaylists?(playlistEl="selectJukeboxPlaylist",sendAPI({cmd:"MPD_API_PLAYLIST_LIST",data:{offset:0,filter:"-"}},getAllPlaylists)):document.getElementById("selectJukeboxPlaylist").innerHTML='<option value="Database">'+t("Database")+"</option>";settings.tags.sort();settings.searchtags.sort();settings.browsetags.sort();filterCols("colsSearch");filterCols("colsQueueCurrent");
filterCols("colsQueueLastPlayed");filterCols("colsBrowsePlaylistsDetail");filterCols("colsBrowseFilesystem");filterCols("colsBrowseDatabase");filterCols("colsPlayback");setCols("QueueCurrent");setCols("Search");setCols("QueueLastPlayed");setCols("BrowseFilesystem");setCols("BrowsePlaylistsDetail");setCols("BrowseDatabase",".tblAlbumTitles");setCols("Playback");addTagList("BrowseDatabaseByTagDropdown","browsetags");addTagList("searchqueuetags","searchtags");addTagList("searchtags","searchtags");for(g=
0;g<settings.tags.length;g++)app.apps.Browse.tabs.Database.views[settings.tags[g]]={state:"0/-/-/",scrollPos:0};initTagMultiSelect("inputEnabledTags","listEnabledTags",settings.allmpdtags,settings.tags);initTagMultiSelect("inputSearchTags","listSearchTags",settings.tags,settings.searchtags);initTagMultiSelect("inputBrowseTags","listBrowseTags",settings.tags,settings.browsetags)}
function initTagMultiSelect(a,b,c,d){for(var f="",g="",h=0;h<c.length;h++)d.includes(c[h])&&(f+=c[h]+", "),g+='<div class="form-check"><input class="form-check-input" type="checkbox" value="1" name="'+c[h]+'" '+(d.includes(c[h])?'checked="checked"':"")+'><label class="form-check-label" for="'+c[h]+'">&nbsp;&nbsp;'+t(c[h])+"</label></div>";document.getElementById(b).addEventListener("click",function(a){a.stopPropagation();if("INPUT"==a.target.nodeName){for(var b=a.target.parentNode.parentNode.getElementsByTagName("input"),
c="",d=0;d<b.length;d++)1==b[d].checked&&(c+=b[d].name+", ");a.target.parentNode.parentNode.parentNode.previousElementSibling.value=c.replace(/(,\s)$/,"")}});document.getElementById(a).value=f.replace(/(,\s)$/,"");document.getElementById(b).innerHTML=g}
function setCols(a,b){var c="",d=settings.tags.slice();0==settings.featTags&&d.push("Title");d.push("Duration");"QueueCurrent"!=a&&"BrowsePlaylistsDetail"!=a&&"QueueLastPlayed"!=a||d.push("Pos");"BrowseFilesystem"==a&&d.push("Type");"QueueLastPlayed"==a&&d.push("LastPlayed");d.sort();for(var f=0;f<d.length;f++)if("Playback"!=a||"Title"!=d[f])c+='<div class="form-check"><input class="form-check-input" type="checkbox" value="1" name="'+d[f]+'"',settings["cols"+a].includes(d[f])&&(c+="checked"),c+='><label class="form-check-label text-light" for="'+
d[f]+'">&nbsp;&nbsp;'+t(d[f])+"</label></div>";document.getElementById(a+"ColsDropdown").firstChild.innerHTML=c;d=app.current.sort;"Search"==a&&"0/any/Title/"==app.apps.Search.state&&(d=settings.tags.includes("Title")?"Title":0==settings.featTags?"Filename":"-");if("Playback"!=a){c="";for(f=0;f<settings["cols"+a].length;f++){var g=settings["cols"+a][f];c+='<th draggable="true" data-col="'+g+'">';if("Track"==g||"Pos"==g)g="#";c+=t(g);"Search"!=a||g!=d&&"-"+g!=d||(g=!1,0==app.current.sort.indexOf("-")&&
(g=!0),c+='<span class="sort-dir material-icons pull-right">'+(1==g?"arrow_drop_up":"arrow_drop_down")+"</span>");c+="</th>"}c+="<th></th>";if(void 0==b)document.getElementById(a+"List").getElementsByTagName("tr")[0].innerHTML=c;else for(a=document.querySelectorAll(b),f=0;f<a.length;f++)a[f].getElementsByTagName("tr")[0].innerHTML=c}}function getSettings(a){0==settingsLock&&(settingsLock=!0,sendAPI({cmd:"MYMPD_API_SETTINGS_GET"},getMpdSettings,a))}
function getMpdSettings(a){if(""==a||"error"==a.type)return settingsParsed="error",0==appInited&&showAppInitAlert(""==a?t("Can not parse settings"):a.data),!1;settingsNew=a.data;document.getElementById("splashScreenAlert").innerText=t("Fetch MPD settings");sendAPI({cmd:"MPD_API_SETTINGS_GET"},joinSettings,!0)}
function joinSettings(a){if(""==a||"error"==a.type)settingsParsed="error",0==appInited&&showAppInitAlert(""==a?t("Can not parse settings"):a.data),settingsNew.mpdConnected=!1;else for(var b in a.data)settingsNew[b]=a.data[b];settings=Object.assign({},settingsNew);settingsLock=!1;parseSettings();toggleUI()}
function saveCols(a,b){var c=document.getElementById(a+"ColsDropdown").firstChild.getElementsByTagName("input");var d=void 0==b?document.getElementById(a+"List").getElementsByTagName("tr")[0]:"string"==typeof b?document.querySelector(b).getElementsByTagName("tr")[0]:b.getElementsByTagName("tr")[0];for(b=0;b<c.length;b++){var f=d.querySelector("[data-col="+c[b].name+"]");0==c[b].checked?f&&f.remove():f||(f=document.createElement("th"),f.innerText=c[b].name,f.setAttribute("data-col",c[b].name),d.appendChild(f))}a=
{cmd:"MYMPD_API_COLS_SAVE",data:{table:"cols"+a,cols:[]}};c=d.getElementsByTagName("th");for(b=0;b<c.length;b++)(d=c[b].getAttribute("data-col"))&&a.data.cols.push(d);sendAPI(a,getSettings)}
function saveColsPlayback(a){for(var b=document.getElementById(a+"ColsDropdown").firstChild.getElementsByTagName("input"),c=document.getElementById("cardPlaybackTags"),d=0;d<b.length;d++){var f=document.getElementById("current"+b[d].name);0==b[d].checked?f&&f.remove():f||(f=document.createElement("div"),f.innerHTML="<small>"+t(b[d].name)+"</small><h4></h4>",f.setAttribute("id","current"+b[d].name),f.setAttribute("data-tag",b[d].name),c.appendChild(f))}a={cmd:"MYMPD_API_COLS_SAVE",data:{table:"cols"+
a,cols:[]}};c=c.getElementsByTagName("div");for(d=0;d<c.length;d++)(b=c[d].getAttribute("data-tag"))&&a.data.cols.push(b);sendAPI(a,getSettings)}
function saveConnection(){var a=!0,b=document.getElementById("inputMpdHost"),c=document.getElementById("inputMpdPort"),d=document.getElementById("inputMpdPass"),f=document.getElementById("selectMusicDirectory");f=f.options[f.selectedIndex].value;"custom"==f&&(f=document.getElementById("inputMusicDirectory"),validatePath(f)||(a=!1),f=f.value);""==c.value&&(c.value="6600");0!=b.value.indexOf("/")&&(validateInt(c)||(a=!1),validateHost(b)||(a=!1));1==a&&(sendAPI({cmd:"MYMPD_API_CONNECTION_SAVE",data:{mpdHost:b.value,
mpdPort:c.value,mpdPass:d.value,musicDirectory:f}},getSettings),modalConnection.hide())}function parseOutputs(a){for(var b="",c=a.data.outputs.length,d=0;d<c;d++)b+='<button id="btnOutput'+a.data.outputs[d].id+'" data-output-id="'+a.data.outputs[d].id+'" class="btn btn-secondary btn-block',1==a.data.outputs[d].state&&(b+=" active"),b+='"><span class="material-icons float-left">volume_up</span> '+e(a.data.outputs[d].name)+"</button>";domCache.outputs.innerHTML=b}
function setCounter(a,b,c){currentSong.totalTime=b;currentSong.elapsedTime=c;currentSong.currentSongId=a;domCache.progressBar.value=Math.floor(1E3*c/b);c=beautifySongDuration(c)+"&nbsp;/&nbsp;"+beautifySongDuration(b);domCache.counter.innerHTML=c;if(lastState&&lastState.data.currentSongId!=a&&(b=document.getElementById("queueTrackId"+lastState.data.currentSongId))){var d=b.querySelector("[data-col=Duration]");d&&(d.innerText=b.getAttribute("data-duration"));if(d=b.querySelector("[data-col=Pos]"))d.classList.remove("material-icons"),
d.innerText=b.getAttribute("data-songpos");b.classList.remove("font-weight-bold")}if(b=document.getElementById("queueTrackId"+a)){if(a=b.querySelector("[data-col=Duration]"))a.innerHTML=c;(a=b.querySelector("[data-col=Pos]"))&&!a.classList.contains("material-icons")&&(a.classList.add("material-icons"),a.innerText="play_arrow");b.classList.add("font-weight-bold")}progressTimer&&clearTimeout(progressTimer);"play"==playstate&&(progressTimer=setTimeout(function(){currentSong.elapsedTime++;requestAnimationFrame(function(){setCounter(currentSong.currentSongId,
currentSong.totalTime,currentSong.elapsedTime)})},1E3))}
function parseState(a){if(JSON.stringify(a)===JSON.stringify(lastState))toggleUI();else{parseUpdateQueue(a);parseVolume(a);setCounter(a.data.currentSongId,a.data.totalTime,a.data.elapsedTime);lastState&&lastState.data.currentSongId==a.data.currentSongId&&lastState.data.queueVersion==a.data.queueVersion||sendAPI({cmd:"MPD_API_PLAYER_CURRENT_SONG"},songChange);if("-1"==a.data.songPos){domCache.currentTitle.innerText="Not playing";document.title="myMPD";document.getElementById("headerTitle").innerText=
"";document.getElementById("headerTitle").removeAttribute("title");clearCurrentCover();1==settings.bgCover&&clearBackgroundImage();for(var b=document.getElementById("cardPlaybackTags").getElementsByTagName("h4"),c=0;c<b.length;c++)b[c].innerText=""}lastState=a;0!=settings.mpdConnected&&0!=uiEnabled||getSettings(!0)}}
function parseUpdateQueue(a){if(1==a.data.state){for(var b=0;b<domCache.btnsPlayLen;b++)domCache.btnsPlay[b].innerText="play_arrow";playstate="stop"}else if(2==a.data.state){for(b=0;b<domCache.btnsPlayLen;b++)domCache.btnsPlay[b].innerText="pause";playstate="play"}else{for(b=0;b<domCache.btnsPlayLen;b++)domCache.btnsPlay[b].innerText="play_arrow";playstate="pause"}if(0==a.data.queueLength)for(b=0;b<domCache.btnsPlayLen;b++)domCache.btnsPlay[b].setAttribute("disabled","disabled");else for(b=0;b<domCache.btnsPlayLen;b++)domCache.btnsPlay[b].removeAttribute("disabled");
domCache.badgeQueueItems.innerText=a.data.queueLength;-1==a.data.nextSongPos&&0==settings.jukeboxMode?domCache.btnNext.setAttribute("disabled","disabled"):domCache.btnNext.removeAttribute("disabled");0>=a.data.songPos?domCache.btnPrev.setAttribute("disabled","disabled"):domCache.btnPrev.removeAttribute("disabled")}
function parseVolume(a){-1==a.data.volume?(domCache.volumePrct.innerText=t("Volumecontrol disabled"),domCache.volumeControl.classList.add("hide")):(domCache.volumeControl.classList.remove("hide"),domCache.volumePrct.innerText=a.data.volume+" %",domCache.volumeMenu.innerText=0==a.data.volume?"volume_off":50>a.data.volume?"volume_down":"volume_up");domCache.volumeBar.value=a.data.volume}
function getQueue(){2<=app.current.search.length?sendAPI({cmd:"MPD_API_QUEUE_SEARCH",data:{filter:app.current.filter,offset:app.current.page,searchstr:app.current.search,cols:settings.colsQueueCurrent}},parseQueue):sendAPI({cmd:"MPD_API_QUEUE_LIST",data:{offset:app.current.page,cols:settings.colsQueueCurrent}},parseQueue)}
function replaceTblRow(a,b){var c=!1;a.querySelector("[data-popover]")&&hideMenu();a.classList.contains("selected")&&(b.classList.add("selected"),b.focus(),c=!0);a.replaceWith(b);return c}
function parseQueue(a){"undefined"!=typeof a.totalTime&&0<a.totalTime&&a.totalEntities<=settings.maxElementsPerPage?document.getElementById("cardFooterQueue").innerText=t("Num songs",a.totalEntities)+" \u2013 "+beautifyDuration(a.totalTime):0<a.totalEntities?document.getElementById("cardFooterQueue").innerText=t("Num songs",a.totalEntities):document.getElementById("cardFooterQueue").innerText="";var b=a.data.length,c=document.getElementById("QueueCurrentList"),d=document.activeElement.parentNode.parentNode==
c?!0:!1,f=0;c.setAttribute("data-version",a.queueVersion);c=c.getElementsByTagName("tbody")[0];for(var g=c.getElementsByTagName("tr"),h=0;h<b;h++){a.data[h].Duration=beautifySongDuration(a.data[h].Duration);a.data[h].Pos++;var l=document.createElement("tr");l.setAttribute("draggable","true");l.setAttribute("data-trackid",a.data[h].id);l.setAttribute("id","queueTrackId"+a.data[h].id);l.setAttribute("data-songpos",a.data[h].Pos);l.setAttribute("data-duration",a.data[h].Duration);l.setAttribute("data-uri",
a.data[h].uri);l.setAttribute("tabindex",0);for(var k="",m=0;m<settings.colsQueueCurrent.length;m++)k+='<td data-col="'+settings.colsQueueCurrent[m]+'">'+e(a.data[h][settings.colsQueueCurrent[m]])+"</td>";k+='<td data-col="Action"><a href="#" class="material-icons color-darkgrey">playlist_add</a></td>';l.innerHTML=k;h<g.length?f=1==replaceTblRow(g[h],l)?h:f:c.append(l)}for(h=g.length-1;h>=b;h--)g[h].remove();g=settings.colsQueueCurrent.length;g--;"queuesearch"==a.type&&0==b?c.innerHTML='<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+
g+'">'+t("No results, please refine your search")+"</td></tr>":"queue"==a.type&&0==b&&(c.innerHTML='<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+g+'">'+t("Empty queue")+"</td></tr>");1==d&&focusTable(f);setPagination(a.totalEntities,a.returnedEntities);document.getElementById("QueueCurrentList").classList.remove("opacity05")}
function parseLastPlayed(a){document.getElementById("cardFooterQueue").innerText=t("Num songs",a.totalEntities);var b=a.data.length,c=document.getElementById("QueueLastPlayedList"),d=document.activeElement.parentNode.parentNode==c?!0:!1,f=0;c=c.getElementsByTagName("tbody")[0];for(var g=c.getElementsByTagName("tr"),h=0;h<b;h++){a.data[h].Duration=beautifySongDuration(a.data[h].Duration);a.data[h].LastPlayed=localeDate(a.data[h].LastPlayed);var l=document.createElement("tr");l.setAttribute("data-uri",
a.data[h].uri);l.setAttribute("data-name",a.data[h].Title);l.setAttribute("data-type","song");l.setAttribute("tabindex",0);for(var k="",m=0;m<settings.colsQueueLastPlayed.length;m++)k+='<td data-col="'+settings.colsQueueLastPlayed[m]+'">'+e(a.data[h][settings.colsQueueLastPlayed[m]])+"</td>";k+='<td data-col="Action">';""!=a.data[h].uri&&(k+='<a href="#" class="material-icons color-darkgrey">playlist_add</a>');k+="</td>";l.innerHTML=k;h<g.length?f=1==replaceTblRow(g[h],l)?h:f:c.append(l)}for(h=g.length-
1;h>=b;h--)g[h].remove();g=settings.colsQueueLastPlayed.length;g--;0==b&&(c.innerHTML='<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+g+'">'+t("Empty list")+"</td></tr>");1==d&&focusTable(f);setPagination(a.totalEntities,a.returnedEntities);document.getElementById("QueueLastPlayedList").classList.remove("opacity05")}
function parseSearch(a){document.getElementById("panel-heading-search").innerText=gtPage("Num songs",a.returnedEntities,a.totalEntities);document.getElementById("cardFooterSearch").innerText=gtPage("Num songs",a.returnedEntities,a.totalEntities);0<a.returnedEntities?(document.getElementById("searchAddAllSongs").removeAttribute("disabled"),document.getElementById("searchAddAllSongsBtn").removeAttribute("disabled")):(document.getElementById("searchAddAllSongs").setAttribute("disabled","disabled"),document.getElementById("searchAddAllSongsBtn").setAttribute("disabled",
"disabled"));parseFilesystem(a)}
function parseFilesystem(a){var b=app.current.app+("Filesystem"==app.current.tab?app.current.tab:""),c=settings["cols"+b].length;c--;var d=a.data.length,f=document.getElementById(app.current.app+(void 0==app.current.tab?"":app.current.tab)+"List"),g=f.getElementsByTagName("tbody")[0],h=g.getElementsByTagName("tr");f=document.activeElement.parentNode.parentNode==f?!0:!1;for(var l=0,k=0;k<d;k++){var m=encodeURI(a.data[k].uri),p=document.createElement("tr"),n="";p.setAttribute("data-type",a.data[k].Type);
p.setAttribute("data-uri",m);p.setAttribute("tabindex",0);"song"==a.data[k].Type?p.setAttribute("data-name",a.data[k].Title):p.setAttribute("data-name",a.data[k].name);switch(a.data[k].Type){case "dir":case "smartpls":case "plist":for(m=0;m<settings["cols"+b].length;m++)n+='<td data-col="'+settings["cols"+b][m]+'">',"Type"==settings["cols"+b][m]?n="dir"==a.data[k].Type?n+'<span class="material-icons">folder_open</span>':n+('<span class="material-icons">'+("smartpls"==a.data[k].Type?"queue_music":
"list")+"</span>"):"Title"==settings["cols"+b][m]&&(n+=e(a.data[k].name)),n+="</td>";n+='<td data-col="Action"><a href="#" class="material-icons color-darkgrey">playlist_add</a></td>';p.innerHTML=n;break;case "song":a.data[k].Duration=beautifySongDuration(a.data[k].Duration);for(m=0;m<settings["cols"+b].length;m++)n+='<td data-col="'+settings["cols"+b][m]+'">',n="Type"==settings["cols"+b][m]?n+'<span class="material-icons">music_note</span>':n+e(a.data[k][settings["cols"+b][m]]),n+="</td>";n+='<td data-col="Action"><a href="#" class="material-icons color-darkgrey">playlist_add</a></td>';
p.innerHTML=n}k<h.length?l=1==replaceTblRow(h[k],p)?k:l:g.append(p)}for(k=h.length-1;k>=d;k--)h[k].remove();1==f&&focusTable(0);setPagination(a.totalEntities,a.returnedEntities);0==d&&(g.innerHTML='<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+c+'">'+t("Empty list")+"</td></tr>");document.getElementById(app.current.app+(void 0==app.current.tab?"":app.current.tab)+"List").classList.remove("opacity05");document.getElementById("cardFooterBrowse").innerText=t("Num entries",
a.totalEntities)}
function parsePlaylists(a){"All"==app.current.view?(document.getElementById("BrowsePlaylistsAllList").classList.remove("hide"),document.getElementById("BrowsePlaylistsDetailList").classList.add("hide"),document.getElementById("btnBrowsePlaylistsAll").parentNode.classList.add("hide"),document.getElementById("btnPlaylistClear").parentNode.classList.add("hide"),document.getElementById("BrowsePlaylistsDetailColsBtn").parentNode.classList.add("hide")):(-1<a.uri.indexOf(".")||1==a.smartpls?(document.getElementById("BrowsePlaylistsDetailList").setAttribute("data-ro",
"true"),document.getElementById("btnPlaylistClear").parentNode.classList.add("hide")):(document.getElementById("BrowsePlaylistsDetailList").setAttribute("data-ro","false"),document.getElementById("btnPlaylistClear").parentNode.classList.remove("hide")),document.getElementById("BrowsePlaylistsDetailList").setAttribute("data-uri",a.uri),document.getElementById("BrowsePlaylistsDetailList").getElementsByTagName("caption")[0].innerHTML=(1==a.smartpls?t("Smart playlist"):t("Playlist"))+": "+a.uri,document.getElementById("BrowsePlaylistsDetailList").classList.remove("hide"),
document.getElementById("BrowsePlaylistsAllList").classList.add("hide"),document.getElementById("btnBrowsePlaylistsAll").parentNode.classList.remove("hide"),settings.featTags&&document.getElementById("BrowsePlaylistsDetailColsBtn").parentNode.classList.remove("hide"));var b=a.data.length,c=document.getElementById(app.current.app+app.current.tab+app.current.view+"List"),d=c.getElementsByTagName("tbody")[0],f=d.getElementsByTagName("tr");c=document.activeElement.parentNode.parentNode==c?!0:!1;var g=
0;if("All"==app.current.view){for(var h=0;h<b;h++){var l=encodeURI(a.data[h].uri),k=document.createElement("tr");k.setAttribute("data-uri",l);k.setAttribute("data-type",a.data[h].Type);k.setAttribute("data-name",a.data[h].name);k.setAttribute("tabindex",0);k.innerHTML='<td data-col="Type"><span class="material-icons">'+("smartpls"==a.data[h].Type?"queue_music":"list")+"</span></td><td>"+e(a.data[h].name)+"</td><td>"+localeDate(a.data[h].last_modified)+'</td><td data-col="Action"><a href="#" class="material-icons color-darkgrey">playlist_add</a></td>';
h<f.length?g=1==replaceTblRow(f[h],k)?h:g:d.append(k)}document.getElementById("cardFooterBrowse").innerText=gtPage("Num playlists",a.returnedEntities,a.totalEntities)}else if("Detail"==app.current.view){for(h=0;h<b;h++){k=encodeURI(a.data[h].uri);l=document.createElement("tr");0==a.smartpls&&l.setAttribute("draggable","true");l.setAttribute("id","playlistTrackId"+a.data[h].Pos);l.setAttribute("data-type",a.data[h].Type);l.setAttribute("data-uri",k);l.setAttribute("data-name",a.data[h].Title);l.setAttribute("data-songpos",
a.data[h].Pos);l.setAttribute("tabindex",0);a.data[h].Duration=beautifySongDuration(a.data[h].Duration);k="";for(var m=0;m<settings.colsBrowsePlaylistsDetail.length;m++)k+='<td data-col="'+settings.colsBrowsePlaylistsDetail[m]+'">'+e(a.data[h][settings.colsBrowsePlaylistsDetail[m]])+"</td>";k+='<td data-col="Action"><a href="#" class="material-icons color-darkgrey">playlist_add</a></td>';l.innerHTML=k;h<f.length?g=1==replaceTblRow(f[h],l)?h:g:d.append(l)}document.getElementById("cardFooterBrowse").innerText=
gtPage("Num songs",a.returnedEntities,a.totalEntities)}for(h=f.length-1;h>=b;h--)f[h].remove();1==c&&focusTable(0);setPagination(a.totalEntities,a.returnedEntities);0==b&&(a=settings["cols"+list].length,a--,d.innerHTML="All"==app.current.view?'<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+a+'">'+t("No playlists found")+"</td></tr>":'<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+a+'">'+t("Empty playlist")+"</td></tr>");document.getElementById(app.current.app+
app.current.tab+app.current.view+"List").classList.remove("opacity05")}
function parseListDBtags(a){scrollTo(0);if(""!=app.current.search){document.getElementById("BrowseDatabaseAlbumList").classList.remove("hide");document.getElementById("BrowseDatabaseTagList").classList.add("hide");document.getElementById("btnBrowseDatabaseByTag").parentNode.classList.add("hide");document.getElementById("btnBrowseDatabaseTag").parentNode.classList.remove("hide");document.getElementById("BrowseDatabaseAddAllSongs").parentNode.parentNode.classList.remove("hide");document.getElementById("BrowseDatabaseColsBtn").parentNode.classList.remove("hide");
document.getElementById("btnBrowseDatabaseTag").innerHTML="&laquo; "+t(app.current.view);document.getElementById("BrowseDatabaseAlbumListCaption").innerHTML="<h2>"+t(a.searchtagtype)+": "+e(a.searchstr)+"</h2><hr/>";document.getElementById("cardFooterBrowse").innerText=t("Num entries",a.totalEntities);for(var b=a.data.length,c=document.getElementById("BrowseDatabaseAlbumList"),d=c.getElementsByClassName("card"),f=0;f<b;f++){var g=genId(a.data[f].value),h=document.createElement("div");h.classList.add("card",
"ml-4","mr-4","mb-4","w-100");h.setAttribute("id","card"+g);h.setAttribute("data-album",encodeURI(a.data[f].value));var l='<div class="card-header"><span id="albumartist'+g+'"></span> &ndash; '+e(a.data[f].value)+'</div><div class="card-body"><div class="row">';1==settings.featCoverimage&&1==settings.coverimage&&(l+='<div class="col-md-auto"><a class="card-img-left"></a></div>');l+='<div class="col"><table class="tblAlbumTitles table table-sm table-hover" tabindex="0" id="tbl'+g+'"><thead><tr></tr></thead><tbody></tbody><tfoot class="bg-light border-bottom"></tfoot></table></div></div></div></div><div class="card-footer"></div>';
h.innerHTML=l;f<d.length?d[f].replaceWith(h):c.append(h);"IntersectionObserver"in window?createListTitleObserver(document.getElementById("card"+g)):sendAPI({cmd:"MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST",data:{album:a.data[f].value,search:app.current.search,tag:app.current.view,cols:settings.colsBrowseDatabase}},parseListTitles)}for(f=d.length-1;f>=b;f--)d[f].remove();setPagination(a.totalEntities,a.returnedEntities);setCols("BrowseDatabase",".tblAlbumTitles");a=document.querySelectorAll(".tblAlbumTitles");
for(f=0;f<a.length;f++)dragAndDropTableHeader(a[f]);document.getElementById("BrowseDatabaseAlbumList").classList.remove("opacity05")}else{document.getElementById("BrowseDatabaseAlbumList").classList.add("hide");document.getElementById("BrowseDatabaseTagList").classList.remove("hide");document.getElementById("btnBrowseDatabaseByTag").parentNode.classList.remove("hide");document.getElementById("BrowseDatabaseAddAllSongs").parentNode.parentNode.classList.add("hide");document.getElementById("BrowseDatabaseColsBtn").parentNode.classList.add("hide");
document.getElementById("btnBrowseDatabaseTag").parentNode.classList.add("hide");document.getElementById("BrowseDatabaseTagListCaption").innerText=app.current.view;document.getElementById("cardFooterBrowse").innerText=a.totalEntities+" Tags";b=a.data.length;f=document.getElementById(app.current.app+app.current.tab+"TagList");c=f.getElementsByTagName("tbody")[0];d=document.activeElement.parentNode.parentNode==f?!0:!1;g=0;h=c.getElementsByTagName("tr");for(f=0;f<b;f++){l=encodeURI(a.data[f].value);
var k=document.createElement("tr");k.setAttribute("data-uri",l);k.setAttribute("tabindex",0);k.innerHTML='<td data-col="Type"><span class="material-icons">album</span></td><td>'+e(a.data[f].value)+"</td>";f<h.length?g=1==replaceTblRow(h[f],k)?f:g:c.append(k)}for(f=h.length-1;f>=b;f--)h[f].remove();1==d&&focusTable(0);setPagination(a.totalEntities,a.returnedEntities);0==b&&(c.innerHTML='<tr><td><span class="material-icons">error_outline</span></td><td>No entries found.</td></tr>');document.getElementById("BrowseDatabaseTagList").classList.remove("opacity05")}}
function createListTitleObserver(a){(new IntersectionObserver(getListTitles,{root:null,rootMargin:"0px"})).observe(a)}function getListTitles(a,b){a.forEach(function(a){0<a.intersectionRatio&&(b.unobserve(a.target),a=decodeURI(a.target.getAttribute("data-album")),sendAPI({cmd:"MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST",data:{album:a,search:app.current.search,tag:app.current.view,cols:settings.colsBrowseDatabase}},parseListTitles))})}
function parseListTitles(a){var b=genId(a.Album),c=document.getElementById("card"+b),d=c.getElementsByTagName("table")[0],f=c.getElementsByTagName("tbody")[0],g=c.querySelector(".card-footer"),h=c.querySelector(".card-header");h.setAttribute("data-uri",encodeURI(a.data[0].uri.replace(/\/[^\/]+$/,"")));h.setAttribute("data-name",a.Album);h.setAttribute("data-type","dir");h.addEventListener("click",function(a){showMenu(this,a)},!1);h.classList.add("clickable");d.addEventListener("keydown",function(a){navigateTable(this,
a.key)},!1);if(c=c.getElementsByTagName("a")[0])c.style.backgroundImage='url("'+subdir+a.cover+'"), url("'+subdir+'/assets/coverimage-loading.png")',c.setAttribute("data-uri",encodeURI(a.data[0].uri.replace(/\/[^\/]+$/,""))),c.setAttribute("data-name",a.Album),c.setAttribute("data-type","dir"),c.addEventListener("click",function(a){showMenu(this,a)},!1);document.getElementById("albumartist"+b).innerText=a.AlbumArtist;b="";c=a.data.length;for(d=0;d<c;d++){a.data[d].Duration&&(a.data[d].Duration=beautifySongDuration(a.data[d].Duration));
b+='<tr tabindex="0" data-type="song" data-name="'+a.data[d].Title+'" data-uri="'+encodeURI(a.data[d].uri)+'">';for(h=0;h<settings.colsBrowseDatabase.length;h++)b+='<td data-col="'+settings.colsBrowseDatabase[h]+'">'+e(a.data[d][settings.colsBrowseDatabase[h]])+"</td>";b+='<td data-col="Action"><a href="#" class="material-icons color-darkgrey">playlist_add</a></td></tr>'}f.innerHTML=b;g.innerHTML=t("Num songs",a.totalEntities)+" &ndash; "+beautifyDuration(a.totalTime);f.parentNode.addEventListener("click",
function(a){"TD"==a.target.nodeName?appendQueue("song",decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name")):"A"==a.target.nodeName&&showMenu(a.target,a)},!1)}
function setPagination(a,b){var c=app.current.app+(void 0==app.current.tab?"":app.current.tab),d=Math.ceil(a/settings.maxElementsPerPage);0==d&&(d=1);for(var f=["PaginationTop","PaginationBottom"],g=0;2>g;g++){document.getElementById(c+f[g]+"Page").innerText=app.current.page/settings.maxElementsPerPage+1+" / "+d;if(1<d){document.getElementById(c+f[g]+"Page").removeAttribute("disabled");for(var h="",l=0;l<d;l++)h+='<button data-page="'+l*settings.maxElementsPerPage+'" type="button" class="mr-1 mb-1 btn-sm btn btn-secondary">'+
(l+1)+"</button>";document.getElementById(c+f[g]+"Pages").innerHTML=h;document.getElementById(c+f[g]+"Page").classList.remove("nodropdown")}else-1==a?(document.getElementById(c+f[g]+"Page").setAttribute("disabled","disabled"),document.getElementById(c+f[g]+"Page").innerText=app.current.page/settings.maxElementsPerPage+1):document.getElementById(c+f[g]+"Page").setAttribute("disabled","disabled"),document.getElementById(c+f[g]+"Page").classList.add("nodropdown");a>app.current.page+settings.maxElementsPerPage||
-1==a&&b>=settings.maxElementsPerPage?(document.getElementById(c+f[g]+"Next").removeAttribute("disabled"),document.getElementById(c+f[g]).classList.remove("hide"),document.getElementById(c+"ButtonsBottom").classList.remove("hide")):(document.getElementById(c+f[g]+"Next").setAttribute("disabled","disabled"),document.getElementById(c+f[g]).classList.add("hide"),document.getElementById(c+"ButtonsBottom").classList.add("hide"));0<app.current.page?(document.getElementById(c+f[g]+"Prev").removeAttribute("disabled"),
document.getElementById(c+f[g]).classList.remove("hide"),document.getElementById(c+"ButtonsBottom").classList.remove("hide")):document.getElementById(c+f[g]+"Prev").setAttribute("disabled","disabled")}}
function queueSelectedItem(a){var b=document.activeElement;b&&"QueueCurrentList"!=b.parentNode.parentNode.id&&(1==a?appendQueue(b.getAttribute("data-type"),b.getAttribute("data-uri"),b.getAttribute("data-name")):replaceQueue(b.getAttribute("data-type"),b.getAttribute("data-uri"),b.getAttribute("data-name")))}function dequeueSelectedItem(){var a=document.activeElement;a&&"QueueCurrentList"==a.parentNode.parentNode.id&&delQueueSong("single",a.getAttribute("data-trackid"))}
function addSelectedItemToPlaylist(){var a=document.activeElement;a&&"BrowsePlaylistsAllList"!=a.parentNode.parentNode.id&&showAddToPlaylist(a.getAttribute("data-uri"))}
function appendQueue(a,b,c){switch(a){case "song":case "dir":sendAPI({cmd:"MPD_API_QUEUE_ADD_TRACK",data:{uri:b}});showNotification(t("%{name} added to queue",{name:c}),"","","success");break;case "plist":sendAPI({cmd:"MPD_API_QUEUE_ADD_PLAYLIST",data:{plist:b}}),showNotification(t("%{name} added to queue",{name:c}),"","","success")}}
function appendAfterQueue(a,b,c,d){switch(a){case "song":sendAPI({cmd:"MPD_API_QUEUE_ADD_TRACK_AFTER",data:{uri:b,to:c}}),c++,showNotification(t("%{name} added to queue position %{to}",{name:d,to:c}),"","","success")}}
function replaceQueue(a,b,c){switch(a){case "song":case "dir":sendAPI({cmd:"MPD_API_QUEUE_REPLACE_TRACK",data:{uri:b}});showNotification(t("Queue replaced with %{name}",{name:c}),"","","success");break;case "plist":sendAPI({cmd:"MPD_API_QUEUE_REPLACE_PLAYLIST",data:{plist:b}}),showNotification(t("Queue replaced with %{name}",{name:c}),"","","success")}}function clickTitle(){var a=decodeURI(domCache.currentTitle.getAttribute("data-uri"));""!=a&&songDetails(a)}
function gotoBrowse(a){var b=a.parentNode.getAttribute("data-tag");a=decodeURI(a.parentNode.getAttribute("data-name"));""!=b&&""!=a&&"-"!=a&&settings.browsetags.includes(b)&&appGoto("Browse","Database",b,"0/-/-/"+a)}function songDetails(a){sendAPI({cmd:"MPD_API_DATABASE_SONGDETAILS",data:{uri:a}},parseSongDetails);modalSongDetails.show()}
function parseFingerprint(a){var b=document.createElement("textarea");b.value=a.data.fingerprint;b.classList.add("form-control","text-monospace","small");a=document.getElementById("fingerprint");a.innerHTML="";a.appendChild(b)}
function parseSongDetails(a){var b=document.getElementById("modalSongDetails");b.getElementsByClassName("album-cover")[0].style.backgroundImage='url("'+subdir+a.data.cover+'"), url("'+subdir+'/assets/coverimage-loading.png")';b.getElementsByTagName("h1")[0].innerText=a.data.Title;for(var c="",d=0;d<settings.tags.length;d++)"Title"!=settings.tags[d]&&(c+="<tr><th>"+t(settings.tags[d])+'</th><td data-tag="'+settings.tags[d]+'" data-name="'+encodeURI(a.data[settings.tags[d]])+'">',c=settings.browsetags.includes(settings.tags[d])?
c+('<a class="text-success" href="#">'+e(a.data[settings.tags[d]])+"</a>"):c+a.data[settings.tags[d]],c+="</td></tr>");c+="<tr><th>"+t("Duration")+"</th><td>"+beautifyDuration(a.data.Duration)+"</td></tr>";c=settings.featLibrary?c+("<tr><th>"+t("Filename")+'</th><td><a class="breakAll text-success" href="/library/'+encodeURI(a.data.uri)+'" download>'+e(a.data.uri)+"</a></td></tr>"):c+("<tr><th>"+t("Filename")+'</th><td class="breakAll">'+e(a.data.uri)+"</td></tr>");1==settings.featFingerprint&&(c+=
"<tr><th>"+t("Fingerprint")+'</th><td class="breakAll" id="fingerprint"><a class="text-success" data-uri="'+encodeURI(a.data.uri)+'" id="calcFingerprint" href="#">'+t("Calculate")+"</a></td></tr>");1==settings.featStickers&&(c+='<tr><th colspan="2" class="pt-3"><h5>'+t("Statistics")+"</h5></th></tr><tr><th>"+t("Play count")+"</th><td>"+a.data.playCount+"</td></tr><tr><th>"+t("Skip count")+"</th><td>"+a.data.skipCount+"</td></tr><tr><th>"+t("Last played")+"</th><td>"+(0==a.data.lastPlayed?t("never"):
localeDate(a.data.lastPlayed))+"</td></tr><tr><th>"+t("Last skipped")+"</th><td>"+(0==a.data.lastSkipped?t("never"):localeDate(a.data.lastSkipped))+"</td></tr><tr><th>"+t("Like")+'</th><td><div class="btn-group btn-group-sm"><button title="'+t("Dislike song")+'" id="btnVoteDown2" data-href=\'{"cmd": "voteSong", "options": [0]}\' class="btn btn-sm btn-light material-icons">thumb_down</button><button title="'+t("Like song")+'" id="btnVoteUp2" data-href=\'{"cmd": "voteSong", "options": [2]}\' class="btn btn-sm btn-light material-icons">thumb_up</button></div></td></tr>');
b.getElementsByTagName("tbody")[0].innerHTML=c;setVoteSongBtns(a.data.like,a.data.uri)}function execSyscmd(a){sendAPI({cmd:"MYMPD_API_SYSCMD",data:{cmd:a}})}function playlistDetails(a){document.getElementById("BrowsePlaylistsAllList").classList.add("opacity05");appGoto("Browse","Playlists","Detail","0/-/-/"+a)}function removeFromPlaylist(a,b){b--;sendAPI({cmd:"MPD_API_PLAYLIST_RM_TRACK",data:{uri:a,track:b}});document.getElementById("BrowsePlaylistsDetailList").classList.add("opacity05")}
function playlistClear(){var a=document.getElementById("BrowsePlaylistsDetailList").getAttribute("data-uri");sendAPI({cmd:"MPD_API_PLAYLIST_CLEAR",data:{uri:a}});document.getElementById("BrowsePlaylistsDetailList").classList.add("opacity05")}
function getAllPlaylists(a){var b=a.data.length,c="";if(0==a.offset)if("addToPlaylistPlaylist"==playlistEl)c='<option value=""></option><option value="new">'+t("New playlist")+"</option>";else if("selectJukeboxPlaylist"==playlistEl||"selectAddToQueuePlaylist"==playlistEl)c='<option value="Database">'+t("Database")+"</option>";for(var d=0;d<b;d++)if("addToPlaylistPlaylist"!=playlistEl||"smartpls"!=a.data[d].Type)c+='<option value="'+e(a.data[d].uri)+'"',"selectJukeboxPlaylist"==playlistEl&&a.data[d].uri==
settings.jukeboxPlaylist&&(c+=" selected"),c+=">"+e(a.data[d].uri)+"</option>";0==a.offset?document.getElementById(playlistEl).innerHTML=c:document.getElementById(playlistEl).innerHTML+=c;a.totalEntities>a.returnedEntities&&(a.offset+=settings.maxElementsPerPage,sendAPI({cmd:"MPD_API_PLAYLIST_LIST",data:{offset:a.offset,filter:"-"}},getAllPlaylists))}function updateSmartPlaylists(){sendAPI({cmd:"MPD_API_SMARTPLS_UPDATE_ALL"})}function loveSong(){sendAPI({cmd:"MPD_API_LOVE",data:{}})}
function voteSong(a){var b=decodeURI(domCache.currentTitle.getAttribute("data-uri"));""!=b&&(2==a&&domCache.btnVoteUp.classList.contains("active-fg-green")?a=1:0==a&&domCache.btnVoteDown.classList.contains("active-fg-red")&&(a=1),sendAPI({cmd:"MPD_API_LIKE",data:{uri:b,like:a}}),setVoteSongBtns(a,b))}
function setVoteSongBtns(a,b){domCache.btnVoteUp2=document.getElementById("btnVoteUp2");domCache.btnVoteDown2=document.getElementById("btnVoteDown2");""==b||-1<b.indexOf("://")?(domCache.btnVoteUp.setAttribute("disabled","disabled"),domCache.btnVoteDown.setAttribute("disabled","disabled"),domCache.btnVoteUp2&&(domCache.btnVoteUp2.setAttribute("disabled","disabled"),domCache.btnVoteDown2.setAttribute("disabled","disabled"))):(domCache.btnVoteUp.removeAttribute("disabled"),domCache.btnVoteDown.removeAttribute("disabled"),
domCache.btnVoteUp2&&(domCache.btnVoteUp2.removeAttribute("disabled"),domCache.btnVoteDown2.removeAttribute("disabled")));0==a?(domCache.btnVoteUp.classList.remove("active-fg-green"),domCache.btnVoteDown.classList.add("active-fg-red"),domCache.btnVoteUp2&&(domCache.btnVoteUp2.classList.remove("active-fg-green"),domCache.btnVoteDown2.classList.add("active-fg-red"))):1==a?(domCache.btnVoteUp.classList.remove("active-fg-green"),domCache.btnVoteDown.classList.remove("active-fg-red"),domCache.btnVoteUp2&&
(domCache.btnVoteUp2.classList.remove("active-fg-green"),domCache.btnVoteDown2.classList.remove("active-fg-red"))):2==a&&(domCache.btnVoteUp.classList.add("active-fg-green"),domCache.btnVoteDown.classList.remove("active-fg-red"),domCache.btnVoteUp2&&(domCache.btnVoteUp2.classList.add("active-fg-green"),domCache.btnVoteDown2.classList.remove("active-fg-red")))}
function toggleAddToPlaylistFrm(){var a=document.getElementById("toggleAddToPlaylistBtn");toggleBtn("toggleAddToPlaylistBtn");a.classList.contains("active")?(document.getElementById("addToPlaylistFrm").classList.remove("hide"),document.getElementById("addStreamFooter").classList.add("hide"),document.getElementById("addToPlaylistFooter").classList.remove("hide")):(document.getElementById("addToPlaylistFrm").classList.add("hide"),document.getElementById("addStreamFooter").classList.remove("hide"),document.getElementById("addToPlaylistFooter").classList.add("hide"))}
function saveSearchAsSmartPlaylist(){parseSmartPlaylist({type:"smartpls",data:{playlist:"",type:"search",tag:app.current.filter,searchstr:app.current.search}})}
function parseSmartPlaylist(a){var b=document.getElementById("saveSmartPlaylistName");b.value=a.data.playlist;b.classList.remove("is-invalid");document.getElementById("saveSmartPlaylistType").value=a.data.type;document.getElementById("saveSmartPlaylistSearch").classList.add("hide");document.getElementById("saveSmartPlaylistSticker").classList.add("hide");document.getElementById("saveSmartPlaylistNewest").classList.add("hide");var c;settings.featTags&&(c='<option value="any">'+t("Any Tag")+"</option>");
c+='<option value="filename">'+t("Filename")+"</option>";for(var d=0;d<settings.searchtags.length;d++)c+='<option value="'+settings.searchtags[d]+'">'+t(settings.searchtags[d])+"</option>";document.getElementById("selectSaveSmartPlaylistTag").innerHTML=c;"search"==a.data.type?(document.getElementById("saveSmartPlaylistSearch").classList.remove("hide"),document.getElementById("selectSaveSmartPlaylistTag").value=a.data.tag,document.getElementById("inputSaveSmartPlaylistSearchstr").value=a.data.searchstr,
settings.featAdvsearch?(document.getElementById("selectSaveSmartPlaylistTag").parentNode.classList.add("hide"),document.getElementById("inputSaveSmartPlaylistSearchstr").parentNode.classList.replace("col-md-6","col-md-12")):(document.getElementById("selectSaveSmartPlaylistTag").parentNode.classList.remove("hide"),document.getElementById("inputSaveSmartPlaylistSearchstr").parentNode.classList.replace("col-md-12","col-md-6"))):"sticker"==a.data.type?(document.getElementById("saveSmartPlaylistSticker").classList.remove("hide"),
document.getElementById("selectSaveSmartPlaylistSticker").value=a.data.sticker,document.getElementById("inputSaveSmartPlaylistStickerMaxentries").value=a.data.maxentries):"newest"==a.data.type&&(document.getElementById("saveSmartPlaylistNewest").classList.remove("hide"),a=a.data.timerange/24/60/60,document.getElementById("inputSaveSmartPlaylistNewestTimerange").value=a);modalSaveSmartPlaylist.show();b.focus()}
function saveSmartPlaylist(){var a=document.getElementById("saveSmartPlaylistName").value,b=document.getElementById("saveSmartPlaylistType").value;if(1==validatePlname(a)){if("search"==b){var c=document.getElementById("selectSaveSmartPlaylistTag");c=c.options[c.selectedIndex].value;settings.featAdvsearch&&(c="expression");var d=document.getElementById("inputSaveSmartPlaylistSearchstr").value;sendAPI({cmd:"MPD_API_SMARTPLS_SAVE",data:{type:b,playlist:a,tag:c,searchstr:d}})}else if("sticker"==b){c=
document.getElementById("selectSaveSmartPlaylistSticker");c=c.options[c.selectedIndex].value;d=document.getElementById("inputSaveSmartPlaylistStickerMaxentries");if(!validateInt(d))return;sendAPI({cmd:"MPD_API_SMARTPLS_SAVE",data:{type:b,playlist:a,sticker:c,maxentries:d.value}})}else if("newest"==b){c=document.getElementById("inputSaveSmartPlaylistNewestTimerange");if(!validateInt(c))return;c=86400*parseInt(c.value);sendAPI({cmd:"MPD_API_SMARTPLS_SAVE",data:{type:b,playlist:a,timerange:c}})}else{document.getElementById("saveSmartPlaylistType").classList.add("is-invalid");
return}modalSaveSmartPlaylist.hide();showNotification(t("Saved smart playlist %{name}",{name:a}),"","","success")}else document.getElementById("saveSmartPlaylistName").classList.add("is-invalid")}
function showAddToPlaylist(a){document.getElementById("addToPlaylistUri").value=a;document.getElementById("addToPlaylistPlaylist").innerHTML="";document.getElementById("addToPlaylistNewPlaylist").value="";document.getElementById("addToPlaylistNewPlaylistDiv").classList.add("hide");document.getElementById("addToPlaylistNewPlaylist").classList.remove("is-invalid");toggleBtn("toggleAddToPlaylistBtn",0);var b=document.getElementById("streamUrl");b.focus();b.value="";b.classList.remove("is-invalid");"stream"!=
a?(document.getElementById("addStreamFooter").classList.add("hide"),document.getElementById("addStreamFrm").classList.add("hide"),document.getElementById("addToPlaylistFooter").classList.remove("hide"),document.getElementById("addToPlaylistFrm").classList.remove("hide"),document.getElementById("addToPlaylistCaption").innerText=t("Add to playlist")):(document.getElementById("addStreamFooter").classList.remove("hide"),document.getElementById("addStreamFrm").classList.remove("hide"),document.getElementById("addToPlaylistFooter").classList.add("hide"),
document.getElementById("addToPlaylistFrm").classList.add("hide"),document.getElementById("addToPlaylistCaption").innerText=t("Add stream"));modalAddToPlaylist.show();settings.featPlaylists&&(playlistEl="addToPlaylistPlaylist",sendAPI({cmd:"MPD_API_PLAYLIST_LIST",data:{offset:0,filter:"-"}},getAllPlaylists))}
function addToPlaylist(){var a=document.getElementById("addToPlaylistUri").value;if("stream"==a&&(a=document.getElementById("streamUrl").value,""==a||-1==a.indexOf("http"))){document.getElementById("streamUrl").classList.add("is-invalid");return}var b=document.getElementById("addToPlaylistPlaylist");b=b.options[b.selectedIndex].value;if("new"==b&&(b=document.getElementById("addToPlaylistNewPlaylist").value,1!=validatePlname(b))){document.getElementById("addToPlaylistNewPlaylist").classList.add("is-invalid");
return}""!=b?("SEARCH"==a?addAllFromSearchPlist(b):"DATABASE"==a?addAllFromBrowseDatabasePlist(b):sendAPI({cmd:"MPD_API_PLAYLIST_ADD_TRACK",data:{uri:a,plist:b}}),modalAddToPlaylist.hide()):document.getElementById("addToPlaylistPlaylist").classList.add("is-invalid")}
function addToQueue(){var a=!0,b=document.getElementById("inputAddToQueueQuantity");validateInt(b)||(a=!1);1==a&&(a=document.getElementById("selectAddToQueueMode"),b=document.getElementById("selectAddToQueuePlaylist"),sendAPI({cmd:"MPD_API_QUEUE_ADD_RANDOM",data:{mode:a.options[a.selectedIndex].value,playlist:b.options[b.selectedIndex].value,quantity:document.getElementById("inputAddToQueueQuantity").value}}),modalAddToQueue.hide())}
function addStream(){var a=document.getElementById("streamUrl");1==validateStream(a)&&(sendAPI({cmd:"MPD_API_QUEUE_ADD_TRACK",data:{uri:a.value}}),modalAddToPlaylist.hide(),showNotification(t("Added stream %{streamUri} to queue",{streamUri:a.value}),"","","success"))}
function showRenamePlaylist(a){document.getElementById("renamePlaylistTo").classList.remove("is-invalid");modalRenamePlaylist.show();document.getElementById("renamePlaylistFrom").value=a;document.getElementById("renamePlaylistTo").value=""}
function renamePlaylist(){var a=document.getElementById("renamePlaylistFrom").value,b=document.getElementById("renamePlaylistTo").value;b!=a&&1==validatePlname(b)&&1==validatePlname(a)?(sendAPI({cmd:"MPD_API_PLAYLIST_RENAME",data:{from:a,to:b}}),modalRenamePlaylist.hide()):document.getElementById("renamePlaylistTo").classList.add("is-invalid")}function showSmartPlaylist(a){sendAPI({cmd:"MPD_API_SMARTPLS_GET",data:{playlist:a}},parseSmartPlaylist)}
function updateSmartPlaylist(a){sendAPI({cmd:"MPD_API_SMARTPLS_UPDATE",data:{playlist:a}},parseSmartPlaylist)}
function parseBookmarks(a){for(var b='<table class="table table-sm table-dark table-borderless mb-0">',c=0;c<a.data.length;c++)b+='<tr data-id="'+a.data[c].id+'" data-type="'+a.data[c].type+'" data-uri="'+encodeURI(a.data[c].uri)+'"><td class="nowrap"><a class="text-light" href="#" data-href="goto">'+e(a.data[c].name)+'</a></td><td><a class="text-light material-icons material-icons-small" href="#" data-href="edit">edit</a></td><td><a class="text-light material-icons material-icons-small" href="#" data-href="delete">delete</a></td></tr>';0==
a.data.length&&(b+='<tr><td class="text-light nowrap">'+t("No bookmarks found")+"</td></tr>");b+="</table>";document.getElementById("BrowseFilesystemBookmarks").innerHTML=b}
function showBookmarkSave(a,b,c,d){document.getElementById("saveBookmarkName").classList.remove("is-invalid");document.getElementById("saveBookmarkId").value=a;document.getElementById("saveBookmarkName").value=b;document.getElementById("saveBookmarkUri").value=c;document.getElementById("saveBookmarkType").value=d;modalSaveBookmark.show()}
function saveBookmark(){var a=parseInt(document.getElementById("saveBookmarkId").value),b=document.getElementById("saveBookmarkName").value,c=document.getElementById("saveBookmarkUri").value,d=document.getElementById("saveBookmarkType").value;""!=b?(sendAPI({cmd:"MYMPD_API_BOOKMARK_SAVE",data:{id:a,name:b,uri:c,type:d}}),modalSaveBookmark.hide()):document.getElementById("saveBookmarkName").classList.add("is-invalid")}function dirname(a){return a.replace(/\/[^\/]*$/,"")}
function b64EncodeUnicode(a){return btoa(encodeURIComponent(a).replace(/%([0-9A-F]{2})/g,function(a,c){return String.fromCharCode("0x"+c)}))}function b64DecodeUnicode(a){return decodeURIComponent(atob(a).split("").map(function(a){return"%"+("00"+a.charCodeAt(0).toString(16)).slice(-2)}).join(""))}function addMenuItem(a,b){return'<a class="dropdown-item" href="#" data-href=\''+b64EncodeUnicode(JSON.stringify(a))+"'>"+b+"</a>"}
function hideMenu(){var a=document.querySelector("[data-popover]");a&&(new Popover(a,{}),a.Popover.hide(),a.removeAttribute("data-popover"),a.parentNode.parentNode.classList.contains("selected")&&focusTable(void 0,a.parentNode.parentNode.parentNode.parentNode))}
function showMenu(a,b){b.preventDefault();b.stopPropagation();hideMenu();if(!a.getAttribute("data-init")){b=a.getAttribute("data-type");var c=decodeURI(a.getAttribute("data-uri")),d=a.getAttribute("data-name"),f=0;if(null==b||""==c)b=a.parentNode.parentNode.getAttribute("data-type"),c=decodeURI(a.parentNode.parentNode.getAttribute("data-uri")),d=a.parentNode.parentNode.getAttribute("data-name");lastState&&(f=lastState.data.nextSongPos);var g="";"Browse"==app.current.app&&"Filesystem"==app.current.tab||
"Search"==app.current.app||"Browse"==app.current.app&&"Database"==app.current.tab?(g+=addMenuItem({cmd:"appendQueue",options:[b,c,d]},t("Append to queue"))+("song"==b?addMenuItem({cmd:"appendAfterQueue",options:[b,c,f,d]},t("Add after current playing song")):"")+addMenuItem({cmd:"replaceQueue",options:[b,c,d]},t("Replace queue"))+("plist"!=b&&"smartpls"!=b&&settings.featPlaylists?addMenuItem({cmd:"showAddToPlaylist",options:[c]},t("Add to playlist")):"")+("song"==b?addMenuItem({cmd:"songDetails",
options:[c]},t("Song details")):"")+("plist"==b||"smartpls"==b?addMenuItem({cmd:"playlistDetails",options:[c]},t("View playlist")):"")+("dir"==b?addMenuItem({cmd:"showBookmarkSave",options:[-1,d,c,b]},t("Add bookmark")):""),"Search"==app.current.app&&(c=dirname(c),g+='<div class="dropdown-divider"></div><a class="dropdown-item" id="advancedMenuLink" data-toggle="collapse" href="#advancedMenu"><span class="material-icons material-icons-small-left">keyboard_arrow_right</span>Album actions</a><div class="collapse" id="advancedMenu">'+
addMenuItem({cmd:"appendQueue",options:[b,c,d]},t("Append to queue"))+addMenuItem({cmd:"appendAfterQueue",options:[b,c,f,d]},t("Add after current playing song"))+addMenuItem({cmd:"replaceQueue",options:[b,c,d]},t("Replace queue"))+(settings.featPlaylists?addMenuItem({cmd:"showAddToPlaylist",options:[c]},t("Add to playlist")):"")+"</div>")):"Browse"==app.current.app&&"Playlists"==app.current.tab&&"All"==app.current.view?g+=addMenuItem({cmd:"appendQueue",options:[b,c,d]},t("Append to queue"))+addMenuItem({cmd:"replaceQueue",
options:[b,c,d]},t("Replace queue"))+("smartpls"==b?addMenuItem({cmd:"playlistDetails",options:[c]},t("View playlist")):addMenuItem({cmd:"playlistDetails",options:[c]},t("Edit playlist")))+("smartpls"==b?addMenuItem({cmd:"showSmartPlaylist",options:[c]},t("Edit smart playlist")):"")+(1==settings.smartpls&&"smartpls"==b?addMenuItem({cmd:"updateSmartPlaylist",options:[c]},t("Update smart playlist")):"")+addMenuItem({cmd:"showRenamePlaylist",options:[c]},t("Rename playlist"))+addMenuItem({cmd:"showDelPlaylist",
options:[c]},t("Delete playlist")):"Browse"==app.current.app&&"Playlists"==app.current.tab&&"Detail"==app.current.view?(f=document.getElementById("BrowsePlaylistsDetailList"),g+=addMenuItem({cmd:"appendQueue",options:[b,c,d]},t("Append to queue"))+addMenuItem({cmd:"replaceQueue",options:[b,c,d]},t("Replace queue"))+("false"==f.getAttribute("data-ro")?addMenuItem({cmd:"removeFromPlaylist",options:[f.getAttribute("data-uri"),a.parentNode.parentNode.getAttribute("data-songpos")]},t("Remove")):"")+addMenuItem({cmd:"showAddToPlaylist",
options:[c]},t("Add to playlist"))+(-1==c.indexOf("http")?addMenuItem({cmd:"songDetails",options:[c]},t("Song details")):"")):"Queue"==app.current.app&&"Current"==app.current.tab?g+=addMenuItem({cmd:"delQueueSong",options:["single",a.parentNode.parentNode.getAttribute("data-trackid")]},t("Remove"))+addMenuItem({cmd:"delQueueSong",options:["range",0,a.parentNode.parentNode.getAttribute("data-songpos")]},t("Remove all upwards"))+addMenuItem({cmd:"delQueueSong",options:["range",parseInt(a.parentNode.parentNode.getAttribute("data-songpos"))-
1,-1]},t("Remove all downwards"))+(-1==c.indexOf("http")?addMenuItem({cmd:"songDetails",options:[c]},t("Song details")):""):"Queue"==app.current.app&&"LastPlayed"==app.current.tab&&(g+=addMenuItem({cmd:"appendQueue",options:[b,c,d]},t("Append to queue"))+addMenuItem({cmd:"replaceQueue",options:[b,c,d]},t("Replace queue"))+addMenuItem({cmd:"showAddToPlaylist",options:[c]},t("Add to playlist"))+(-1==c.indexOf("http")?addMenuItem({cmd:"songDetails",options:[c]},t("Song details")):""));new Popover(a,
{trigger:"click",delay:0,dismissible:!0,template:'<div class="popover" role="tooltip"><div class="arrow"></div><div class="popover-content">'+g+"</div></div>",content:" "});b=a.Popover;a.setAttribute("data-init","true");a.addEventListener("shown.bs.popover",function(a){a.target.setAttribute("data-popover","true");document.getElementsByClassName("popover-content")[0].addEventListener("click",function(a){a.preventDefault();a.stopPropagation();if("A"==a.target.nodeName){var b=a.target.getAttribute("data-href");
b&&(b=JSON.parse(b64DecodeUnicode(b)),parseCmd(a,b),hideMenu())}},!1);document.getElementsByClassName("popover-content")[0].addEventListener("keydown",function(a){a.preventDefault();a.stopPropagation();if("ArrowDown"==a.key||"ArrowUp"==a.key){var b=this.getElementsByTagName("a");b=Array.prototype.slice.call(b);var c=b.indexOf(document.activeElement);do if(c="ArrowUp"==a.key?1<c?c-1:0:"ArrowDown"==a.key?c<b.length-1?c+1:c:c,0===c||c===b.length-1)break;while(!b[c].offsetHeight);b[c]&&b[c].focus()}else"Enter"==
a.key?a.target.click():"Escape"==a.key&&hideMenu()},!1);if(a=document.getElementById("advancedMenuLink"))a.addEventListener("click",function(a){a=this.getElementsByTagName("span")[0];a.innerText="keyboard_arrow_right"==a.innerText?"keyboard_arrow_down":"keyboard_arrow_right"},!1),new Collapse(a);document.getElementsByClassName("popover-content")[0].firstChild.focus()},!1);b.show()}}
function sendAPI(a,b,c){var d=new XMLHttpRequest;d.open("POST",subdir+"/api",!0);d.setRequestHeader("Content-type","application/json");d.onreadystatechange=function(){if(4==d.readyState)if(""!=d.responseText){var f=JSON.parse(d.responseText);"error"==f.type?(void 0!=f.number?showNotification(t(f.data,f.number,f.values),"","","danger"):showNotification(t(f.data,f.values),"","","success"),logError(f.data),1==c&&void 0!=b&&"function"==typeof b&&(logDebug('Got API response of type "'+f.type+'" calling '+
b.name),b(f))):"result"==f.type&&"ok"!=f.data?(logDebug("Got API response: "+f.data),void 0!=f.number?showNotification(t(f.data,f.number,f.values),"","","success"):showNotification(t(f.data,f.values),"","","success")):void 0!=b&&"function"==typeof b&&(logDebug('Got API response of type "'+f.type+'" calling '+b.name),b(f))}else logError("Empty response for request: "+JSON.stringify(a)),1==c&&void 0!=b&&"function"==typeof b&&(logDebug("Got empty API response calling "+b.name),b(""))};d.send(JSON.stringify(a));
logDebug("Send API request: "+a.cmd)}function updateDB(){sendAPI({cmd:"MPD_API_DATABASE_UPDATE"});updateDBstarted(!0)}function rescanDB(){sendAPI({cmd:"MPD_API_DATABASE_RESCAN"});updateDBstarted(!0)}
function updateDBstarted(a){1==a?(document.getElementById("updateDBfinished").innerText="",document.getElementById("updateDBfooter").classList.add("hide"),updateDBprogress.style.width="20px",updateDBprogress.style.marginLeft="-20px",modalUpdateDB.show(),document.getElementById("updateDBprogress").classList.add("updateDBprogressAnimate")):showNotification(t("Database update started"),"","","success")}
function updateDBfinished(a){document.getElementById("modalUpdateDB").classList.contains("show")?("update_database"==a?document.getElementById("updateDBfinished").innerText=t("Database successfully updated"):"update_finished"==a&&(document.getElementById("updateDBfinished").innerText=t("Database update finished")),a=document.getElementById("updateDBprogress"),a.classList.remove("updateDBprogressAnimate"),a.style.width="100%",a.style.marginLeft="0px",document.getElementById("updateDBfooter").classList.remove("hide")):
"update_database"==a?showNotification(t("Database successfully updated"),"","","success"):"update_finished"==a&&showNotification(t("Database update finished"),"","","success")}function clickPlay(){"play"!=playstate?sendAPI({cmd:"MPD_API_PLAYER_PLAY"}):sendAPI({cmd:"MPD_API_PLAYER_PAUSE"})}function clickStop(){sendAPI({cmd:"MPD_API_PLAYER_STOP"})}function clickPrev(){sendAPI({cmd:"MPD_API_PLAYER_PREV"})}function clickNext(){sendAPI({cmd:"MPD_API_PLAYER_NEXT"})}
function delQueueSong(a,b,c){"range"==a?sendAPI({cmd:"MPD_API_QUEUE_RM_RANGE",data:{start:b,end:c}}):"single"==a&&sendAPI({cmd:"MPD_API_QUEUE_RM_TRACK",data:{track:b}})}function showDelPlaylist(a){document.getElementById("deletePlaylist").value=a;modalDeletePlaylist.show()}function delPlaylist(){var a=document.getElementById("deletePlaylist").value;sendAPI({cmd:"MPD_API_PLAYLIST_RM",data:{uri:a}});modalDeletePlaylist.hide()}
function saveSettings(){var a=!0,b=document.getElementById("inputCrossfade");b.getAttribute("disabled")||validateInt(b)||(a=!1);b=document.getElementById("inputJukeboxQueueLength");validateInt(b)||(a=!1);var c=document.getElementById("selectStreamMode"),d=b="";"port"==c.options[c.selectedIndex].value?(d=document.getElementById("inputStreamUrl").value,validateInt(inputStreamUrl)||(a=!1)):(b=document.getElementById("inputStreamUrl").value,validateStream(inputStreamUrl)||(a=!1));c=document.getElementById("inputCoverimageSize");
validateInt(c)||(a=!1);c=document.getElementById("inputCoverimageName");validateFilename(c)||(a=!1);c=document.getElementById("inputMaxElementsPerPage");validateInt(c)||(a=!1);200<parseInt(c.value)&&(a=!1);c=document.getElementById("inputLastPlayedCount");validateInt(c)||(a=!1);if(document.getElementById("btnLoveEnable").classList.contains("active")){c=document.getElementById("inputLoveChannel");var f=document.getElementById("inputLoveMessage");validateNotBlank(c)&&validateNotBlank(f)||(a=!1)}1==
settings.featMixramp&&(c=document.getElementById("inputMixrampdb"),c.getAttribute("disabled")||validateFloat(c)||(a=!1),c=document.getElementById("inputMixrampdelay"),c.getAttribute("disabled")||("nan"==c.value&&(c.value="-1"),validateFloat(c)||(a=!1)));if(1==a){a=document.getElementById("selectReplaygain");c=document.getElementById("selectJukeboxPlaylist");f=document.getElementById("selectJukeboxMode");var g=document.getElementById("selectLocale");sendAPI({cmd:"MYMPD_API_SETTINGS_SET",data:{consume:document.getElementById("btnConsume").classList.contains("active")?
1:0,random:document.getElementById("btnRandom").classList.contains("active")?1:0,single:document.getElementById("btnSingle").classList.contains("active")?1:0,repeat:document.getElementById("btnRepeat").classList.contains("active")?1:0,replaygain:a.options[a.selectedIndex].value,crossfade:document.getElementById("inputCrossfade").value,mixrampdb:1==settings.featMixramp?document.getElementById("inputMixrampdb").value:settings.mixrampdb,mixrampdelay:1==settings.featMixramp?document.getElementById("inputMixrampdelay").value:
settings.mixrampdelay,notificationWeb:document.getElementById("btnNotifyWeb").classList.contains("active")?!0:!1,notificationPage:document.getElementById("btnNotifyPage").classList.contains("active")?!0:!1,jukeboxMode:f.options[f.selectedIndex].value,jukeboxPlaylist:c.options[c.selectedIndex].value,jukeboxQueueLength:document.getElementById("inputJukeboxQueueLength").value,autoPlay:document.getElementById("btnAutoPlay").classList.contains("active")?!0:!1,bgCover:document.getElementById("btnBgCover").classList.contains("active")?
!0:!1,bgColor:document.getElementById("inputBgColor").value,bgCssFilter:document.getElementById("inputBgCssFilter").value,featLocalplayer:document.getElementById("btnFeatLocalplayer").classList.contains("active")?!0:!1,localplayerAutoplay:document.getElementById("btnLocalplayerAutoplay").classList.contains("active")?!0:!1,streamUrl:b,streamPort:d,coverimage:document.getElementById("btnCoverimage").classList.contains("active")?!0:!1,coverimageName:document.getElementById("inputCoverimageName").value,
coverimageSize:document.getElementById("inputCoverimageSize").value,locale:g.options[g.selectedIndex].value,love:document.getElementById("btnLoveEnable").classList.contains("active")?!0:!1,loveChannel:document.getElementById("inputLoveChannel").value,loveMessage:document.getElementById("inputLoveMessage").value,maxElementsPerPage:document.getElementById("inputMaxElementsPerPage").value,stickers:document.getElementById("btnStickers").classList.contains("active")?!0:!1,lastPlayedCount:document.getElementById("inputLastPlayedCount").value,
smartpls:document.getElementById("btnSmartpls").classList.contains("active")?!0:!1,taglist:document.getElementById("inputEnabledTags").value.replace(/\s/g,""),searchtaglist:document.getElementById("inputSearchTags").value.replace(/\s/g,""),browsetaglist:document.getElementById("inputBrowseTags").value.replace(/\s/g,"")}},getSettings);modalSettings.hide()}}function resetSettings(){sendAPI({cmd:"MYMPD_API_SETTINGS_RESET"},getSettings)}
function addAllFromBrowseFilesystem(){sendAPI({cmd:"MPD_API_QUEUE_ADD_TRACK",data:{uri:app.current.search}});showNotification(t("Added all songs"),"","","success")}
function addAllFromSearchPlist(a){settings.featAdvsearch?sendAPI({cmd:"MPD_API_DATABASE_SEARCH_ADV",data:{plist:a,sort:"",sortdesc:!1,expression:app.current.search,offset:0,cols:settings.colsSearch}}):sendAPI({cmd:"MPD_API_DATABASE_SEARCH",data:{plist:a,filter:app.current.filter,searchstr:app.current.search,offset:0,cols:settings.colsSearch}});showNotification(t("Added all songs from search to %{playlist}",{playlist:a}),"","","success")}
function addAllFromBrowseDatabasePlist(a){2<=app.current.search.length&&(sendAPI({cmd:"MPD_API_DATABASE_SEARCH",data:{plist:a,filter:app.current.view,searchstr:app.current.search,offset:0,cols:settings.colsSearch}}),showNotification(t("Added all songs from database selection to %{playlist}",{playlist:a}),"","","success"))}function scrollTo(a){document.body.scrollTop=a;document.documentElement.scrollTop=a}
function gotoPage(a){switch(a){case "next":app.current.page+=settings.maxElementsPerPage;break;case "prev":app.current.page-=settings.maxElementsPerPage;0>app.current.page&&(app.current.page=0);break;default:app.current.page=a}appGoto(app.current.app,app.current.tab,app.current.view,app.current.page+"/"+app.current.filter+"/"+app.current.sort+"/"+app.current.search)}
function saveQueue(){var a=document.getElementById("saveQueueName").value;1==validatePlname(a)?(sendAPI({cmd:"MPD_API_QUEUE_SAVE",data:{plist:a}}),modalSaveQueue.hide()):document.getElementById("saveQueueName").classList.add("is-invalid")}function toggleAlert(a,b,c){a=document.getElementById(a);0==b?(a.innerHTML="",a.classList.add("hide")):(a.innerHTML=c,a.classList.remove("hide"))}
function showNotification(a,b,c,d){if(1==settings.notificationWeb){var f=new Notification(a,{icon:"assets/favicon.ico",body:b});setTimeout(function(a){a.close()},3E3,f)}1==settings.notificationPage&&(document.getElementById("alertBox")?f=document.getElementById("alertBox"):(f=document.createElement("div"),f.setAttribute("id","alertBox"),f.addEventListener("click",function(){hideNotification()},!1)),f.classList.remove("alert-success","alert-danger"),f.classList.add("alert","alert-"+d),f.innerHTML=
"<div><strong>"+e(a)+"</strong><br/>"+(""==c?e(b):c)+"</div>",document.getElementsByTagName("main")[0].append(f),document.getElementById("alertBox").classList.add("alertBoxActive"),alertTimeout&&clearTimeout(alertTimeout),alertTimeout=setTimeout(function(){hideNotification()},3E3))}
function hideNotification(){document.getElementById("alertBox")&&(document.getElementById("alertBox").classList.remove("alertBoxActive"),setTimeout(function(){var a=document.getElementById("alertBox");a&&a.remove()},600))}function notificationsSupported(){return"Notification"in window}
function setBackgroundImage(a){for(var b=document.querySelectorAll(".albumartbg"),c=0;c<b.length;c++)-10==b[c].style.zIndex?b[c].remove():b[c].style.zIndex=-10;b=document.createElement("div");b.classList.add("albumartbg");b.style.backgroundImage='url("'+subdir+a+'")';b.style.opacity=0;c=document.getElementsByTagName("body")[0];c.insertBefore(b,c.firstChild);b=new Image;b.onload=function(){document.querySelector(".albumartbg").style.opacity=1};b.src=a}
function clearBackgroundImage(){for(var a=document.querySelectorAll(".albumartbg"),b=0;b<a.length;b++)-10==a[b].style.zIndex?a[b].remove():(a[b].style.zIndex=-10,a[b].style.opacity=0)}
function setCurrentCover(a){for(var b=domCache.currentCover.querySelectorAll(".coverbg"),c=0;c<b.length;c++)2==b[c].style.zIndex?b[c].remove():b[c].style.zIndex=2;b=document.createElement("div");b.classList.add("coverbg");b.style.backgroundImage='url("'+subdir+a+'")';b.style.opacity=0;domCache.currentCover.insertBefore(b,domCache.currentCover.firstChild);b=new Image;b.onload=function(){domCache.currentCover.querySelector(".coverbg").style.opacity=1};b.src=a}
function clearCurrentCover(){for(var a=domCache.currentCover.querySelectorAll(".coverbg"),b=0;b<a.length;b++)2==a[b].style.zIndex?a[b].remove():(a[b].style.zIndex=2,a[b].style.opacity=0)}
function songChange(a){if("song_change"==a.type){var b=a.data.Title+a.data.Artist+a.data.Album+a.data.uri+a.data.currentSongId;if(lastSong!=b){var c="",d="",f="";setCurrentCover(a.data.cover);1==settings.bgCover&&1==settings.featCoverimage&&(-1<a.data.cover.indexOf("coverimage-")?clearBackgroundImage():setBackgroundImage(a.data.cover));"undefined"!=typeof a.data.Artist&&0<a.data.Artist.length&&"-"!=a.data.Artist&&(c+=a.data.Artist,d+=a.data.Artist,f+=a.data.Artist+" - ");"undefined"!=typeof a.data.Album&&
0<a.data.Album.length&&"-"!=a.data.Album&&(c+=" - "+a.data.Album,d+="<br/>"+a.data.Album);"undefined"!=typeof a.data.Title&&0<a.data.Title.length?(f+=a.data.Title,domCache.currentTitle.innerText=a.data.Title,domCache.currentTitle.setAttribute("data-uri",encodeURI(a.data.uri))):(domCache.currentTitle.innerText="",domCache.currentTitle.setAttribute("data-uri",""));document.title="myMPD: "+f;document.getElementById("headerTitle").innerText=f;document.getElementById("headerTitle").title=f;1==settings.featStickers&&
setVoteSongBtns(a.data.like,a.data.uri);for(f=0;f<settings.colsPlayback.length;f++){var g=document.getElementById("current"+settings.colsPlayback[f]);g&&(g.getElementsByTagName("h4")[0].innerText=a.data[settings.colsPlayback[f]],g.setAttribute("data-name",encodeURI(a.data[settings.colsPlayback[f]])))}if(f=document.getElementById("queueTrackId"+a.data.currentSongId))f.getElementsByTagName("td")[1].innerText=a.data.Title;"play"==playstate&&showNotification(a.data.Title,c,d,"success");lastSong=b;lastSongObj=
a}}}function doSetFilterLetter(a){var b=document.getElementById(a+"Letters").getElementsByClassName("active")[0];b&&b.classList.remove("active");b=app.current.filter;"0"==b&&(b="#");document.getElementById(a).innerHTML='<span class="material-icons">filter_list</span>'+("-"!=b?" "+b:"");if("-"!=b){a=document.getElementById(a+"Letters").getElementsByTagName("button");for(var c=a.length,d=0;d<c;d++)if(a[d].innerText==b){a[d].classList.add("active");break}}}
function addFilterLetter(a){for(var b='<button class="mr-1 mb-1 btn btn-sm btn-secondary material-icons material-icons-small">delete</button><button class="mr-1 mb-1 btn btn-sm btn-secondary">#</button>',c=65;90>=c;c++)b+='<button class="mr-1 mb-1 btn-sm btn btn-secondary">'+String.fromCharCode(c)+"</button>";a=document.getElementById(a);a.innerHTML=b;a.addEventListener("click",function(a){switch(a.target.innerText){case "delete":b="-";break;case "#":b="0";break;default:b=a.target.innerText}appGoto(app.current.app,
app.current.tab,app.current.view,"0/"+b+"/"+app.current.sort+"/"+app.current.search)},!1)}function selectTag(a,b,c){a=document.getElementById(a);var d=a.querySelector(".active");d&&d.classList.remove("active");if(d=a.querySelector("[data-tag="+c+"]"))d.classList.add("active"),document.getElementById(b).innerText=d.innerText}
function addTagList(a,b){var c="";"searchtags"==b&&(1==settings.featTags&&(c+='<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="any">'+t("Any Tag")+"</button>"),c+='<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="filename">'+t("Filename")+"</button>");for(var d=0;d<settings[b].length;d++)c+='<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="'+settings[b][d]+'">'+t(settings[b][d])+"</button>";document.getElementById(a).innerHTML=
c}function gotoTagList(){appGoto(app.current.app,app.current.tab,app.current.view,"0/-/-/")}function openModal(a){window[a].show()}function openDropdown(a){window[a].toggle()}function focusSearch(){"Queue"==app.current.app?document.getElementById("searchqueuestr").focus():"Search"==app.current.app?domCache.searchstr.focus():appGoto("Search")}
function chVolume(a){a=parseInt(domCache.volumeBar.value)+a;0>a?a=0:100<a&&(a=100);domCache.volumeBar.value=a;sendAPI({cmd:"MPD_API_PLAYER_VOLUME_SET",data:{volume:a}})}function gtPage(a,b,c){return-1<c?t(a,c):b+app.current.page<settings.maxElementsPerPage?t(a,b):"> "+t(a,settings.maxElementsPerPage)}
function beautifyDuration(a){var b=Math.floor(a/86400),c=Math.floor(a/3600)-24*b,d=Math.floor(a/60)-60*c-1440*b;a=a-86400*b-3600*c-60*d;return(0<b?b+"\u2009"+t("Days")+" ":"")+(0<c?c+"\u2009"+t("Hours")+" "+(10>d?"0":""):"")+d+"\u2009"+t("Minutes")+" "+(10>a?"0":"")+a+"\u2009"+t("Seconds")}function beautifySongDuration(a){var b=Math.floor(a/3600),c=Math.floor(a/60)-60*b;a=a-3600*b-60*c;return(0<b?b+":"+(10>c?"0":""):"")+c+":"+(10>a?"0":"")+a}function genId(a){return"id"+a.replace(/[^\w\-]/g,"")}
function validateFilename(a){if(""==a.value)return a.classList.add("is-invalid"),!1;if(null!=a.value.match(/^[\w\-]+\.\w+$/))return a.classList.remove("is-invalid"),!0;a.classList.add("is-invalid");return!1}function validatePath(a){if(""==a.value)return a.classList.add("is-invalid"),!1;if(null!=a.value.match(/^\/[\/\.\w\-]+$/))return a.classList.remove("is-invalid"),!0;a.classList.add("is-invalid");return!1}function localeDate(a){return(new Date(1E3*a)).toLocaleString(locale)}
function validatePlname(a){return""==a?!1:null==a.match(/\/|\r|\n|"|'/)?!0:!1}function validateNotBlank(a){if(""==a.value.replace(/\s/g,""))return a.classList.add("is-invalid"),!1;a.classList.remove("is-invalid");return!0}function validateInt(a){if(""!=a.value.replace(/\d/g,""))return a.classList.add("is-invalid"),!1;a.classList.remove("is-invalid");return!0}
function validateFloat(a){if(""!=a.value.replace(/[\d\-\.]/g,""))return a.classList.add("is-invalid"),!1;a.classList.remove("is-invalid");return!0}function validateStream(a){if(-1<a.value.indexOf("://"))return a.classList.remove("is-invalid"),!0;a.classList.add("is-invalid");return!1}function validateHost(a){if(null==a.value.match("^(w-.)$"))return a.classList.remove("is-invalid"),!0;a.classList.add("is-invalid");return!1}function logError(a){logLog(0,"ERROR: "+a)}
function logWarn(a){logLog(1,"WARN: "+a)}function logInfo(a){logLog(2,"INFO: "+a)}function logVerbose(a){logLog(3,"VERBOSE: "+a)}function logDebug(a){logLog(4,"DEBUG: "+a)}function logLog(a,b){settings.loglevel>=a&&console.log(b)}function e(a){return isNaN(a)?a.replace(/([<>])/g,function(a,c){if("<"==c)return"&lt;";if(">"==c)return"&gt;"}):a}appInitStart();
