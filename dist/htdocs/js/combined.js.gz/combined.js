"use strict";
/*!
  * Native JavaScript for Bootstrap v3.0.3 (https://thednp.github.io/bootstrap.native/)
  * Copyright 2015-2020 © dnp_theme
  * Licensed under MIT (https://github.com/thednp/bootstrap.native/blob/master/LICENSE)
  */
(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
  typeof define === 'function' && define.amd ? define(factory) :
  (global = global || self, global.BSN = factory());
}(this, function () { 'use strict';

  function hasClass(element,classNAME) {
    return element.classList.contains(classNAME)
  }

  function removeClass(element,classNAME) {
    element.classList.remove(classNAME);
  }

  function on (element, event, handler, options) {
    options = options || false;
    element.addEventListener(event, handler, options);
  }

  function off (element, event, handler, options) {
    options = options || false;
    element.removeEventListener(event, handler, options);
  }

  function one (element, event, handler, options) {
    on(element, event, function handlerWrapper(e){
      if (e.target === element) {
        handler(e);
        off(element, event, handlerWrapper, options);
      }
    }, options);
  }

  var transitionEndEvent = 'webkitTransition' in document.body.style ? 'webkitTransitionEnd' : 'transitionend';

  var supportTransition = 'webkitTransition' in document.body.style || 'transition' in document.body.style;

  var transitionDuration = 'webkitTransition' in document.body.style ? 'webkitTransitionDuration' : 'transitionDuration';

  function getElementTransitionDuration (element) {
    var duration = supportTransition ? window.getComputedStyle(element)[transitionDuration] : 0;
    duration = parseFloat(duration);
    duration = typeof duration === 'number' && !isNaN(duration) ? duration * 1000 : 0;
    return duration;
  }

  function emulateTransitionEnd (element,handler){
    var called = 0, duration = getElementTransitionDuration(element);
    duration ? one(element, transitionEndEvent, function(e){ !called && handler(e), called = 1; })
             : setTimeout(function() { !called && handler(), called = 1; }, 17);
  }

  function queryElement (selector, parent) {
    var lookUp = parent && parent instanceof Element ? parent : document;
    return selector instanceof Element ? selector : lookUp.querySelector(selector);
  }

  function tryWrapper (fn,origin){
    try{ fn(); }
    catch(e){
      console.error((origin + ": " + e));
    }
  }

  function bootstrapCustomEvent (eventName, componentName, related) {
    var OriginalCustomEvent = new CustomEvent( eventName + '.bs.' + componentName, {cancelable: true});
    OriginalCustomEvent.relatedTarget = related;
    return OriginalCustomEvent;
  }
  function dispatchCustomEvent (customEvent){
    this && this.dispatchEvent(customEvent);
  }

  function Alert(element) {
    var self = this,
      alert,
      closeCustomEvent = bootstrapCustomEvent('close','alert'),
      closedCustomEvent = bootstrapCustomEvent('closed','alert');
    function triggerHandler() {
      hasClass(alert,'fade') ? emulateTransitionEnd(alert,transitionEndHandler) : transitionEndHandler();
    }
    function clickHandler(e) {
      alert = e && e.target.closest(".alert");
      element = queryElement('[data-dismiss="alert"]',alert);
      element && alert && (element === e.target || element.contains(e.target)) && self.close();
    }
    function transitionEndHandler() {
      off(element, 'click', clickHandler);
      alert.parentNode.removeChild(alert);
      dispatchCustomEvent.call(alert,closedCustomEvent);
    }
    self.close = function () {
      if ( alert && element && hasClass(alert,'show') ) {
        dispatchCustomEvent.call(alert,closeCustomEvent);
        if ( closeCustomEvent.defaultPrevented ) { return; }
        self.dispose();
        removeClass(alert,'show');
        triggerHandler();
      }
    };
    self.dispose = function () {
      off(element, 'click', clickHandler);
      delete element.Alert;
    };
    tryWrapper(function (){
      element = queryElement(element);
      alert = element.closest('.alert');
      element.Alert && element.Alert.dispose();
      if ( !element.Alert ) {
        on(element, 'click', clickHandler);
      }
      self.element = element;
      element.Alert = self;
    },"BSN.Alert");
  }

  function addClass(element,classNAME) {
    element.classList.add(classNAME);
  }

  function Button(element) {
    var self = this, labels,
        changeCustomEvent = bootstrapCustomEvent('change', 'button');
    function toggle(e) {
      var input,
          label = e.target.tagName === 'LABEL' ? e.target
                : e.target.closest('LABEL') ? e.target.closest('LABEL') : null;
      input = label && label.getElementsByTagName('INPUT')[0];
      if ( !input ) { return; }
      dispatchCustomEvent.call(input, changeCustomEvent);
      dispatchCustomEvent.call(element, changeCustomEvent);
      if ( input.type === 'checkbox' ) {
        if ( changeCustomEvent.defaultPrevented ) { return; }
        if ( !input.checked ) {
          addClass(label,'active');
          input.getAttribute('checked');
          input.setAttribute('checked','checked');
          input.checked = true;
        } else {
          removeClass(label,'active');
          input.getAttribute('checked');
          input.removeAttribute('checked');
          input.checked = false;
        }
        if (!element.toggled) {
          element.toggled = true;
        }
      }
      if ( input.type === 'radio' && !element.toggled ) {
        if ( changeCustomEvent.defaultPrevented ) { return; }
        if ( !input.checked || (e.screenX === 0 && e.screenY == 0) ) {
          addClass(label,'active');
          addClass(label,'focus');
          input.setAttribute('checked','checked');
          input.checked = true;
          element.toggled = true;
          Array.from(labels).map(function (otherLabel){
            var otherInput = otherLabel.getElementsByTagName('INPUT')[0];
            if ( otherLabel !== label && hasClass(otherLabel,'active') )  {
              dispatchCustomEvent.call(otherInput, changeCustomEvent);
              removeClass(otherLabel,'active');
              otherInput.removeAttribute('checked');
              otherInput.checked = false;
            }
          });
        }
      }
      setTimeout( function () { element.toggled = false; }, 50 );
    }
    function keyHandler(e) {
      var key = e.which || e.keyCode;
      key === 32 && e.target === document.activeElement && toggle(e);
    }
    function preventScroll(e) {
      var key = e.which || e.keyCode;
      key === 32 && e.preventDefault();
    }
    function focusToggle(e) {
      var action = e.type === 'focusin' ? addClass : removeClass;
      if (e.target.tagName === 'INPUT' ) {
        action(e.target.closest('.btn'),'focus');
      }
    }
    function toggleEvents(action) {
      action( element, 'click', toggle );
      action( element, 'keyup', keyHandler ), action( element, 'keydown', preventScroll );
      action( element, 'focusin', focusToggle), action( element, 'focusout', focusToggle);
    }
    self.dispose = function () {
      toggleEvents(off);
      delete element.Button;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Button && element.Button.dispose();
      labels = element.getElementsByClassName('btn');
      if (!labels.length) { return; }
      if ( !element.Button ) {
        toggleEvents(on);
      }
      element.toggled = false;
      element.Button = self;
      Array.from(labels).map(function (btn){
        !hasClass(btn,'active')
          && queryElement('input:checked',btn)
          && addClass(btn,'active');
        hasClass(btn,'active')
          && !queryElement('input:checked',btn)
          && removeClass(btn,'active');
      });
    },"BSN.Button");
  }

  var touchEvents = { start: 'touchstart', end: 'touchend', move:'touchmove', cancel:'touchcancel' };

  var mouseHoverEvents = ('onmouseleave' in document) ? [ 'mouseenter', 'mouseleave'] : [ 'mouseover', 'mouseout' ];

  var supportPassive = (function () {
    var result = false;
    try {
      var opts = Object.defineProperty({}, 'passive', {
        get: function() {
          result = true;
        }
      });
      one(document, 'DOMContentLoaded', function (){}, opts);
    } catch (e) {}
    return result;
  })();

  var passiveHandler = supportPassive ? { passive: true } : false;

  function isElementInScrollRange(element) {
    var bcr = element.getBoundingClientRect(),
        viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    return bcr.top <= viewportHeight && bcr.bottom >= 0;
  }

  function Carousel (element,options) {
    options = options || {};
    var self = this,
      vars, ops,
      slideCustomEvent, slidCustomEvent,
      slides, leftArrow, rightArrow, indicator, indicators;
    function pauseHandler() {
      if ( ops.interval !==false && !hasClass(element,'paused') ) {
        addClass(element,'paused');
        !vars.isSliding && ( clearInterval(vars.timer), vars.timer = null );
      }
    }
    function resumeHandler() {
      if ( ops.interval !== false && hasClass(element,'paused') ) {
        removeClass(element,'paused');
        !vars.isSliding && ( clearInterval(vars.timer), vars.timer = null );
        !vars.isSliding && self.cycle();
      }
    }
    function indicatorHandler(e) {
      e.preventDefault();
      if (vars.isSliding) { return; }
      var eventTarget = e.target;
      if ( eventTarget && !hasClass(eventTarget,'active') && eventTarget.getAttribute('data-slide-to') ) {
        vars.index = parseInt( eventTarget.getAttribute('data-slide-to'));
      } else { return false; }
      self.slideTo( vars.index );
    }
    function controlsHandler(e) {
      e.preventDefault();
      if (vars.isSliding) { return; }
      var eventTarget = e.currentTarget || e.srcElement;
      if ( eventTarget === rightArrow ) {
        vars.index++;
      } else if ( eventTarget === leftArrow ) {
        vars.index--;
      }
      self.slideTo( vars.index );
    }
    function keyHandler(ref) {
      var which = ref.which;
      if (vars.isSliding) { return; }
      switch (which) {
        case 39:
          vars.index++;
          break;
        case 37:
          vars.index--;
          break;
        default: return;
      }
      self.slideTo( vars.index );
    }
    function toggleEvents(action) {
      if ( ops.pause && ops.interval ) {
        action( element, mouseHoverEvents[0], pauseHandler );
        action( element, mouseHoverEvents[1], resumeHandler );
        action( element, touchEvents.start, pauseHandler, passiveHandler );
        action( element, touchEvents.end, resumeHandler, passiveHandler );
      }
      ops.touch && slides.length > 1 && action( element, touchEvents.start, touchDownHandler, passiveHandler );
      rightArrow && action( rightArrow, 'click', controlsHandler );
      leftArrow && action( leftArrow, 'click', controlsHandler );
      indicator && action( indicator, 'click', indicatorHandler );
      ops.keyboard && action( window, 'keydown', keyHandler );
    }
    function toggleTouchEvents(action) {
      action( element, touchEvents.move, touchMoveHandler, passiveHandler );
      action( element, touchEvents.end, touchEndHandler, passiveHandler );
    }
    function touchDownHandler(e) {
      if ( vars.isTouch ) { return; }
      vars.touchPosition.startX = e.changedTouches[0].pageX;
      if ( element.contains(e.target) ) {
        vars.isTouch = true;
        toggleTouchEvents(on);
      }
    }
    function touchMoveHandler(e) {
      if ( !vars.isTouch ) { e.preventDefault(); return; }
      vars.touchPosition.currentX = e.changedTouches[0].pageX;
      if ( e.type === 'touchmove' && e.changedTouches.length > 1 ) {
        e.preventDefault();
        return false;
      }
    }
    function touchEndHandler (e) {
      if ( !vars.isTouch || vars.isSliding ) { return }
      vars.touchPosition.endX = vars.touchPosition.currentX || e.changedTouches[0].pageX;
      if ( vars.isTouch ) {
        if ( (!element.contains(e.target) || !element.contains(e.relatedTarget) )
            && Math.abs(vars.touchPosition.startX - vars.touchPosition.endX) < 75 ) {
          return false;
        } else {
          if ( vars.touchPosition.currentX < vars.touchPosition.startX ) {
            vars.index++;
          } else if ( vars.touchPosition.currentX > vars.touchPosition.startX ) {
            vars.index--;
          }
          vars.isTouch = false;
          self.slideTo(vars.index);
        }
        toggleTouchEvents(off);
      }
    }
    function setActivePage(pageIndex) {
      Array.from(indicators).map(function (x){removeClass(x,'active');});
      indicators[pageIndex] && addClass(indicators[pageIndex], 'active');
    }
    function transitionEndHandler(e){
      if (vars.touchPosition){
        var next = vars.index,
            timeout = e && e.target !== slides[next] ? e.elapsedTime*1000+100 : 20,
            activeItem = self.getActiveIndex(),
            orientation = vars.direction === 'left' ? 'next' : 'prev';
        vars.isSliding && setTimeout(function () {
          if (vars.touchPosition){
            vars.isSliding = false;
            addClass(slides[next],'active');
            removeClass(slides[activeItem],'active');
            removeClass(slides[next],("carousel-item-" + orientation));
            removeClass(slides[next],("carousel-item-" + (vars.direction)));
            removeClass(slides[activeItem],("carousel-item-" + (vars.direction)));
            dispatchCustomEvent.call(element, slidCustomEvent);
            if ( !document.hidden && ops.interval && !hasClass(element,'paused') ) {
              self.cycle();
            }
          }
        }, timeout);
      }
    }
    self.cycle = function () {
      if (vars.timer) {
        clearInterval(vars.timer);
        vars.timer = null;
      }
      vars.timer = setInterval(function () {
        var idx = vars.index || self.getActiveIndex();
        isElementInScrollRange(element) && (idx++, self.slideTo( idx ) );
      }, ops.interval);
    };
    self.slideTo = function (next) {
      if (vars.isSliding) { return; }
      var activeItem = self.getActiveIndex(), orientation;
      if ( activeItem === next ) {
        return;
      } else if  ( (activeItem < next ) || (activeItem === 0 && next === slides.length -1 ) ) {
        vars.direction = 'left';
      } else if  ( (activeItem > next) || (activeItem === slides.length - 1 && next === 0 ) ) {
        vars.direction = 'right';
      }
      if ( next < 0 ) { next = slides.length - 1; }
      else if ( next >= slides.length ){ next = 0; }
      orientation = vars.direction === 'left' ? 'next' : 'prev';
      slideCustomEvent = bootstrapCustomEvent('slide', 'carousel', slides[next]);
      slidCustomEvent = bootstrapCustomEvent('slid', 'carousel', slides[next]);
      dispatchCustomEvent.call(element, slideCustomEvent);
      if (slideCustomEvent.defaultPrevented) { return; }
      vars.index = next;
      vars.isSliding = true;
      clearInterval(vars.timer);
      vars.timer = null;
      setActivePage( next );
      if ( getElementTransitionDuration(slides[next]) && hasClass(element,'slide') ) {
        addClass(slides[next],("carousel-item-" + orientation));
        slides[next].offsetWidth;
        addClass(slides[next],("carousel-item-" + (vars.direction)));
        addClass(slides[activeItem],("carousel-item-" + (vars.direction)));
        emulateTransitionEnd(slides[next], transitionEndHandler);
      } else {
        addClass(slides[next],'active');
        slides[next].offsetWidth;
        removeClass(slides[activeItem],'active');
        setTimeout(function () {
          vars.isSliding = false;
          if ( ops.interval && element && !hasClass(element,'paused') ) {
            self.cycle();
          }
          dispatchCustomEvent.call(element, slidCustomEvent);
        }, 100 );
      }
    };
    self.getActiveIndex = function () { return Array.from(slides).indexOf(element.getElementsByClassName('carousel-item active')[0]) || 0; };
    self.dispose = function () {
      var itemClasses = ['left','right','prev','next'];
      Array.from(slides).map(function (slide,idx) {
        hasClass(slide,'active') && setActivePage( idx );
        itemClasses.map(function (cls) { return removeClass(slide,("carousel-item-" + cls)); });
      });
      clearInterval(vars.timer);
      toggleEvents(off);
      vars = {};
      ops = {};
      delete element.Carousel;
    };
    tryWrapper(function (){
      element = queryElement( element );
      element.Carousel && element.Carousel.dispose();
      slides = element.getElementsByClassName('carousel-item');
      leftArrow = element.getElementsByClassName('carousel-control-prev')[0];
      rightArrow = element.getElementsByClassName('carousel-control-next')[0];
      indicator = element.getElementsByClassName('carousel-indicators')[0];
      indicators = indicator && indicator.getElementsByTagName( "LI" ) || [];
      if (slides.length < 2) { return }
      var
        intervalAttribute = element.getAttribute('data-interval'),
        intervalData = intervalAttribute === 'false' ? 0 : parseInt(intervalAttribute),
        touchData = element.getAttribute('data-touch') === 'false' ? 0 : 1,
        pauseData = element.getAttribute('data-pause') === 'hover' || false,
        keyboardData = element.getAttribute('data-keyboard') === 'true' || false,
        intervalOption = options.interval,
        touchOption = options.touch;
      ops = {};
      ops.keyboard = options.keyboard === true || keyboardData;
      ops.pause = (options.pause === 'hover' || pauseData) ? 'hover' : false;
      ops.touch = touchOption || touchData;
      ops.interval = typeof intervalOption === 'number' ? intervalOption
                  : intervalOption === false || intervalData === 0 || intervalData === false ? 0
                  : isNaN(intervalData) ? 5000
                  : intervalData;
      if (self.getActiveIndex()<0) {
        slides.length && addClass(slides[0],'active');
        indicators.length && setActivePage(0);
      }
      vars = {};
      vars.direction = 'left';
      vars.index = 0;
      vars.timer = null;
      vars.isSliding = false;
      vars.isTouch = false;
      vars.touchPosition = {
        startX : 0,
        currentX : 0,
        endX : 0
      };
      toggleEvents(on);
      if ( ops.interval ){ self.cycle(); }
      element.Carousel = self;
    },"BSN.Carousel");
  }

  function Collapse(element,options) {
    options = options || {};
    var self = this;
    var accordion = null,
        collapse = null,
        activeCollapse,
        activeElement,
        showCustomEvent,
        shownCustomEvent,
        hideCustomEvent,
        hiddenCustomEvent;
    function openAction(collapseElement, toggle) {
      dispatchCustomEvent.call(collapseElement, showCustomEvent);
      if ( showCustomEvent.defaultPrevented ) { return; }
      collapseElement.isAnimating = true;
      addClass(collapseElement,'collapsing');
      removeClass(collapseElement,'collapse');
      collapseElement.style.height = (collapseElement.scrollHeight) + "px";
      emulateTransitionEnd(collapseElement, function () {
        collapseElement.isAnimating = false;
        collapseElement.setAttribute('aria-expanded','true');
        toggle.setAttribute('aria-expanded','true');
        removeClass(collapseElement,'collapsing');
        addClass(collapseElement, 'collapse');
        addClass(collapseElement,'show');
        collapseElement.style.height = '';
        dispatchCustomEvent.call(collapseElement, shownCustomEvent);
      });
    }
    function closeAction(collapseElement, toggle) {
      dispatchCustomEvent.call(collapseElement, hideCustomEvent);
      if ( hideCustomEvent.defaultPrevented ) { return; }
      collapseElement.isAnimating = true;
      collapseElement.style.height = (collapseElement.scrollHeight) + "px";
      removeClass(collapseElement,'collapse');
      removeClass(collapseElement,'show');
      addClass(collapseElement,'collapsing');
      collapseElement.offsetWidth;
      collapseElement.style.height = '0px';
      emulateTransitionEnd(collapseElement, function () {
        collapseElement.isAnimating = false;
        collapseElement.setAttribute('aria-expanded','false');
        toggle.setAttribute('aria-expanded','false');
        removeClass(collapseElement,'collapsing');
        addClass(collapseElement,'collapse');
        collapseElement.style.height = '';
        dispatchCustomEvent.call(collapseElement, hiddenCustomEvent);
      });
    }
    self.toggle = function (e) {
      if (e && e.target.tagName === 'A' || element.tagName === 'A') {e.preventDefault();}
      if (element.contains(e.target) || e.target === element) {
        if (!hasClass(collapse,'show')) { self.show(); }
        else { self.hide(); }
      }
    };
    self.hide = function () {
      if ( collapse.isAnimating ) { return; }
      closeAction(collapse,element);
      addClass(element,'collapsed');
    };
    self.show = function () {
      if ( accordion ) {
        activeCollapse = accordion.getElementsByClassName("collapse show")[0];
        activeElement = activeCollapse && (queryElement(("[data-target=\"#" + (activeCollapse.id) + "\"]"),accordion)
                      || queryElement(("[href=\"#" + (activeCollapse.id) + "\"]"),accordion) );
      }
      if ( !collapse.isAnimating ) {
        if ( activeElement && activeCollapse !== collapse ) {
          closeAction(activeCollapse,activeElement);
          addClass(activeElement,'collapsed');
        }
        openAction(collapse,element);
        removeClass(element,'collapsed');
      }
    };
    self.dispose = function () {
      off(element, 'click', self.toggle);
      delete element.Collapse;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Collapse && element.Collapse.dispose();
      var accordionData = element.getAttribute('data-parent');
      showCustomEvent = bootstrapCustomEvent('show', 'collapse');
      shownCustomEvent = bootstrapCustomEvent('shown', 'collapse');
      hideCustomEvent = bootstrapCustomEvent('hide', 'collapse');
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'collapse');
      collapse = queryElement(options.target || element.getAttribute('data-target') || element.getAttribute('href'));
      collapse.isAnimating = false;
      accordion = element.closest(options.parent || accordionData);
      if ( !element.Collapse ) {
        on(element, 'click', self.toggle);
      }
      element.Collapse = self;
    },"BSN.Collapse");
  }

  var mouseClickEvents = { down: 'mousedown', up: 'mouseup' };

  var support3DTransform = 'webkitPerspective' in document.body.style || 'perspective' in document.body.style;

  var supportTransform = 'webkitTransform' in document.body.style || 'transform' in document.body.style;

  function setFocus (element){
    element.focus ? element.focus() : element.setActive();
  }
  function getScroll () {
    return {
      y : window.pageYOffset || document.documentElement.scrollTop,
      x : window.pageXOffset || document.documentElement.scrollLeft
    }
  }
  function styleTip (link,element,position,parent) {
    var tipPositions = /\b(top|bottom|left|right)+/,
        elementDimensions = { w : element.offsetWidth, h: element.offsetHeight },
        windowWidth = (document.documentElement.clientWidth || document.body.clientWidth),
        windowHeight = (document.documentElement.clientHeight || document.body.clientHeight),
        rect = link.getBoundingClientRect(),
        scroll = parent === document.body ? getScroll() : { x: parent.offsetLeft + parent.scrollLeft, y: parent.offsetTop + parent.scrollTop },
        linkDimensions = { w: rect.right - rect.left, h: rect.bottom - rect.top },
        isPopover = hasClass(element,'popover'),
        arrow = queryElement('.arrow',element),
        halfTopExceed = rect.top + linkDimensions.h/2 - elementDimensions.h/2 < 0,
        halfLeftExceed = rect.left + linkDimensions.w/2 - elementDimensions.w/2 < 0,
        halfRightExceed = rect.left + elementDimensions.w/2 + linkDimensions.w/2 >= windowWidth,
        halfBottomExceed = rect.top + elementDimensions.h/2 + linkDimensions.h/2 >= windowHeight,
        topExceed = rect.top - elementDimensions.h < 0,
        leftExceed = rect.left - elementDimensions.w < 0,
        bottomExceed = rect.top + elementDimensions.h + linkDimensions.h >= windowHeight,
        rightExceed = rect.left + elementDimensions.w + linkDimensions.w >= windowWidth;
    position = (position === 'left' || position === 'right') && leftExceed && rightExceed ? 'top' : position;
    position = position === 'top' && topExceed ? 'bottom' : position;
    position = position === 'bottom' && bottomExceed ? 'top' : position;
    position = position === 'left' && leftExceed ? 'right' : position;
    position = position === 'right' && rightExceed ? 'left' : position;
    var topPosition,
      leftPosition,
      arrowTop,
      arrowLeft,
      arrowWidth,
      arrowHeight;
    element.className.indexOf(position) === -1 && (element.className = element.className.replace(tipPositions,position));
    arrowWidth = arrow.offsetWidth; arrowHeight = arrow.offsetHeight;
    if ( position === 'left' || position === 'right' ) {
      if ( position === 'left' ) {
        leftPosition = rect.left + scroll.x - elementDimensions.w - ( isPopover ? arrowWidth : 0 );
      } else {
        leftPosition = rect.left + scroll.x + linkDimensions.w;
      }
      if (halfTopExceed) {
        topPosition = rect.top + scroll.y;
        arrowTop = linkDimensions.h/2 - arrowWidth;
      } else if (halfBottomExceed) {
        topPosition = rect.top + scroll.y - elementDimensions.h + linkDimensions.h;
        arrowTop = elementDimensions.h - linkDimensions.h/2 - arrowWidth;
      } else {
        topPosition = rect.top + scroll.y - elementDimensions.h/2 + linkDimensions.h/2;
        arrowTop = elementDimensions.h/2 - (isPopover ? arrowHeight*0.9 : arrowHeight/2);
      }
    } else if ( position === 'top' || position === 'bottom' ) {
      if ( position === 'top') {
        topPosition =  rect.top + scroll.y - elementDimensions.h - ( isPopover ? arrowHeight : 0 );
      } else {
        topPosition = rect.top + scroll.y + linkDimensions.h;
      }
      if (halfLeftExceed) {
        leftPosition = 0;
        arrowLeft = rect.left + linkDimensions.w/2 - arrowWidth;
      } else if (halfRightExceed) {
        leftPosition = windowWidth - elementDimensions.w*1.01;
        arrowLeft = elementDimensions.w - ( windowWidth - rect.left ) + linkDimensions.w/2 - arrowWidth/2;
      } else {
        leftPosition = rect.left + scroll.x - elementDimensions.w/2 + linkDimensions.w/2;
        arrowLeft = elementDimensions.w/2 - ( isPopover ? arrowWidth : arrowWidth/2 );
      }
    }
    element.style.top = topPosition + 'px';
    element.style.left = leftPosition + 'px';
    arrowTop && (arrow.style.top = arrowTop + 'px');
    arrowLeft && (arrow.style.left = arrowLeft + 'px');
  }

  function Dropdown(element,option) {
    var self = this,
        showCustomEvent,
        shownCustomEvent,
        hideCustomEvent,
        hiddenCustomEvent,
        relatedTarget = null,
        parent, menu, menuItems = [],
        persist;
    function preventEmptyAnchor(anchor) {
      (anchor.href && anchor.href.slice(-1) === '#' || anchor.parentNode && anchor.parentNode.href
        && anchor.parentNode.href.slice(-1) === '#') && this.preventDefault();
    }
    function toggleDismiss() {
      var action = element.open ? on : off;
      action(document, 'click', dismissHandler);
      action(document, 'keydown', preventScroll);
      action(document, 'keyup', keyHandler);
      action(document, 'focus', dismissHandler, true);
    }
    function dismissHandler(e) {
      if (e.target.getAttribute === undefined)
          { return; }
      var eventTarget = e.target,
            hasData = eventTarget && (eventTarget.getAttribute('data-toggle')
                                  || eventTarget.parentNode && eventTarget.parentNode.getAttribute
                                  && eventTarget.parentNode.getAttribute('data-toggle'));
      if ( e.type === 'focus' && (eventTarget === element || eventTarget === menu || menu.contains(eventTarget) ) ) {
        return;
      }
      if ( (eventTarget === menu || menu.contains(eventTarget)) && (persist || hasData) ) { return; }
      else {
        relatedTarget = eventTarget === element || element.contains(eventTarget) ? element : null;
        self.hide();
      }
      preventEmptyAnchor.call(e,eventTarget);
    }
    function clickHandler(e) {
      relatedTarget = element;
      self.show();
      preventEmptyAnchor.call(e,e.target);
    }
    function preventScroll(e) {
      var key = e.which || e.keyCode;
      if( key === 38 || key === 40 ) { e.preventDefault(); }
    }
    function keyHandler(ref) {
      var which = ref.which;
      var keyCode = ref.keyCode;
      var key = which || keyCode,
          activeItem = document.activeElement,
          isSameElement = activeItem === element,
          isInsideMenu = menu.contains(activeItem),
          isMenuItem = activeItem.parentNode === menu || activeItem.parentNode.parentNode === menu;
      var idx = menuItems.indexOf(activeItem);
      if ( isMenuItem ) {
          do {
            idx = isSameElement ? 0
                                : key === 38 ? (idx>1?idx-1:0)
                                : key === 40 ? (idx<menuItems.length-1?idx+1:idx) : idx;
            if ( idx === 0 || idx === menuItems[length]-1)
              { break; }
          } while ( !menuItems[idx].offsetHeight )
          menuItems[idx] && setFocus(menuItems[idx]);
      }
      if ( (menuItems.length && isMenuItem
            || !menuItems.length && (isInsideMenu || isSameElement)
            || !isInsideMenu )
            && element.open && key === 27
      ) {
        self.toggle();
        relatedTarget = null;
      }
    }
    self.show = function () {
      showCustomEvent = bootstrapCustomEvent('show', 'dropdown', relatedTarget);
      dispatchCustomEvent.call(parent, showCustomEvent);
      if ( showCustomEvent.defaultPrevented ) { return; }
      addClass(menu,'show');
      addClass(parent,'show');
      element.setAttribute('aria-expanded',true);
      element.open = true;
      off(element, 'click', clickHandler);
      setTimeout(function () {
        setFocus( menu.getElementsByTagName('INPUT')[0] || (menuItems.length && menuItems[0]) || element );
        toggleDismiss();
        shownCustomEvent = bootstrapCustomEvent( 'shown', 'dropdown', relatedTarget);
        dispatchCustomEvent.call(parent, shownCustomEvent);
      },1);
    };
    self.hide = function () {
      hideCustomEvent = bootstrapCustomEvent('hide', 'dropdown', relatedTarget);
      dispatchCustomEvent.call(parent, hideCustomEvent);
      if ( hideCustomEvent.defaultPrevented ) { return; }
      removeClass(menu,'show');
      removeClass(parent,'show');
      element.setAttribute('aria-expanded',false);
      element.open = false;
      toggleDismiss();
      setFocus(element);
      setTimeout(function () {
        element.Dropdown && on(element, 'click', clickHandler);
      },1);
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'dropdown', relatedTarget);
      dispatchCustomEvent.call(parent, hiddenCustomEvent);
    };
    self.toggle = function () {
      if (hasClass(parent,'show') && element.open) { self.hide(); }
      else { self.show(); }
    };
    self.dispose = function () {
      if (hasClass(parent,'show') && element.open) { self.hide(); }
      off(element, 'click', clickHandler);
      delete element.Dropdown;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Dropdown && element.Dropdown.dispose();
      parent = element.parentNode;
      menu = queryElement('.dropdown-menu', parent);
      Array.from(menu.children).map(function (child){
        Array.from(child.children).map(function(child2){
          child2.tagName === 'A' && menuItems.push(child2);
        });
        child.tagName === 'A' && menuItems.push(child);
      });
      if ( !element.Dropdown ) {
        !('tabindex' in menu) && menu.setAttribute('tabindex', '0');
        on(element, 'click', clickHandler);
      }
      persist = option === true || element.getAttribute('data-persist') === 'true' || false;
      element.open = false;
      element.Dropdown = self;
    },"BSN.Dropdown");
  }

  function Modal(element,options) {
    options = options || {};
    var self = this, modal,
      showCustomEvent,
      shownCustomEvent,
      hideCustomEvent,
      hiddenCustomEvent,
      relatedTarget = null,
      scrollBarWidth,
      overlay,
      overlayDelay,
      fixedItems,
      ops = {};
    function setScrollbar() {
      var openModal = hasClass(document.body,'modal-open'),
          bodyPad = parseInt(getComputedStyle(document.body).paddingRight),
          bodyOverflow = document.documentElement.clientHeight !== document.documentElement.scrollHeight
                      || document.body.clientHeight !== document.body.scrollHeight,
          modalOverflow = modal.clientHeight !== modal.scrollHeight;
      scrollBarWidth = measureScrollbar();
      modal.style.paddingRight = !modalOverflow && scrollBarWidth ? (scrollBarWidth + "px") : '';
      document.body.style.paddingRight = modalOverflow || bodyOverflow ? ((bodyPad + (openModal ? 0:scrollBarWidth)) + "px") : '';
      fixedItems.length && fixedItems.map(function (fixed){
        var itemPad = getComputedStyle(fixed).paddingRight;
        fixed.style.paddingRight = modalOverflow || bodyOverflow ? ((parseInt(itemPad) + (openModal?0:scrollBarWidth)) + "px") : ((parseInt(itemPad)) + "px");
      });
    }
    function resetScrollbar() {
      document.body.style.paddingRight = '';
      modal.style.paddingRight = '';
      fixedItems.length && fixedItems.map(function (fixed){
        fixed.style.paddingRight = '';
      });
    }
    function measureScrollbar() {
      var scrollDiv = document.createElement('div'), widthValue;
      scrollDiv.className = 'modal-scrollbar-measure';
      document.body.appendChild(scrollDiv);
      widthValue = scrollDiv.offsetWidth - scrollDiv.clientWidth;
      document.body.removeChild(scrollDiv);
      return widthValue;
    }
    function createOverlay() {
      var newOverlay = document.createElement('div');
      overlay = queryElement('.modal-backdrop');
      if ( overlay === null ) {
        newOverlay.setAttribute('class', 'modal-backdrop' + (ops.animation ? ' fade' : ''));
        overlay = newOverlay;
        document.body.appendChild(overlay);
      }
      return overlay;
    }
    function removeOverlay () {
      overlay = queryElement('.modal-backdrop');
      if ( overlay && !document.getElementsByClassName('modal show')[0] ) {
        document.body.removeChild(overlay); overlay = null;
      }
      overlay === null && (removeClass(document.body,'modal-open'), resetScrollbar());
    }
    function toggleEvents(action) {
      action(window, 'resize', self.update, passiveHandler);
      action(modal, 'click', dismissHandler);
      action(document, 'keydown', keyHandler);
    }
    function beforeShow() {
      modal.style.display = 'block';
      setScrollbar();
      !document.getElementsByClassName('modal show')[0] && addClass(document.body,'modal-open');
      addClass(modal,'show');
      modal.setAttribute('aria-hidden', false);
      hasClass(modal,'fade') ? emulateTransitionEnd(modal, triggerShow) : triggerShow();
    }
    function triggerShow() {
      setFocus(modal);
      modal.isAnimating = false;
      toggleEvents(on);
      shownCustomEvent = bootstrapCustomEvent('shown', 'modal', relatedTarget);
      dispatchCustomEvent.call(modal, shownCustomEvent);
    }
    function triggerHide(force) {
      modal.style.display = '';
      element && (setFocus(element));
      overlay = queryElement('.modal-backdrop');
      if (force !== 1 && overlay && hasClass(overlay,'show') && !document.getElementsByClassName('modal show')[0]) {
        removeClass(overlay,'show');
        emulateTransitionEnd(overlay,removeOverlay);
      } else {
        removeOverlay();
      }
      toggleEvents(off);
      modal.isAnimating = false;
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'modal');
      dispatchCustomEvent.call(modal, hiddenCustomEvent);
    }
    function clickHandler(e) {
      if ( modal.isAnimating ) { return; }
      var clickTarget = e.target,
          modalID = "#" + (modal.getAttribute('id')),
          targetAttrValue = clickTarget.getAttribute('data-target') || clickTarget.getAttribute('href'),
          elemAttrValue = element.getAttribute('data-target') || element.getAttribute('href');
      if ( !hasClass(modal,'show')
          && (clickTarget === element && targetAttrValue === modalID
          || element.contains(clickTarget) && elemAttrValue === modalID) ) {
        modal.modalTrigger = element;
        relatedTarget = element;
        self.show();
        e.preventDefault();
      }
    }
    function keyHandler(ref) {
      var which = ref.which;
      if (!modal.isAnimating && ops.keyboard && which == 27 && hasClass(modal,'show') ) {
        self.hide();
      }
    }
    function dismissHandler(e) {
      if ( modal.isAnimating ) { return; }
      var clickTarget = e.target,
          hasData = clickTarget.getAttribute('data-dismiss') === 'modal',
          parentWithData = clickTarget.closest('[data-dismiss="modal"]');
      if ( hasClass(modal,'show') && ( parentWithData || hasData
          || clickTarget === modal && ops.backdrop !== 'static' ) ) {
        self.hide(); relatedTarget = null;
        e.preventDefault();
      }
    }
    self.toggle = function () {
      if ( hasClass(modal,'show') ) {self.hide();} else {self.show();}
    };
    self.show = function () {
      if (hasClass(modal, 'show') && !!modal.isAnimating ) {return}
      showCustomEvent = bootstrapCustomEvent('show', 'modal', relatedTarget);
      dispatchCustomEvent.call(modal, showCustomEvent);
      if ( showCustomEvent.defaultPrevented ) { return; }
      modal.isAnimating = true;
      var currentOpen = document.getElementsByClassName('modal show')[0];
      if (currentOpen && currentOpen !== modal) {
        currentOpen.modalTrigger && currentOpen.modalTrigger.Modal.hide();
        currentOpen.Modal && currentOpen.Modal.hide();
      }
      if ( ops.backdrop ) {
        overlay = createOverlay();
      }
      if ( overlay && !currentOpen && !hasClass(overlay,'show') ) {
        overlay.offsetWidth;
        overlayDelay = getElementTransitionDuration(overlay);
        addClass(overlay, 'show');
      }
      !currentOpen ? setTimeout( beforeShow, overlay && overlayDelay ? overlayDelay:0 ) : beforeShow();
    };
    self.hide = function (force) {
      if ( !hasClass(modal,'show') ) {return}
      hideCustomEvent = bootstrapCustomEvent( 'hide', 'modal');
      dispatchCustomEvent.call(modal, hideCustomEvent);
      if ( hideCustomEvent.defaultPrevented ) { return; }
      modal.isAnimating = true;
      removeClass(modal,'show');
      modal.setAttribute('aria-hidden', true);
      hasClass(modal,'fade') && force !== 1 ? emulateTransitionEnd(modal, triggerHide) : triggerHide();
    };
    self.setContent = function (content) {
      queryElement('.modal-content',modal).innerHTML = content;
    };
    self.update = function () {
      if (hasClass(modal,'show')) {
        setScrollbar();
      }
    };
    self.dispose = function () {
      self.hide(1);
      if (element) {off(element, 'click', clickHandler); delete element.Modal; }
      else {delete modal.Modal;}
    };
    tryWrapper(function (){
      element = queryElement(element);
      var checkModal = queryElement( element.getAttribute('data-target') || element.getAttribute('href') );
      modal = hasClass(element,'modal') ? element : checkModal;
      fixedItems = Array.from(document.getElementsByClassName('fixed-top'))
                        .concat(Array.from(document.getElementsByClassName('fixed-bottom')));
      if ( hasClass(element, 'modal') ) { element = null; }
      element && element.Modal && element.Modal.dispose();
      modal && modal.Modal && modal.Modal.dispose();
      ops.keyboard = options.keyboard === false || modal.getAttribute('data-keyboard') === 'false' ? false : true;
      ops.backdrop = options.backdrop === 'static' || modal.getAttribute('data-backdrop') === 'static' ? 'static' : true;
      ops.backdrop = options.backdrop === false || modal.getAttribute('data-backdrop') === 'false' ? false : ops.backdrop;
      ops.animation = hasClass(modal, 'fade') ? true : false;
      ops.content = options.content;
      modal.isAnimating = false;
      if ( element && !element.Modal ) {
        on(element, 'click', clickHandler);
      }
      if ( ops.content ) {
        self.setContent( ops.content.trim() );
      }
      if (element) {
        modal.modalTrigger = element;
        element.Modal = self;
      } else {
        modal.Modal = self;
      }
    },"BSN.Modal");
  }

  function Popover(element,options) {
    options = options || {};
    var self = this;
    var popover = null,
        timer = 0,
        isIphone = /(iPhone|iPod|iPad)/.test(navigator.userAgent),
        titleString,
        contentString,
        ops = {};
    var triggerData,
        animationData,
        placementData,
        dismissibleData,
        delayData,
        containerData,
        closeBtn,
        showCustomEvent,
        shownCustomEvent,
        hideCustomEvent,
        hiddenCustomEvent,
        containerElement,
        containerDataElement,
        modal,
        navbarFixedTop,
        navbarFixedBottom,
        placementClass;
    function dismissibleHandler(e) {
      if (popover !== null && e.target === queryElement('.close',popover)) {
        self.hide();
      }
    }
    function getContents() {
      return {
        0 : options.title || element.getAttribute('data-title') || null,
        1 : options.content || element.getAttribute('data-content') || null
      }
    }
    function removePopover() {
      ops.container.removeChild(popover);
      timer = null; popover = null;
    }
    function createPopover() {
      titleString = getContents()[0] || null;
      contentString = getContents()[1];
      contentString = !!contentString ? contentString.trim() : null;
      popover = document.createElement('div');
      var popoverArrow = document.createElement('div');
      addClass(popoverArrow,'arrow');
      popover.appendChild(popoverArrow);
      if ( contentString !== null && ops.template === null ) {
        popover.setAttribute('role','tooltip');
        if (titleString !== null) {
          var popoverTitle = document.createElement('h3');
          addClass(popoverTitle,'popover-header');
          popoverTitle.innerHTML = ops.dismissible ? titleString + closeBtn : titleString;
          popover.appendChild(popoverTitle);
        }
        var popoverBodyMarkup = document.createElement('div');
        addClass(popoverBodyMarkup,'popover-body');
        popoverBodyMarkup.innerHTML = ops.dismissible && titleString === null ? contentString + closeBtn : contentString;
        popover.appendChild(popoverBodyMarkup);
      } else {
        var popoverTemplate = document.createElement('div');
        popoverTemplate.innerHTML = ops.template.trim();
        popover.className = popoverTemplate.firstChild.className;
        popover.innerHTML = popoverTemplate.firstChild.innerHTML;
        var popoverHeader = queryElement('.popover-header',popover),
            popoverBody = queryElement('.popover-body',popover);
        titleString && popoverHeader && (popoverHeader.innerHTML = titleString.trim());
        contentString && popoverBody && (popoverBody.innerHTML = contentString.trim());
      }
      ops.container.appendChild(popover);
      popover.style.display = 'block';
      !hasClass(popover, 'popover') && addClass(popover, 'popover');
      !hasClass(popover, ops.animation) && addClass(popover, ops.animation);
      !hasClass(popover, placementClass) && addClass(popover, placementClass);
    }
    function showPopover() {
      !hasClass(popover,'show') && ( addClass(popover,'show') );
    }
    function updatePopover() {
      styleTip(element, popover, ops.placement, ops.container);
    }
    function forceFocus () {
      if (popover === null) { element.focus(); }
    }
    function toggleEvents(action) {
      if (ops.trigger === 'hover') {
        action( element, mouseClickEvents.down, self.show );
        action( element, mouseHoverEvents[0], self.show );
        if (!ops.dismissible) { action( element, mouseHoverEvents[1], self.hide ); }
      } else if ('click' == ops.trigger) {
        action( element, ops.trigger, self.toggle );
      } else if ('focus' == ops.trigger) {
        isIphone && action( element, 'click', forceFocus );
        action( element, ops.trigger, self.toggle );
      }
    }
    function touchHandler(e){
      if ( popover && popover.contains(e.target) || e.target === element || element.contains(e.target)) ; else {
        self.hide();
      }
    }
    function dismissHandlerToggle(action) {
      if (ops.dismissible) {
        action( document, 'click', dismissibleHandler );
      } else {
        'focus' == ops.trigger && action( element, 'blur', self.hide );
        'hover' == ops.trigger && action( document, touchEvents.start, touchHandler, passiveHandler );
      }
      action( window, 'resize', self.hide, passiveHandler );
    }
    function showTrigger() {
      dismissHandlerToggle(on);
      dispatchCustomEvent.call(element, shownCustomEvent);
    }
    function hideTrigger() {
      dismissHandlerToggle(off);
      removePopover();
      dispatchCustomEvent.call(element, hiddenCustomEvent);
    }
    self.toggle = function () {
      if (popover === null) { self.show(); }
      else { self.hide(); }
    };
    self.show = function () {
      clearTimeout(timer);
      timer = setTimeout( function () {
        if (popover === null) {
          dispatchCustomEvent.call(element, showCustomEvent);
          if ( showCustomEvent.defaultPrevented ) { return; }
          createPopover();
          updatePopover();
          showPopover();
          !!ops.animation ? emulateTransitionEnd(popover, showTrigger) : showTrigger();
        }
      }, 20 );
    };
    self.hide = function () {
      clearTimeout(timer);
      timer = setTimeout( function () {
        if (popover && popover !== null && hasClass(popover,'show')) {
          dispatchCustomEvent.call(element, hideCustomEvent);
          if ( hideCustomEvent.defaultPrevented ) { return; }
          removeClass(popover,'show');
          !!ops.animation ? emulateTransitionEnd(popover, hideTrigger) : hideTrigger();
        }
      }, ops.delay );
    };
    self.dispose = function () {
      self.hide();
      toggleEvents(off);
      delete element.Popover;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Popover && element.Popover.dispose();
      triggerData = element.getAttribute('data-trigger');
      animationData = element.getAttribute('data-animation');
      placementData = element.getAttribute('data-placement');
      dismissibleData = element.getAttribute('data-dismissible');
      delayData = element.getAttribute('data-delay');
      containerData = element.getAttribute('data-container');
      closeBtn = '<button type="button" class="close">×</button>';
      showCustomEvent = bootstrapCustomEvent('show', 'popover');
      shownCustomEvent = bootstrapCustomEvent('shown', 'popover');
      hideCustomEvent = bootstrapCustomEvent('hide', 'popover');
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'popover');
      containerElement = queryElement(options.container);
      containerDataElement = queryElement(containerData);
      modal = element.closest('.modal');
      navbarFixedTop = element.closest('.fixed-top');
      navbarFixedBottom = element.closest('.fixed-bottom');
      ops.template = options.template ? options.template : null;
      ops.trigger = options.trigger ? options.trigger : triggerData || 'hover';
      ops.animation = options.animation && options.animation !== 'fade' ? options.animation : animationData || 'fade';
      ops.placement = options.placement ? options.placement : placementData || 'top';
      ops.delay = parseInt(options.delay || delayData) || 200;
      ops.dismissible = options.dismissible || dismissibleData === 'true' ? true : false;
      ops.container = containerElement ? containerElement
                             : containerDataElement ? containerDataElement
                             : navbarFixedTop ? navbarFixedTop
                             : navbarFixedBottom ? navbarFixedBottom
                             : modal ? modal : document.body;
      placementClass = "bs-popover-" + (ops.placement);
      var popoverContents = getContents();
      titleString = popoverContents[0];
      contentString = popoverContents[1];
      if ( !contentString && !ops.template ) { return; }
      if ( !element.Popover ) {
        toggleEvents(on);
      }
      element.Popover = self;
    },"BSN.Popover");
  }

  function Tab(element,options) {
    options = options || {};
    var self = this,
      heightData,
      tabs, dropdown,
      showCustomEvent,
      shownCustomEvent,
      hideCustomEvent,
      hiddenCustomEvent,
      next,
      tabsContentContainer = false,
      activeTab,
      activeContent,
      nextContent,
      containerHeight,
      equalContents,
      nextHeight,
      animateHeight;
    function triggerEnd() {
      tabsContentContainer.style.height = '';
      removeClass(tabsContentContainer,'collapsing');
      tabs.isAnimating = false;
    }
    function triggerShow() {
      if (tabsContentContainer) {
        if ( equalContents ) {
          triggerEnd();
        } else {
          setTimeout(function () {
            tabsContentContainer.style.height = nextHeight + "px";
            tabsContentContainer.offsetWidth;
            emulateTransitionEnd(tabsContentContainer, triggerEnd);
          },50);
        }
      } else {
        tabs.isAnimating = false;
      }
      shownCustomEvent = bootstrapCustomEvent('shown', 'tab', activeTab);
      dispatchCustomEvent.call(next, shownCustomEvent);
    }
    function triggerHide() {
      if (tabsContentContainer) {
        activeContent.style.float = 'left';
        nextContent.style.float = 'left';
        containerHeight = activeContent.scrollHeight;
      }
      showCustomEvent = bootstrapCustomEvent('show', 'tab', activeTab);
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'tab', next);
      dispatchCustomEvent.call(next, showCustomEvent);
      if ( showCustomEvent.defaultPrevented ) { return; }
      addClass(nextContent,'active');
      removeClass(activeContent,'active');
      if (tabsContentContainer) {
        nextHeight = nextContent.scrollHeight;
        equalContents = nextHeight === containerHeight;
        addClass(tabsContentContainer,'collapsing');
        tabsContentContainer.style.height = containerHeight + "px";
        tabsContentContainer.offsetHeight;
        activeContent.style.float = '';
        nextContent.style.float = '';
      }
      if ( hasClass(nextContent, 'fade') ) {
        setTimeout(function () {
          addClass(nextContent,'show');
          emulateTransitionEnd(nextContent,triggerShow);
        },20);
      } else { triggerShow(); }
      dispatchCustomEvent.call(activeTab, hiddenCustomEvent);
    }
    function getActiveTab() {
      var activeTabs = tabs.getElementsByClassName('active'), activeTab;
      if ( activeTabs.length === 1 && !hasClass(activeTabs[0].parentNode,'dropdown') ) {
        activeTab = activeTabs[0];
      } else if ( activeTabs.length > 1 ) {
        activeTab = activeTabs[activeTabs.length-1];
      }
      return activeTab;
    }
    function getActiveContent() { return queryElement(getActiveTab().getAttribute('href')) }
    function clickHandler(e) {
      e.preventDefault();
      next = e.currentTarget;
      !tabs.isAnimating && self.show();
    }
    self.show = function () {
      next = next || element;
      if (!hasClass(next,'active')) {
        nextContent = queryElement(next.getAttribute('href'));
        activeTab = getActiveTab();
        activeContent = getActiveContent();
        hideCustomEvent = bootstrapCustomEvent( 'hide', 'tab', next);
        dispatchCustomEvent.call(activeTab, hideCustomEvent);
        if (hideCustomEvent.defaultPrevented) { return; }
        tabs.isAnimating = true;
        removeClass(activeTab,'active');
        activeTab.setAttribute('aria-selected','false');
        addClass(next,'active');
        next.setAttribute('aria-selected','true');
        if ( dropdown ) {
          if ( !hasClass(element.parentNode,'dropdown-menu') ) {
            if (hasClass(dropdown,'active')) { removeClass(dropdown,'active'); }
          } else {
            if (!hasClass(dropdown,'active')) { addClass(dropdown,'active'); }
          }
        }
        if (hasClass(activeContent, 'fade')) {
          removeClass(activeContent,'show');
          emulateTransitionEnd(activeContent, triggerHide);
        } else { triggerHide(); }
      }
    };
    self.dispose = function () {
      off(element, 'click', clickHandler);
      delete element.Tab;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Tab && element.Tab.dispose();
      heightData = element.getAttribute('data-height');
      tabs = element.closest('.nav');
      dropdown = tabs && queryElement('.dropdown-toggle',tabs);
      animateHeight = !supportTransition || (options.height === false || heightData === 'false') ? false : true;
      tabs.isAnimating = false;
      if ( !element.Tab ) {
        on(element, 'click', clickHandler);
      }
      if (animateHeight) { tabsContentContainer = getActiveContent().parentNode; }
      element.Tab = self;
    },'BSN.Tab');
  }

  function Toast(element,options) {
    options = options || {};
    var self = this,
        toast, timer = 0,
        animationData,
        autohideData,
        delayData,
        showCustomEvent,
        hideCustomEvent,
        shownCustomEvent,
        hiddenCustomEvent,
        ops = {};
    function showComplete() {
      removeClass( toast, 'showing' );
      addClass( toast, 'show' );
      dispatchCustomEvent.call(toast,shownCustomEvent);
      if (ops.autohide) { self.hide(); }
    }
    function hideComplete() {
      addClass( toast, 'hide' );
      dispatchCustomEvent.call(toast,hiddenCustomEvent);
    }
    function close () {
      removeClass( toast,'show' );
      ops.animation ? emulateTransitionEnd(toast, hideComplete) : hideComplete();
    }
    function disposeComplete() {
      clearTimeout(timer);
      off(element, 'click', self.hide);
      delete element.Toast;
    }
    self.show = function () {
      if (toast && !hasClass(toast,'show')) {
        dispatchCustomEvent.call(toast,showCustomEvent);
        if (showCustomEvent.defaultPrevented) { return; }
        ops.animation && addClass( toast,'fade' );
        removeClass( toast,'hide' );
        toast.offsetWidth;
        addClass( toast,'showing' );
        ops.animation ? emulateTransitionEnd(toast, showComplete) : showComplete();
      }
    };
    self.hide = function (noTimer) {
      if (toast && hasClass(toast,'show')) {
        dispatchCustomEvent.call(toast,hideCustomEvent);
        if(hideCustomEvent.defaultPrevented) { return; }
        noTimer ? close() : (timer = setTimeout( close, ops.delay));
      }
    };
    self.dispose = function () {
      ops.animation ? emulateTransitionEnd(toast, disposeComplete) : disposeComplete();
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Toast && element.Toast.dispose();
      toast = element.closest('.toast');
      animationData = element.getAttribute('data-animation');
      autohideData = element.getAttribute('data-autohide');
      delayData = element.getAttribute('data-delay');
      showCustomEvent = bootstrapCustomEvent('show', 'toast');
      hideCustomEvent = bootstrapCustomEvent('hide', 'toast');
      shownCustomEvent = bootstrapCustomEvent('shown', 'toast');
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'toast');
      ops.animation = options.animation === false || animationData === 'false' ? 0 : 1;
      ops.autohide = options.autohide === false || autohideData === 'false' ? 0 : 1;
      ops.delay = parseInt(options.delay || delayData) || 500;
      if ( !element.Toast ) {
        on(element, 'click', self.hide);
      }
      element.Toast = self;
    },'BSN.Toast');
  }

  var componentsInit = {};

  var initCallback = function (lookUp){
    lookUp = lookUp || document;
    var initializeDataAPI = function( Constructor, collection ){
      Array.from(collection).map(function (x){ return new Constructor(x); });
    };
    for (var component in componentsInit) {
      initializeDataAPI( componentsInit[component][0], lookUp.querySelectorAll (componentsInit[component][1]) );
    }
  };
  var removeDataAPI = function (lookUp) {
    lookUp = lookUp || document;
    var removeElementDataAPI = function( ConstructorName, collection ){
      Array.from(collection).map(function (x){ return x[ConstructorName].dispose(); });
    };
    for (var component in componentsInit) {
      removeElementDataAPI( component, lookUp.querySelectorAll (componentsInit[component][1]) );
    }
  };

  function ScrollSpy(element,options) {
    options = options || {};
    var self = this,
      vars,
      targetData,
      offsetData,
      spyTarget,
      scrollTarget,
      ops = {};
    function updateTargets(){
      var links = spyTarget.getElementsByTagName('A');
      if (vars.length !== links.length) {
        vars.items = [];
        vars.targets = [];
        Array.from(links).map(function (link){
          var href = link.getAttribute('href'),
            targetItem = href && href.charAt(0) === '#' && href.slice(-1) !== '#' && queryElement(href);
          if ( targetItem ) {
            vars.items.push(link);
            vars.targets.push(targetItem);
          }
        });
        vars.length = links.length;
      }
    }
    function updateItem(index) {
      var item = vars.items[index],
        targetItem = vars.targets[index],
        dropmenu = hasClass(item,'dropdown-item') && item.closest('.dropdown-menu'),
        dropLink = dropmenu && dropmenu.previousElementSibling,
        nextSibling = item.nextElementSibling,
        activeSibling = nextSibling && nextSibling.getElementsByClassName('active').length,
        targetRect = vars.isWindow && targetItem.getBoundingClientRect(),
        isActive = hasClass(item,'active') || false,
        topEdge = (vars.isWindow ? targetRect.top + vars.scrollOffset : targetItem.offsetTop) - ops.offset,
        bottomEdge = vars.isWindow ? targetRect.bottom + vars.scrollOffset - ops.offset
                   : vars.targets[index+1] ? vars.targets[index+1].offsetTop - ops.offset
                   : element.scrollHeight,
        inside = activeSibling || vars.scrollOffset >= topEdge && bottomEdge > vars.scrollOffset;
       if ( !isActive && inside ) {
        addClass(item,'active');
        if (dropLink && !hasClass(dropLink,'active') ) {
          addClass(dropLink,'active');
        }
        dispatchCustomEvent.call(element, bootstrapCustomEvent( 'activate', 'scrollspy', vars.items[index]));
      } else if ( isActive && !inside ) {
        removeClass(item,'active');
        if (dropLink && hasClass(dropLink,'active') && !item.parentNode.getElementsByClassName('active').length ) {
          removeClass(dropLink,'active');
        }
      } else if ( isActive && inside || !inside && !isActive ) {
        return;
      }
    }
    function updateItems() {
      updateTargets();
      vars.scrollOffset = vars.isWindow ? getScroll().y : element.scrollTop;
      vars.items.map(function (l,idx){ return updateItem(idx); });
    }
    function toggleEvents(action) {
      action( scrollTarget, 'scroll', self.refresh, passiveHandler );
      action( window, 'resize', self.refresh, passiveHandler );
    }
    self.refresh = function () {
      updateItems();
    };
    self.dispose = function () {
      toggleEvents(off);
      delete element.ScrollSpy;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.ScrollSpy && element.ScrollSpy.dispose();
      targetData = element.getAttribute('data-target');
      offsetData = element.getAttribute('data-offset');
      spyTarget = queryElement(options.target || targetData);
      scrollTarget = element.offsetHeight < element.scrollHeight ? element : window;
      if (!spyTarget) { return }
      ops.target = spyTarget;
      ops.offset = parseInt(options.offset || offsetData) || 10;
      vars = {};
      vars.length = 0;
      vars.items = [];
      vars.targets = [];
      vars.isWindow = scrollTarget === window;
      if ( !element.ScrollSpy ) {
        toggleEvents(on);
      }
      self.refresh();
      element.ScrollSpy = self;
    },"BSN.ScrollSpy");
  }

  function Tooltip(element,options) {
    options = options || {};
    var self = this,
        tooltip = null, timer = 0, titleString,
        animationData,
        placementData,
        delayData,
        containerData,
        showCustomEvent,
        shownCustomEvent,
        hideCustomEvent,
        hiddenCustomEvent,
        containerElement,
        containerDataElement,
        modal,
        navbarFixedTop,
        navbarFixedBottom,
        placementClass,
        ops = {};
    function getTitle() {
      return element.getAttribute('title')
          || element.getAttribute('data-title')
          || element.getAttribute('data-original-title')
    }
    function removeToolTip() {
      ops.container.removeChild(tooltip);
      tooltip = null; timer = null;
    }
    function createToolTip() {
      titleString = getTitle();
      if ( titleString ) {
        tooltip = document.createElement('div');
        if (ops.template) {
          var tooltipMarkup = document.createElement('div');
          tooltipMarkup.innerHTML = ops.template.trim();
          tooltip.className = tooltipMarkup.firstChild.className;
          tooltip.innerHTML = tooltipMarkup.firstChild.innerHTML;
          queryElement('.tooltip-inner',tooltip).innerHTML = titleString.trim();
        } else {
          var tooltipArrow = document.createElement('div');
          addClass(tooltipArrow,'arrow');
          tooltip.appendChild(tooltipArrow);
          var tooltipInner = document.createElement('div');
          addClass(tooltipInner,'tooltip-inner');
          tooltip.appendChild(tooltipInner);
          tooltipInner.innerHTML = titleString;
        }
        tooltip.style.left = '0';
        tooltip.style.top = '0';
        tooltip.setAttribute('role','tooltip');
        !hasClass(tooltip, 'tooltip') && addClass(tooltip, 'tooltip');
        !hasClass(tooltip, ops.animation) && addClass(tooltip, ops.animation);
        !hasClass(tooltip, placementClass) && addClass(tooltip, placementClass);
        ops.container.appendChild(tooltip);
      }
    }
    function updateTooltip() {
      styleTip(element, tooltip, ops.placement, ops.container);
    }
    function showTooltip() {
      !hasClass(tooltip,'show') && ( addClass(tooltip,'show') );
    }
    function touchHandler(e){
      if ( tooltip && tooltip.contains(e.target) || e.target === element || element.contains(e.target)) ; else {
        self.hide();
      }
    }
    function showAction() {
      on( document, touchEvents.start, touchHandler, passiveHandler );
      on( window, 'resize', self.hide, passiveHandler );
      dispatchCustomEvent.call(element, shownCustomEvent);
    }
    function hideAction() {
      off( document, touchEvents.start, touchHandler, passiveHandler );
      off( window, 'resize', self.hide, passiveHandler );
      removeToolTip();
      dispatchCustomEvent.call(element, hiddenCustomEvent);
    }
    function toggleEvents(action) {
      action(element, mouseClickEvents.down, self.show);
      action(element, mouseHoverEvents[0], self.show);
      action(element, mouseHoverEvents[1], self.hide);
    }
    self.show = function () {
      clearTimeout(timer);
      timer = setTimeout( function () {
        if (tooltip === null) {
          dispatchCustomEvent.call(element, showCustomEvent);
          if (showCustomEvent.defaultPrevented) { return; }
          if(createToolTip() !== false) {
            updateTooltip();
            showTooltip();
            !!ops.animation ? emulateTransitionEnd(tooltip, showAction) : showAction();
          }
        }
      }, 20 );
    };
    self.hide = function () {
      clearTimeout(timer);
      timer = setTimeout( function () {
        if (tooltip && hasClass(tooltip,'show')) {
          dispatchCustomEvent.call(element, hideCustomEvent);
          if (hideCustomEvent.defaultPrevented) { return; }
          removeClass(tooltip,'show');
          !!ops.animation ? emulateTransitionEnd(tooltip, hideAction) : hideAction();
        }
      }, ops.delay);
    };
    self.toggle = function () {
      if (!tooltip) { self.show(); }
      else { self.hide(); }
    };
    self.dispose = function () {
      toggleEvents(off);
      self.hide();
      element.setAttribute('title', element.getAttribute('data-original-title'));
      element.removeAttribute('data-original-title');
      delete element.Tooltip;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Tooltip && element.Tooltip.dispose();
      animationData = element.getAttribute('data-animation');
      placementData = element.getAttribute('data-placement');
      delayData = element.getAttribute('data-delay');
      containerData = element.getAttribute('data-container');
      showCustomEvent = bootstrapCustomEvent('show', 'tooltip');
      shownCustomEvent = bootstrapCustomEvent('shown', 'tooltip');
      hideCustomEvent = bootstrapCustomEvent('hide', 'tooltip');
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'tooltip');
      containerElement = queryElement(options.container);
      containerDataElement = queryElement(containerData);
      modal = element.closest('.modal');
      navbarFixedTop = element.closest('.fixed-top');
      navbarFixedBottom = element.closest('.fixed-bottom');
      ops.animation = options.animation && options.animation !== 'fade' ? options.animation : animationData || 'fade';
      ops.placement = options.placement ? options.placement : placementData || 'top';
      ops.template = options.template ? options.template : null;
      ops.delay = parseInt(options.delay || delayData) || 200;
      ops.container = containerElement ? containerElement
                             : containerDataElement ? containerDataElement
                             : navbarFixedTop ? navbarFixedTop
                             : navbarFixedBottom ? navbarFixedBottom
                             : modal ? modal : document.body;
      placementClass = "bs-tooltip-" + (ops.placement);
      titleString = getTitle();
      if ( !titleString ) { return; }
      if (!element.Tooltip) {
        element.setAttribute('data-original-title',titleString);
        element.removeAttribute('title');
        toggleEvents(on);
      }
      element.Tooltip = self;
    },'BSN.Tooltip');
  }

  componentsInit.Alert = [ Alert, '[data-dismiss="alert"]'];
  componentsInit.Button = [ Button, '[data-toggle="buttons"]' ];
  componentsInit.Carousel = [ Carousel, '[data-ride="carousel"]' ];
  componentsInit.Collapse = [ Collapse, '[data-toggle="collapse"]' ];
  componentsInit.Dropdown = [ Dropdown, '[data-toggle="dropdown"]'];
  componentsInit.Modal = [ Modal, '[data-toggle="modal"]' ];
  componentsInit.Popover = [ Popover, '[data-toggle="popover"],[data-tip="popover"]' ];
  componentsInit.ScrollSpy = [ ScrollSpy, '[data-spy="scroll"]' ];
  componentsInit.Tab = [ Tab, '[data-toggle="tab"]' ];
  componentsInit.Toast = [ Toast, '[data-dismiss="toast"]' ];
  componentsInit.Tooltip = [ Tooltip, '[data-toggle="tooltip"],[data-tip="tooltip"]' ];
  document.body ? initCallback() : one( document, 'DOMContentLoaded', initCallback );

  var version = "3.0.3";

  var indexMympd = {
    Alert: Alert,
    Button: Button,
    Carousel: Carousel,
    Collapse: Collapse,
    Dropdown: Dropdown,
    Modal: Modal,
    Popover: Popover,
    Tab: Tab,
    Toast: Toast,
    initCallback: initCallback,
    removeDataAPI: removeDataAPI,
    componentsInit: componentsInit,
    Version: version
  };

  return indexMympd;

}));
var locales=[{"code":"de-DE","desc":"Deutsch"},{"code":"en-US","desc":"English"},{"code":"es-VE","desc":"Español"},{"code":"fi-FI","desc":"Finnish"},{"code":"ko-KR","desc":"한국어"},{"code":"nl-NL","desc":"Nederlands"}];var phrases={"%{name} added to queue":{"de-DE":"%{name} hinzugefügt","es-VE":"%{name} agregado a la cola de reproducción","fi-FI":"%{name} lisätty jonoon","ko-KR":"순서에 %{name} 추가함","nl-NL":"%{name} toegevoegd"},"%{name} added to queue position %{to}":{"de-DE":"%{name} an Warteschlangenposition %{to} hinzugefügt","es-VE":"%{name} agregado a la cola de reproducción en la posición %{to}","fi-FI":"%{name} lisätty jonossa kohtaan %{to}","ko-KR":"%{to} 순서 위치에 %{name} 추가함","nl-NL":"%{name} toegevoegd aan wachtrijpositie %{to}"},"About":{"de-DE":"Über myMPD","es-VE":"Acerca de","fi-FI":"Tietoja","ko-KR":"정보","nl-NL":"Over myMPD"},"Action":{"de-DE":"Aktion","es-VE":"Acción","fi-FI":"Toiminto","ko-KR":"기능","nl-NL":"Aktie"},"Add":{"de-DE":"Hinzufügen","es-VE":"Agregar","fi-FI":"Lisää","ko-KR":"추가","nl-NL":"Toevoegen"},"Add after current playing song":{"de-DE":"Nach aktuellem Lied hinzufügen","es-VE":"Añadir despues de la canción actual","fi-FI":"Lisää soivan kappaleen jälkeen","ko-KR":"지금 연주 중인 곡 다음에 추가","nl-NL":"Als volgende afspelen"},"Add all to playlist":{"de-DE":"Alles zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar todo a lista de reproducción","fi-FI":"Lisää kaikki soittolistaan","ko-KR":"연주목록에 모두 추가","nl-NL":"Alle aan afspeellijst toevoegen"},"Add all to queue":{"de-DE":"Alles zur Warteschlange hinzufügen","es-VE":"Agregar todo a cola de reproducción","fi-FI":"Lisää kaikki jonoon","ko-KR":"순서에 모두 추가","nl-NL":"Alle aan wachtrij toevoegen"},"Add bookmark":{"de-DE":"Lesezeichen hinzufügen","es-VE":"Agregar marcador","fi-FI":"Lisää kirjanmerkki","ko-KR":"즐겨찾기 추가","nl-NL":"Voeg bladwijzer toe"},"Add random":{"de-DE":"Zufällig hinzufügen","es-VE":"Agregar aleatorio","fi-FI":"Lisää satunnainen","ko-KR":"무작위 추가","nl-NL":"Voeg willekeurige toe"},"Add smart playlist":{"de-DE":"Neue intelligente Wiedergabeliste","es-VE":"Agregar Lista de reproducción inteligente","fi-FI":"Lisää älykäs soittolista","ko-KR":"스마트 연주목록 추가","nl-NL":"Slimme afspeellijst toevoegen"},"Add stream":{"de-DE":"Stream hinzufügen","es-VE":"Agregar fuente","fi-FI":"Lisää streami","ko-KR":"스트리밍 서비스 추가","nl-NL":"Stream toevoegen"},"Add to home screen":{"de-DE":"Zum Startbildschirm hinzufügen","es-VE":"Agregar a pantalla de inicio","fi-FI":"Lisää aloitus näkymään","ko-KR":"홈 화면에 추가","nl-NL":"Aan startscherm toevoegen"},"Add to playlist":{"de-DE":"Zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar a lista de reproducción","fi-FI":"Lisää soittolistaan","ko-KR":"연주목록에 추가","nl-NL":"Voeg toe aan afspeellijst "},"Add to queue":{"de-DE":"Zu Warteschlange hinzufügen","es-VE":"Agregar a la cola de reproducción","fi-FI":"Lisää jonoon","ko-KR":"순서에 추가","nl-NL":"Toevoegen aan wachtrij"},"Added %{uri} to playlist %{playlist}":{"de-DE":"%{uri} zu Wiedergabeliste %{playlist} hinzugefügt","es-VE":"%{uri} agregado a lista de reproducción %{playlist}","fi-FI":"%{uri} lisätty soittolistaan %{playlist}","ko-KR":"%{uri}의 %{playlist} 연주목록 추가에 실패함","nl-NL":"%{uri} toegevoegd aan afspeellijst %{playlist}"},"Added all songs":{"de-DE":"Alle Lieder hinzugefügt","es-VE":"Agregadas todas las canciones","fi-FI":"Kaikki kappaleet lisätty","ko-KR":"모든 곡을 추가함","nl-NL":"Alle nummers toegevoegd"},"Added songs to %{playlist}":{"de-DE":"Lieder zur Wiedergabeliste %{playlist} hinzugefügt","es-VE":"Canciones agregadas a la lista de reproducción %{playlist}","fi-FI":"Kappaleet lisätty soittolistaan %{playlist}","ko-KR":"%{playlist}에 곡 추가함","nl-NL":"Nummers aan %{playlist} toegevoegd"},"Added songs to queue":{"de-DE":"Lieder zur Warteschlange hinzugefügt","es-VE":"Canciones agregadas a la cola de reproducción","fi-FI":"Kappaleet lisätty jonoon","ko-KR":"순서에 곡 추가함","nl-NL":"Nummer aan wachtrij toegevoegd"},"Added stream %{streamUri} to queue":{"de-DE":"Stream %{streamUri} zu Warteschlange hinzugefügt","es-VE":"Agregar Fuente %{streamUri} a la cola de reproducción","fi-FI":"Streami %{streamUri} lisätty jonoon","ko-KR":"%{streamUri} 스트리밍을 순서에 추가함","nl-NL":"Stream %{streamUri} aan wachtrij toevoegen"},"Adding random songs to queue failed":{"de-DE":"Zufällige Lieder konnten nicht zur Warteschlange hinzugefügt werden","es-VE":"Error al agregar canciones aleatorias a la cola de reproducción","fi-FI":"Satunnaisten kappaleiden lisääminen jonoon epäonnistui","ko-KR":"순서에 무작위 곡 추가 안 됨","nl-NL":"Toevoegen willekeurig nummer mislukt"},"Adding timer failed":{"de-DE":"Timer konnte nicht hinzugefügt werden","es-VE":"Fallo al agregar Temporizador","fi-FI":"Ajastimen lisäys epäonnistui","ko-KR":"타이머를 추가할 수 없음","nl-NL":"Toevoegen timer mislukt"},"Advanced":{"de-DE":"Erweitert","es-VE":"Avanzado","fi-FI":"Lisäasetukset","ko-KR":"고급","nl-NL":"Geavanceerd"},"Album":{"de-DE":"Album","es-VE":"Álbum","fi-FI":"Albumi","ko-KR":"음반","nl-NL":"Album"},"AlbumArtist":{"de-DE":"Album Interpret","en-US":"Albumartist","es-VE":"Artista álbum","fi-FI":"Albumi Esittäjä","ko-KR":"음반 연주가","nl-NL":"Albumartiest"},"AlbumArtistSort":{"de-DE":"Album Interpret","es-VE":"Artista álbum","fi-FI":"AlbumiArtistiJärjestely","ko-KR":"음반 연주가 정렬","nl-NL":"Albumartiest"},"AlbumSort":{"de-DE":"Album","es-VE":"Álbum","fi-FI":"AlbumiJärjestely","ko-KR":"음반 정렬","nl-NL":"Album"},"Albumart":{"de-DE":"Albumcover","es-VE":"Carátula del álbum","fi-FI":"Albumcover","ko-KR":"음반 표지","nl-NL":"Albumcover"},"Albums":{"de-DE":"Alben","es-VE":"Álbumes","fi-FI":"Albumit","ko-KR":"음반","nl-NL":"Albums"},"Any Tag":{"de-DE":"Alle Tags","es-VE":"Cualquier etiqueta","fi-FI":"Mikä tahansa tagi","ko-KR":"모든 태그","nl-NL":"Alle tags"},"Appearance":{"de-DE":"Design","es-VE":"Apariencia","fi-FI":"Ulkoasu","ko-KR":"외관","nl-NL":"Uiterlijk"},"Append item to playlist":{"de-DE":"Ausgewähltes Element zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar elemento a lista de reproducción","fi-FI":"Lisää kohde soittolistaan","ko-KR":"연주목록에 항목 추가","nl-NL":"Selectie aan afspeellijst toevoegen"},"Append item to queue":{"de-DE":"Ausgewähltes Element an Warteschlange anhängen","es-VE":"Agregar elemento a la cola de reproducción","fi-FI":"Lisää kohde jonoon","ko-KR":"순서에 항목 추가","nl-NL":"Selectie aan wachtrij toevoegen"},"Append to queue":{"de-DE":"An Warteschlange anhängen","es-VE":"Añadir a la cola de reproducción","fi-FI":"Lisää jonoon","ko-KR":"순서에 추가","nl-NL":"Toevoegen aan wachtrij"},"Apply":{"de-DE":"Anwenden","es-VE":"Aplicar","fi-FI":"Käytä","ko-KR":"적용","nl-NL":"Toepassen"},"Applying settings":{"de-DE":"Einstellungen werden angewendet","es-VE":"Aplicando configuraciones","fi-FI":"Asetuksia otetaan käyttöön","ko-KR":"설정 적용","nl-NL":"Instellingen toepassen"},"Arguments":{"de-DE":"Parameter","ko-KR":"변수","nl-NL":"Parameters"},"Artist":{"de-DE":"Künstler","es-VE":"Artista","fi-FI":"Artisti","ko-KR":"연주가","nl-NL":"Artiest"},"ArtistSort":{"de-DE":"Künstler","es-VE":"Artista","fi-FI":"ArtistiJärjestely","ko-KR":"연주가 정렬","nl-NL":"Artiest"},"Artists":{"de-DE":"Interpreten","es-VE":"Artistas","fi-FI":"Artistit","ko-KR":"연주가","nl-NL":"Artiesten"},"Author":{"de-DE":"Autor","es-VE":"Autor","fi-FI":"Luoja","ko-KR":"저자","nl-NL":"Auteur"},"Auto":{"de-DE":"Auto","es-VE":"Auto","fi-FI":"Auto","ko-KR":"자동","nl-NL":"Auto"},"Autodetect":{"de-DE":"Automatisch","es-VE":"Auto detectar","fi-FI":"Automaattinen tunnistus","ko-KR":"자동 감지","nl-NL":"Automatisch"},"Autoplay":{"de-DE":"Automatische Wiedergabe","es-VE":"Reproducción automática","fi-FI":"Automaattitoisto","ko-KR":"자동 연주","nl-NL":"Auto-afspelen"},"Backend uri":{"de-DE":"Einzuhängende URL","es-VE":"URL Back-End","fi-FI":"Järjestelmä uri","ko-KR":"백엔드 URL","nl-NL":"Backend-url"},"Background":{"de-DE":"Hintergrund","es-VE":"Fondo","fi-FI":"Tausta","ko-KR":"배경","nl-NL":"Achtergrond"},"Background color":{"de-DE":"Hintergrundfarbe","es-VE":"Color de fondo","fi-FI":"Taustaväri","ko-KR":"배경색","nl-NL":"Achtergrondkleur"},"Best rated":{"de-DE":"Am Besten bewertet","es-VE":"Mejor calificado","fi-FI":"Paras arvostelu","ko-KR":"최고 평점","nl-NL":"Best beoordeeld"},"Booklet":{"de-DE":"Booklet","es-VE":"Folleto","fi-FI":"Booklet","ko-KR":"책자","nl-NL":"Booklet"},"Booklet filename":{"de-DE":"Booklet Dateiname","es-VE":"Archivo de folleto","fi-FI":"Bookletin tiedostonimi","ko-KR":"책자 파일 이름","nl-NL":"Booklet bestandsnaam"},"Bookmark URI":{"de-DE":"Lesezeichen URL","es-VE":"URL de marcador","fi-FI":"Kirjanmerkin URL","ko-KR":"즐겨찾기 주소","nl-NL":"Url bladwijzer"},"Bookmark name":{"de-DE":"Name","es-VE":"Nombre de marcador","fi-FI":"Kirjanmerkin nimi","ko-KR":"즐겨찾기 이름","nl-NL":"Naam"},"Bookmarks":{"de-DE":"Lesezeichen","es-VE":"Marcadores","fi-FI":"Kirjanmerkit","ko-KR":"즐겨찾기","nl-NL":"Bladwijzers"},"Browse":{"de-DE":"Durchsuchen","es-VE":"Explorar","fi-FI":"Selaa","ko-KR":"열기","nl-NL":"Browse"},"Browse directories":{"de-DE":"Verzeichnisse anzeigen","es-VE":"Explorar directorios","fi-FI":"Selaa kansioita","ko-KR":"디렉터리 열기","nl-NL":"Browse bestanden"},"Browser default":{"de-DE":"Browsereinstellung","es-VE":"Por defecto del navegador","fi-FI":"Selaimen asetus","ko-KR":"기본 열기","nl-NL":"Browserinstelling"},"CSS filter":{"de-DE":"CSS Filter","es-VE":"Filtro CSS","fi-FI":"CSS suodatin","ko-KR":"CSS 필터","nl-NL":"CSS filter"},"Calculate":{"de-DE":"Berechne Fingerabdruck","es-VE":"Calcular","fi-FI":"Laske","ko-KR":"계산","nl-NL":"Bereken"},"Can not crop the queue":{"de-DE":"Die Warteschlange konnte nicht abgeschnitten werden","fi-FI":"Ei voi rajata jonoa","ko-KR":"순서에 남길 수 없음","nl-NL":"Kan wachtrij niet inkorten"},"Can not open scriptfile":{"de-DE":"Skript konnte nicht geöffnet werden","ko-KR":"스크립트 파일을 열 수 없음","nl-NL":"Kan script niet openen"},"Can not parse settings":{"de-DE":"Einstellungen können nicht geladen werden","es-VE":"Error al leer configuraciones","fi-FI":"Asetusten käsittely ei onnistu","ko-KR":"설정을 분석할 수 없음","nl-NL":"Laden instellingen mislukt "},"Can not parse smart playlist file":{"de-DE":"Intelligente Wiedergabeliste konnte nicht geparsed werden","es-VE":"No se puede interpretar el archivo de lista de reproducción inteligente","fi-FI":"Älykkään soittolista tiedoston käsittely ei onnistu","ko-KR":"스마트 연주목록 파일을 분석할 수 없음","nl-NL":"Slimme afspeellijst kon niet worden ingelezen"},"Can not read smart playlist file":{"de-DE":"Intelligente Wiedergabeliste konnte nicht eingelesen werden","es-VE":"No se puede leer el archivo de lista de reproducción inteligente","fi-FI":"Älykkään soittolista tiedoston luku ei onnistu","ko-KR":"스마트 연주목록 파일을 읽을 수 없음","nl-NL":"Slimme afspeellijst kon niet worden gelezen"},"Can not start playing":{"de-DE":"Wiedergabe kann nicht gestartet werden","es-VE":"No se puede iniciar la reproducción","fi-FI":"Toistoa ei voi käynnistää","ko-KR":"연주를 시작할 수 없음","nl-NL":"Afspelen niet gestart"},"Can't access music directory":{"de-DE":"Musik Verzeichnis ist nicht verfügbar","es-VE":"No se puede acceder al directorio de música","fi-FI":"Musiikkikansiota ei pysty avaamaan","ko-KR":"음원 디렉터리에 접근할 수 없음","nl-NL":"Map niet toegankelijk"},"Can't create mympd_script thread":{"de-DE":"Konnte mympd_script Thread nicht erstellen","ko-KR":"mympd_script 스레드를 만들 수 없음","nl-NL":"Kan Mympd_script Thread niet maken"},"Can't save setting %{setting}":{"de-DE":"%{setting} konnte nicht gespeichert werden","es-VE":"Error al guardar la configuración: %{setting}","fi-FI":"Ei voi tallentaa asetusta %{setting}","ko-KR":"%{setting} 설정 저장할 수 없음","nl-NL":"Instelling %{setting} niet opgeslagen"},"Cancel":{"de-DE":"Abbrechen","es-VE":"Cancelar","fi-FI":"Peruuta","ko-KR":"취소","nl-NL":"Annuleren"},"Clear":{"de-DE":"Löschen","es-VE":"Limpiar","fi-FI":"Tyhjennä","ko-KR":"지우기","nl-NL":"Wissen"},"Clear app cache and reload":{"de-DE":"Browser Cache löschen und neu laden","es-VE":"Borrar caché de la app y recargar","fi-FI":"Tyhjennä ohjelman välimuisti ja lataa uudelleen","ko-KR":"앱 캐시를 지우고 다시 읽기","nl-NL":"Wis app-cache en herlaad"},"Clear covercache":{"de-DE":"Covercache löschen","es-VE":"Limpiar Covercache","fi-FI":"Tyhjennä Covercache","ko-KR":"표지 캐시 지우기","nl-NL":"Wis covercache"},"Clear playlist":{"de-DE":"Playlist leeren","es-VE":"Limpiar lista de reproducción","fi-FI":"Tyhjää soittolista","ko-KR":"연주목록 비우기","nl-NL":"Wis afspeellijst"},"Clear queue":{"de-DE":"Warteschlange leeren","es-VE":"Borrar cola de reproducción","fi-FI":"Tyhjennä jono","ko-KR":"순서 비우기","nl-NL":"Wis wachtrij"},"Clearing bookmarks failed":{"de-DE":"Löschen aller Lesezeichen fehlgeschlagen","es-VE":"Error al borrar marcadores","fi-FI":"Kirjanmerkkien tyhjentäminen epäonnistui","ko-KR":"즐겨찾기 지우기 안 됨","nl-NL":"Wissen bladwijzers mislukt"},"Close":{"de-DE":"Schließen","es-VE":"Cerrar","fi-FI":"Sulje","ko-KR":"닫기","nl-NL":"Sluit"},"Comment":{"de-DE":"Kommentar","es-VE":"Comentario","fi-FI":"Kommenttti","ko-KR":"설명","nl-NL":"Commentaar"},"Composer":{"de-DE":"Komponist","es-VE":"Compositor","fi-FI":"Säveltäjä","ko-KR":"작곡가","nl-NL":"Componist"},"Conductor":{"de-DE":"Dirigent","es-VE":"Director","fi-FI":"Kapelllimestari","ko-KR":"지휘자","nl-NL":"Dirigent"},"Connect to websocket":{"de-DE":"Websocketverbindung wird hergestellt","es-VE":"Conectando a websocket","fi-FI":"Yhdistetään websockettiin","ko-KR":"웹소켓에 연결","nl-NL":"Verbinden met websocket"},"Connected to MPD":{"de-DE":"Verbindung zu MPD hergestellt","es-VE":"Conectado a MPD","fi-FI":"Yhdistetty MPD:hen","ko-KR":"MPD로 연결됨","nl-NL":"Verbonden met MPD"},"Connected to myMPD":{"de-DE":"Verbindung zu myMPD hergestellt","es-VE":"Conectado a myMPD","fi-FI":"Yhdistetty myMPD:hen","ko-KR":"myMPD로 연결됨","nl-NL":"Verbonden met myMPD"},"Connecting to stream...":{"de-DE":"Verbinde...","es-VE":"Conectando fuente...","fi-FI":"Yhdistetään...","ko-KR":"스트리밍에 연결 중...","nl-NL":"Verbinden..."},"Connection":{"de-DE":"Verbindung","es-VE":"Conexión","fi-FI":"Yhteys","ko-KR":"연결","nl-NL":"Verbinding"},"Consume":{"de-DE":"Konsumieren","es-VE":"Consumir","fi-FI":"Kuluta","ko-KR":"써버리기","nl-NL":"Consumeren"},"Consume must be enabled":{"de-DE":"Konsumieren muss aktiviert sein","es-VE":"Modo Consumir debe estar habilitado","fi-FI":"Kulutuksen oltava päällä","ko-KR":"소비를 선택해야 함","nl-NL":"Consumeren moet zijn ingeschakeld"},"Could not delete script":{"de-DE":"Skript konnte nicht gelöscht werden","ko-KR":"스크립트를 지울 수 없음","nl-NL":"Kan script niet verwijderen"},"Could not delete trigger":{"de-DE":"Konnte Trigger nicht löschen","ko-KR":"트리거를 지울 수 없음"},"Could not save script":{"de-DE":"Skript konnte nicht gespeichert werden","ko-KR":"스크립트를 저장할 수 없음","nl-NL":"Kan script niet opslaan"},"Could not save trigger":{"de-DE":"Konnte Trigger nicht speichern","ko-KR":"트리거를 저장할 수 없음"},"Create Playlist":{"de-DE":"Neue Wiedergabeliste erstellen","es-VE":"Crear lista de reproducción","fi-FI":"Luo soittolista","ko-KR":"연주목록 만들기","nl-NL":"Afspeellijst maken"},"Crop":{"de-DE":"Abschneiden","es-VE":"Cortar","fi-FI":"Rajaa","ko-KR":"잘라내기","nl-NL":"Inkorten"},"Crop queue":{"de-DE":"Warteschlange abschneiden","es-VE":"Cortar cola de reproducción","fi-FI":"Rajaa jono","ko-KR":"순서 남기기","nl-NL":"Wachtrij inkorten"},"Crossfade":{"de-DE":"Crossfade","es-VE":"Fundido cruzado","fi-FI":"Crossfade","ko-KR":"크로스페이드","nl-NL":"Crossfade"},"Current partition":{"de-DE":"Momentane Partition","ko-KR":"현재 파티션"},"DB play time":{"de-DE":"Datenbank Wiedergabedauer","es-VE":"Tiempo de reproducción BD","fi-FI":"Tietokannan toistoaika","ko-KR":"DB 연주 시간","nl-NL":"DB speeltijd"},"DB updated":{"de-DE":"Datenbank zuletzt aktualisiert","es-VE":"BD actualizada","fi-FI":"Tietokanta päivitettty","ko-KR":"DB 업데이트됨","nl-NL":"DB geüpdatet"},"Dark":{"de-DE":"Dunkel","es-VE":"Oscuro","fi-FI":"Tumma","ko-KR":"어둠","nl-NL":"Donker"},"Database":{"de-DE":"Datenbank","es-VE":"Base de datos","fi-FI":"Tietokanta","ko-KR":"데이터 베이스","nl-NL":"Database"},"Database statistics":{"de-DE":"Datenbank Statistiken","es-VE":"Estadísticas de Base de datos","fi-FI":"Tietokanta tilastot","ko-KR":"데이터베이스 통계","nl-NL":"Database statistieken"},"Database successfully updated":{"de-DE":"Datenbank erfolgreich aktualisiert","es-VE":"Base de datos actualizada exitosamente","fi-FI":"Tietokannan päivitys onnistui","ko-KR":"데이터베이스 업데이트됨","nl-NL":"Database geüpdatet"},"Database update finished":{"de-DE":"Datenbankaktualisierung beendet","es-VE":"Finalizó la actualización de la base de datos","fi-FI":"Tietokannan päivitys valmis","ko-KR":"데이터베이스 업데이트 마침","nl-NL":"Update database klaar"},"Database update started":{"de-DE":"Datenbankaktualisierung gestartet","es-VE":"Inició la actualización de la base de datos","fi-FI":"Tietokannan päivitys aloitettu","ko-KR":"데이터베이스 업데이트 시작됨","nl-NL":"Updaten database gestart"},"Date":{"de-DE":"Datum","es-VE":"Año","fi-FI":"Päiväys","ko-KR":"날짜","nl-NL":"Datum"},"Days":{"de-DE":"Tage","en-US":"Days","es-VE":"Dias","fi-FI":"Päivää","ko-KR":"일","nl-NL":"Dagen"},"Default":{"de-DE":"Standard","es-VE":"Por defecto","fi-FI":"Vakio","ko-KR":"기본","nl-NL":"Standaard"},"Definition":{"de-DE":"Definition","es-VE":"Definición","fi-FI":"Määritelmä","ko-KR":"결정","nl-NL":"Definitie"},"Delete":{"de-DE":"Löschen","es-VE":"Eliminar","fi-FI":"Poista","ko-KR":"지우기","nl-NL":"Verwijder"},"Delete all playlists":{"de-DE":"Alle Wiedergabelisten löschen","es-VE":"Eliminar todas las listas de reproducción","fi-FI":"Poista kaikki soittolistat","ko-KR":"모든 연주목록 지움","nl-NL":"Alle afspeellijsten verwijderd"},"Delete all smart playlists":{"de-DE":"Alle Intelligenten Wiedergabelisten löschen","es-VE":"Eliminar todas las listas de reproducción inteligentes","fi-FI":"Poista kaikki älykkäät soittolistat","ko-KR":"모든 스마트 연주목록 지움","nl-NL":"Verwijder alle afspeellijsten"},"Delete empty playlists":{"de-DE":"Alle leere Wiedergabelisten löschen","es-VE":"Eliminar listas de reproducción vacias","fi-FI":"Poista tyhjät soittolistat","ko-KR":"빈 연주목록 지움","nl-NL":"Verwijderen lege afspeellijsten"},"Delete playlist":{"de-DE":"Wiedergabeliste löschen","es-VE":"Eliminar lista de reproducción","fi-FI":"Poista soittolista","ko-KR":"연주목록 지우기","nl-NL":"Verwijder afspeellijst"},"Delete playlists":{"de-DE":"Wiedergabelisten löschen","es-VE":"Eliminar listas de reproducción","fi-FI":"Poista soittolistat","ko-KR":"연주목록 지움","nl-NL":"Verwijder afspeellijsten"},"Deleting bookmark failed":{"de-DE":"Lesezeichen konnte nicht gelöscht werden","es-VE":"Error al eliminar marcador","fi-FI":"Kirjanmerkin poisto epäonnistui","ko-KR":"즐겨찾기 지우기 안 됨","nl-NL":"Verwijderen bladwijzer mislukt"},"Deleting smart playlist failed":{"de-DE":"Intelligente Wiedergabeliste konnte nicht gelöscht werden","es-VE":"Error al eliminar lista de reproducción inteligente","fi-FI":"Älykkään soittolista poisto epäonnistui","ko-KR":"스마트 연주목록 지우기 안 됨","nl-NL":"Verwijderen slimme afspeellijst mislukt"},"Dependent on the size of your music collection this can take a while":{"de-DE":"Der Aktualisierungsvorgang kann einige Zeit in Anspruch nehmen","es-VE":"Dependiendo del tamaño de su colección de música, esto puede llevar un tiempo","fi-FI":"Riippuen musiikkikokoelman koosta, tässä voi mennä hetki","ko-KR":"음원 크기에 따라 시간이 걸릴 수 있습니다","nl-NL":"Afhankelijk van de grootte van de muziekcollectie kan dit even duren"},"Descending":{"de-DE":"Absteigend","es-VE":"Descendiente","fi-FI":"Laskeva","ko-KR":"내림차순","nl-NL":"Aflopend"},"Details":{"de-DE":"Details"},"Disabled":{"de-DE":"Deaktiviert","es-VE":"Desactivado","fi-FI":"Poistettu käytöstä","ko-KR":"사용 안 함","nl-NL":"Uitgeschakeld"},"Disc":{"de-DE":"CD","es-VE":"Disco","fi-FI":"Levy","ko-KR":"디스크","nl-NL":"Cd"},"Dislike song":{"de-DE":"Schlechtes Lied","es-VE":"No me gusta esta canción","fi-FI":"Dissaa kappaletta","ko-KR":"곡 좋아하지 않음","nl-NL":"Dislike nummer"},"Download":{"de-DE":"Herunterladen","es-VE":"Descargar","fi-FI":"Lataa","ko-KR":"내려받기","nl-NL":"Download"},"Duration":{"de-DE":"Länge","es-VE":"Duración","fi-FI":"Kesto","ko-KR":"길이","nl-NL":"Duur"},"Edit attributes":{"de-DE":"Eigenschaften editieren","ko-KR":"속성 수정"},"Edit playlist":{"de-DE":"Wiegergabeliste bearbeiten","es-VE":"Editar lista de reproducción","fi-FI":"Muokkaa soittolistaa","ko-KR":"연주목록 편집","nl-NL":"Bewerk afspeellijst"},"Edit smart playlist":{"de-DE":"Intelligente Wiedergabeliste bearbeiten","es-VE":"Editar lista de reproducción inteligente","fi-FI":"Muokkaa älykästä soittolistaa","ko-KR":"스마트 연주목록 편집","nl-NL":"Bewerk slimme afspeellijst"},"Editing scripts is disabled":{"de-DE":"Das Editieren von Skripts ist deaktiviert","ko-KR":"스크립트 편집 사용 안 함","nl-NL":"Bewerken scripts is uitgeschakeld"},"Empty list":{"de-DE":"Leere Liste","es-VE":"Lista vacía","fi-FI":"Tyhjä lista","ko-KR":"목록 비우기","nl-NL":"Lege lijst"},"Empty playlist":{"de-DE":"Leere Wiedergabeliste","es-VE":"Lista de reproducción vacía","fi-FI":"Tyhjä soittolista","ko-KR":"연주목록 비우기","nl-NL":"Lege afspeellijst"},"Empty queue":{"de-DE":"Leere Warteschlange","es-VE":"Cola de reproducción vavía","fi-FI":"Tyhjä jono","ko-KR":"순서 비우기","nl-NL":"Lege wachtrij"},"Enable jukebox if playlist is database":{"de-DE":"Jukebox muss aktiviert sein, wenn als Wiedergabeliste die Datenbank ausgewählt ist.","es-VE":"Habilite Jukebox si la lista de reproducción es la base de datos","fi-FI":"Salli jukeboksi jos soittolista tietokanta","ko-KR":"연주목록이 데이터베이스이면 뮤직박스 사용함","nl-NL":"Schakel jukebox in wanneer database als afspeellijst is geselecteerd"},"Enabled":{"de-DE":"Aktiv","es-VE":"Habilitado","fi-FI":"Päällä","ko-KR":"사용함","nl-NL":"Ingeschakeld"},"Enforce uniqueness":{"de-DE":"Erzwinge Eindeutigkeit","es-VE":"Hacer cumplir la singularidad","fi-FI":"Pakota yksilöllisyys","ko-KR":"유일성 강제","nl-NL":"Gelijkenis op basis van"},"Error":{"de-DE":"Fehler","es-VE":"Error","fi-FI":"Virhe","ko-KR":"오류","nl-NL":"Fout"},"Error executing script %{script}":{"de-DE":"Fehler beim Ausführen des Skripts %{script}","ko-KR":"스크립트 %{script} 실행 오류","nl-NL":"Fout bij uitvoeren script %{script}"},"Error executing script %{script}: Can not open or read script file":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Skript Datei kann nicht geöffnet oder gelesen werden","ko-KR":"스크립트 %{script} 실행 오류: 스크립트 파일을 열거나 읽을 수 없음","nl-NL":"Fout bij uitvoeren script %{script}: Kan script niet openen of lezen"},"Error executing script %{script}: Error in garbage collector":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Fehler im Garbage Collector","ko-KR":"스크립트 %{script} 실행 오류: 가비지 수집 오류","nl-NL":"Fout bij uitvoeren script %{script}: Fout in garbage collector"},"Error executing script %{script}: Error while running the message handler":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Fehler bei der Ausführung des Messagehandlers","ko-KR":"스크립트 %{script} 실행 오류: 메시지 처리 실행 오류","nl-NL":"Fout bij uitvoeren script %{script}: Fout tijdens uitvoeren van message handler"},"Error executing script %{script}: Memory allocation error":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Speicherzuweisungsfehler","ko-KR":"스크립트 %{script} 실행 오류: 메모리 할당 오류","nl-NL":"Fout bij uitvoeren script %{script}: Geheugentoewijzingsfout"},"Error executing script %{script}: Runtime error":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Laufzeitfehler","ko-KR":"스크립트 %{script} 실행 오류: 런타임 오류","nl-NL":"Fout bij uitvoeren script %{script}: Runtime-fout"},"Error executing script %{script}: Syntax error during precompilation":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Syntax Fehler","ko-KR":"스크립트 %{script} 실행 오류: 전처리 컴파일 문법 오류","nl-NL":"Fout bij uitvoeren script %{script}: syntaxisfout tijdens precompilatie"},"Error in response to command: %{command}":{"de-DE":"Fehler beim Ausführen von %{command}","es-VE":"Error en respuesta al comando: %{command}","fi-FI":"Virhe komennolla %{command}","ko-KR":"명령어 오류: %{command}","nl-NL":"Uitvoerfout in: %{command}"},"Error loading stream":{"de-DE":"Fehler beim Laden des Streams","ko-KR":"스트리밍 읽기 오류"},"Event":{"de-DE":"Ereignis","ko-KR":"이벤트"},"Execute":{"de-DE":"Ausführen","ko-KR":"실행","nl-NL":"Uitvoeren"},"Execute script":{"de-DE":"Skript ausführen","ko-KR":"스크립트 실행","nl-NL":"Voer script uit"},"Failed to execute cmd %{cmd}":{"de-DE":"Fehler beim Ausführen des Systembefehls %{cmd}","es-VE":"Error al ejecutar el comando: %{cmd}","fi-FI":"Komennon %{cmd} suorittaminen epäonnistui","ko-KR":"%{cmd} 명령어 실행 안 됨","nl-NL":"Uitvoeren mislukt cmd %{cmd}"},"Failed to open bookmarks file":{"de-DE":"Lesezeichen Datei konnte nicht geöffnet werden","es-VE":"Error al abrir el archivo de marcadores","fi-FI":"Kirjanmerkki tiedoston avaaminen epäonnistui","ko-KR":"즐겨찾기 파일 열기 안 됨","nl-NL":"Openen bladwijzer mislukt"},"Failed to save playlist":{"de-DE":"Wiedergabeliste konnte nicht gespeichert werden","es-VE":"Error al guardar lista de reproducción","fi-FI":"Soittolistan tallennus epäonnistui","ko-KR":"연주목록 저장 안 됨","nl-NL":"Opslaan afspeellijst mislukt"},"Failed to send love message to channel":{"de-DE":"Lieblingslied Nachricht konnte nicht gesendet werden","es-VE":"Error al enviar Me gusta al canal","fi-FI":"Rakkausviestin lähetys kanavalle epäonnistui","ko-KR":"채널에 애청곡 메시지 보내기 안 됨","nl-NL":"Versturen favoriet mislukt"},"Failed to set like, invalid like value":{"de-DE":"Wertung konnte nicht gesetzt werden, ungültiger Wert","es-VE":"Error al establecer me gusta, no válido","fi-FI":"Tykkäystä ei voitu asettaa, virheellinen tykkäys arvo","ko-KR":"잘못된 값으로 좋아요 설정 안 됨","nl-NL":"Like mislukt, ongeldige waarde"},"Failed to set like, invalid song uri":{"de-DE":"Wertung konnte nicht gesetzt werden, ungültige Lied URL","es-VE":"Error al establecer me gusta, URI de canción inválido","fi-FI":"Tykkäystä ei voitu asettaa, virheellinen kappaleen URI","ko-KR":"잘못된 곡 주소로 좋아요 설정 안 됨","nl-NL":"Like mislukt, ongeldige url"},"Fetch MPD settings":{"de-DE":"Lade MPD Einstellungen","es-VE":"Cargando configuraciones de myMPD","fi-FI":"Haetaan MPD asetukset","ko-KR":"MPD 설정 가져오기","nl-NL":"MPD-instellingen laden"},"Fetch myMPD settings":{"de-DE":"Lade myMPD Einstellungen","es-VE":"Cargando configuraciones de myMPD","fi-FI":"Noudetaan myMPD asetukset","ko-KR":"myMPD 설정 가져오기","nl-NL":"myMPD-instellingen laden"},"Fileformat":{"de-DE":"Dateiformat","es-VE":"Formato","fi-FI":"Tiedostomuoto","ko-KR":"파일 포맷","nl-NL":"Bestandsformaat"},"Filename":{"de-DE":"Dateiname","es-VE":"Archivo","fi-FI":"Tiedostonimi","ko-KR":"파일 이름","nl-NL":"Bestandsnaam"},"Filesystem":{"de-DE":"Dateisystem","es-VE":"Sistema de archivos","fi-FI":"Tiedostojärjestelmä","ko-KR":"파일 시스템","nl-NL":"Bestanden"},"Filetype":{"de-DE":"Dateityp","es-VE":"Tipo","fi-FI":"Tiedostotyyppi","ko-KR":"파일 형식","nl-NL":"Bestandstype"},"Filling jukebox queue failed, disabling jukebox":{"de-DE":"Jukebox Warteschlange konnte nicht aufgefüllt werden, Jukebox wurde deaktiviert","ko-KR":"뮤직박스 순서를 채울 수 없어 사용 안 함","nl-NL":"Vullen van de jukebox-wachtrij mislukt, jukebox wordt uitgeschakeld"},"Fingerprint":{"de-DE":"Fingerabdruck","es-VE":"Huella","fi-FI":"Sormenjälki","ko-KR":"지문","nl-NL":"Fingerprint"},"Fingerprint command not supported":{"de-DE":"Fingerprint Befehl ist nicht unterstützt","es-VE":"Comando de huella no soportado","fi-FI":"Sormenjälki komento ei tuettu","ko-KR":"지문 명령어 지원 안 됨","nl-NL":"Fingerprint commando niet ondersteund"},"Focus search":{"de-DE":"Gehe zur Suche","es-VE":"Centrar en búsqueda","fi-FI":"Tarkenna haku","ko-KR":"찾기로 가기","nl-NL":"Naar Zoeken"},"Focus table":{"de-DE":"In Tabelle navigieren","es-VE":"Centrar en tabla","fi-FI":"Tarkenna taulu","ko-KR":"목록에서 찾기","nl-NL":"In tabel navigeren"},"Force smart playlist update":{"de-DE":"Aktualisierung der intelligenten Wiedergabelisten erzwingen","ko-KR":"스마트 연주목록 강제 업데이트","nl-NL":"Forceer update smart playlist"},"Force update":{"de-DE":"Erzwinge Aktualisierung","ko-KR":"강제 업데이트","nl-NL":"Forceer update"},"Fri":{"de-DE":"Fr","es-VE":"Vie","fi-FI":"Pe","ko-KR":"금","nl-NL":"Vr"},"From":{"de-DE":"Von","es-VE":"De","fi-FI":"Mistä","ko-KR":"원래","nl-NL":"Van"},"Fullscreen":{"de-DE":"Vollbild","ko-KR":"전체 화면","nl-NL":"Schermvullend"},"General":{"de-DE":"Allgemein","es-VE":"General","fi-FI":"Yleinen","ko-KR":"일반","nl-NL":"Algemeen"},"Generate smart playlist per":{"de-DE":"Erstelle intelligente Wiedergabelisten für","es-VE":"Generar lista de reproducción inteligente por","fi-FI":"Luo älykäs soittolista perustuen","ko-KR":"스마트 연주목록 생성","nl-NL":"Genereer slimme afspeellijst op basis van"},"Genre":{"de-DE":"Genre","es-VE":"Género","fi-FI":"Genre","ko-KR":"장르","nl-NL":"Genre"},"Goto browse database":{"de-DE":"Gehe zu Datenbank durchsuchen","es-VE":"Ir a explorar base de datos","fi-FI":"Siirry tietokannan selaamiseen","ko-KR":"데이터베이스 열기로 가기","nl-NL":"Database openen"},"Goto browse filesystem":{"de-DE":"Gehe zu Dateisystem","es-VE":"Ir a explorar sistema de archivos","fi-FI":"Siirry tiedostojärjelmän selaukseen","ko-KR":"파일 시스템 열기로 가기","nl-NL":"Bestandssysteem openen"},"Goto browse playlists":{"de-DE":"Gehe zu Wiedergabelisten","es-VE":"Ir a explorar listas de reproducción","fi-FI":"Siirry soittolistojen selaukseen","ko-KR":"연주목록 열기로 가기","nl-NL":"Afspeellijsten openen"},"Goto last played":{"de-DE":"Gehe zu Zuletzt gespielt","es-VE":"Ir a última reproducción","fi-FI":"Siirry viimeksi soitettuun","ko-KR":"앞선 연주로 가기","nl-NL":"Laatst afgespeeld openen"},"Goto playback":{"de-DE":"Gehe zu Wiedergabe","es-VE":"Ir a lista de reproducción","fi-FI":"Siirry toistoon","ko-KR":"연주로 가기","nl-NL":"Afspelen openen"},"Goto queue":{"de-DE":"Gehe zu Warteschlange","es-VE":"Ir a cola de reproducción","fi-FI":"Siirry jonoon","ko-KR":"순서로 가기","nl-NL":"Wachtrij openen"},"Goto search":{"de-DE":"Gehe zur Suche","es-VE":"Ir a buscar","fi-FI":"Siirry hakuun","ko-KR":"찾기로 가기","nl-NL":"Zoeken openen"},"Grouping":{"de-DE":"Grupierung","es-VE":"Agrupación","fi-FI":"Ryhmittely","ko-KR":"묶음","nl-NL":"Groepering"},"HTTP Port":{"de-DE":"HTTP Port","ko-KR":"HTTP 포트"},"HTTPS Port":{"de-DE":"HTTPS Port","ko-KR":"HTTPS 포트"},"Highlight color":{"de-DE":"Highlight Farbe","es-VE":"Color de realce","fi-FI":"Valintaväri","ko-KR":"강조색","nl-NL":"Accentkleur"},"Homepage":{"de-DE":"Homepage","es-VE":"Página de Inicio","fi-FI":"Kotisivu","ko-KR":"홈페이지","nl-NL":"Website"},"Hours":{"de-DE":"Std","en-US":"Hrs","es-VE":"Horas","fi-FI":"Tuntia","ko-KR":"시간","nl-NL":"h"},"IP-Address":{"de-DE":"IP-Adresse","es-VE":"Dirección IP","fi-FI":"IP-osoite","ko-KR":"IP 주소","nl-NL":"IP-adres"},"Info":{"de-DE":"Hinweis","es-VE":"Info","fi-FI":"Tietoa","ko-KR":"정보","nl-NL":"Info"},"Initializing myMPD":{"de-DE":"Initialisiere myMPD","es-VE":"Inicializando myMPD","fi-FI":"Käynnistetään myMPD","ko-KR":"myMPD 초기화","nl-NL":"Voorbereiden myMPD"},"Invalid API request":{"de-DE":"Ungültiger API Befehl","es-VE":"Solicitud API incorrecta","fi-FI":"Virheellinen API pyyntö","ko-KR":"잘못된 API 요구","nl-NL":"Ongeldig API-verzoek"},"Invalid CSS filter":{"de-DE":"Ungültiger CSS Filter","es-VE":"Filtro CSS inválido","fi-FI":"Virheellinen CSS suodatin","ko-KR":"잘못된 CSS 필터","nl-NL":"Ongeldig CSS-filter"},"Invalid MPD host":{"de-DE":"Ungültiger MPD Host","es-VE":"Servidor MPD inválido","fi-FI":"Virheellinen MPD isäntä","ko-KR":"잘못된 MPD 호스트","nl-NL":"Ongeldige MPD host"},"Invalid MPD password":{"de-DE":"Ungültiges MPD Passwort","es-VE":"Contraseña MPD inválida","fi-FI":"Virheellinen MPD salasana","ko-KR":"잘못된 MPD 비밀번호","nl-NL":"Ongeldig MPD wachtwoord"},"Invalid MPD port":{"de-DE":"Ungültiger MPD Port","es-VE":"Puerto MPD inválido","fi-FI":"Virheellinen MPD Portti","ko-KR":"잘못된 MPD 포트","nl-NL":"Ongeldige MPD poort"},"Invalid URI":{"de-DE":"Ungültige URL","es-VE":"URL Inválida","fi-FI":"Epäkelpo URI","ko-KR":"잘못된 주소","nl-NL":"Ongeldige url"},"Invalid backend uri":{"de-DE":"Ungültige einzuhängende URL","es-VE":"URL de Back-End inválida","fi-FI":"Virheellinen järjestelmä uri","ko-KR":"잘못된 백엔드 URL","nl-NL":"Ongeldige backend-url"},"Invalid channel name":{"de-DE":"Ungültiger Channel name","es-VE":"Nombre de canal inválido","fi-FI":"Virheellinen kanavanimi","ko-KR":"잘못된 채널 이름","nl-NL":"ongeldige naam"},"Invalid color":{"de-DE":"Ungültige Farbe","es-VE":"Color inválido","fi-FI":"Virheellinen väri","ko-KR":"잘못된 색상","nl-NL":"Ongeldige kleur"},"Invalid column":{"de-DE":"Ungültiger Spaltenname","fi-FI":"Väärä sarake","ko-KR":"잘못된 열","nl-NL":"Onjuiste kolom"},"Invalid filename":{"de-DE":"Ungültiger Dateiname","es-VE":"Nombre de archivo inválido","fi-FI":"Väärä tiedostonimi","ko-KR":"잘못된 파일 이름","nl-NL":"Ongeldige bestandsnaam"},"Invalid message":{"de-DE":"Ungültige Zeichen in Nachricht","es-VE":"Mensaje inválido","fi-FI":"Virheellinen viesti","ko-KR":"잘못된 메시지","nl-NL":"Ongeldig bericht"},"Invalid mount point":{"de-DE":"Ungültiger Einhängepunkt","es-VE":"Punto de montaje inválido","fi-FI":"Virheellinen liityntäköhta","ko-KR":"잘못된 마운트 위치","nl-NL":"Ongeldig aankoppelpunt"},"Invalid music directory":{"de-DE":"Ungültiges Musikverzeichnis","es-VE":"Directorio de música inválido","fi-FI":"Virheellinen musiikkikansio","ko-KR":"잘못된 음원 디렉터리","nl-NL":"Ongeldige muziekmap"},"Invalid name":{"de-DE":"Ungültiger Name","es-VE":"Nombre inválido","fi-FI":"Virheellinen nimi","ko-KR":"잘못된 이름","nl-NL":"Ongeldige naam"},"Invalid number":{"de-DE":"Ungültige Zahl","es-VE":"Número inválido","fi-FI":"Virheellinen numero","ko-KR":"잘못된 숫자","nl-NL":"Ongeldig getal"},"Invalid partition name":{"de-DE":"Ungültiger Partition Name","ko-KR":"잘못된 파티션 이름"},"Invalid prefix":{"de-DE":"Ungültiger Prefix","es-VE":"Prefijo inválido","fi-FI":"Virheellinen etuliite","ko-KR":"잘못된 덧붙임","nl-NL":"Ongeldig voorvoegsel"},"Invalid scale ratio":{"de-DE":"Ungültiger Skalierungswert","ko-KR":"잘못된 크기 비율","nl-NL":"Ongeldige schaalverhouding"},"Invalid script API request":{"de-DE":"Ungültiger Script-API Aufruf","ko-KR":"잘못된 스크립트 API 요청","nl-NL":"Ongeldige script-API-verzoek"},"Invalid script argument":{"de-DE":"Ungültiger Skriptparameter","ko-KR":"잘못된 스크립트 변수","nl-NL":"Ongeldige scriptparameter"},"Invalid script name":{"de-DE":"Ungültiger Skriptname","ko-KR":"잘못된 스크립트 이름","nl-NL":"Ongeldige script naam"},"Invalid script order":{"de-DE":"Ungültige Skriptreihenfolge","ko-KR":"잘못된 스크립트 순서","nl-NL":"Ongeldige scriptvolgorde"},"Invalid size":{"de-DE":"Ungültige Größe","es-VE":"Tamaño inválido","fi-FI":"Virheellinen koko","ko-KR":"잘못된 크기","nl-NL":"Ongeldige grootte"},"Invalid trigger name":{"de-DE":"Ungültiger Trigger Name","ko-KR":"잘못된 트리거 이름"},"Invalid type":{"de-DE":"Ungültiger Typ","es-VE":"Tipo inválido","fi-FI":"Väärä tyyppi","ko-KR":"잘못된 형식","nl-NL":"Ongeldig type"},"JavaScript error":{"de-DE":"JavaScript Fehler","es-VE":"Error de JavaScript","fi-FI":"JavaScript virhe","ko-KR":"자바스크립트 오류","nl-NL":"JavaScript fout"},"JavaScript is disabled":{"de-DE":"JavaScript ist deaktiviert","es-VE":"JavaScript esta deshabilitado","fi-FI":"JavaScript poistettu käytöstä","ko-KR":"자바스크립트 사용 안 함","nl-NL":"JavaScript uitgeschakeld"},"Jukebox":{"de-DE":"Jukebox","es-VE":"Jukebox","fi-FI":"Jukebox","ko-KR":"뮤직박스","nl-NL":"Jukebox"},"Jukebox mode":{"de-DE":"Jukebox Modus","es-VE":"Modo Jukebox","fi-FI":"Jukebox tila","ko-KR":"뮤직박스 모드","nl-NL":"Jukebox-modus"},"Keep queue length":{"de-DE":"Warteschlangenlänge","es-VE":"Mantener longitud de cola de reproducción","fi-FI":"Pidä jonon pituus","ko-KR":"순서 길이 유지","nl-NL":"Aantal in wachtrij"},"Label":{"de-DE":"Herausgeber","es-VE":"Etiqueta","fi-FI":"Julkaisija","ko-KR":"음반사","nl-NL":"Label"},"Last modified":{"de-DE":"Zuletzt geändert","es-VE":"Últ. modificación","fi-FI":"Viimeksi muokattu","ko-KR":"앞서 수정함","nl-NL":"Laatst gewijzigd"},"Last played":{"de-DE":"Zuletzt gespielt","es-VE":"Última reproducción","fi-FI":"Viimeksi soitettu","ko-KR":"앞서 연주함","nl-NL":"Laatst afgespeeld"},"Last played list count":{"de-DE":"Anzahl zuletzt gespielte Lieder","es-VE":"Conteo reproducción de última lista","fi-FI":"Viimeksi soitettujen listan koko","ko-KR":"앞선 연주 목록 개수","nl-NL":"Aantal laatst afgespeelde nummers"},"Last played older than (hours)":{"de-DE":"Zuletzte gespielt, vor mehr als (Stunden)","es-VE":"Última reproducción mas viejo que (horas)","fi-FI":"Viimeksi toistettu vanhempi kuin (Stunden)","ko-KR":"이전에 연주됨 (시간)","nl-NL":"Laatst afgespeeld, ouder dan (uur)"},"Last skipped":{"de-DE":"Zuletzt übersprungen","es-VE":"Última omisión","fi-FI":"Viimeksi ohitettu","ko-KR":"앞서 건너뜀","nl-NL":"Laatst overgeslagen"},"LastModified":{"de-DE":"Zuletzt geändert","en-US":"Last modified","es-VE":"Últ. modif.","fi-FI":"ViimeksiMuokattu","ko-KR":"마지막 수정","nl-NL":"Laatst gewijzigd"},"LastPlayed":{"de-DE":"Zuletzt gespielt","es-VE":"Última reproducción","fi-FI":"ViimeksiSoitettu","ko-KR":"앞서 연주함","nl-NL":"Laatst afgespeeld"},"Leaving playlist as it is":{"de-DE":"Wiedergabeliste wird nicht verändert","es-VE":"Dejando la lista de reproducción como está","fi-FI":"Soittolista jätetään entiselleen","ko-KR":"연주목록을 그대로 둠","nl-NL":"Afspeellijst niet gewijzigd"},"Libmpdclient version":{"de-DE":"Libmpdclient Version","es-VE":"Versión Libmpdclient","fi-FI":"Libmpdclient Versio","ko-KR":"Libmpdclient 버전","nl-NL":"Versie libmpdclient"},"Libmympdclient version":{"de-DE":"Libmympdclient Version","es-VE":"Versión Libmympdclient","fi-FI":"Libmympdclient Versio","ko-KR":"Libmympdclient 버전","nl-NL":"Versie libmympdclient"},"Light":{"de-DE":"Hell","es-VE":"Claro","fi-FI":"Vaalea","ko-KR":"밝음","nl-NL":"Licht"},"Like":{"de-DE":"Wertung","es-VE":"Me gusta","fi-FI":"Tykkää","ko-KR":"좋아요","nl-NL":"Like"},"Like song":{"de-DE":"Gutes Lied","es-VE":"Me gusta esta canción","fi-FI":"Tykkää kappaleesta","ko-KR":"곡 좋아요","nl-NL":"Like nummer"},"Local playback":{"de-DE":"Lokale Wiedergabe","es-VE":"Reproducción local","fi-FI":"Paikallinen toisto","ko-KR":"로컬 연주","nl-NL":"Lokaal afspelen"},"Locale":{"de-DE":"Sprache","es-VE":"Idioma","fi-FI":"Kielivalinta","ko-KR":"언어","nl-NL":"Taal"},"Love song":{"de-DE":"Lieblingslied","es-VE":"Me encanta esta canción","fi-FI":"Rakkauslaulu","ko-KR":"애청곡","nl-NL":"Favoriet"},"Lyrics":{"de-DE":"Liedtext","es-VE":"Letras","fi-FI":"Sanoitukset","ko-KR":"가사","nl-NL":"Songtekst"},"MPD channel":{"de-DE":"MPD Channel","es-VE":"Canal MPD","fi-FI":"MPD kanava","ko-KR":"MPD 채널","nl-NL":"MPD-kanaal"},"MPD channel not found":{"de-DE":"MPD Channel nicht gefunden","es-VE":"Canal MPD no encontrado","fi-FI":"MPD kanavaa ei löytynyt","ko-KR":"MPD 채널 없음","nl-NL":"MPD-kanaal niet gevonden"},"MPD connection":{"de-DE":"MPD Verbindung","es-VE":"Conexión MPD","fi-FI":"MPD Yhteys","ko-KR":"MPD 연결","nl-NL":"MPD-verbinding"},"MPD connection error: %{error}":{"de-DE":"MPD Verbindungsfehler: %{error}","es-VE":"Error de conexión MPD: %{error}","fi-FI":"MPD yhteysvirhe: %{error}","ko-KR":"MPD 연결 오류: %{error}","nl-NL":"MPD verbindingsfout: %{error}"},"MPD disconnected":{"de-DE":"MPD nicht verbunden","es-VE":"MPD desconectado","fi-FI":"MPD yhteys katkaistu","ko-KR":"MPD 연결 끊어짐","nl-NL":"MPD niet verbonden"},"MPD host":{"de-DE":"MPD Host","es-VE":"Servidor MPD","fi-FI":"MPD isäntä","ko-KR":"MPD 호스트","nl-NL":"MPD host"},"MPD password":{"de-DE":"MPD Passwort","es-VE":"Contraseña MPD","fi-FI":"MPD Salasana","ko-KR":"MPD 비밀번호","nl-NL":"MPD wachtwoord"},"MPD port":{"de-DE":"MPD Port","es-VE":"Puerto MPD","fi-FI":"MPD Portti","ko-KR":"MPD 포트","nl-NL":"MPD poort"},"MPD stickers are disabled":{"de-DE":"MPD Sticker sind deaktiviert","es-VE":"Los Stickers MPD están deshabilitados","fi-FI":"MPD Stickerit pois käytöstä","ko-KR":"MPD 스티커 사용 안 함","nl-NL":"MPD-stickers uitgeschakeld"},"MPD uptime":{"de-DE":"MPD Uptime","es-VE":"Tiempo de actividad MPD","fi-FI":"MPD Uptime","ko-KR":"MPD 가동 시간","nl-NL":"MPD uptime"},"MUSICBRAINZ_ALBUMARTISTID":{"de-DE":"Musicbrainz AlbumArtist ID","es-VE":"Musicbrainz AlbumArtist ID","fi-FI":"Musicbrainz AlbumiArtisti ID","ko-KR":"뮤직브레인즈 음반 연주자 ID","nl-NL":"Musicbrainz AlbumArtist ID"},"MUSICBRAINZ_ALBUMID":{"de-DE":"Musicbrainz Album ID","es-VE":"Musicbrainz Album ID","fi-FI":"Musicbrainz Albumi ID","ko-KR":"뮤직브레인즈 음반 ID","nl-NL":"Musicbrainz Album ID"},"MUSICBRAINZ_ARTISTID":{"de-DE":"Musicbrainz Künstler ID","es-VE":"Musicbrainz Artist ID","fi-FI":"Musicbrainz artisti ID","ko-KR":"뮤직브레인즈 연주자 ID","nl-NL":"Musicbrainz Ariest ID"},"MUSICBRAINZ_RELEASETRACKID":{"de-DE":"Musicbrainz Release Track ID","es-VE":"Musicbrainz Release Track ID","fi-FI":"Musicbrainz Release Track ID","ko-KR":"뮤직브레인즈 발표 곡 ID","nl-NL":"Musicbrainz Release Track ID"},"MUSICBRAINZ_TRACKID":{"de-DE":"Musicbrainz Track ID","es-VE":"Musicbrainz Track ID","fi-FI":"Musicbrainz Track ID","ko-KR":"뮤직브레인즈 곡 ID","nl-NL":"Musicbrainz Track ID"},"MUSICBRAINZ_WORKID":{"de-DE":"Musicbrainz Werk ID","es-VE":"Musicbrainz Work ID","fi-FI":"Musicbrainz Työ ID","ko-KR":"뮤직브레인즈 작품 ID","nl-NL":"Musicbrainz Werk ID"},"Max. songs":{"de-DE":"Max. Lieder","es-VE":"Canciones max.","fi-FI":"Max. kappaleet","ko-KR":"최대 곡","nl-NL":"Max. nummers"},"Media session support":{"de-DE":"Media Session Unterstützung","es-VE":"Soporte de sesión de medios","fi-FI":"Media Session tuki","ko-KR":"미디어 세션 지원","nl-NL":"Mediasessie ondersteuning"},"Message":{"de-DE":"Nachricht","es-VE":"Mensaje","fi-FI":"Viesti","ko-KR":"메시지","nl-NL":"Bericht"},"Min. value":{"de-DE":"Min. Wert","es-VE":"Valor min.","fi-FI":"Min. arvo","ko-KR":"최소 값","nl-NL":"Min. waarde"},"Minimum one weekday must be selected":{"de-DE":"Es muss mindestens ein Wochentag ausgewählt sein.","es-VE":"Debe seleccionar al menos un dia de la semana","fi-FI":"Vähintään yksi päivä pitää valita","ko-KR":"최소 일주일 선택해야 함","nl-NL":"Selecteer minimaal 1 weekdag"},"Minutes":{"de-DE":"Min","en-US":"Min","es-VE":"Min","fi-FI":"Min","ko-KR":"분","nl-NL":"min"},"Mixramp DB":{"de-DE":"Mixramp DB","es-VE":"Mixramp dB","fi-FI":"Mixramp DB","ko-KR":"Mixramp DB","nl-NL":"Mixramp DB"},"Mixramp delay":{"de-DE":"Mixramp Verzögerung","es-VE":"Retraso Mixramp","fi-FI":"Mixramp viive","ko-KR":"Mixramp 지연","nl-NL":"Mixramp-vertraging"},"Mon":{"de-DE":"Mo","es-VE":"Lun","fi-FI":"Ma","ko-KR":"월","nl-NL":"Ma"},"Mongoose version":{"de-DE":"Mongoose Version","es-VE":"Versión Mongoose","fi-FI":"Mongoose Versio","ko-KR":"Mongoose 버전","nl-NL":"Versie Mongoose"},"Most played":{"de-DE":"Am Öftesten gespielt","es-VE":"Más reproducido","fi-FI":"Eniten soitettu","ko-KR":"자주 연주","nl-NL":"Meest afgespeeld"},"Mount point":{"de-DE":"Einhängepunkt","es-VE":"Punto de monaje","fi-FI":"Liityntäkohta","ko-KR":"마운트 위치","nl-NL":"Aankoppelpunt"},"Mounts":{"de-DE":"Einhängepunkte","es-VE":"Montar","fi-FI":"Liitokset","ko-KR":"마운트","nl-NL":"Aankoppelpunten"},"Move an output to this partition":{"de-DE":"Verschiebe ein Ausgabegerät zu dieser Partition","ko-KR":"출력을 이 파티션으로 옮김"},"Music directory":{"de-DE":"Musikverzeichnis","es-VE":"Directorio de música","fi-FI":"Musiikkikansio","ko-KR":"음원 디렉터리","nl-NL":"Muziekmap"},"Music directory not found":{"de-DE":"Musikverzeichnis nicht gefunden","es-VE":"Directorio de música no encontrado","fi-FI":"Musiikkikansiota ei löydy","ko-KR":"음원 디렉터리 없음","nl-NL":"Muziekmap niet gevonden"},"Must be a number":{"de-DE":"Muss eine Zahl sein","es-VE":"Debe ser un número","fi-FI":"Pitää olla numero","ko-KR":"숫자여야 함","nl-NL":"Moet een getal zijn"},"Must be a number and equal or greater than zero":{"de-DE":"Muss eine Zahl größergleich 0 sein","es-VE":"Debe ser un número igual o mayor a cero","fi-FI":"Pitää olla numero joka on nolla tai suurempi","ko-KR":"숫자이고 0과 같거나 커야 함","nl-NL":"Getal moet gelijk of groter zijn dan 0"},"Must be a number and greater than zero":{"de-DE":"Muss eine Zahl größer als 0 sein","es-VE":"Debe ser un número mayor a cero","fi-FI":"Tarvii olla numero joka on suurempi kuin 0","ko-KR":"0보다 큰 숫자여야 함","nl-NL":"Moet een getal zijn en groter dan 0"},"Must be a number smaller or equal 200":{"de-DE":"Muss eine Zahl kleinergleich 200 sein","es-VE":"Debe ser un número menor o igual a 200","fi-FI":"Tarvii olla luku joka on pienempi tai yhtäsuuri kuin 200","ko-KR":"200이하의 숫자여야 함","nl-NL":"Getal moet kleiner zijn dan 200"},"Name":{"de-DE":"Name","es-VE":"Nombre","fi-FI":"Nimi","ko-KR":"이름","nl-NL":"Naam"},"Neighbors are disabled":{"de-DE":"Kein Neighbor Plugin aktiviert","fi-FI":"Naapurit lisäosa poissa käytöstä","ko-KR":"Neighbors 사용 안 함","nl-NL":"Neighbor-plugin uitgeschakeld"},"New mount":{"de-DE":"Neuer Einhängepunkt","es-VE":"Nuevo punto de montaje","fi-FI":"Uusi liitos","ko-KR":"새로운 마운트","nl-NL":"Nieuw aankoppelpunt"},"New partition":{"de-DE":"Neue Partition","ko-KR":"새 파티션"},"New playlist":{"de-DE":"Neue Wiedergabeliste","es-VE":"Nueva lista de reproducción","fi-FI":"Uusi soittolista","ko-KR":"새 연주목록","nl-NL":"Nieuwe afspeellijst"},"New script":{"de-DE":"Neues Skript","ko-KR":"새 스크립트","nl-NL":"Nieuw script"},"New timer":{"de-DE":"Neuer Timer","es-VE":"Nuevo Temporizador","fi-FI":"Uusi ajastin","ko-KR":"새로운 타이머","nl-NL":"Nieuwe Timer"},"New trigger":{"de-DE":"Neuer Trigger","ko-KR":"새 트리거"},"Newest songs":{"de-DE":"Neueste Lieder","es-VE":"Canciones mas recientes","fi-FI":"Uusimmat kappaleet","ko-KR":"새 곡","nl-NL":"Nieuwste nummers"},"Next page":{"de-DE":"Nächste Seite","es-VE":"Página siguiente","fi-FI":"Seuraava sivu","ko-KR":"다음 페이지","nl-NL":"Volgende pagina"},"Next song":{"de-DE":"Nächstes Lied","es-VE":"Canción siguiente","fi-FI":"Seuraava kappale","ko-KR":"다음 곡","nl-NL":"Volgende nummer"},"No action selected":{"de-DE":"Keine Aktion ausgewählt","ko-KR":"기능 선택 안 됨","nl-NL":"Geen actie geselecteerd"},"No albumart found by mpd":{"de-DE":"MPD konnte keine Cover finden","es-VE":"No se encontró carátula por MPD","fi-FI":"MPD ei löytäny albumi taidetta","ko-KR":"MPD가 음반 표지를 찾을 수 없음","nl-NL":"Geen albumcover gevonden door mpd"},"No bookmarks found":{"de-DE":"Keine Lesezeichen gefunden","es-VE":"No se encontraron marcadores","fi-FI":"Kirjanmerkkejä ei löytynyt","ko-KR":"즐겨찾기를 찾을 수 없음","nl-NL":"Geen bladwijzers gevonden"},"No current song":{"de-DE":"Kein Lied ausgwählt","es-VE":"No hay canción actual","fi-FI":"Ei toistettavaa kappaletta","ko-KR":"지금 곡 없음","nl-NL":"Geen nummer gekozen"},"No lyrics found":{"de-DE":"Kein Songtext gefunden","fi-FI":"Sanoituksia ei löydy","ko-KR":"가사 없음","nl-NL":"Geen songteksten gevonden"},"No mixed content,  MPD stream must be served over https:":{"de-DE":"Mixed Content: MPD stream muss über https ausgeliefert werden:","ko-KR":"혼합된 컨텐트는 안되며, MPD 스트리밍 서비스는 https:를 통해야 합니다."},"No mpd state for script execution submitted":{"de-DE":"Es wurde kein MPD Status für die Skriptausführung mitgeliefert","ko-KR":"스크립트 실행을 위한 MPD 상태 없음","nl-NL":"Geen mpd-status voor uitvoering script gegeven"},"No outputs":{"de-DE":"Keine Ausgabegeräte","ko-KR":"출력 없음"},"No playlists found":{"de-DE":"Keine Wiedergabelisten gefunden","es-VE":"No se encontraron Listas de reproducción","fi-FI":"Soittolistoja ei löydy","ko-KR":"연주목록 찾을 수 없음","nl-NL":"Geen afspeellijsten gevonden"},"No response for method %{method}":{"de-DE":"Keine Rückmeldung für Aufruf %{method}","es-VE":"Sin respuesta para el método %{method}","fi-FI":"Ei vastausta metodiin %{method}","ko-KR":"%{method} 응답 없음","nl-NL":"Geen antwoord op methode %{method}"},"No results, please refine your search":{"de-DE":"Keine Ergebnisse, bitte passe die Suche an","es-VE":"Sin resultados, cambie los parámetros de búsqueda","fi-FI":"Ei tuloksia, tarkista hakuehdot","ko-KR":"결과가 없으므로, 맞게 찾아야 함","nl-NL":"Geen hits, gebruik andere zoekterm"},"No search expression defined":{"de-DE":"Kein Suchausdruck angegeben","es-VE":"Ninguna expresión de búsqueda definida","fi-FI":"Hakutermiä ei määritetty","ko-KR":"찾을 문구 없음","nl-NL":"Zoekopdracht niet gedefinieerd"},"No search tag defined and advanced search is disabled":{"de-DE":"Kein Such-Tag definiert und erweiterte Suche ist deaktiviert.","ko-KR":"검색 태그가 없고 정의되지 않고 고급 검색을 사용 안 함","nl-NL":"Geen zoektag gedefinieerd en geavanceerd zoeken is uitgeschakeld"},"No such directory":{"de-DE":"Verzeichnis nicht gefunden","es-VE":"No se encontró ese directorio","fi-FI":"Kansiota ei ole","ko-KR":"그런 디렉터리가 없음","nl-NL":"Map niet gevonden"},"None":{"de-DE":"Keines","es-VE":"Ninguno","fi-FI":"Ei mitään","ko-KR":"없음","nl-NL":"Geen"},"Notifications":{"de-DE":"Hinweise","es-VE":"Notificaciones","fi-FI":"Ilmoitukset","ko-KR":"알림","nl-NL":"Notificaties"},"Notifications are blocked":{"de-DE":"Benachrichtungen sind nicht erlaubt","es-VE":"Las Notificaciones están bloqueadas","fi-FI":"Ilmoitukset on estetty","ko-KR":"알림 차단됨","nl-NL":"Meldingen zijn geblokkeerd"},"Num entries":{"de-DE":"%{smart_count} Eintrag |||| %{smart_count} Einträge","en-US":"%{smart_count} Entry |||| %{smart_count} Entries","es-VE":"%{smart_count} Entrada |||| %{smart_count} Entradas","fi-FI":"%{smart_count} Kohde |||| %{smart_count} Kohdetta","ko-KR":"%{smart_count} 항목 |||| %{smart_count} 항목","nl-NL":"%{smart_count} entry |||| %{smart_count} entries"},"Num playlists":{"de-DE":"%{smart_count} Wiedergabeliste |||| %{smart_count} Wiedergabelisten","en-US":"%{smart_count} Playlist |||| %{smart_count} Playlists","es-VE":"%{smart_count} Lista de reproducción |||| %{smart_count} Listas de reproducción","fi-FI":"%{smart_count} Soittolista |||| %{smart_count} Soittolistaa","ko-KR":"%{smart_count} 연주목록 |||| %{smart_count} 연주목록","nl-NL":"%{smart_count} afspeellijst |||| %{smart_count} afspeellijsten"},"Num songs":{"de-DE":"%{smart_count} Lied |||| %{smart_count} Lieder","en-US":"%{smart_count} Song |||| %{smart_count} Songs","es-VE":"%{smart_count} Canción |||| %{smart_count} Canciones","fi-FI":"%{smart_count} Kappale |||| %{smart_count} Kappaletta","ko-KR":"%{smart_count} 곡 |||| %{smart_count} 곡","nl-NL":"%{smart_count} nummer |||| %{smart_count} nummers"},"Off":{"de-DE":"Deaktiviert","es-VE":"Apagado","fi-FI":"Pois","ko-KR":"끄기","nl-NL":"Uit"},"On":{"de-DE":"Aktiv","es-VE":"On","fi-FI":"Päällä","ko-KR":"켜기","nl-NL":"Aan"},"On page notifications":{"de-DE":"Integrierte Hinweise","es-VE":"Notificaciones en la Página","fi-FI":"Sivun ilmoitukset","ko-KR":"페이지에 알림","nl-NL":"Meldingen op pagina"},"Oneshot":{"de-DE":"Oneshot","es-VE":"Oneshot","fi-FI":"Oneshot","ko-KR":"1회","nl-NL":"Oneshot"},"Open about":{"de-DE":"Öffne Über myMPD","es-VE":"Abrir acerca de ","fi-FI":"Avaa tiedot","ko-KR":"정보 열기","nl-NL":"Over myMPD openen"},"Open fullscreen":{"de-DE":"Öffnet den Vollbildmodus","ko-KR":"전체 화면 열기","nl-NL":"Open schermvullend"},"Open local player":{"de-DE":"Lokale Wiedergabe","es-VE":"Abrir reproductor local","fi-FI":"Avaa paikallinen soitin","ko-KR":"로컬 연주기 열기","nl-NL":"Lokaal afspelen"},"Open main menu":{"de-DE":"Öffne Hauptmenü","es-VE":"Abrir menú principal","fi-FI":"Avaa päävalikko","ko-KR":"주 메뉴로 가기","nl-NL":"Hoofdmenu openen"},"Open settings":{"de-DE":"Einstellungen","es-VE":"Abrir configuraciones","fi-FI":"Avaa asetukset","ko-KR":"설정 열기","nl-NL":"Instellingen"},"Open song details":{"de-DE":"Lieddetails","es-VE":"Abrir detalles de canción","fi-FI":"Avaa kappaleen tiedot","ko-KR":"곡 정보 열기","nl-NL":"Nummerdetails"},"Open volume menu":{"de-DE":"Öffne Lautstärkemenü","es-VE":"Abrir menú de volumen","fi-FI":"Avaa äänenvoimakkuus valikko","ko-KR":"음량 메뉴 열기","nl-NL":"Volumeregeing openen"},"Order":{"de-DE":"Reihenfolge","es-VE":"Orden","fi-FI":"Järjestys","ko-KR":"순서","nl-NL":"Volgorde"},"Other features":{"de-DE":"Weitere Features","es-VE":"Más funciones","fi-FI":"Muut ominaisuudet","ko-KR":"다른 기능","nl-NL":"Overige functies"},"Output":{"de-DE":"Ausgabegerät","ko-KR":"출력"},"Output attributes":{"de-DE":"Ausgabeeigenschaften","ko-KR":"출력 속성"},"Pagination":{"de-DE":"Seitenumbruch","es-VE":"Paginación","fi-FI":"Rivien määrä","ko-KR":"페이지 매기기","nl-NL":"Paginagrootte"},"Partition":{"de-DE":"Partition","ko-KR":"파티션"},"Partition name":{"de-DE":"Partition Name","ko-KR":"파티션 이름"},"Partitions":{"de-DE":"Partitionen","ko-KR":"파티션"},"Performer":{"de-DE":"Aufführender","es-VE":"Interprete","fi-FI":"Esittäjä","ko-KR":"연주자","nl-NL":"Uitvoerend artiest"},"Pictures":{"de-DE":"Bilder","es-VE":"Imágenes","fi-FI":"Kuvat","ko-KR":"그림","nl-NL":"Foto's "},"Play count":{"de-DE":"Wie oft gespielt","es-VE":"Conteo reproducciones","fi-FI":"Soittokerrat","ko-KR":"연주 횟수","nl-NL":"Aantal x afgespeeld"},"Play time":{"de-DE":"Wiedergabedauer","es-VE":"Tiempo de reproducción","fi-FI":"Toisto aika","ko-KR":"연주 시간","nl-NL":"Gespeelde tijd"},"Playback":{"de-DE":"Wiedergabe","es-VE":"Reproducción","fi-FI":"Toisto","ko-KR":"연주","nl-NL":"Afspelen"},"Playback statistics":{"de-DE":"Wiedergabestatistiken","es-VE":"Estadísticas de reproducción","fi-FI":"Toistotilastot","ko-KR":"연주 통계","nl-NL":"Afspeelgegevens"},"Playback statistics are disabled":{"de-DE":"Wiedergabestatistiken sind deaktiviert","es-VE":"Las estadísticas de reproducción están deshabilitadas","fi-FI":"Toistotilastot ovat pois päältä","ko-KR":"연주 통계 사용 안 함","nl-NL":"Afspeelstatistieken uitgeschakeld"},"Playlist":{"de-DE":"Wiedergabeliste","es-VE":"Lista de reproducción","fi-FI":"Soittolista","ko-KR":"연주목록","nl-NL":"Afspeellijst"},"Playlist is too small to shuffle":{"de-DE":"Wiedergabeliste ist zu klein um sie zu mischen","es-VE":"La lista de reproducción es muy pequeña para mezclar aleatoriamente","fi-FI":"Soittolista on liian pieni sekoitettavaksi","ko-KR":"연주목록이 너무 작아 뒤섞을 수 없음","nl-NL":"Afspeellijst te klein om te shufflen"},"Playlist is too small to sort":{"de-DE":"Wiedergabeliste ist zu klein um sie zu sortieren","es-VE":"Wiedergabeliste ist zu klein um sie zu sortieren","fi-FI":"Soittolista on liian pieni järjestettäväksi","ko-KR":"연주목록이 너무 작아 정렬할 수 없음","nl-NL":"Afspeellijst te klein om te sorteren"},"Playlist name":{"de-DE":"Wiedergabelistenname","es-VE":"Nombre de lista de reproducción","fi-FI":"Soittolistan nimi","ko-KR":"연주목록 이름","nl-NL":"Naam afspeellijst"},"Playlist to small, disabling jukebox unique constraints temporarily":{"de-DE":"Die Wiedergabeliste ist zu klein, die Jukebox Regeln werden deaktiviert","ko-KR":"연주목록이 작아서, 임시로 뮤직박스의 하나 제한 사용 안 함","nl-NL":"Afspeellijst te klein, jukebox-voorwaarden worden tijdelijk uitgeschakeld"},"Playlists":{"de-DE":"Wiedergabelisten","es-VE":"Listas de reproducción","fi-FI":"Soittolistat","ko-KR":"연주목록","nl-NL":"Afspeellijsten"},"Playlists are disabled":{"de-DE":"Wiedergabelisten sind deaktiviert","es-VE":"Listas de reproducción deshabilitadas","fi-FI":"Soittolistat ovat pois päältä","ko-KR":"연주목록 사용 안 함","nl-NL":"Afspeellijsten uitgeschakeld"},"Playlists deleted":{"de-DE":"Wiedergabeliste wurde gelöscht","es-VE":"Listas de reproducción eliminadas","fi-FI":"Soittolistat poistettu","ko-KR":"연주목록 지워짐","nl-NL":"Afspeellijsten verwijderd"},"Please choose playlist":{"de-DE":"Bitte Wiedergabeliste auswählen","es-VE":"Seleccione lista de reproducción","fi-FI":"Valitse soittolista","ko-KR":"연주목록을 선택합니다","nl-NL":"Aub afspeellijst kiezen"},"Plugin":{"de-DE":"Plugin","ko-KR":"플러그인"},"Port":{"de-DE":"Port","es-VE":"Puerto","fi-FI":"Portti","nl-NL":"Poort"},"Pos":{"de-DE":"Pos","es-VE":"Pos","fi-FI":"Pos","ko-KR":"위치","nl-NL":"Pos"},"Preview":{"de-DE":"Vorschau","es-VE":"Previsualizar","fi-FI":"Esikatselu","ko-KR":"미리 보기","nl-NL":"Voorbeeld"},"Previous page":{"de-DE":"Vorige Seite","es-VE":"Página anterior","fi-FI":"Edellinen sivu","ko-KR":"이전 페이지","nl-NL":"Vorige pagina"},"Previous song":{"de-DE":"Voriges Lied","es-VE":"Canción anterior","fi-FI":"Edellinen kappale","ko-KR":"이전 곡","nl-NL":"Vorig nummer"},"Protocol version":{"de-DE":"Protokoll Version","es-VE":"Versión de protocolo","fi-FI":"Protokolla Versio","ko-KR":"프로토콜 버전","nl-NL":"Versie protocol"},"Quantity":{"de-DE":"Anzahl","es-VE":"Cantidad","fi-FI":"Määrä","ko-KR":"갯수","nl-NL":"Aantal"},"Queue":{"de-DE":"Warteschlange","es-VE":"Cola de reproducción","fi-FI":"Jono","ko-KR":"순서","nl-NL":"Wachtrij"},"Queue replaced with %{name}":{"de-DE":"Warteschlange mit %{name} ersetzt","es-VE":"Cola de reproducción reemplazada con %{name}","fi-FI":"Jono korvattu %{name}:lla","ko-KR":"%{name} 순서 바꿈","nl-NL":"Wachtrij vervangen door %{name}"},"Random":{"de-DE":"Zufall","es-VE":"Aleatorio","fi-FI":"Satunnainen","ko-KR":"무작위","nl-NL":"Willekeurig"},"Reload":{"de-DE":"Neu laden","es-VE":"Recargar","fi-FI":"Lataa uudelleen","ko-KR":"다시 읽기","nl-NL":"Herladen"},"Remote scripting is disabled":{"de-DE":"Remotescripting ist deaktiviert","ko-KR":"원격 스크립트 사용 안 함","nl-NL":"Scripten op afstand uitgeschakeld"},"Remove":{"de-DE":"Entfernen","es-VE":"Remover","fi-FI":"Poista","ko-KR":"지우기","nl-NL":"Verwijder"},"Remove all downwards":{"de-DE":"Aller Lieder darunter entfernen","es-VE":"Remover todo hacia abajo","fi-FI":"Poista kaikki alempana","ko-KR":"아래로 지우기","nl-NL":"Verwijder alle hieronder"},"Remove all upwards":{"de-DE":"Alle Lieder darüber entfernen","es-VE":"Remover todo hacia arriba","fi-FI":"Poista kaikki ylempänä","ko-KR":"위로 지우기","nl-NL":"Verwijder alle hierboven"},"Remove item from queue":{"de-DE":"Ausgewähltes Element aus Warteschlange entfernen","es-VE":"Eliminar elemento de la cola de reproducción","fi-FI":"Poista jonosta","ko-KR":"순서에서 항목 지우기","nl-NL":"Verwijder selectie uit wachtrij"},"Rename playlist":{"de-DE":"Wiedergabeliste umbenennen","es-VE":"Renombrar lista de reproducción","fi-FI":"Nimeä soittolista uudelleen","ko-KR":"연주목록 이름 바꾸기","nl-NL":"Hernoem afspeellijst"},"Renaming playlist failed":{"de-DE":"Wiedergabeliste konnte nicht umbenannt werden","es-VE":"Error al renombrar lista de reproducción","fi-FI":"Soittolistan nimeäminen epäonnistui","ko-KR":"연주목록 이름 바꾸기 안 됨","nl-NL":"Hernoemen afspeellijst mislukt"},"Repeat":{"de-DE":"Wiederholen","es-VE":"Repetir","fi-FI":"Uudelleentoisto","ko-KR":"다시","nl-NL":"Herhalen"},"Replace queue":{"de-DE":"Warteschlange ersetzen","es-VE":"Reemplazar cola de reproducción","fi-FI":"Korvaa jono","ko-KR":"순서 바꾸기","nl-NL":"Vervang wachtrij"},"Replace queue with item":{"de-DE":"Warteschlange mit ausgewähltem Element ersetzen","es-VE":"Reemplazar cola de reproducción con esto","fi-FI":"Korvaa jono kohteella","ko-KR":"순서에 항목 대체","nl-NL":"Vervang wachtrij met selectie"},"Replaygain":{"de-DE":"Lautstärkeanpassung","es-VE":"Volver a reproducir","fi-FI":"Replaygain","ko-KR":"리플레이게인","nl-NL":"Replaygain"},"Rescan database":{"de-DE":"Datenbank neu einlesen","es-VE":"Reescanear base de datos","fi-FI":"Lue tietokanta uudelleen","ko-KR":"데이터베이스 다시 검색","nl-NL":"Herscan database"},"Rescan directory":{"de-DE":"Verzeichnis neu einlesen","es-VE":"Reescanear directorio","fi-FI":"Lue kansio uudelleen","ko-KR":"디렉터리 다시 검색","nl-NL":"Herscan map"},"Reset":{"de-DE":"Zurücksetzen","es-VE":"Restablecer","fi-FI":"Nollaa","ko-KR":"다시 설정","nl-NL":"Reset"},"Reset settings":{"de-DE":"Einstellungen zurücksetzen","es-VE":"Restablecer configuraciones","fi-FI":"Nollaa asetukset","ko-KR":"다시 설정 하기","nl-NL":"Reset instellingen"},"Sat":{"de-DE":"Sa","es-VE":"Sáb","fi-FI":"La","ko-KR":"토","nl-NL":"Za"},"Save":{"de-DE":"Speichern","es-VE":"Guardar","fi-FI":"Tallenna","ko-KR":"저장","nl-NL":"Opslaan"},"Save as smart playlist":{"de-DE":"Als intelligente Wiedergabeliste speichern","es-VE":"Guardar como lista de reproducción inteligente","fi-FI":"Tallenna älykkäänä soittolistana","ko-KR":"스마트 연주목록 저장","nl-NL":"Als slimme afspeellijst opslaan"},"Save bookmark":{"de-DE":"Lesezeichen speichern","es-VE":"Guardad marcador","fi-FI":"Tallenna kirjanmerkki","ko-KR":"즐겨찾기 저장","nl-NL":"Bladwijzer opslaan"},"Save queue":{"de-DE":"Warteschlange speichern","es-VE":"Guardar cola de reproducción","fi-FI":"Tallenna Jono","ko-KR":"순서 저장","nl-NL":"Wachtrij opslaan"},"Save smart playlist":{"de-DE":"Intelligente Wiedergabeliste sichern","es-VE":"Guardar lista de reproducción inteligente","fi-FI":"Tallenna älykäs soittolista","ko-KR":"스마트 연주목록 저장","nl-NL":"Slimme afspeellijst opslaan"},"Saved smart playlist %{name}":{"de-DE":"Intelligente Wiedergabeliste %{name} gespeichert","es-VE":"Lista de reproducción inteligente guardada: %{name}","fi-FI":"Älykäs soittolista %{name} tallennettu","ko-KR":"%{name} 스마트 연주목록 저장함","nl-NL":"Slimme afspeellijst %{name} opgeslagen"},"Saving bookmark failed":{"de-DE":"Lesezeichen konnte nicht gespeichert werden","es-VE":"Error al guardar marcador","fi-FI":"Kirjanmerkin tallennus epäonnistui","ko-KR":"즐겨찾기 저장 안 됨","nl-NL":"Opslaan bladwijzer mislukt"},"Scale ratio":{"de-DE":"Skalierungswert","ko-KR":"크기 비율","nl-NL":"Schaalverhouding"},"Script":{"de-DE":"Skript","ko-KR":"스크립트","nl-NL":"Script"},"Script %{script} executed successfully":{"de-DE":"Skript %{script} erfolgreich gestartet","ko-KR":"스크립트 %{script} 실행 성공","nl-NL":"Script %{script} succesvol uitgevoerd"},"Script arguments":{"de-DE":"Skriptparameter","ko-KR":"스크립트 변수","nl-NL":"Scriptparameters"},"Script name":{"de-DE":"Skriptname","ko-KR":"스크립트 이름","nl-NL":"Script naam"},"Scripting is disabled":{"de-DE":"Skripte sind deaktiviert","ko-KR":"스크립트 사용 안 함","nl-NL":"Scripten is uitgeschakeld"},"Scripts":{"de-DE":"Skripte","ko-KR":"스크립트","nl-NL":"Scripts"},"Scrobbled love":{"de-DE":"Lieblingslied wurde gescrobbelt","es-VE":"Me gusta recomendado","fi-FI":"Scrobbled rakkaus","ko-KR":"애청곡 추천","nl-NL":"Favoriet werd gescrobbeld"},"Scrobbler integration":{"de-DE":"Scrobbler Integration","es-VE":"Scrobbler Integration","fi-FI":"Scrobbler Integration","ko-KR":"추천 통합","nl-NL":"Scrobbler-integratie"},"Search":{"de-DE":"Suchen","es-VE":"Buscar","fi-FI":"Etsi","ko-KR":"찾기","nl-NL":"Zoeken"},"Search queue":{"de-DE":"Warteschlange durchsuchen","es-VE":"Buscar cola de reproducción","fi-FI":"Etsi jonosta","ko-KR":"순서 찾기","nl-NL":"Zoek in wachtrij"},"Searching...":{"de-DE":"Suche...","es-VE":"Buscando...","fi-FI":"Etsitään...","ko-KR":"찾는 중...","nl-NL":"Zoek..."},"Seconds":{"de-DE":"Sek","en-US":"Sec","es-VE":"Seg","fi-FI":"Sekuntia","ko-KR":"초","nl-NL":"sec"},"Select tag to display":{"de-DE":"Tag für Anzeige auswählen"},"Select tag to search":{"de-DE":"Tag zum Suchen auswählen","es-VE":"Seleccionar etiqueta para buscar","fi-FI":"Valitse etsittävä tagi","ko-KR":"찾을 태그 선택","nl-NL":"Selecteer tag om te zoeken"},"Send love message":{"de-DE":"Sende Lieblingslied","es-VE":"Enviar mensaje de Me gusta","fi-FI":"Lähetä rakkausviesti","ko-KR":"애청 메시지 보내기","nl-NL":"Stuur favoriet"},"Settings":{"de-DE":"Einstellungen","es-VE":"Ajustes","fi-FI":"Asetukset","ko-KR":"설정","nl-NL":"Instellingen"},"Shortcut":{"de-DE":"Tastenkürzel","es-VE":"Acceso directo","fi-FI":"Pikalinkki","ko-KR":"단축키","nl-NL":"Sneltoets"},"Shortcuts":{"de-DE":"Tastenkombinationen","es-VE":"Accesos directos","fi-FI":"Pikalinkki","ko-KR":"단축키","nl-NL":"Sneltoetsen"},"Show attributes":{"de-DE":"Eigenschaften anzeigen","ko-KR":"속성 보기"},"Shuffle":{"de-DE":"Mischen","es-VE":"Aleatorio","fi-FI":"Sekoita","ko-KR":"뒤섞기","nl-NL":"Shuffle"},"Shuffle playlist":{"de-DE":"Wiedergabeliste mischen","es-VE":"Mezclar aleatoriamente la lista de reproducción","fi-FI":"Sekoita soittolista","ko-KR":"연주목록 뒤섞기","nl-NL":"Shuffle afspeellijst"},"Shuffle queue":{"de-DE":"Warteschlange mischen","es-VE":"Cola de reproducción aleatoria","fi-FI":"Sekoita Jono","ko-KR":"순서 뒤섞기","nl-NL":"Wachtrij shufflen"},"Shuffled playlist succesfully":{"de-DE":"Wiedergabeliste erfolgreich gemischt","es-VE":"Lista de reproducción mezclada aleatoriamente","fi-FI":"Soittolista sekoitetttu onnistuneesti","ko-KR":"연주목록을 뒤섞음","nl-NL":"Afspeellijst geshuffled"},"Single":{"de-DE":"Nur ein Lied","es-VE":"Individual","fi-FI":"Yksittäistoisto","ko-KR":"한 곡만","nl-NL":"Single"},"Size in px":{"de-DE":"Größe in PX","es-VE":"Tamaño en px","fi-FI":"koko pikseleinä","ko-KR":"픽셀 크기","nl-NL":"Grootte in px"},"Size normal":{"de-DE":"Normale Größe","es-VE":"Tamaño normal","fi-FI":"Normaali koko","ko-KR":"일반 크기","nl-NL":"Standaard formaat"},"Size small":{"de-DE":"Kleine Größe","es-VE":"Tamaño pequeño","fi-FI":"Pieni koko","ko-KR":"작은 크기","nl-NL":"Klein formaat"},"Skip count":{"de-DE":"Wie oft übersprungen","es-VE":"Conteo omisiones","fi-FI":"Ohitus laskuri","ko-KR":"건너뛴 횟수","nl-NL":"Aantal x geskipt"},"Smart playlist":{"de-DE":"Intelligente Wiedergabeliste","es-VE":"Lista de reproducción inteligente","fi-FI":"Älykäs soittolista","ko-KR":"스마트 연주목록","nl-NL":"Slimmme afspeellijst"},"Smart playlist %{playlist} updated":{"de-DE":"Intelligente Wiedergabeliste %{playlist} aktualisiert","es-VE":"Lista de reproducción %{playlist} actualizada","fi-FI":"Älykäs soittolista %{playlist} päivitetty","ko-KR":"%{playlist} 스마트 연주목록 업데이트함","nl-NL":"Slimmme afspeellijst %{playlist} geüpdatet"},"Smart playlists":{"de-DE":"Intelligente Wiedergabelisten","es-VE":"Listas de reproducción inteligentes","fi-FI":"Älykkäät soittolistat","ko-KR":"스마트 연주목록","nl-NL":"Slimmme afspeellijsten"},"Smart playlists are disabled":{"de-DE":"Intelligente Wiedergabelisten sind deaktiviert","ko-KR":"스마트 연주목록 사용 안 함","nl-NL":"Smart playlists uitgeschakeld"},"Smart playlists prefix":{"de-DE":"Prefix von Intelligenten Wiedergabelisten","es-VE":"Prefijo de listas de reproducción inteligente","fi-FI":"Älykkäiden soittolistojen etuliite","ko-KR":"스마트 연주목록 덧붙임","nl-NL":"Voorvoegsel slimme afspeellijsten"},"Smart playlists update failed":{"de-DE":"Intelligente Wiedergabelisten konnten nicht aktualisiert werden","es-VE":"Error Actualizando listas de reproducción inteligentes","fi-FI":"Älykkäiden soittolistojen päivitys epäonnistui","ko-KR":"스마트 연주목록 업데이트 안 됨","nl-NL":"Updaten slimmme afspeellijsten mislukt"},"Smart playlists update started":{"de-DE":"Aktualisierung der intelligenten Wiedergabelisten gestartet","ko-KR":"스마트 연주목록 업데이트 시작","nl-NL":"Smart playlists wordt geupdatet"},"Smart playlists updated":{"de-DE":"Intelligente Wiedergabelisten wurden aktualisiert","es-VE":"Listas de reproducción inteligentes actualizadas","fi-FI":"Älykkäät soittolistat päivitetty","ko-KR":"스마트 연주목록 업데이트됨","nl-NL":"Slimmme afspeellijsten geüpdatet"},"Song":{"de-DE":"Lied","es-VE":"Canción","fi-FI":"Kappale","ko-KR":"곡","nl-NL":"Nummer"},"Song details":{"de-DE":"Lieddetails","es-VE":"Detalles de canción","fi-FI":"Kappaleen tiedot","ko-KR":"곡 정보","nl-NL":"Nummerdetails"},"Songs":{"de-DE":"Lieder","es-VE":"Canciones","fi-FI":"Kappaleet","ko-KR":"곡","nl-NL":"Nummers"},"Sorry, your MPD version is too old":{"de-DE":"Entschuldige, deine MPD version ist zu alt","es-VE":"Su versión de MPD es muy vieja","fi-FI":"Liian vanha MPD versio","ko-KR":"MPD 버전이 낮음","nl-NL":"Sorry, je MPD-versie is te oud"},"Sort by":{"de-DE":"Sortieren","es-VE":"Ordenar por","fi-FI":"Järjestä","ko-KR":"정렬","nl-NL":"Sorteer op"},"Sort by tag":{"de-DE":"Sortiere nach Tag","es-VE":"Ordenar por etiqueta","fi-FI":"Lahittele tagin mukaan","ko-KR":"태그로 정렬","nl-NL":"Sorteer op tag"},"Sort order of the script, 0 disables listing in main menu":{"de-DE":"Sortierreihenfolge der Skripts, 0 deaktiviert die Anzeige im Hauptmenü","ko-KR":"스크립트 분류 순서, 0은 주 메뉴에 안 보임","nl-NL":"Sorteervolgorde van het script, 0 schakelt lijst in hoofdmenu uit"},"Sort playlist":{"de-DE":"Wiedergabeliste sortieren","es-VE":"Ordenar lista de reproducción","fi-FI":"Järjestä soittolista","ko-KR":"연주목록 정렬","nl-NL":"Sorteer afspeellijst"},"Sorted playlist succesfully":{"de-DE":"Wiedergabeliste erfolgreich sortiert","es-VE":"Lista de reproducción ordenada","fi-FI":"Soittolista järjestetty onnistuneesti","ko-KR":"연주목록 정렬함","nl-NL":"Afspeellijst gesorteerd"},"Specify":{"de-DE":"Manuell","es-VE":"Especificar","fi-FI":"Määritä","ko-KR":"지정","nl-NL":"Specifiek"},"Start":{"de-DE":"Start","es-VE":"Iniciar","fi-FI":"Aloita","ko-KR":"시작","nl-NL":"Start"},"Start playback":{"de-DE":"Wiedergabe starten","es-VE":"Iniciar reproducción","fi-FI":"Aloita toisto","ko-KR":"연주 시작","nl-NL":"Start afspelen"},"State":{"de-DE":"Status","ko-KR":"상태"},"Statistics":{"de-DE":"Statistiken","es-VE":"Estadísticas","fi-FI":"Tilastot","ko-KR":"통계","nl-NL":"Gegevens"},"Sticker":{"de-DE":"Sticker","es-VE":"Sticker","fi-FI":"Sticker","ko-KR":"스티커","nl-NL":"Sticker"},"Sticker cache is NULL":{"de-DE":"Sticker Cache ist leer","ko-KR":"Sticker 캐시가 없음","nl-NL":"Sticker cache is leeg"},"Stickers are disabled":{"de-DE":"Sticker sind deaktiviert","es-VE":"Los Stickers están deshabilitados","fi-FI":"Stickerit on poistettu käytöstä","ko-KR":"스티커 사용 안 함","nl-NL":"Stickers uitgeschakeld"},"Stop playback":{"de-DE":"Wiedergabe anhalten","es-VE":"Detener reproducción","fi-FI":"Pysäytä toisto","ko-KR":"연주 정지","nl-NL":"Stop afspelen"},"Stop playing":{"de-DE":"Stop","es-VE":"Stop","fi-FI":"Stop","ko-KR":"정지","nl-NL":"Stop"},"Stream URI":{"de-DE":"Stream URL","es-VE":"URL Streaming","fi-FI":"Stream URI","ko-KR":"스트리밍 주소","nl-NL":"Streaming url"},"Successfully cleared covercache":{"de-DE":"Covercache erfolgreich geleert","es-VE":"Covercache limpiado exitosamente","fi-FI":"Covercache tyhjennetty onnistuneesti","ko-KR":"표지 캐시 지우기 완료","nl-NL":"Covercache gewist"},"Successfully croped covercache":{"de-DE":"Covercache erfolgreich bereinigt","es-VE":"Covercache cortado exitosamente","fi-FI":"Covercache rajattu onnistuneesti","ko-KR":"표지 캐시 잘라내기 완료","nl-NL":"Covercache opgeschoond"},"Successfully execute cmd %{cmd}":{"de-DE":"Systembefehl %{cmd} erfolgreich ausgeführt","es-VE":"Ejecutado %{cmd} exitosamente","fi-FI":"Komennon  %{cmd} suorittaminen onnistui","ko-KR":"%{cmd} 명령어 실행함","nl-NL":"Systeemcommando %{cmd} uitgevoerd"},"Sucessfully added random songs to queue":{"de-DE":"Zufällige Lieder wurden zur Warteschlange hinzugefügt","es-VE":"Agregadas canciones aleatorias a la cola de reproducción exitosamente","fi-FI":"Satunnaisten kappaleiden lisääminen jonoon onnistui","ko-KR":"무작위 곡을 순서에 추가함","nl-NL":"Willekeurig nummer aan wachtrij toegevoegd"},"Sucessfully renamed playlist":{"de-DE":"Wiedergabeliste erfolgreich umbenannt","es-VE":"Lista de reproducción renombrada exitosamente","fi-FI":"Soittolista nimeäminen onnistui","ko-KR":"연주목록 이름 바꿈","nl-NL":"Afspeellijst is hernoemd"},"Sun":{"de-DE":"So","es-VE":"Dom","fi-FI":"Sun","ko-KR":"일","nl-NL":"Zo"},"Switch to":{"de-DE":"Wechsle zu","ko-KR":"바꿈"},"System command":{"de-DE":"Systembefehl","es-VE":"Comando de sistema","fi-FI":"Järjestelmä komento","ko-KR":"시스템 명령어","nl-NL":"Systeemcommando"},"System command not defined":{"de-DE":"Systembefehl nicht definiert","es-VE":"Comando del sistema no definido","fi-FI":"Järjestelmäkomentoa ei ole määritetty","ko-KR":"시스템 명령어 정의 안됨","nl-NL":"Systeemcommando niet bekend"},"System commands":{"de-DE":"Systembefehle","es-VE":"Comandos de sistema","fi-FI":"Järjestelmäkomennot","ko-KR":"시스템 명령어","nl-NL":"Systemcommando"},"System commands are disabled":{"de-DE":"Systembefehle sind deaktiviert","es-VE":"Comandos del sistema deshabilitados","fi-FI":"Järjestelmäkomennot on poistettu käytöstä","ko-KR":"시스템 명령어 사용 안 함","nl-NL":"Systeemcommando's uitgeschakeld"},"Tag":{"de-DE":"Tag","es-VE":"Etiqueta","fi-FI":"Tag","ko-KR":"태그","nl-NL":"Tag"},"Tags":{"de-DE":"Tags","es-VE":"Etiquetas","fi-FI":"Tagit","ko-KR":"태그","nl-NL":"Tags"},"Tags to browse":{"de-DE":"Tags für die Datenbankanzeige","es-VE":"Etiquetas para explorar","fi-FI":"Selattavat tagit","ko-KR":"열 태그","nl-NL":"Tags om te browsen"},"Tags to search":{"de-DE":"Tags für die Suche","es-VE":"Etiquetas para buscar","fi-FI":"Etsittävät tagit","ko-KR":"찾을 태그","nl-NL":"Tags om te zoeken"},"Tags to use":{"de-DE":"Genutzte Tags","es-VE":"Etiquetas para usar","fi-FI":"Käytettävät tagit","ko-KR":"쓸 태그","nl-NL":"Te gebruiken tags"},"Theme":{"de-DE":"Design","es-VE":"Tema","fi-FI":"Teema","ko-KR":"테마","nl-NL":"Thema"},"Thu":{"de-DE":"Do","es-VE":"Jue","fi-FI":"To","ko-KR":"목","nl-NL":"Do"},"Timer":{"de-DE":"Timer","es-VE":"Temporizador","fi-FI":"Ajastin","ko-KR":"타이머","nl-NL":"Timer"},"Timer with given id not found":{"de-DE":"Timer nicht gefunden","es-VE":"Temporizador no se encontró con ese ID","fi-FI":"Ajastinta annetulla tunnuksella ei löydy","ko-KR":"타이머를 찾을 수 없음","nl-NL":"Timer niet gevonden"},"Timerange (days)":{"de-DE":"Tage","es-VE":"Tiempo (días)","fi-FI":"Aikaväli (päiviä)","ko-KR":"시간 범위 (날짜)","nl-NL":"Dagen"},"Title":{"de-DE":"Titel","es-VE":"Título","fi-FI":"Nimi","ko-KR":"제목","nl-NL":"Titel"},"To":{"de-DE":"Zu","es-VE":"Para","fi-FI":"Mihin","ko-KR":"바꿈","nl-NL":"Naar"},"To top":{"de-DE":"Nach oben","es-VE":"Arriba","fi-FI":"Huipulle","ko-KR":"위로","nl-NL":"Omhoog"},"Toggle play / pause":{"de-DE":"Play / Pause","es-VE":"Play / Pausa","fi-FI":"Play / Pause","ko-KR":"연주 / 잠시 멈춤","nl-NL":"Play / Pause"},"Track":{"de-DE":"Liednummer","es-VE":"# Pista","fi-FI":"Kappalenumero","ko-KR":"트랙","nl-NL":"Track"},"Trigger":{"de-DE":"Trigger","ko-KR":"트리거"},"Trigger name":{"de-DE":"Trigger Name","ko-KR":"트리거 이름"},"Trigger not found":{"de-DE":"Trigger nicht gefunden","ko-KR":"트리거를 찾을 수 없음"},"Tue":{"de-DE":"Di","es-VE":"Mar","fi-FI":"Ti","ko-KR":"화","nl-NL":"Di"},"Type":{"de-DE":"Typ","es-VE":"Tipo","fi-FI":"Tyyppi","ko-KR":"형식","nl-NL":"Type"},"URI":{"de-DE":"URL","es-VE":"URL","fi-FI":"URL","ko-KR":"주소","nl-NL":"Url"},"Unknown album":{"de-DE":"Unbekanntes Album","es-VE":"Álbum desconocido","fi-FI":"Tuntematon albumi","ko-KR":"모르는 음반","nl-NL":"Onbekend album"},"Unknown artist":{"de-DE":"Unbekannter Künstler","es-VE":"Artista desconocido","fi-FI":"Tuntematon artisti","ko-KR":"모르는 연주자","nl-NL":"Onbekende artiest"},"Unknown request":{"de-DE":"Unbekannter Befehl","es-VE":"Solicitud desconocida","fi-FI":"Tuntematon pyyntö","ko-KR":"알 수 없는 요구","nl-NL":"Onbekend verzoek"},"Unknown smart playlist type":{"de-DE":"Unbekannter intelligenter Wiedergabenlisten Typ","es-VE":"Tipo de lista de reproducción inteligente desconocido","fi-FI":"Älykkään soittolistan tyyppi tuntematon","ko-KR":"스마트 연주목록 형식을 알 수 없음","nl-NL":"Onbekend type afspeellijst"},"Unknown table %{table}":{"de-DE":"Unbekannte Tabelle %{table}","es-VE":"Tabla desconocida: %{table}","fi-FI":"Tuntematon taulu %{table}","ko-KR":"%{table} 테이블 알 수 없음","nl-NL":"Onbekende tabel %{table}"},"Unmount":{"de-DE":"Aushängen","es-VE":"Desmontar","fi-FI":"Poista liityntä","ko-KR":"언마운트","nl-NL":"Ontkoppelen"},"Update":{"de-DE":"Aktualisieren","es-VE":"Actualizar","fi-FI":"Päivitä","ko-KR":"업데이트","nl-NL":"Updaten"},"Update database":{"de-DE":"Datenbank aktualisieren","es-VE":"Actualizar base de datos","fi-FI":"Päivitä tietokanta","ko-KR":"데이터베이스 업데이트","nl-NL":"Update database"},"Update directory":{"de-DE":"Verzeichnis aktualisieren","es-VE":"Actualizar directorio","fi-FI":"Päivitä kansio","ko-KR":"디렉터리 업데이트","nl-NL":"Update map"},"Update smart playlist":{"de-DE":"Intelligente Wiedergabeliste aktualisieren","es-VE":"Actualizar lista de reproducción inteligente","fi-FI":"Päivitä alykäs soittolista","ko-KR":"스마트 연주목록 업데이트","nl-NL":"Update slimme afspeellijst"},"Update smart playlists":{"de-DE":"Intelligente Wiedergabelisten aktualisieren","es-VE":"Actualizar listas de reproducción inteligentes","fi-FI":"Päivitä älykkäät soittolistat","ko-KR":"스마트 연주목록 업데이트","nl-NL":"Update slimme afspeellijsten"},"Update smart playlists (hours)":{"de-DE":"Intelligente Wiedergabelisten aktualisieren (Stunden)","es-VE":"Actualizar listas de reproducción inteligentes (horas)","fi-FI":"Älykkäiden soittolistojen päivitys (tunteja)","ko-KR":"스마트 연주목록 업데이트 (시간)","nl-NL":"Update slimme afspeellijsten (uren)"},"Updating MPD database":{"de-DE":"MPD Datenbank wird aktualisiert","es-VE":"Actualizando base de datos MPD","fi-FI":"Päivitetään MPD tietokantaa","ko-KR":"MPD 데이터베이스 업데이트 중","nl-NL":"MPD-database wordt geüpdatet"},"Updating of smart playlist %{playlist} failed":{"de-DE":"Intelligente Wiedergabeliste %{playlist} konnte nicht aktualisiert werden","es-VE":"Error actualizando de lista de reproducción inteligente %{playlist} ","fi-FI":"Älykkään soittolistan %{playlist} päivitys epäonnistui","ko-KR":"%{playlist} 스마트 연주목록 업데이트 안 됨","nl-NL":"Updaten slimmme afspeellijst %{playlist} mislukt "},"Version":{"de-DE":"Version","es-VE":"Versión","fi-FI":"Versio","ko-KR":"버전","nl-NL":"Versie"},"View playlist":{"de-DE":"Wiedergabeliste anzeigen","es-VE":"Ver lista de reproducción","fi-FI":"Näytä soittolista","ko-KR":"연주목록 보기","nl-NL":"Bekijk afspeellijst"},"Volume":{"de-DE":"Lautstärke","es-VE":"Volumen","fi-FI":"Äänenvoimakkuus","ko-KR":"음량","nl-NL":"Volume"},"Volume down":{"de-DE":"Leiser","es-VE":"Volumen -","fi-FI":"Pienemmälle","ko-KR":"소리 작게","nl-NL":"Volume min"},"Volume up":{"de-DE":"Lauter","es-VE":"Volumen +","fi-FI":"Isommalle","ko-KR":"소리 크게","nl-NL":"Volume plus"},"Volumecontrol disabled":{"de-DE":"Lautstärkeregelung deaktiviert","es-VE":"Control de volumen deshabilitado","fi-FI":"Äänenvoimakkuuden säätö pois käytöstä","ko-KR":"음량 조절 안 함","nl-NL":"Volumeregeling uitgeschakeld"},"Web notifications":{"de-DE":"Systemhinweise","es-VE":"Notificaciones Web","fi-FI":"Web ilmoitukset","ko-KR":"웹 알림","nl-NL":"Webmeldingen"},"Webserver":{"de-DE":"Webserver","es-VE":"Servidor Web","fi-FI":"Webserver","ko-KR":"웹서버","nl-NL":"Webserver"},"Websocket connection failed":{"de-DE":"Websocket Verbindung fehlgeschlagen","es-VE":"Error en la conexión con el Websocket","fi-FI":"Websocket yhteys epäonnistui","ko-KR":"웹소켓 연결 안 됨","nl-NL":"Websocket Verbinding mislukt"},"Websocket connection failed, trying to reconnect":{"de-DE":"Websocket Verbindung fehlgeschlagen, versuche neue Verbindung","es-VE":"Error en la conexión Websocket, intentando reconectar","fi-FI":"Websocket yhteys epäonnistui, yritetään uudelleen","ko-KR":"웹소켓 연결이 안 되어, 다시 시도하는 중","nl-NL":"Websocket Verbinding mislukt, nieuwe poging"},"Websocket is disconnected":{"de-DE":"Websockt ist nicht verbunden","es-VE":"Websocket está desconectado","fi-FI":"Websocket yhteys on katkaistu","ko-KR":"웹소켓 연결 안 됨","nl-NL":"Geen connectie met Websocket"},"Wed":{"de-DE":"Mit","es-VE":"Mié","fi-FI":"Ke","ko-KR":"수","nl-NL":"Wo"},"Weekdays":{"de-DE":"Wochentage","es-VE":"Días de semana","fi-FI":"Viikonpäivät","ko-KR":"주일","nl-NL":"Weekdagen"},"Work":{"de-DE":"Werk","es-VE":"Trabajo","fi-FI":"Työ","ko-KR":"작품","nl-NL":"Werk"},"bits":{"de-DE":"Bits","es-VE":"Bits","fi-FI":"bittiä","ko-KR":"비트","nl-NL":"bits"},"contains":{"de-DE":"enthält","es-VE":"contiene","fi-FI":"sisältää","ko-KR":"내용","nl-NL":"bevat"},"current":{"de-DE":"aktive","ko-KR":"현재"},"disabled":{"de-DE":"deaktiviert","ko-KR":"사용 안 함"},"enabled":{"de-DE":"aktiviert","ko-KR":"사용함"},"folder.jpg":{"de-DE":"folder.jpg","es-VE":"carpeta.jpg","fi-FI":"folder.jpg","ko-KR":"folder.jpg","nl-NL":"folder.jpg"},"http://uri.to/stream.mp3":{"de-DE":"http://url.zum/stream.mp3","es-VE":"http://url.to/stream.mp3","fi-FI":"http://url.to/stream.mp3","ko-KR":"http://주소/stream.mp3","nl-NL":"http://url.naar/stream.mp3"},"kHz":{"de-DE":"kHz","es-VE":"kHz","fi-FI":"kHz","ko-KR":"kHz","nl-NL":"kHz"},"myMPD CA":{"de-DE":"myMPD Stammzertifikat","es-VE":"myMPD CA","fi-FI":"myMPD Sertifikaatti","ko-KR":"myMPD 인증서","nl-NL":"myMPD CA"},"myMPD installed as app":{"de-DE":"myMPD wurde als App installiert","es-VE":"myMPD instalado como aplicación","fi-FI":"myMPD asennettu sovelluksena","ko-KR":"myMPD가 앱으로 설치됨","nl-NL":"myMPD werd als app geïnstalleerd "},"myMPD is in readonly mode":{"de-DE":"myMPD ist im Readonly Modus","es-VE":"myMPD está en modo solo lectura","fi-FI":"myMPD on vain luku tilassa","ko-KR":"읽기 전용 모드임","nl-NL":"myMPD is in alleen lezen modus"},"myMPD uptime":{"de-DE":"myMPD Uptime","es-VE":"Tiempo de actividad myMPD","fi-FI":"myMPD Uptime","ko-KR":"myMPD 가동 시간","nl-NL":"myMPD uptime"},"never":{"de-DE":"noch nie","es-VE":"nunca","fi-FI":"Ei koskaan","ko-KR":"안 함","nl-NL":"nooit"},"newest":{"de-DE":"Neueste Lieder","es-VE":"más reciente","fi-FI":"Uusin","ko-KR":"최신","nl-NL":"Nieuwste nummers"},"on":{"de-DE":"an","es-VE":"on","fi-FI":"Päällä","ko-KR":"켜기","nl-NL":"aan"},"search":{"de-DE":"Suche","es-VE":"buscar","fi-FI":"haku","ko-KR":"찾기","nl-NL":"Zoek"},"sticker":{"de-DE":"Sticker","es-VE":"Sticker","fi-FI":"Sticker","ko-KR":"스티커","nl-NL":"Sticker"}};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
var keymap = {
    "ArrowLeft": {"cmd": "clickPrev", "options": [], "desc": "Previous song", "key": "keyboard_arrow_left"},
    "ArrowRight": {"cmd": "clickNext", "options": [], "desc": "Next song", "key": "keyboard_arrow_right"},
    " ": {"cmd": "clickPlay", "options": [], "desc": "Toggle play / pause", "key": "space_bar"},
    "s": {"cmd": "clickStop", "options": [], "desc": "Stop playing"},
    "-": {"cmd": "volumeStep", "options": ["down"], "desc": "Volume down"},
    "+": {"cmd": "volumeStep", "options": ["up"], "desc": "Volume up"},
    "c": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_CLEAR"}], "desc": "Clear queue"},
    "u": {"cmd": "updateDB", "options": ["", true], "desc": "Update database"},
    "r": {"cmd": "rescanDB", "options": ["", true], "desc": "Rescan database"},
    "p": {"cmd": "updateSmartPlaylists", "options": [false], "desc": "Update smart playlists", "req": "featSmartpls"},
    "a": {"cmd": "showAddToPlaylist", "options": ["stream", ""], "desc": "Add stream"},
    "t": {"cmd": "openModal", "options": ["modalSettings"], "desc": "Open settings"},
    "i": {"cmd": "clickTitle", "options": [], "desc": "Open song details"},
    "l": {"cmd": "openDropdown", "options": ["dropdownLocalPlayer"], "desc": "Open local player"},
    "0": {"cmd": "appGoto", "options": ["Playback"], "desc": "Goto playback"},
    "1": {"cmd": "appGoto", "options": ["Queue", "Current"], "desc": "Goto queue"},
    "2": {"cmd": "appGoto", "options": ["Queue", "LastPlayed"], "desc": "Goto last played"},
    "3": {"cmd": "appGoto", "options": ["Browse", "Database"], "desc": "Goto browse database", "req": "featTags"},
    "4": {"cmd": "appGoto", "options": ["Browse", "Playlists"], "desc": "Goto browse playlists", "req": "featPlaylists"},
    "5": {"cmd": "appGoto", "options": ["Browse", "Filesystem"], "desc": "Goto browse filesystem"},
    "6": {"cmd": "appGoto", "options": ["Search"], "desc": "Goto search"},
    "m": {"cmd": "openDropdown", "options": ["dropdownMainMenu"], "desc": "Open main menu"},
    "v": {"cmd": "openDropdown", "options": ["dropdownVolumeMenu"], "desc": "Open volume menu"},
    "S": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_SHUFFLE"}], "desc": "Shuffle queue"},
    "C": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_CROP"}], "desc": "Crop queue"},
    "?": {"cmd": "openModal", "options": ["modalAbout"], "desc": "Open about"},
    "/": {"cmd": "focusSearch", "options": [], "desc": "Focus search"},
    "n": {"cmd": "focusTable", "options": [], "desc": "Focus table"},
    "q": {"cmd": "queueSelectedItem", "options": [true], "desc": "Append item to queue"},
    "Q": {"cmd": "queueSelectedItem", "options": [false], "desc": "Replace queue with item"},
    "d": {"cmd": "dequeueSelectedItem", "options": [], "desc": "Remove item from queue"},
    "x": {"cmd": "addSelectedItemToPlaylist", "options": [], "desc": "Append item to playlist"},
    "F": {"cmd": "openFullscreen", "options": [], "desc": "Open fullscreen"}
};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function sendAPI(method, params, callback, onerror) {
    let request = {"jsonrpc": "2.0", "id": 0, "method": method, "params": params};
    let ajaxRequest=new XMLHttpRequest();
    ajaxRequest.open('POST', subdir + '/api', true);
    ajaxRequest.setRequestHeader('Content-type', 'application/json');
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState === 4) {
            if (ajaxRequest.responseText !== '') {
                let obj = JSON.parse(ajaxRequest.responseText);
                if (obj.error) {
                    showNotification(t(obj.error.message, obj.error.data), '', '', 'danger');
                    logError(JSON.stringify(obj.error));
                }
                else if (obj.result && obj.result.message && obj.result.message !== 'ok') {
                    logDebug('Got API response: ' + JSON.stringify(obj.result));
                    showNotification(t(obj.result.message, obj.result.data), '', '', 'success');
                }
                else if (obj.result && obj.result.message && obj.result.message === 'ok') {
                    logDebug('Got API response: ' + JSON.stringify(obj.result));
                }
                else if (obj.result && obj.result.method) {
                    logDebug('Got API response of type: ' + obj.result.method);
                }
                else {
                    logError('Got invalid API response: ' + JSON.stringify(obj));
                    if (onerror !== true) {
                        return;
                    }
                }
                if (callback !== undefined && typeof(callback) === 'function') {
                    if (obj.result !== undefined || onerror === true) {
                        logDebug('Calling ' + callback.name);
                        callback(obj);
                    }
                    else {
                        logDebug('Undefined resultset, skip calling ' + callback.name);
                    }
                }
            }
            else {
                logError('Empty response for request: ' + JSON.stringify(request));
                if (onerror === true) {
                    if (callback !== undefined && typeof(callback) === 'function') {
                        logDebug('Got empty API response calling ' + callback.name);
                        callback('');
                    }
                }
            }
        }
    };
    ajaxRequest.send(JSON.stringify(request));
    logDebug('Send API request: ' + method);
}

function webSocketConnect() {
    if (socket !== null && socket.readyState === WebSocket.OPEN) {
        logInfo('Socket already connected');
        websocketConnected = true;
        socketRetry = 0;
        return;
    }
    else if (socket !== null && socket.readyState === WebSocket.CONNECTING) {
        logInfo('Socket connection in progress');
        websocketConnected = false;
        socketRetry++;
        if (socketRetry > 20) {
            logError('Socket connection timed out');
            webSocketClose();
            setTimeout(function() {
                webSocketConnect();
            }, 1000);
            socketRetry = 0;
        }
        return;
    }
    else {
        websocketConnected = false;
    }
    
    let wsUrl = getWsUrl();
    socket = new WebSocket(wsUrl);
    socketRetry = 0;
    logInfo('Connecting to ' + wsUrl);

    try {
        socket.onopen = function() {
            logInfo('Websocket is connected');
            websocketConnected = true;
            if (websocketTimer !== null) {
                clearTimeout(websocketTimer);
                websocketTimer = null;
            }
        }

        socket.onmessage = function got_packet(msg) {
            var obj;
            try {
                obj = JSON.parse(msg.data);
                logDebug('Websocket notification: ' + JSON.stringify(obj));
            }
            catch(error) {
                logError('Invalid JSON data received: ' + msg.data);
                return;
            }
            
            if (obj.error) {
                showNotification(t(obj.error.message, obj.error.data), '', '', 'danger');
                return;
            }
            else if (obj.result) {
                showNotification(t(obj.result.message, obj.result.data), '', '', 'success');
                return;
            }

            switch (obj.method) {
                case 'welcome':
                    websocketConnected = true;
                    showNotification(t('Connected to myMPD'), wsUrl, '', 'success');
                    appRoute();
                    sendAPI("MPD_API_PLAYER_STATE", {}, parseState, true);
                    break;
                case 'update_state':
                    obj.result = obj.params;
                    parseState(obj);
                    break;
                case 'mpd_disconnected':
                    if (progressTimer) {
                        clearTimeout(progressTimer);
                    }
                    getSettings(true);
                    break;
                case 'mpd_connected':
                    showNotification(t('Connected to MPD'), '', '', 'success');
                    sendAPI("MPD_API_PLAYER_STATE", {}, parseState);
                    getSettings(true);
                    break;
                case 'update_queue':
                    if (app.current.app === 'Queue') {
                        getQueue();
                    }
                    obj.result = obj.params;
                    parseUpdateQueue(obj);
                    break;
                case 'update_options':
                    getSettings();
                    break;
                case 'update_outputs':
                    sendAPI("MPD_API_PLAYER_OUTPUT_LIST", {}, parseOutputs);
                    break;
                case 'update_started':
                    updateDBstarted(false);
                    break;
                case 'update_database':
                    //fall through
                case 'update_finished':
                    updateDBfinished(obj.method);
                    break;
                case 'update_volume':
                    obj.result = obj.params;
                    parseVolume(obj);
                    break;
                case 'update_stored_playlist':
                    if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'All') {
                        sendAPI("MPD_API_PLAYLIST_LIST", {"offset": app.current.page, "filter": app.current.filter}, parsePlaylists);
                    }
                    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
                        sendAPI("MPD_API_PLAYLIST_CONTENT_LIST", {"offset": app.current.page, "filter": app.current.filter, "uri": app.current.search, "cols": settings.colsBrowsePlaylistsDetail}, parsePlaylists);
                    }
                    break;
                case 'update_lastplayed':
                    if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
                        sendAPI("MPD_API_QUEUE_LAST_PLAYED", {"offset": app.current.page, "cols": settings.colsQueueLastPlayed}, parseLastPlayed);
                    }
                    break;
                case 'error':
                    if (document.getElementById('alertMpdState').classList.contains('hide')) {
                        showNotification(t(obj.params.message), '', '', 'danger');
                    }
                    break;
                case 'warn':
                    if (document.getElementById('alertMpdState').classList.contains('hide')) {
                        showNotification(t(obj.params.message), '', '', 'warning');
                    }
                    break;
                case 'info':
                    if (document.getElementById('alertMpdState').classList.contains('hide')) {
                        showNotification(t(obj.params.message), '', '', 'success');
                    }
                    break;
                default:
                    break;
            }
        }

        socket.onclose = function(){
            logError('Websocket is disconnected');
            websocketConnected = false;
            if (appInited === true) {
                toggleUI();
                if (progressTimer) {
                    clearTimeout(progressTimer);
                }
            }
            else {
                showAppInitAlert(t('Websocket connection failed'));
                logError('Websocket connection failed.');
            }
            if (websocketTimer !== null) {
                clearTimeout(websocketTimer);
                websocketTimer = null;
            }
            websocketTimer = setTimeout(function() {
                logInfo('Reconnecting websocket');
                toggleAlert('alertMympdState', true, t('Websocket connection failed, trying to reconnect') + '&nbsp;&nbsp;<div class="spinner-border spinner-border-sm"></div>');
                webSocketConnect();
            }, 3000);
            socket = null;
        }

    } catch(error) {
        logError(error);
    }
}

function webSocketClose() {
    if (websocketTimer !== null) {
        clearTimeout(websocketTimer);
        websocketTimer = null;
    }
    if (socket !== null) {
        socket.onclose = function () {}; // disable onclose handler first
        socket.close();
        socket = null;
    }
    websocketConnected = false;
}

function getWsUrl() {
    let hostname = window.location.hostname;
    let protocol = window.location.protocol;
    let port = window.location.port;
    
    if (protocol === 'https:') {
        protocol = 'wss://';
    }
    else {
        protocol = 'ws://';
    }

    let wsUrl = protocol + hostname + (port !== '' ? ':' + port : '') + subdir + '/ws/';
    return wsUrl;
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function navBrowseHandler(event) {
    if (event.target.nodeName === 'BUTTON') {
        const tag = event.target.getAttribute('data-tag');
        if (tag === 'Playlists' || tag === 'Filesystem') {
            appGoto('Browse', tag, undefined);
            return;
        }
        
        if (app.current.app === 'Browse' && app.current.tab !== 'Database') {
            let view = app.apps.Browse.tabs.Database.active;
            appGoto('Browse', 'Database', view);
            return;
        }
        if (tag !== 'Album') {
            app.current.filter = tag;
            app.current.sort = tag;
        }
        appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/' 
                + tag  + '/' + app.current.search);
    }
}

function gotoBrowse() {
    let x = event.target;
    let tag = x.getAttribute('data-tag');
    let name = decodeURI(x.getAttribute('data-name'));
    if (tag === null) {
        tag = x.parentNode.getAttribute('data-tag');
        name = decodeURI(x.parentNode.getAttribute('data-name'));
    }
    if (tag !== '' && name !== '' && name !== '-' && settings.browsetags.includes(tag)) {
        appGoto('Browse', 'Database', 'List', '0/' + tag + '/AlbumArtist/Album/' + name);
    }
}

function parseFilesystem(obj) {
    let list = app.current.app + (app.current.tab === 'Filesystem' ? app.current.tab : '');
    let table = document.getElementById(app.current.app + (app.current.tab === undefined ? '' : app.current.tab) + 'List');
    let tbody = table.getElementsByTagName('tbody')[0];
    let colspan = settings['cols' + list].length;
    colspan--;

    if (obj.error) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t(obj.error.message) + '</td></tr>';
        document.getElementById(app.current.app + (app.current.tab === undefined ? '' : app.current.tab) + 'List').classList.remove('opacity05');
        document.getElementById('cardFooterBrowse').innerText = '';
        return;
    }

    let nrItems = obj.result.returnedEntities;
    let tr = tbody.getElementsByTagName('tr');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    for (let i = 0; i < nrItems; i++) {
        let uri = encodeURI(obj.result.data[i].uri);
        let row = document.createElement('tr');
        let tds = '';
        row.setAttribute('data-type', obj.result.data[i].Type);
        row.setAttribute('data-uri', uri);
        row.setAttribute('tabindex', 0);
        if (obj.result.data[i].Type === 'song') {
            row.setAttribute('data-name', obj.result.data[i].Title);
        }
        else {
            row.setAttribute('data-name', obj.result.data[i].name);
        }
        
        switch(obj.result.data[i].Type) {
            case 'dir':
            case 'smartpls':
            case 'plist':
                for (let c = 0; c < settings['cols' + list].length; c++) {
                    tds += '<td data-col="' + settings['cols' + list][c] + '">';
                    if (settings['cols' + list][c] === 'Type') {
                        if (obj.result.data[i].Type === 'dir') {
                            tds += '<span class="material-icons">folder_open</span>';
                        }
                        else {
                            tds += '<span class="material-icons">' + (obj.result.data[i].Type === 'smartpls' ? 'queue_music' : 'list') + '</span>';
                        }
                    }
                    else if (settings['cols' + list][c] === 'Title') {
                        tds += e(obj.result.data[i].name);
                    }
                    tds += '</td>';
                }
                tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
                row.innerHTML = tds;
                break;
            case 'song':
                obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
                for (let c = 0; c < settings['cols' + list].length; c++) {
                    tds += '<td data-col="' + settings['cols' + list][c] + '">';
                    if (settings['cols' + list][c] === 'Type') {
                        tds += '<span class="material-icons">music_note</span>';
                    }
                    else {
                        tds += e(obj.result.data[i][settings['cols' + list][c]]);
                    }
                    tds += '</td>';
                }
                tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
                row.innerHTML = tds;
                break;
        }
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

    if (navigate === true) {
        focusTable(0);
    }

    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
                    
    if (nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t('Empty list') + '</td></tr>';
    }
    document.getElementById(app.current.app + (app.current.tab === undefined ? '' : app.current.tab) + 'List').classList.remove('opacity05');
    //document.getElementById('cardFooterBrowse').innerText = t('Num entries', obj.result.totalEntities);
}

function addAllFromBrowseFilesystem() {
    sendAPI("MPD_API_QUEUE_ADD_TRACK", {"uri": app.current.search});
    showNotification(t('Added all songs'), '', '', 'success');
}

function addAllFromBrowseDatabasePlist(plist) {
    if (app.current.search.length >= 2) {
        sendAPI("MPD_API_DATABASE_SEARCH", {"plist": plist, "filter": app.current.view, "searchstr": app.current.search, "offset": 0, "cols": settings.colsSearch, "replace": false});
    }
}

function parseBookmarks(obj) {
    let list = '<table class="table table-sm table-dark table-borderless mb-0">';
    for (let i = 0; i < obj.result.returnedEntities; i++) {
        list += '<tr data-id="' + obj.result.data[i].id + '" data-type="' + obj.result.data[i].type + '" ' +
                'data-uri="' + encodeURI(obj.result.data[i].uri) + '">' +
                '<td class="nowrap"><a class="text-light" href="#" data-href="goto">' + e(obj.result.data[i].name) + '</a></td>' +
                '<td><a class="text-light material-icons material-icons-small" href="#" data-href="edit">edit</a></td><td>' +
                '<a class="text-light material-icons material-icons-small" href="#" data-href="delete">delete</a></td></tr>';
    }
    if (obj.result.returnedEntities === 0) {
        list += '<tr><td class="text-light nowrap">' + t('No bookmarks found') + '</td></tr>';
    }
    list += '</table>';
    document.getElementById('BrowseFilesystemBookmarks').innerHTML = list;
}

function showBookmarkSave(id, name, uri, type) {
    document.getElementById('saveBookmarkName').classList.remove('is-invalid');
    document.getElementById('saveBookmarkId').value = id;
    document.getElementById('saveBookmarkName').value = name;
    document.getElementById('saveBookmarkUri').value = uri;
    document.getElementById('saveBookmarkType').value = type;
    modalSaveBookmark.show();
}

//eslint-disable-next-line no-unused-vars
function saveBookmark() {
    let id = parseInt(document.getElementById('saveBookmarkId').value);
    let name = document.getElementById('saveBookmarkName').value;
    let uri = document.getElementById('saveBookmarkUri').value;
    let type = document.getElementById('saveBookmarkType').value;
    if (name !== '') {
        sendAPI("MYMPD_API_BOOKMARK_SAVE", {"id": id, "name": name, "uri": uri, "type": type});
        modalSaveBookmark.hide();
    }
    else {
        document.getElementById('saveBookmarkName').classList.add('is-invalid');
    }
}

function parseDatabase(obj) {
    let nrItems = obj.result.returnedEntities;
    let cardContainer = document.getElementById('BrowseDatabaseCards');
    let cols = cardContainer.getElementsByClassName('col');
    if (cols.length === 0) {
        cardContainer.innerHTML = '';
    }
    for (let i = 0; i < nrItems; i++) {
        let col = document.createElement('div');
        col.classList.add('col', 'px-0', 'flex-grow-0');
        if (obj.result.data[i].AlbumArtist === '') {
            obj.result.data[i].AlbumArtist = t('Unknown artist');
        }
        if (obj.result.data[i].Album === '') {
            obj.result.data[i].Album = t('Unknown album');
        }
        let id = genId('database' + obj.result.data[i].Album + obj.result.data[i].AlbumArtist);
        let html;
        let picture = '';
        if (obj.result.tag === 'Album') {
            id = genId('database' + obj.result.data[i].Album + obj.result.data[i].AlbumArtist);
            picture = subdir + '/albumart/' + encodeURI(obj.result.data[i].FirstSongUri);
            html = '<div class="card card-grid clickable" data-picture="' + picture  + '" ' + 
                       'data-uri="' + encodeURI(obj.result.data[i].FirstSongUri.replace(/\/[^/]+$/, '')) + '" ' +
                       'data-type="dir" data-name="' + encodeURI(obj.result.data[i].Album) + '" ' +
                       'data-album="' + encodeURI(obj.result.data[i].Album) + '" ' +
                       'data-albumartist="' + encodeURI(obj.result.data[i].AlbumArtist) + '" tabindex="0">' +
                   '<div class="card-body album-cover-loading album-cover-grid bg-white" id="' + id + '"></div>' +
                   '<div class="card-footer card-footer-grid p-2" title="' + obj.result.data[i].AlbumArtist + ': ' + obj.result.data[i].Album + '">' +
                   obj.result.data[i].Album + '<br/><small>' + obj.result.data[i].AlbumArtist + '</small>' +
                   '</div></div>';
        }
        else {
            id = genId('database' + obj.result.data[i].value);
            picture = subdir + '/tagpics/' + obj.result.tag + '/' + encodeURI(obj.result.data[i].value);
            html = '<div class="card card-grid clickable" data-picture="' + picture + '" data-tag="' + encodeURI(obj.result.data[i].value) + '" tabindex="0">' +
                   (obj.result.pics === true ? '<div class="card-body album-cover-loading album-cover-grid bg-white" id="' + id + '"></div>' : '') +
                   '<div class="card-footer card-footer-grid p-2" title="' + obj.result.data[i].value + '">' +
                   obj.result.data[i].value + '<br/>' +
                   '</div></div>';
        }
        col.innerHTML = html;
        let replaced = false;
        if (i < cols.length) {
            if (cols[i].firstChild.getAttribute('data-picture') !== col.firstChild.getAttribute('data-picture')) {
                cols[i].replaceWith(col);
                replaced = true;
            }
        }
        else {
            cardContainer.append(col);
            replaced = true;
        }
        if ('IntersectionObserver' in window && replaced === true) {
            let options = {
                root: null,
                rootMargin: '0px',
            };
            let observer = new IntersectionObserver(setGridImage, options);
            observer.observe(col);
        }
        else if (replaced === true) {
            col.firstChild.firstChild.style.backgroundImage = picture;
        }
        if (replaced === true) {
            col.firstChild.addEventListener('click', function(event) {
                if (app.current.tag === 'Album') {
                    if (event.target.classList.contains('card-body')) {
                        appGoto('Browse', 'Database', 'Detail', '0/Album/AlbumArtist/' + 
                            decodeURI(event.target.parentNode.getAttribute('data-album')) + 
                            '/' + decodeURI(event.target.parentNode.getAttribute('data-albumartist')));
                    }
                    else if (event.target.classList.contains('card-footer')){
                        showMenu(event.target, event);                
                    }
                }
                else {
                    appGoto(app.current.app, app.current.card, undefined, '0/' + app.current.tag + 
                        '/AlbumArtist/Album/' + decodeURI(event.target.parentNode.getAttribute('data-tag')));
                }
            }, false);
            col.firstChild.addEventListener('keydown', function(event) {
                let handled = false;
                if (event.key === 'Enter') {
                    if (app.current.tag === 'Album') {
                        appGoto('Browse', 'Database', 'Detail', '0/Album/AlbumArtist/' + 
                            decodeURI(event.target.getAttribute('data-album')) + 
                            '/' + decodeURI(event.target.getAttribute('data-albumartist')));
                    }
                    else {
                        appGoto(app.current.app, app.current.card, undefined, '0/' + app.current.tag + 
                        '/AlbumArtist/Album/' + decodeURI(event.target.getAttribute('data-tag')));
                    }
                    handled = true;
                }
                else if (event.key === ' ') {
                    if (app.current.tag === 'Album') {
                        showMenu(event.target.getElementsByClassName('card-footer')[0], event);
                    }
                    handled = true;
                }
                else if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
                    const cur = event.target;
                    const next = event.key === 'ArrowDown' ? (event.target.parentNode.nextElementSibling !== null ? event.target.parentNode.nextElementSibling.firstChild : null)
                                                           : (event.target.parentNode.previousElementSibling != null ? event.target.parentNode.previousElementSibling.firstChild : null);
                    if (next != null) {
                        next.focus();
                        cur.classList.remove('selected');
                        next.classList.add('selected');
                        handled = true;
                        scrollFocusIntoView();
                    }
                }
                else if (event.key === 'Escape') {
                    const cur = event.target;
                    cur.blur();
                    cur.classList.remove('selected');
                    handled = true;
                }
                if (handled === true) {
                    event.stopPropagation();
                    event.preventDefault();
                }
            }, false);
        }
    }
    let colsLen = cols.length - 1;
    for (let i = colsLen; i >= nrItems; i --) {
        cols[i].remove();
    }
    
    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
                    
    if (nrItems === 0) {
        cardContainer.innerHTML = '<div><span class="material-icons">error_outline</span>&nbsp;' + t('Empty list') + '</div>';
    }
    //document.getElementById('cardFooterBrowse').innerText = gtPage('Num entries', obj.result.returnedEntities, obj.result.totalEntities);
}

function setGridImage(changes, observer) {
    changes.forEach(change => {
        if (change.intersectionRatio > 0) {
            observer.unobserve(change.target);
            const uri = decodeURI(change.target.firstChild.getAttribute('data-picture'));
            const body = change.target.firstChild.getElementsByClassName('card-body')[0];
            if (body) {
                body.style.backgroundImage = 'url("' + uri + '"), url("' + subdir + '/assets/coverimage-loading.svg")';
            }
        }
    });
}

function parseAlbumDetails(obj) {
    const coverEl = document.getElementById('viewDetailDatabaseCover');
    coverEl.style.backgroundImage = 'url("' + subdir + '/albumart/' + obj.result.data[0].uri + '"), url("' + subdir + '/assets/coverimage-loading.svg")';
    const infoEl = document.getElementById('viewDetailDatabaseInfo');
    infoEl.innerHTML = '<h1>' + e(obj.result.Album) + '</h1>' +
        '<p>' + e(obj.result.AlbumArtist) + '</p>';
    const cardFooter = document.getElementById('cardFooterBrowse');
    const table = document.getElementById('BrowseDatabaseDetailList');
    const tbody = table.getElementsByTagName('tbody')[0];
    let titleList = '';
    let nrItems = obj.result.returnedEntities;
    for (let i = 0; i < nrItems; i++) {
        if (obj.result.data[i].Duration) {
            obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        }
        titleList += '<tr tabindex="0" data-type="song" data-name="' + obj.result.data[i].Title + '" data-uri="' + encodeURI(obj.result.data[i].uri) + '">';
        for (let c = 0; c < settings.colsBrowseDatabaseDetail.length; c++) {
            titleList += '<td data-col="' + settings.colsBrowseDatabaseDetail[c] + '">' + e(obj.result.data[i][settings.colsBrowseDatabaseDetail[c]]) + '</td>';
        }
        titleList += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td></tr>';
    }
    tbody.innerHTML = titleList;
    //cardFooter.innerHTML = t('Num songs', obj.result.totalEntities) + ' &ndash; ' + beautifyDuration(obj.result.totalTime);
    document.getElementById('BrowseDatabaseDetailList').classList.remove('opacity05');
}

function backToAlbumGrid() {
    appGoto('Browse', 'Database', 'List');
}  

function addAlbum(action) {
    const album = decodeURI(app.current.tag);
    const albumArtist = decodeURI(app.current.search);
    const expression = '((Album == \'' + album + '\') AND (AlbumArtist == \'' + albumArtist + '\'))';
    if (action === 'appendQueue') {
        addAllFromSearchPlist('queue', expression, false);
    }
    else if (action === 'replaceQueue') {
        addAllFromSearchPlist('queue', expression, true);
    }
    else if (action === 'addPlaylist') {
        showAddToPlaylist('ALBUM', expression);
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
var keymap = {
    "ArrowLeft": {"cmd": "clickPrev", "options": [], "desc": "Previous song", "key": "keyboard_arrow_left"},
    "ArrowRight": {"cmd": "clickNext", "options": [], "desc": "Next song", "key": "keyboard_arrow_right"},
    " ": {"cmd": "clickPlay", "options": [], "desc": "Toggle play / pause", "key": "space_bar"},
    "s": {"cmd": "clickStop", "options": [], "desc": "Stop playing"},
    "-": {"cmd": "volumeStep", "options": ["down"], "desc": "Volume down"},
    "+": {"cmd": "volumeStep", "options": ["up"], "desc": "Volume up"},
    "c": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_CLEAR"}], "desc": "Clear queue"},
    "u": {"cmd": "updateDB", "options": ["", true], "desc": "Update database"},
    "r": {"cmd": "rescanDB", "options": ["", true], "desc": "Rescan database"},
    "p": {"cmd": "updateSmartPlaylists", "options": [false], "desc": "Update smart playlists", "req": "featSmartpls"},
    "a": {"cmd": "showAddToPlaylist", "options": ["stream", ""], "desc": "Add stream"},
    "t": {"cmd": "openModal", "options": ["modalSettings"], "desc": "Open settings"},
    "i": {"cmd": "clickTitle", "options": [], "desc": "Open song details"},
    "l": {"cmd": "openDropdown", "options": ["dropdownLocalPlayer"], "desc": "Open local player"},
    "0": {"cmd": "appGoto", "options": ["Playback"], "desc": "Goto playback"},
    "1": {"cmd": "appGoto", "options": ["Queue", "Current"], "desc": "Goto queue"},
    "2": {"cmd": "appGoto", "options": ["Queue", "LastPlayed"], "desc": "Goto last played"},
    "3": {"cmd": "appGoto", "options": ["Browse", "Database"], "desc": "Goto browse database", "req": "featTags"},
    "4": {"cmd": "appGoto", "options": ["Browse", "Playlists"], "desc": "Goto browse playlists", "req": "featPlaylists"},
    "5": {"cmd": "appGoto", "options": ["Browse", "Filesystem"], "desc": "Goto browse filesystem"},
    "6": {"cmd": "appGoto", "options": ["Search"], "desc": "Goto search"},
    "m": {"cmd": "openDropdown", "options": ["dropdownMainMenu"], "desc": "Open main menu"},
    "v": {"cmd": "openDropdown", "options": ["dropdownVolumeMenu"], "desc": "Open volume menu"},
    "S": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_SHUFFLE"}], "desc": "Shuffle queue"},
    "C": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_CROP"}], "desc": "Crop queue"},
    "?": {"cmd": "openModal", "options": ["modalAbout"], "desc": "Open about"},
    "/": {"cmd": "focusSearch", "options": [], "desc": "Focus search"},
    "n": {"cmd": "focusTable", "options": [], "desc": "Focus table"},
    "q": {"cmd": "queueSelectedItem", "options": [true], "desc": "Append item to queue"},
    "Q": {"cmd": "queueSelectedItem", "options": [false], "desc": "Replace queue with item"},
    "d": {"cmd": "dequeueSelectedItem", "options": [], "desc": "Remove item from queue"},
    "x": {"cmd": "addSelectedItemToPlaylist", "options": [], "desc": "Append item to playlist"},
    "F": {"cmd": "openFullscreen", "options": [], "desc": "Open fullscreen"}
};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function e(x) {
    if (isNaN(x)) {
        return x.replace(/([<>"'])/g, function(m0, m1) {
            if (m1 === '<') return '&lt;';
            else if (m1 === '>') return '&gt;';
            else if (m1 === '"') return '&quot;';
            else if (m1 === '\'') return '&apos;';
        }).replace(/\\u(003C|003E|0022|0027)/gi, function(m0, m1) {
            if (m1 === '003C') return '&lt;';
            else if (m1 === '003E') return '&gt;';
            else if (m1 === '0022') return '&quot;';
            else if (m1 === '0027') return '&apos;';
        });
    }
    return x;
}

function t(phrase, number, data) {
    let result = undefined;
    if (isNaN(number)) {
        data = number;
    }

    if (phrases[phrase]) {
        result = phrases[phrase][locale];
        if (result === undefined) {
            if (locale !== 'en-US') {
                logWarn('Phrase "' + phrase + '" for locale ' + locale + ' not found');
            }
            result = phrases[phrase]['en-US'];
        }
    }
    if (result === undefined) {
        result = phrase;
    }

    if (isNaN(number) === false) {
        let p = result.split(' |||| ');
        if (p.length > 1) {
            result = p[smartCount(number)];
        }
        result = result.replace('%{smart_count}', number);
    }
    
    if (data !== null) {
        result = result.replace(/%\{(\w+)\}/g, function(m0, m1) {
            return data[m1];
        });
    }
    
    return e(result);
}

function smartCount(number) {
    if (number === 0) { return 1; }
    else if (number === 1) { return 0; }
    else { return 1; }
}

function localeDate(secs) {
    let d;
    if (secs === undefined) {
       d  = new Date();
    }
    else {
        d = new Date(secs * 1000);
    }
    return d.toLocaleString(locale);
}

function beautifyDuration(x) {
    let days = Math.floor(x / 86400);
    let hours = Math.floor(x / 3600) - days * 24;
    let minutes = Math.floor(x / 60) - hours * 60 - days * 1440;
    let seconds = x - days * 86400 - hours * 3600 - minutes * 60;

    return (days > 0 ? days + '\u2009'+ t('Days') + ' ' : '') +
        (hours > 0 ? hours + '\u2009' + t('Hours') + ' ' + 
        (minutes < 10 ? '0' : '') : '') + minutes + '\u2009' + t('Minutes') + ' ' + 
        (seconds < 10 ? '0' : '') + seconds + '\u2009' + t('Seconds');
}

function beautifySongDuration(x) {
    let hours = Math.floor(x / 3600);
    let minutes = Math.floor(x / 60) - hours * 60;
    let seconds = x - hours * 3600 - minutes * 60;

    return (hours > 0 ? hours + ':' + (minutes < 10 ? '0' : '') : '') + 
        minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
}

function gtPage(phrase, returnedEntities, totalEntities) {
    if (totalEntities > -1) {
        return t(phrase, totalEntities);
    }
    else if (returnedEntities + app.current.page < settings.maxElementsPerPage) {
        return t(phrase, returnedEntities);
    }
    else {
        return '> ' + t(phrase, settings.maxElementsPerPage);
    }
}

function i18nHtml(root) {
    let attributes = [['data-phrase', 'innerText'], 
        ['data-title-phrase', 'title'], 
        ['data-placeholder-phrase', 'placeholder']
    ];
    for (let i = 0; i < attributes.length; i++) {
        let els = root.querySelectorAll('[' + attributes[i][0] + ']');
        let elsLen = els.length;
        for (let j = 0; j < elsLen; j++) {
            els[j][attributes[i][1]] = t(els[j].getAttribute(attributes[i][0]));
        }
    }
}
function setLocalPlayerUrl() {
    if (window.location.protocol === 'https:') {
        document.getElementById('infoLocalplayer').classList.remove('hide');
        document.getElementById('selectStreamMode').options[0].setAttribute('data-phrase','HTTPS Port');
    }
    else {
        document.getElementById('infoLocalplayer').classList.add('hide');
        document.getElementById('selectStreamMode').options[0].setAttribute('data-phrase','HTTP Port');
    }
    if (settings.streamUrl === '') {
        settings.mpdstream = window.location.protocol + '//';
        if (settings.mpdHost.match(/^127\./) !== null || settings.mpdHost === 'localhost' || settings.mpdHost.match(/^\//) !== null) {
            settings.mpdstream += window.location.hostname;
        }
        else {
            settings.mpdstream += settings.mpdHost;
        }
        settings.mpdstream += ':' + settings.streamPort + '/';
    } 
    else {
        settings.mpdstream = settings.streamUrl;
    }
    const localPlayer = document.getElementById('localPlayer');
    if (localPlayer.src !== settings.mpdstream) {
        localPlayer.pause();
        localPlayer.src = settings.mpdstream;
        localPlayer.load();
        setTimeout(function() {
            checkLocalPlayerState();
        }, 500);
    }

}

function clickCheckLocalPlayerState(event) {
    const el = event.target;
    el.classList.add('disabled');
    const parent = document.getElementById('localPlayer').parentNode;
    document.getElementById('localPlayer').remove();
    let localPlayer = document.createElement('audio');
    localPlayer.setAttribute('preload', 'none');
    localPlayer.setAttribute('controls', '');
    localPlayer.setAttribute('id', 'localPlayer');
    localPlayer.classList.add('mx-4');
    parent.appendChild(localPlayer);
    setLocalPlayerUrl();
    setTimeout(function() {
        el.classList.remove('disabled');
        localPlayer.play();
    }, 500);
}

function checkLocalPlayerState() {
    const localPlayer = document.getElementById('localPlayer');
    document.getElementById('errorLocalPlayback').classList.add('hide');
    document.getElementById('alertLocalPlayback').classList.add('hide');
    if (localPlayer.networkState === 0) {
        logDebug('localPlayer networkState: ' + localPlayer.networkState);
        document.getElementById('alertLocalPlayback').classList.remove('hide');
    }
    else if (localPlayer.networkState >=1) {
        logDebug('localPlayer networkState: ' + localPlayer.networkState);
    }
    if (localPlayer.networkState === 3) {
        logError('localPlayer networkState: ' + localPlayer.networkState);
        document.getElementById('errorLocalPlayback').classList.remove('hide');
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function logError(line) {
    logLog(0, 'ERROR: ' + line);
}

function logWarn(line) {
    logLog(1, 'WARN: ' + line);
}

function logInfo(line) {
    logLog(2, 'INFO: ' + line);
}

function logVerbose(line) {
    logLog(3, 'VERBOSE: ' + line);
}

function logDebug(line) {
    logLog(4, 'DEBUG: ' + line);
}

function logLog(loglevel, line) {
    if (settings.loglevel >= loglevel) {
        if (loglevel === 0) {
            console.error(line);
        }
        else if (loglevel === 1) {
            console.warn(line);
        }
        else if (loglevel === 4) {
            console.debug(line);
        }
        else {
            console.log(line);
        }
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function openFullscreen() {
    let elem = document.documentElement;
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { /* Firefox */
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { /* IE/Edge */
        elem.msRequestFullscreen();
    }
}

function setViewport(store) {
    let viewport = document.querySelector("meta[name=viewport]");
    viewport.setAttribute('content', 'width=device-width, initial-scale=' + scale + ', maximum-scale=' + scale);
    if (store === true) {
        try {
            localStorage.setItem('scale-ratio', scale);
        }
        catch(err) {
            logError('Can not save scale-ratio in localStorage: ' + err.message);
        }
    }
}

async function localplayerPlay() {
    let localPlayer = document.getElementById('localPlayer');
    if (localPlayer.paused) {
        try {
            await localPlayer.play();
        } 
        catch(err) {
            showNotification(t('Local playback'), t('Can not start playing'), '', 'danger');
        }
    }
}

//eslint-disable-next-line no-unused-vars
function addStream() {
    let streamUriEl = document.getElementById('streamUrl');
    if (validateStream(streamUriEl) === true) {
        sendAPI("MPD_API_QUEUE_ADD_TRACK", {"uri": streamUriEl.value});
        modalAddToPlaylist.hide();
        showNotification(t('Added stream %{streamUri} to queue', {"streamUri": streamUriEl.value}), '', '', 'success');
    }
}

function seekRelativeForward() {
    seekRelative(5);
}

function seekRelativeBackward() {
    seekRelative(-5);
}

function seekRelative(offset) {
    sendAPI("MPD_API_SEEK_CURRENT", {"seek": offset, "relative": true});
}

//eslint-disable-next-line no-unused-vars
function clickPlay() {
    if (playstate !== 'play') {
        sendAPI("MPD_API_PLAYER_PLAY", {});
    }
    else if (settings.footerStop === true) {
        sendAPI("MPD_API_PLAYER_STOP", {});
    }
    else {
        sendAPI("MPD_API_PLAYER_PAUSE", {});
    }
}

//eslint-disable-next-line no-unused-vars
function clickStop() {
    sendAPI("MPD_API_PLAYER_STOP", {});
}

//eslint-disable-next-line no-unused-vars
function clickPrev() {
    sendAPI("MPD_API_PLAYER_PREV", {});
}

//eslint-disable-next-line no-unused-vars
function clickNext() {
    sendAPI("MPD_API_PLAYER_NEXT", {});
}

//eslint-disable-next-line no-unused-vars
function execSyscmd(cmd) {
    sendAPI("MYMPD_API_SYSCMD", {"cmd": cmd});
}

//eslint-disable-next-line no-unused-vars
function clearCovercache() {
    sendAPI("MYMPD_API_COVERCACHE_CLEAR", {});
}

//eslint-disable-next-line no-unused-vars
function cropCovercache() {
    sendAPI("MYMPD_API_COVERCACHE_CROP", {});
}

//eslint-disable-next-line no-unused-vars
function updateDB(uri, showModal) {
    sendAPI("MPD_API_DATABASE_UPDATE", {"uri": uri});
    updateDBstarted(showModal);
}

//eslint-disable-next-line no-unused-vars
function rescanDB(uri, showModal) {
    sendAPI("MPD_API_DATABASE_RESCAN", {"uri": uri});
    updateDBstarted(showModal);
}

function updateDBstarted(showModal) {
    if (showModal === true) {
        document.getElementById('updateDBfinished').innerText = '';
        document.getElementById('updateDBfooter').classList.add('hide');
        let updateDBprogress = document.getElementById('updateDBprogress');
        updateDBprogress.style.width = '20px';
        updateDBprogress.style.marginLeft = '-20px';
        modalUpdateDB.show();
        updateDBprogress.classList.add('updateDBprogressAnimate');
    }

    showNotification(t('Database update started'), '', '', 'success');
}

function updateDBfinished(idleEvent) {
    if (document.getElementById('modalUpdateDB').classList.contains('show')) {
        _updateDBfinished(idleEvent);
    }
    else {
        //on small databases the modal opens after the finish event
        setTimeout(function() {
            _updateDBfinished(idleEvent);
        }, 100);
    }
}

function _updateDBfinished(idleEvent) {
    //spinner in mounts modal
    let el = document.getElementById('spinnerUpdateProgress');
    if (el) {
        let parent = el.parentNode;
        el.remove();
        for (let i = 0; i < parent.children.length; i++) {
            parent.children[i].classList.remove('hide');
        }
    }

    //update database modal
    if (document.getElementById('modalUpdateDB').classList.contains('show')) {
        if (idleEvent === 'update_database') {
            document.getElementById('updateDBfinished').innerText = t('Database successfully updated');
        }
        else if (idleEvent === 'update_finished') {
            document.getElementById('updateDBfinished').innerText = t('Database update finished');
        }
        let updateDBprogress = document.getElementById('updateDBprogress');
        updateDBprogress.classList.remove('updateDBprogressAnimate');
        updateDBprogress.style.width = '100%';
        updateDBprogress.style.marginLeft = '0px';
        document.getElementById('updateDBfooter').classList.remove('hide');
    }

    //general notification
    if (idleEvent === 'update_database') {
        showNotification(t('Database successfully updated'), '', '', 'success');
    }
    else if (idleEvent === 'update_finished') {
        showNotification(t('Database update finished'), '', '', 'success');
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function unmountMount(mountPoint) {
    sendAPI("MPD_API_MOUNT_UNMOUNT", {"mountPoint": mountPoint}, showListMounts);
}

//eslint-disable-next-line no-unused-vars
function mountMount() {
    let formOK = true;
    document.getElementById('errorMount').classList.add('hide');
    
    if (formOK === true) {
        sendAPI("MPD_API_MOUNT_MOUNT", {
            "mountUrl": getSelectValue('selectMountUrlhandler') + document.getElementById('inputMountUrl').value,
            "mountPoint": document.getElementById('inputMountPoint').value,
            }, showListMounts, true);
    }
}

//eslint-disable-next-line no-unused-vars
function updateMount(el, uri) {
    let parent = el.parentNode;
    for (let i = 0; i < parent.children.length; i++) {
        parent.children[i].classList.add('hide');
    }
    let spinner = document.createElement('div');
    spinner.setAttribute('id', 'spinnerUpdateProgress');
    spinner.classList.add('spinner-border', 'spinner-border-sm');
    el.parentNode.insertBefore(spinner, el);
    updateDB(uri, false);    
}

//eslint-disable-next-line no-unused-vars
function showEditMount(uri, storage) {
    document.getElementById('listMounts').classList.remove('active');
    document.getElementById('editMount').classList.add('active');
    document.getElementById('listMountsFooter').classList.add('hide');
    document.getElementById('editMountFooter').classList.remove('hide');
    document.getElementById('errorMount').classList.add('hide');

    let c = uri.match(/^(\w+:\/\/)(.+)$/);
    if (c !== null && c.length > 2) {
        document.getElementById('selectMountUrlhandler').value = c[1];
        document.getElementById('inputMountUrl').value = c[2];
        document.getElementById('inputMountPoint').value = storage;
    }
    else {
        document.getElementById('inputMountUrl').value = '';
        document.getElementById('inputMountPoint').value = '';
    }
    document.getElementById('inputMountUrl').focus();
    document.getElementById('inputMountUrl').classList.remove('is-invalid');
    document.getElementById('inputMountPoint').classList.remove('is-invalid');
}

function showListMounts(obj) {
    if (obj && obj.error && obj.error.message) {
        let emEl = document.getElementById('errorMount');
        emEl.innerText = obj.error.message;
        emEl.classList.remove('hide');
        return;
    }
    document.getElementById('listMounts').classList.add('active');
    document.getElementById('editMount').classList.remove('active');
    document.getElementById('listMountsFooter').classList.remove('hide');
    document.getElementById('editMountFooter').classList.add('hide');
    sendAPI("MPD_API_MOUNT_LIST", {}, parseListMounts);
}

function parseListMounts(obj) {
    let tbody = document.getElementById('listMounts').getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    
    let activeRow = 0;
    for (let i = 0; i < obj.result.returnedEntities; i++) {
        let row = document.createElement('tr');
        row.setAttribute('data-url', encodeURI(obj.result.data[i].mountUrl));
        row.setAttribute('data-point', encodeURI(obj.result.data[i].mountPoint));
        if (obj.result.data[i].mountPoint === '') {
            row.classList.add('not-clickable');
        }
        let tds = '<td>' + (obj.result.data[i].mountPoint === '' ? '<span class="material-icons">home</span>' : e(obj.result.data[i].mountPoint)) + '</td>' +
                  '<td>' + e(obj.result.data[i].mountUrl) + '</td>';
        if (obj.result.data[i].mountPoint !== '') {
            tds += '<td data-col="Action">' + 
                   '<a href="#" title="' + t('Unmount') + '" data-action="unmount" class="material-icons color-darkgrey">delete</a>' +
                   '<a href="#" title="' + t('Update') + '" data-action="update"class="material-icons color-darkgrey">refresh</a>' +
                   '</td>';
        }
        else {
            tds += '<td>&nbsp;</td>';
        }
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= obj.result.returnedEntities; i --) {
        tr[i].remove();
    }

    if (obj.result.returnedEntities === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="4">' + t('Empty list') + '</td></tr>';
    }     
}

function parseNeighbors(obj) {
    let list = '';
    if (obj.error) {
        list = '<div class="list-group-item"><span class="material-icons">error_outline</span> ' + t(obj.error.message) + '</div>';
    }
    else {
        for (let i = 0; i < obj.result.returnedEntities; i++) {
            list += '<a href="#" class="list-group-item list-group-item-action" data-value="' + obj.result.data[i].uri + '">' + 
                    obj.result.data[i].uri + '<br/><small>' + obj.result.data[i].displayName + '</small></a>';
        }    
        if (obj.result.returnedEntities === 0) {
            list = '<div class="list-group-item"><span class="material-icons">error_outline</span>&nbsp;' + t('Empty list') + '</div>';
        }
    }
    document.getElementById('dropdownNeighbors').children[0].innerHTML = list;
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

/* Disable eslint warnings */
/* global BSN, phrases, locales */

var socket = null;
var websocketConnected = false;
var websocketTimer = null;
var socketRetry = 0;

var lastSong = '';
var lastSongObj = {};
var lastState;
var currentSong = {};
var playstate = '';
var settingsLock = false;
var settingsParsed = false;
var settingsNew = {};
var settings = {};
settings.loglevel = 2;
var alertTimeout = null;
var progressTimer = null;
var deferredA2HSprompt;
var dragEl;

var appInited = false;
var subdir = '';
var uiEnabled = true;
var locale = navigator.language || navigator.userLanguage;
var scale = '1.0';
var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
var ligatureMore = 'menu';
var progressBarTransition = 'width 1s linear';

var app = {};
app.apps = { "Playback":   { "state": "0/-/-/-/", "scrollPos": 0 },
             "Queue":	   {
                  "active": "Current",
                  "tabs": { "Current": { "state": "0/any/-/-/", "scrollPos": 0 },
                            "LastPlayed": { "state": "0/any/-/-/", "scrollPos": 0 }
                          }
                  },
             "Browse":     { 
                  "active": "Database", 
                  "tabs":  { "Filesystem": { "state": "0/-/-/-/", "scrollPos": 0 },
                             "Playlists":  { 
                                 "active": "All",
                                 "views": { "All":    { "state": "0/-/-/-/", "scrollPos": 0 },
                                            "Detail": { "state": "0/-/-/-/", "scrollPos": 0 }
                                 }
                             },
                             "Database":   { 
                                 "active": "List",
                                 "views": { "List":   { "state": "0/AlbumArtist/AlbumArtist/Album/", "scrollPos": 0  },
                                            "Detail": { "state": "0/-/-/-/", "scrollPos": 0 }
                                 }
                             }
                  }
             },
             "Search": { "state": "0/any/-/-/", "scrollPos": 0 }
           };

app.current = { "app": "Playback", "tab": undefined, "view": undefined, "page": 0, "filter": "", "search": "", "sort": "", "tag": "", "scrollPos": 0 };
app.last = { "app": undefined, "tab": undefined, "view": undefined, "filter": "", "search": "", "sort": "", "tag": "", "scrollPos": 0 };

var domCache = {};
domCache.navbarBtns = document.getElementById('navbar-main').getElementsByTagName('div');
domCache.navbarBtnsLen = domCache.navbarBtns.length;
domCache.counter = document.getElementById('counter');
domCache.volumePrct = document.getElementById('volumePrct');
domCache.volumeControl = document.getElementById('volumeControl');
domCache.volumeMenu = document.getElementById('volumeMenu');
domCache.btnsPlay = document.getElementsByClassName('btnPlay');
domCache.btnsPlayLen = domCache.btnsPlay.length;
domCache.btnPrev = document.getElementById('btnPrev');
domCache.btnNext = document.getElementById('btnNext');
domCache.progress = document.getElementById('footerProgress');
domCache.progressBar = document.getElementById('footerProgressBar');
domCache.progressPos = document.getElementById('footerProgressPos')
domCache.volumeBar = document.getElementById('volumeBar');
domCache.outputs = document.getElementById('outputs');
domCache.btnA2HS = document.getElementById('nav-add2homescreen');
domCache.currentCover = document.getElementById('currentCover');
domCache.currentTitle = document.getElementById('currentTitle');
domCache.footerTitle = document.getElementById('footerTitle');
domCache.footerArtist = document.getElementById('footerArtist');
domCache.footerAlbum = document.getElementById('footerAlbum');
domCache.footerCover = document.getElementById('footerCover');
domCache.btnVoteUp = document.getElementById('btnVoteUp');
domCache.btnVoteDown = document.getElementById('btnVoteDown');
domCache.badgeQueueItems = document.getElementById('badgeQueueItems');
domCache.searchstr = document.getElementById('searchstr');
domCache.searchCrumb = document.getElementById('searchCrumb');
domCache.body = document.getElementsByTagName('body')[0];
domCache.footer = document.getElementsByTagName('footer')[0];
domCache.header = document.getElementById('header');
domCache.mainMenu = document.getElementById('mainMenu');

/* eslint-disable no-unused-vars */
var modalConnection = new BSN.Modal(document.getElementById('modalConnection'));
var modalSettings = new BSN.Modal(document.getElementById('modalSettings'));
var modalAbout = new BSN.Modal(document.getElementById('modalAbout')); 
var modalSaveQueue = new BSN.Modal(document.getElementById('modalSaveQueue'));
var modalAddToQueue = new BSN.Modal(document.getElementById('modalAddToQueue'));
var modalSongDetails = new BSN.Modal(document.getElementById('modalSongDetails'));
var modalAddToPlaylist = new BSN.Modal(document.getElementById('modalAddToPlaylist'));
var modalRenamePlaylist = new BSN.Modal(document.getElementById('modalRenamePlaylist'));
var modalUpdateDB = new BSN.Modal(document.getElementById('modalUpdateDB'));
var modalSaveSmartPlaylist = new BSN.Modal(document.getElementById('modalSaveSmartPlaylist'));
var modalDeletePlaylist = new BSN.Modal(document.getElementById('modalDeletePlaylist'));
var modalSaveBookmark = new BSN.Modal(document.getElementById('modalSaveBookmark'));
var modalTimer = new BSN.Modal(document.getElementById('modalTimer'));
var modalMounts = new BSN.Modal(document.getElementById('modalMounts'));
var modalExecScript = new BSN.Modal(document.getElementById('modalExecScript'));
var modalScripts = new BSN.Modal(document.getElementById('modalScripts'));
var modalPartitions = new BSN.Modal(document.getElementById('modalPartitions'));
var modalPartitionOutputs = new BSN.Modal(document.getElementById('modalPartitionOutputs'));
var modalTrigger = new BSN.Modal(document.getElementById('modalTrigger'));
var modalOutputAttributes = new BSN.Modal(document.getElementById('modalOutputAttributes'));

var dropdownMainMenu = new BSN.Dropdown(document.getElementById('mainMenu'));
var dropdownVolumeMenu = new BSN.Dropdown(document.getElementById('volumeMenu'));
var dropdownBookmarks = new BSN.Dropdown(document.getElementById('BrowseFilesystemBookmark'));
var dropdownLocalPlayer = new BSN.Dropdown(document.getElementById('localPlaybackMenu'));
var dropdownPlay = new BSN.Dropdown(document.getElementById('btnPlayDropdown'));
var dropdownDatabaseSort = new BSN.Dropdown(document.getElementById('btnDatabaseSortDropdown'));
var dropdownNeighbors = new BSN.Dropdown(document.getElementById('btnDropdownNeighbors'));

var collapseDBupdate = new BSN.Collapse(document.getElementById('navDBupdate'));
var collapseSettings = new BSN.Collapse(document.getElementById('navSettings'));
var collapseSyscmds = new BSN.Collapse(document.getElementById('navSyscmds'));
var collapseScripting = new BSN.Collapse(document.getElementById('navScripting'));
var collapseJukeboxMode = new BSN.Collapse(document.getElementById('labelJukeboxMode'));
/* eslint-enable no-unused-vars */

function appPrepare(scrollPos) {
    if (app.current.app !== app.last.app || app.current.tab !== app.last.tab || app.current.view !== app.last.view) {
        //Hide all cards + nav
        for (let i = 0; i < domCache.navbarBtnsLen; i++) {
            domCache.navbarBtns[i].classList.remove('active');
        }
        document.getElementById('cardPlayback').classList.add('hide');
        document.getElementById('cardQueue').classList.add('hide');
        document.getElementById('cardBrowse').classList.add('hide');
        document.getElementById('cardSearch').classList.add('hide');
        document.getElementById('cardQueueCurrent').classList.add('hide');
        document.getElementById('cardQueueLastPlayed').classList.add('hide');
        document.getElementById('cardBrowsePlaylists').classList.add('hide');
        document.getElementById('cardBrowseFilesystem').classList.add('hide');
        document.getElementById('cardBrowseDatabase').classList.add('hide');
        //show active card + nav
        document.getElementById('card' + app.current.app).classList.remove('hide');
        if (document.getElementById('nav' + app.current.app)) {
            document.getElementById('nav' + app.current.app).classList.add('active');
        }
        if (app.current.tab !== undefined) {
            document.getElementById('card' + app.current.app + app.current.tab).classList.remove('hide');
        }
        scrollToPosY(scrollPos);
    }
    let list = document.getElementById(app.current.app + 
        (app.current.tab === undefined ? '' : app.current.tab) + 
        (app.current.view === undefined ? '' : app.current.view) + 'List');
    if (list) {
        list.classList.add('opacity05');
    }
}

function appGoto(card, tab, view, state) {
    let scrollPos = 0;
    if (document.body.scrollTop) {
        scrollPos = document.body.scrollTop
    }
    else {
        scrollPos = document.documentElement.scrollTop;
    }
        
    if (app.apps[app.current.app].scrollPos !== undefined) {
        app.apps[app.current.app].scrollPos = scrollPos
    }
    else if (app.apps[app.current.app].tabs[app.current.tab].scrollPos !== undefined) {
        app.apps[app.current.app].tabs[app.current.tab].scrollPos = scrollPos
    }
    else if (app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos !== undefined) {
        app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos = scrollPos;
    }

    let hash = '';
    if (app.apps[card].tabs) {
        if (tab === undefined) {
            tab = app.apps[card].active;
        }
        if (app.apps[card].tabs[tab].views) {
            if (view === undefined) {
                view = app.apps[card].tabs[tab].active;
            }
            hash = '/' + card + '/' + tab +'/' + view + '!' + (state === undefined ? app.apps[card].tabs[tab].views[view].state : state);
        }
        else {
            hash = '/' + card +'/' + tab + '!' + (state === undefined ? app.apps[card].tabs[tab].state : state);
        }
    }
    else {
        hash = '/' + card + '!'+ (state === undefined ? app.apps[card].state : state);
    }
    location.hash = encodeURI(hash);
}

function appRoute() {
    if (settingsParsed === false) {
        appInitStart();
        return;
    }
    let hash = decodeURI(location.hash);
    let params = hash.match(/^#\/(\w+)\/?(\w+)?\/?(\w+)?!((\d+)\/([^/]+)\/([^/]+)\/([^/]+)\/(.*))$/);
    if (params) {
        app.current.app = params[1];
        app.current.tab = params[2];
        app.current.view = params[3];
        if (app.apps[app.current.app].state) {
            app.apps[app.current.app].state = params[4];
            app.current.scrollPos = app.apps[app.current.app].scrollPos;
        }
        else if (app.apps[app.current.app].tabs[app.current.tab].state) {
            app.apps[app.current.app].tabs[app.current.tab].state = params[4];
            app.apps[app.current.app].active = app.current.tab;
            app.current.scrollPos = app.apps[app.current.app].tabs[app.current.tab].scrollPos;
        }
        else if (app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].state) {
            app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].state = params[4];
            app.apps[app.current.app].active = app.current.tab;
            app.apps[app.current.app].tabs[app.current.tab].active = app.current.view;
            app.current.scrollPos = app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos;
        }
        app.current.page = parseInt(params[5]);
        app.current.filter = params[6];
        app.current.sort = params[7];
        app.current.tag = params[8];
        app.current.search = params[9];
    }
    else {
        appPrepare(0);
        appGoto('Playback');
        return;
    }

    appPrepare(app.current.scrollPos);

    if (app.current.app === 'Playback') {
        sendAPI("MPD_API_PLAYER_CURRENT_SONG", {}, songChange);
    }    
    else if (app.current.app === 'Queue' && app.current.tab === 'Current' ) {
        selectTag('searchqueuetags', 'searchqueuetagsdesc', app.current.filter);
        getQueue();
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
        sendAPI("MPD_API_QUEUE_LAST_PLAYED", {"offset": app.current.page, "cols": settings.colsQueueLastPlayed}, parseLastPlayed);
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'All') {
        sendAPI("MPD_API_PLAYLIST_LIST", {"offset": app.current.page, "filter": app.current.filter}, parsePlaylists);
        doSetFilterLetter('BrowsePlaylistsFilter');
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
        sendAPI("MPD_API_PLAYLIST_CONTENT_LIST", {"offset": app.current.page, "filter": app.current.filter, "uri": app.current.search, "cols": settings.colsBrowsePlaylistsDetail}, parsePlaylists);
        doSetFilterLetter('BrowsePlaylistsFilter');
    }    
    else if (app.current.app === 'Browse' && app.current.tab === 'Filesystem') {
        sendAPI("MPD_API_DATABASE_FILESYSTEM_LIST", {"offset": app.current.page, "path": (app.current.search ? app.current.search : "/"), "filter": app.current.filter, "cols": settings.colsBrowseFilesystem}, parseFilesystem, true);
        // Don't add all songs from root
        if (app.current.search) {
            document.getElementById('BrowseFilesystemAddAllSongs').removeAttribute('disabled');
            document.getElementById('BrowseFilesystemAddAllSongsBtn').removeAttribute('disabled');
        }
        else {
            document.getElementById('BrowseFilesystemAddAllSongs').setAttribute('disabled', 'disabled');
            document.getElementById('BrowseFilesystemAddAllSongsBtn').setAttribute('disabled', 'disabled');
        }
        // Create breadcrumb
        let breadcrumbs='<li class="breadcrumb-item"><a data-uri="" class="text-body material-icons">home</a></li>';
        let pathArray = app.current.search.split('/');
        let pathArrayLen = pathArray.length;
        let fullPath = '';
        for (let i = 0; i < pathArrayLen; i++) {
            if (pathArrayLen - 1 === i) {
                breadcrumbs += '<li class="breadcrumb-item active">' + e(pathArray[i]) + '</li>';
                break;
            }
            fullPath += pathArray[i];
            breadcrumbs += '<li class="breadcrumb-item"><a class="text-body" href="#" data-uri="' + encodeURI(fullPath) + '">' + e(pathArray[i]) + '</a></li>';
            fullPath += '/';
        }
        document.getElementById('BrowseBreadcrumb').innerHTML = breadcrumbs;
        doSetFilterLetter('BrowseFilesystemFilter');
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Database' && app.current.view === 'List') {
        document.getElementById('viewListDatabase').classList.remove('hide');
        document.getElementById('viewDetailDatabase').classList.add('hide');
        document.getElementById('searchDatabaseStr').value = app.current.search;
        selectTag('searchDatabaseTags', 'searchDatabaseTagsDesc', app.current.filter);
        selectTag('BrowseDatabaseByTagDropdown', 'btnBrowseDatabaseByTagDesc', app.current.tag);
        let sort = app.current.sort;
        let sortdesc = false;
        if (app.current.sort.charAt(0) === '-') {
            sortdesc = true;
            sort = app.current.sort.substr(1);
            toggleBtnChk('databaseSortDesc', true);
        }
        else {
            toggleBtnChk('databaseSortDesc', false);
        }
        selectTag('databaseSortTags', undefined, sort);
        if (app.current.tag === 'Album') {
            sendAPI("MPD_API_DATABASE_GET_ALBUMS", {"offset": app.current.page, "searchstr": app.current.search, 
                "filter": app.current.filter, "sort": sort, "sortdesc": sortdesc}, parseDatabase);
        }
        else {
            sendAPI("MPD_API_DATABASE_TAG_LIST", {"offset": app.current.page, "searchstr": app.current.search, 
                "filter": app.current.filter, "sort": sort, "sortdesc": sortdesc, "tag": app.current.tag}, parseDatabase);
        }
        if (app.current.tag !== 'Album') {
            document.getElementById('btnDatabaseSortDropdown').setAttribute('disabled', 'disabled');
            document.getElementById('btnDatabaseSearchDropdown').setAttribute('disabled', 'disabled');
        }
        else {
            document.getElementById('btnDatabaseSortDropdown').removeAttribute('disabled');
            document.getElementById('btnDatabaseSearchDropdown').removeAttribute('disabled');
        }
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Database' && app.current.view === 'Detail') {
        document.getElementById('viewListDatabase').classList.add('hide');
        document.getElementById('viewDetailDatabase').classList.remove('hide');
        if (app.current.filter === 'Album') {
            sendAPI("MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", {"album": app.current.tag,
                "search": app.current.search,
                "tag": app.current.sort, "cols": settings.colsBrowseDatabaseDetail}, parseAlbumDetails);
        }    
    }
    else if (app.current.app === 'Search') {
        domCache.searchstr.focus();
        if (settings.featAdvsearch) {
            let crumbs = '';
            let elements = app.current.search.substring(1, app.current.search.length - 1).split(' AND ');
            for (let i = 0; i < elements.length - 1 ; i++) {
                let value = elements[i].substring(1, elements[i].length - 1);
                crumbs += '<button data-filter="' + encodeURI(value) + '" class="btn btn-light mr-2">' + e(value) + '<span class="ml-2 badge badge-secondary">&times</span></button>';
            }
            domCache.searchCrumb.innerHTML = crumbs;
            if (domCache.searchstr.value === '' && elements.length >= 1) {
                let lastEl = elements[elements.length - 1].substring(1,  elements[elements.length - 1].length - 1);
                let lastElValue = lastEl.substring(lastEl.indexOf('\'') + 1, lastEl.length - 1);
                if (domCache.searchstr.value !== lastElValue) {
                    domCache.searchCrumb.innerHTML += '<button data-filter="' + encodeURI(lastEl) +'" class="btn btn-light mr-2">' + e(lastEl) + '<span href="#" class="ml-2 badge badge-secondary">&times;</span></button>';
                }
                let match = lastEl.substring(lastEl.indexOf(' ') + 1);
                match = match.substring(0, match.indexOf(' '));
                if (match === '') {
                    match = 'contains';
                }
                document.getElementById('searchMatch').value = match;
            }
        }
        else {
            if (domCache.searchstr.value === '' && app.current.search !== '') {
                domCache.searchstr.value = app.current.search;
            }
        }
        if (app.last.app !== app.current.app) {
            if (app.current.search !== '') {
                let colspan = settings['cols' + app.current.app].length;
                colspan--;
                document.getElementById('SearchList').getElementsByTagName('tbody')[0].innerHTML=
                    '<tr><td><span class="material-icons">search</span></td>' +
                    '<td colspan="' + colspan + '">' + t('Searching...') + '</td></tr>';
            }
        }

        if (domCache.searchstr.value.length >= 2 || domCache.searchCrumb.children.length > 0) {
            if (settings.featAdvsearch) {
                let sort = app.current.sort;
                let sortdesc = false;
                if (sort === '-') {
                    if (settings.tags.includes('Title')) {
                        sort = 'Title';
                    }
                    else {
                        sort = '-';
                    }
                    document.getElementById('SearchList').setAttribute('data-sort', sort);
                }
                else {
                    if (sort.indexOf('-') === 0) {
                        sortdesc = true;
                        sort = sort.substring(1);
                    }
                }
                sendAPI("MPD_API_DATABASE_SEARCH_ADV", {"plist": "", "offset": app.current.page, "sort": sort, "sortdesc": sortdesc, "expression": app.current.search, "cols": settings.colsSearch, "replace": false}, parseSearch);
            }
            else {
                sendAPI("MPD_API_DATABASE_SEARCH", {"plist": "", "offset": app.current.page, "filter": app.current.filter, "searchstr": app.current.search, "cols": settings.colsSearch, "replace": false}, parseSearch);
            }
        } else {
            document.getElementById('SearchList').getElementsByTagName('tbody')[0].innerHTML = '';
            document.getElementById('searchAddAllSongs').setAttribute('disabled', 'disabled');
            document.getElementById('searchAddAllSongsBtn').setAttribute('disabled', 'disabled');
            document.getElementById('SearchList').classList.remove('opacity05');
            setPagination(0, 0);
        }
        selectTag('searchtags', 'searchtagsdesc', app.current.filter);
    }
    else {
        appGoto("Playback");
    }

    app.last.app = app.current.app;
    app.last.tab = app.current.tab;
    app.last.view = app.current.view;
}

function showAppInitAlert(text) {
    document.getElementById('splashScreenAlert').innerHTML = '<p class="text-danger">' + t(text) + '</p>' +
        '<p><a id="appReloadBtn" class="btn btn-danger text-light clickable">' + t('Reload') + '</a></p>';
    document.getElementById('appReloadBtn').addEventListener('click', function() {
        clearAndReload();
    }, false);
}


function clearAndReload() {
    if ('serviceWorker' in navigator) {
        caches.keys().then(function(cacheNames) {
            cacheNames.forEach(function(cacheName) {
                caches.delete(cacheName);
            });
        });
    }
    location.reload();
}

function a2hsInit() {
    window.addEventListener('beforeinstallprompt', function(event) {
        logDebug('Event: beforeinstallprompt');
        // Prevent Chrome 67 and earlier from automatically showing the prompt
        event.preventDefault();
        // Stash the event so it can be triggered later
        deferredA2HSprompt = event;
        // Update UI notify the user they can add to home screen
        domCache.btnA2HS.classList.remove('hide');
    });

    domCache.btnA2HS.addEventListener('click', function() {
        // Hide our user interface that shows our A2HS button
        domCache.btnA2HS.classList.add('hide');
        // Show the prompt
        deferredA2HSprompt.prompt();
        // Wait for the user to respond to the prompt
        deferredA2HSprompt.userChoice.then((choiceResult) => {
            choiceResult.outcome === 'accepted' ? logDebug('User accepted the A2HS prompt') : logDebug('User dismissed the A2HS prompt');
            deferredA2HSprompt = null;
        });
    });
    
    window.addEventListener('appinstalled', function() {
        logInfo('myMPD installed as app');
        showNotification(t('myMPD installed as app'), '', '', 'success');
    });
}

function appInitStart() {
    //set initial scale
    if (isMobile === true) {
        scale = localStorage.getItem('scale-ratio');
        if (scale === null) {
            scale = '1.0';
        }
        setViewport(false);
    }
    else {
        let m = document.getElementsByClassName('featMobile');
        for (let i = 0; i < m.length; i++) {
            m[i].classList.add('hide');
        }        
    }

    subdir = window.location.pathname.replace('/index.html', '').replace(/\/$/, '');
    let localeList = '<option value="default" data-phrase="Browser default"></option>';
    for (let i = 0; i < locales.length; i++) {
        localeList += '<option value="' + e(locales[i].code) + '">' + e(locales[i].desc) + ' (' + e(locales[i].code) + ')</option>';
    }
    document.getElementById('selectLocale').innerHTML = localeList;
    
    i18nHtml(document.getElementById('splashScreenAlert'));
    
    //set loglevel
    let script = document.getElementsByTagName("script")[0].src.replace(/^.*[/]/, '');
    if (script !== 'combined.js') {
        settings.loglevel = 4;
    }
    //register serviceworker
    if ('serviceWorker' in navigator && window.location.protocol === 'https:' 
        && window.location.hostname !== 'localhost' && script === 'combined.js')
    {
        window.addEventListener('load', function() {
            navigator.serviceWorker.register('/sw.js', {scope: '/'}).then(function(registration) {
                // Registration was successful
                logInfo('ServiceWorker registration successful.');
                registration.update();
            }, function(err) {
                // Registration failed
                logError('ServiceWorker registration failed: ' + err);
            });
        });
    }

    appInited = false;
    document.getElementById('splashScreen').classList.remove('hide');
    document.getElementsByTagName('body')[0].classList.add('overflow-hidden');
    document.getElementById('splashScreenAlert').innerText = t('Fetch myMPD settings');

    a2hsInit();

    getSettings(true);
    appInitWait();
}

function appInitWait() {
    setTimeout(function() {
        if (settingsParsed === 'true' && websocketConnected === true) {
            //app initialized
            document.getElementById('splashScreenAlert').innerText = t('Applying settings');
            document.getElementById('splashScreen').classList.add('hide-fade');
            setTimeout(function() {
                document.getElementById('splashScreen').classList.add('hide');
                document.getElementById('splashScreen').classList.remove('hide-fade');
                document.getElementsByTagName('body')[0].classList.remove('overflow-hidden');
            }, 500);
            appInit();
            appInited = true;
            return;
        }
        
        if (settingsParsed === 'true') {
            //parsed settings, now its save to connect to websocket
            document.getElementById('splashScreenAlert').innerText = t('Connect to websocket');
            webSocketConnect();
        }
        else if (settingsParsed === 'error') {
            return;
        }
        appInitWait();
    }, 500);
}

function appInit() {
    document.getElementById('btnChVolumeDown').addEventListener('click', function(event) {
        event.stopPropagation();
    }, false);
    document.getElementById('btnChVolumeUp').addEventListener('click', function(event) {
        event.stopPropagation();
    }, false);

    domCache.volumeBar.addEventListener('click', function(event) {
        event.stopPropagation();
    }, false);
    domCache.volumeBar.addEventListener('change', function() {
        sendAPI("MPD_API_PLAYER_VOLUME_SET", {"volume": domCache.volumeBar.value});
    }, false);

    domCache.progress.addEventListener('click', function(event) {
        if (currentSong && currentSong.currentSongId >= 0) {
            domCache.progressBar.style.transition = 'none';
            domCache.progressBar.style.width = event.clientX + 'px';
            setTimeout(function() {
                domCache.progressBar.style.transition = progressBarTransition;
            }, 10)
            const seekVal = Math.ceil((currentSong.totalTime * event.clientX) / event.target.offsetWidth);
            sendAPI("MPD_API_PLAYER_SEEK", {"songid": currentSong.currentSongId, "seek": seekVal});
        }
    }, false);
    domCache.progress.addEventListener('mousemove', function(event) {
        if (playstate === 'pause' || playstate === 'play') {
	    domCache.progressPos.innerText = beautifySongDuration(Math.ceil((currentSong.totalTime / event.target.offsetWidth) * event.clientX));
	    domCache.progressPos.style.display = 'block';
	    domCache.progressPos.style.left = event.clientX + 'px';
        }
    }, false);
    domCache.progress.addEventListener('mouseout', function(event) {
        domCache.progressPos.style.display = 'none';
    }, false);

    let collapseArrows = document.querySelectorAll('.subMenu');
    let collapseArrowsLen = collapseArrows.length;
    for (let i = 0; i < collapseArrowsLen; i++) {
        collapseArrows[i].addEventListener('click', function(event) {
            event.stopPropagation();
            event.preventDefault();
            let icon = this.getElementsByTagName('span')[0];
            icon.innerText = icon.innerText === 'keyboard_arrow_right' ? 'keyboard_arrow_down' : 'keyboard_arrow_right';
        }, false);
    }    
    
    document.getElementById('volumeMenu').parentNode.addEventListener('show.bs.dropdown', function () {
        sendAPI("MPD_API_PLAYER_OUTPUT_LIST", {}, parseOutputs);
    });
    
    document.getElementById('btnDropdownNeighbors').parentNode.addEventListener('show.bs.dropdown', function () {
        if (settings.featNeighbors === true) {
            sendAPI("MPD_API_MOUNT_NEIGHBOR_LIST", {}, parseNeighbors, true);
        }
        else {
            document.getElementById('dropdownNeighbors').children[0].innerHTML = 
                '<div class="list-group-item"><span class="material-icons">warning</span> ' + t('Neighbors are disabled') + '</div>';
        }
    });
    
    document.getElementById('dropdownNeighbors').children[0].addEventListener('click', function (event) {
        event.preventDefault();
        if (event.target.nodeName === 'A') {
            let c = event.target.getAttribute('data-value').match(/^(\w+:\/\/)(.+)$/);
            document.getElementById('selectMountUrlhandler').value = c[1];
            document.getElementById('inputMountUrl').value = c[2];
        }
    });
    
    document.getElementById('BrowseFilesystemBookmark').parentNode.addEventListener('show.bs.dropdown', function () {
        sendAPI("MYMPD_API_BOOKMARK_LIST", {"offset": 0}, parseBookmarks);
    });
    
    document.getElementById('playDropdown').parentNode.addEventListener('show.bs.dropdown', function () {
        showPlayDropdown();
    });

    document.getElementById('playDropdown').addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
    });
    
    let dropdowns = document.querySelectorAll('.dropdown-toggle');
    for (let i = 0; i < dropdowns.length; i++) {
        dropdowns[i].parentNode.addEventListener('show.bs.dropdown', function () {
            alignDropdown(this);
        });
    }
    
    document.getElementById('modalTimer').addEventListener('shown.bs.modal', function () {
        showListTimer();
    });

    document.getElementById('modalMounts').addEventListener('shown.bs.modal', function () {
        showListMounts();
    });
    
    document.getElementById('modalScripts').addEventListener('shown.bs.modal', function () {
        showListScripts();
    });
    
    document.getElementById('modalTrigger').addEventListener('shown.bs.modal', function () {
        showListTrigger();
    });
    
    document.getElementById('modalPartitions').addEventListener('shown.bs.modal', function () {
        showListPartitions();
    });
    
    document.getElementById('modalPartitionOutputs').addEventListener('shown.bs.modal', function () {
        sendAPI("MPD_API_PLAYER_OUTPUT_LIST", {"partition": "default"}, parsePartitionOutputsList, false);
    });
    
    document.getElementById('modalAbout').addEventListener('shown.bs.modal', function () {
        sendAPI("MPD_API_DATABASE_STATS", {}, parseStats);
        getServerinfo();
        let trs = '';
        for (let key in keymap) {
            if (keymap[key].req === undefined || settings[keymap[key].req] === true) {
                trs += '<tr><td><div class="key' + (keymap[key].key && keymap[key].key.length > 1 ? ' material-icons material-icons-small' : '') + 
                       '">' + (keymap[key].key !== undefined ? keymap[key].key : key ) + '</div></td><td>' + t(keymap[key].desc) + '</td></tr>';
            }
        }
        document.getElementById('tbodyShortcuts').innerHTML = trs;
    });
    
    document.getElementById('modalAddToPlaylist').addEventListener('shown.bs.modal', function () {
        if (!document.getElementById('addStreamFrm').classList.contains('hide')) {
            document.getElementById('streamUrl').focus();
            document.getElementById('streamUrl').value = '';
        }
        else {
            document.getElementById('addToPlaylistPlaylist').focus();
        }
    });
    
    document.getElementById('inputTimerVolume').addEventListener('change', function() {
        document.getElementById('textTimerVolume').innerHTML = this.value + '&nbsp;%';
    }, false);
    
    document.getElementById('selectTimerAction').addEventListener('change', function() {
        selectTimerActionChange();
    }, false);
    
    document.getElementById('selectTriggerScript').addEventListener('change', function() {
        selectTriggerActionChange();
    }, false);
    
    let selectTimerHour = ''; 
    for (let i = 0; i < 24; i++) {
        selectTimerHour += '<option value="' + i + '">' + zeroPad(i, 2) + '</option>';
    }
    document.getElementById('selectTimerHour').innerHTML = selectTimerHour;
    
    let selectTimerMinute = ''; 
    for (let i = 0; i < 60; i = i + 5) {
        selectTimerMinute += '<option value="' + i + '">' + zeroPad(i, 2) + '</option>';
    }
    document.getElementById('selectTimerMinute').innerHTML = selectTimerMinute;
    

    document.getElementById('inputHighlightColor').addEventListener('change', function() {
        document.getElementById('highlightColorPreview').style.backgroundColor = this.value;
    }, false);
    
    document.getElementById('inputBgColor').addEventListener('change', function() {
        document.getElementById('bgColorPreview').style.backgroundColor = this.value;
    }, false);
    
    document.getElementById('modalAddToQueue').addEventListener('shown.bs.modal', function () {
        document.getElementById('inputAddToQueueQuantity').classList.remove('is-invalid');
        document.getElementById('warnJukeboxPlaylist2').classList.add('hide');
        if (settings.featPlaylists === true) {
            sendAPI("MPD_API_PLAYLIST_LIST_ALL", {"offset": 0, "filter": "-"}, function(obj) { 
                getAllPlaylists(obj, 'selectAddToQueuePlaylist');
            });
        }
    });

    document.getElementById('modalUpdateDB').addEventListener('hidden.bs.modal', function () {
        document.getElementById('updateDBprogress').classList.remove('updateDBprogressAnimate');
    });
    
    document.getElementById('modalSaveQueue').addEventListener('shown.bs.modal', function () {
        let plName = document.getElementById('saveQueueName');
        plName.focus();
        plName.value = '';
        plName.classList.remove('is-invalid');
    });
        
    document.getElementById('modalSettings').addEventListener('shown.bs.modal', function () {
        getSettings();
        document.getElementById('inputCrossfade').classList.remove('is-invalid');
        document.getElementById('inputMixrampdb').classList.remove('is-invalid');
        document.getElementById('inputMixrampdelay').classList.remove('is-invalid');
        document.getElementById('inputScaleRatio').classList.remove('is-invalid');
    });

    document.getElementById('modalConnection').addEventListener('shown.bs.modal', function () {
        getSettings();
        document.getElementById('inputMpdHost').classList.remove('is-invalid');
        document.getElementById('inputMpdPort').classList.remove('is-invalid');
        document.getElementById('inputMpdPass').classList.remove('is-invalid');
    });

    document.getElementById('btnJukeboxModeGroup').addEventListener('mouseup', function () {
        setTimeout(function() {
            let value = document.getElementById('btnJukeboxModeGroup').getElementsByClassName('active')[0].getAttribute('data-value');
            if (value === '0') {
                document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
                document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
            }
            else if (value === '2') {
                document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
                document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
                document.getElementById('selectJukeboxPlaylist').value = 'Database';
            }
            else if (value === '1') {
                document.getElementById('inputJukeboxQueueLength').removeAttribute('disabled');
                document.getElementById('selectJukeboxPlaylist').removeAttribute('disabled');
            }
            if (value !== '0') {
                toggleBtnChk('btnConsume', true);            
            }
            checkConsume();
        }, 100);
    });
    
    document.getElementById('btnConsume').addEventListener('mouseup', function() {
        setTimeout(function() { 
            checkConsume(); 
        }, 100);
    });
    
    document.getElementById('btnStickers').addEventListener('mouseup', function() {
        setTimeout(function() {
            if (document.getElementById('btnStickers').classList.contains('active')) {
                document.getElementById('warnPlaybackStatistics').classList.add('hide');
                document.getElementById('inputJukeboxLastPlayed').removeAttribute('disabled');
            }
            else {
                document.getElementById('warnPlaybackStatistics').classList.remove('hide');
                document.getElementById('inputJukeboxLastPlayed').setAttribute('disabled', 'disabled');
            }
        }, 100);
    });
    
    document.getElementById('selectAddToQueueMode').addEventListener('change', function () {
        let value = this.options[this.selectedIndex].value;
        if (value === '2') {
            document.getElementById('inputAddToQueueQuantity').setAttribute('disabled', 'disabled');
            document.getElementById('inputAddToQueueQuantity').value = '1';
            document.getElementById('selectAddToQueuePlaylist').setAttribute('disabled', 'disabled');
            document.getElementById('selectAddToQueuePlaylist').value = 'Database';
        }
        else if (value === '1') {
            document.getElementById('inputAddToQueueQuantity').removeAttribute('disabled');
            document.getElementById('selectAddToQueuePlaylist').removeAttribute('disabled');
        }
    });

    document.getElementById('addToPlaylistPlaylist').addEventListener('change', function () {
        if (this.options[this.selectedIndex].value === 'new') {
            document.getElementById('addToPlaylistNewPlaylistDiv').classList.remove('hide');
            document.getElementById('addToPlaylistNewPlaylist').focus();
        }
        else {
            document.getElementById('addToPlaylistNewPlaylistDiv').classList.add('hide');
        }
    }, false);
    
    document.getElementById('selectMusicDirectory').addEventListener('change', function () {
        if (this.options[this.selectedIndex].value === 'auto') {
            document.getElementById('inputMusicDirectory').value = settings.musicDirectoryValue;
            document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
        }
        else if (this.options[this.selectedIndex].value === 'none') {
            document.getElementById('inputMusicDirectory').value = '';
            document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
        }
        else {
            document.getElementById('inputMusicDirectory').value = '';
            document.getElementById('inputMusicDirectory').removeAttribute('readonly');
        }
    }, false);
    
    addFilterLetter('BrowseFilesystemFilterLetters');
    addFilterLetter('BrowsePlaylistsFilterLetters');

    document.getElementById('syscmds').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            parseCmd(event, event.target.getAttribute('data-href'));
        }
    }, false);
    
    document.getElementById('scripts').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            execScript(event.target.getAttribute('data-href'));
        }
    }, false);

    let hrefs = document.querySelectorAll('[data-href]');
    let hrefsLen = hrefs.length;
    for (let i = 0; i < hrefsLen; i++) {
        if (hrefs[i].classList.contains('notclickable') === false) {
            hrefs[i].classList.add('clickable');
        }
        let parentInit = hrefs[i].parentNode.classList.contains('noInitChilds') ? true : false;
        if (parentInit === true) {
            //handler on parentnode
            continue;
        }
        hrefs[i].addEventListener('click', function(event) {
            parseCmd(event, this.getAttribute('data-href'));
        }, false);
    }

    let pd = document.getElementsByClassName('pages');
    let pdLen = pd.length;
    for (let i = 0; i < pdLen; i++) {
        pd[i].addEventListener('click', function(event) {
            if (event.target.nodeName === 'BUTTON') {
                gotoPage(event.target.getAttribute('data-page'));
            }
        }, false);
    }

    document.getElementById('cardPlaybackTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'P') 
            gotoBrowse(event.target);
    }, false);

    document.getElementById('BrowseBreadcrumb').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            event.preventDefault();
            appGoto('Browse', 'Filesystem', undefined, '0/' + app.current.filter + '/' + app.current.sort + '/-/' + decodeURI(event.target.getAttribute('data-uri')));
        }
    }, false);
    
    document.getElementById('tbodySongDetails').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            if (event.target.id === 'calcFingerprint') {
                sendAPI("MPD_API_DATABASE_FINGERPRINT", {"uri": decodeURI(event.target.getAttribute('data-uri'))}, parseFingerprint);
                event.preventDefault();
                let parent = event.target.parentNode;
                let spinner = document.createElement('div');
                spinner.classList.add('spinner-border', 'spinner-border-sm');
                event.target.classList.add('hide');
                parent.appendChild(spinner);
            }
            else if (event.target.parentNode.getAttribute('data-tag') !== null) {
                modalSongDetails.hide();
                event.preventDefault();
                gotoBrowse(event.target);
            } 
        }
        else if (event.target.nodeName === 'BUTTON') { 
            if (event.target.getAttribute('data-href')) {
                parseCmd(event, event.target.getAttribute('data-href'));
            }
        }
    }, false);

    document.getElementById('outputs').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            event.stopPropagation();
            event.preventDefault();
            sendAPI("MPD_API_PLAYER_TOGGLE_OUTPUT", {"output": event.target.getAttribute('data-output-id'), "state": (event.target.classList.contains('active') ? 0 : 1)});
            toggleBtn(event.target.id);
        }
        else if (event.target.nodeName === 'A') {
            event.preventDefault();
            showListOutputAttributes(decodeURI(event.target.parentNode.getAttribute('data-output-name')));
        }
    }, false);
    
    document.getElementById('listTimerList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            if (!event.target.parentNode.classList.contains('not-clickable')) {
                showEditTimer(event.target.parentNode.getAttribute('data-id'));
            }
        }
        else if (event.target.nodeName === 'A') {
            deleteTimer(event.target.parentNode.parentNode.getAttribute('data-id'));
        }
        else if (event.target.nodeName === 'BUTTON') {
            toggleTimer(event.target, event.target.parentNode.parentNode.getAttribute('data-id'));
        }
    }, false);

    document.getElementById('listMountsList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            if (event.target.parentNode.getAttribute('data-point') === '') {
                return false;
            }
            showEditMount(decodeURI(event.target.parentNode.getAttribute('data-url')),decodeURI(event.target.parentNode.getAttribute('data-point')));
        }
        else if (event.target.nodeName === 'A') {
            let action = event.target.getAttribute('data-action');
            let mountPoint = decodeURI(event.target.parentNode.parentNode.getAttribute('data-point'));
            if (action === 'unmount') {
                unmountMount(mountPoint);
            }
            else if (action === 'update') {
                updateMount(event.target, mountPoint);
            }
        }
    }, false);
    
    document.getElementById('listScriptsList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            if (settings.featScripteditor === false || event.target.parentNode.getAttribute('data-script') === '') {
                return false;
            }
            showEditScript(decodeURI(event.target.parentNode.getAttribute('data-script')));
        }
        else if (event.target.nodeName === 'A') {
            let action = event.target.getAttribute('data-action');
            let script = decodeURI(event.target.parentNode.parentNode.getAttribute('data-script'));
            if (action === 'delete') {
                deleteScript(script);
            }
            else if (action === 'execute') {
                execScript(event.target.getAttribute('data-href'));
            }
        }
    }, false);
    
    document.getElementById('listTriggerList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            let id = decodeURI(event.target.parentNode.getAttribute('data-trigger-id'));
            showEditTrigger(id);
        }
        else if (event.target.nodeName === 'A') {
            let action = event.target.getAttribute('data-action');
            let id = decodeURI(event.target.parentNode.parentNode.getAttribute('data-trigger-id'));
            if (action === 'delete') {
                deleteTrigger(id);
            }
        }
    }, false);
    
    document.getElementById('listPartitionsList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'A') {
            let action = event.target.getAttribute('data-action');
            let partition = decodeURI(event.target.parentNode.parentNode.getAttribute('data-partition'));
            if (action === 'delete') {
                deletePartition(partition);
            }
            else if (action === 'switch') {
                switchPartition(partition);
            }
        }
    }, false);
    
    document.getElementById('partitionOutputsList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            let outputName = decodeURI(event.target.parentNode.getAttribute('data-output'));
            moveOutput(outputName);
            modalPartitionOutputs.hide();
        }
    }, false);
    
    document.getElementById('QueueCurrentList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            sendAPI("MPD_API_PLAYER_PLAY_TRACK", {"track": event.target.parentNode.getAttribute('data-trackid')});
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);
    
    document.getElementById('QueueLastPlayedList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);    

    document.getElementById('BrowseFilesystemList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            switch(event.target.parentNode.getAttribute('data-type')) {
                case 'parentDir':
                case 'dir':
                    appGoto('Browse', 'Filesystem', undefined, '0/' + app.current.filter + '/' + app.current.sort + '/-/' + decodeURI(event.target.parentNode.getAttribute("data-uri")));
                    break;
                case 'song':
                    appendQueue('song', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
                    break;
                case 'plist':
                    appendQueue('plist', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
                    break;
            }
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowseFilesystemBookmarks').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            let id = event.target.parentNode.parentNode.getAttribute('data-id');
            let type = event.target.parentNode.parentNode.getAttribute('data-type');
            let uri = decodeURI(event.target.parentNode.parentNode.getAttribute('data-uri'));
            let name = event.target.parentNode.parentNode.firstChild.innerText;
            let href = event.target.getAttribute('data-href');
            
            if (href === 'delete') {
                sendAPI("MYMPD_API_BOOKMARK_RM", {"id": id}, function() {
                    sendAPI("MYMPD_API_BOOKMARK_LIST", {"offset": 0}, parseBookmarks);
                });
                event.preventDefault();
                event.stopPropagation();
            }
            else if (href === 'edit') {
                showBookmarkSave(id, name, uri, type);
            }
            else if (href === 'goto') {
                appGoto('Browse', 'Filesystem', undefined, '0/-/-/-/' + uri );
            }
        }
    }, false);

    document.getElementById('BrowsePlaylistsAllList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('plist', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowsePlaylistsDetailList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('plist', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);    
    
    document.getElementById('SearchList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('song', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);
    
    document.getElementById('BrowseDatabaseDetailList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('song', decodeURI(event.target.parentNode.getAttribute('data-uri')), event.target.parentNode.getAttribute('data-name'));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowseFilesystemAddAllSongsDropdown').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            if (event.target.getAttribute('data-phrase') === 'Add all to queue') {
                addAllFromBrowseFilesystem();
            }
            else if (event.target.getAttribute('data-phrase') === 'Add all to playlist') {
                showAddToPlaylist(app.current.search, '');
            }
        }
    }, false);

    document.getElementById('searchAddAllSongsDropdown').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            if (event.target.getAttribute('data-phrase') === 'Add all to queue') {
                addAllFromSearchPlist('queue', null, false);
            }
            else if (event.target.getAttribute('data-phrase') === 'Add all to playlist') {
                showAddToPlaylist('SEARCH', '');
            }
            else if (event.target.getAttribute('data-phrase') === 'Save as smart playlist') {
                saveSearchAsSmartPlaylist();
            }
        }
    }, false);
    
    document.getElementById('searchtags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            app.current.filter = event.target.getAttribute('data-tag');
            search(domCache.searchstr.value);
        }
    }, false);
    
    document.getElementById('searchDatabaseTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            app.current.filter = event.target.getAttribute('data-tag');
            appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/' 
                + app.current.tag + '/' + app.current.search);
        }
    }, false);
    
    document.getElementById('databaseSortDesc').addEventListener('click', function(event) {
        toggleBtnChk(this);
        event.stopPropagation();
        event.preventDefault();
        if (app.current.sort.charAt(0) === '-') {
            app.current.sort = app.current.sort.substr(1);
        }
        else {
            app.current.sort = '-' + app.current.sort;
        }
        appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/' 
            + app.current.tag + '/' + app.current.search);
    }, false);

    document.getElementById('databaseSortTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            event.preventDefault();
            event.stopPropagation();
            app.current.sort = event.target.getAttribute('data-tag');
            appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/' 
                + app.current.tag + '/' + app.current.search);
        }
    }, false);
    
    document.getElementById('searchDatabaseStr').addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else {
            appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/'
                + app.current.tag + '/' + this.value);
        }
    }, false);

    document.getElementById('BrowseDatabaseByTagDropdown').addEventListener('click', function(event) {
        navBrowseHandler(event);
    }, false);
    document.getElementById('BrowseNavPlaylistsDropdown').addEventListener('click', function(event) {
        navBrowseHandler(event);
    }, false);
    document.getElementById('BrowseNavFilesystemDropdown').addEventListener('click', function(event) {
        navBrowseHandler(event);
    }, false);

    document.getElementById('dropdownSortPlaylistTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            event.preventDefault();
            playlistSort(event.target.getAttribute('data-tag'));
        }
    }, false);

    document.getElementById('searchqueuestr').addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else {
            appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/-/' + this.value);
        }
    }, false);

    document.getElementById('searchqueuetags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            appGoto(app.current.app, app.current.tab, app.current.view, app.current.page + '/' + event.target.getAttribute('data-tag') + '/' + app.current.sort  + 
                '/-/' + app.current.search);
        }
    }, false);

    let colDropdowns = ['PlaybackColsDropdown'];
    for (let i = 0; i < colDropdowns.length; i++) {
        document.getElementById(colDropdowns[i]).addEventListener('click', function(event) {
            if (event.target.nodeName === 'BUTTON' && event.target.classList.contains('material-icons')) {
                event.stopPropagation();
                event.preventDefault();
                toggleBtnChk(event.target);
            }
        }, false);
    }
    
    document.getElementById('search').addEventListener('submit', function() {
        return false;
    }, false);

    document.getElementById('searchqueue').addEventListener('submit', function() {
        return false;
    }, false);
    
    document.getElementById('searchdatabase').addEventListener('submit', function() {
        return false;
    }, false);

    domCache.searchstr.addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else if (event.key === 'Enter' && settings.featAdvsearch) {
            if (this.value !== '') {
                let match = document.getElementById('searchMatch');
                let li = document.createElement('button');
                li.classList.add('btn', 'btn-light', 'mr-2');
                li.setAttribute('data-filter', encodeURI(app.current.filter + ' ' + match.options[match.selectedIndex].value +' \'' + this.value + '\''));
                li.innerHTML = e(app.current.filter) + ' ' + e(match.options[match.selectedIndex].value) + ' \'' + e(this.value) + '\'<span class="ml-2 badge badge-secondary">&times;</span>';
                this.value = '';
                domCache.searchCrumb.appendChild(li);
            }
            else {
                search(this.value);
            }
        }
        else {
            search(this.value);
        }
    }, false);

    domCache.searchCrumb.addEventListener('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        if (event.target.nodeName === 'SPAN') {
            event.target.parentNode.remove();
            search('');
        }
        else if (event.target.nodeName === 'BUTTON') {
            let value = decodeURI(event.target.getAttribute('data-filter'));
            domCache.searchstr.value = value.substring(value.indexOf('\'') + 1, value.length - 1);
            let filter = value.substring(0, value.indexOf(' '));
            selectTag('searchtags', 'searchtagsdesc', filter);
            let match = value.substring(value.indexOf(' ') + 1);
            match = match.substring(0, match.indexOf(' '));
            document.getElementById('searchMatch').value = match;
            event.target.remove();
            search(domCache.searchstr.value);
        }
    }, false);

    document.getElementById('searchMatch').addEventListener('change', function() {
        search(domCache.searchstr.value);
    }, false);
    
    document.getElementById('SearchList').getElementsByTagName('tr')[0].addEventListener('click', function(event) {
        if (settings.featAdvsearch) {
            if (event.target.nodeName === 'TH') {
                if (event.target.innerHTML === '') {
                    return;
                }
                let col = event.target.getAttribute('data-col');
                if (col === 'Duration') {
                    return;
                }
                let sortcol = app.current.sort;
                let sortdesc = true;
                
                if (sortcol === col || sortcol === '-' + col) {
                    if (sortcol.indexOf('-') === 0) {
                        sortdesc = true;
                        col = sortcol.substring(1);
                    }
                    else {
                        sortdesc = false;
                    }
                }
                if (sortdesc === false) {
                    sortcol = '-' + col;
                    sortdesc = true;
                }
                else {
                    sortdesc = false;
                    sortcol = col;
                }
                
                let s = document.getElementById('SearchList').getElementsByClassName('sort-dir');
                for (let i = 0; i < s.length; i++) {
                    s[i].remove();
                }
                app.current.sort = sortcol;
                event.target.innerHTML = t(col) + '<span class="sort-dir material-icons pull-right">' + (sortdesc === true ? 'arrow_drop_up' : 'arrow_drop_down') + '</span>';
                appGoto(app.current.app, app.current.tab, app.current.view, app.current.page + '/' + app.current.filter + '/' + app.current.sort + '/-/' + app.current.search);
            }
        }
    }, false);



    document.getElementById('inputScriptArgument').addEventListener('keyup', function(event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            event.stopPropagation();
            addScriptArgument();
        }
    }, false);
    
    document.getElementById('selectScriptArguments').addEventListener('click', function(event) {
        if (event.target.nodeName === 'OPTION') {
            removeScriptArgument(event);
        }
    }, false);

    document.getElementsByTagName('body')[0].addEventListener('click', function() {
        hideMenu();
    }, false);

    dragAndDropTable('QueueCurrentList');
    dragAndDropTable('BrowsePlaylistsDetailList');
    dragAndDropTableHeader('QueueCurrent');
    dragAndDropTableHeader('QueueLastPlayed');
    dragAndDropTableHeader('Search');
    dragAndDropTableHeader('BrowseFilesystem');
    dragAndDropTableHeader('BrowsePlaylistsDetail');
    dragAndDropTableHeader('BrowseDatabaseDetail');

    window.addEventListener('hashchange', appRoute, false);

    window.addEventListener('focus', function() {
        sendAPI("MPD_API_PLAYER_STATE", {}, parseState);
    }, false);


    document.addEventListener('keydown', function(event) {
        if (event.target.tagName === 'INPUT' || event.target.tagName === 'SELECT' ||
            event.target.tagName === 'TEXTAREA' || event.ctrlKey || event.altKey) {
            return;
        }
        let cmd = keymap[event.key];
        if (cmd && typeof window[cmd.cmd] === 'function') {
            if (keymap[event.key].req === undefined || settings[keymap[event.key].req] === true)
                parseCmd(event, cmd);
        }        
        
    }, false);
    

    let tables = document.getElementsByTagName('table');
    for (let i = 0; i < tables.length; i++) {
        tables[i].setAttribute('tabindex', 0);
        tables[i].addEventListener('keydown', function(event) {
            navigateTable(this, event.key);
        }, false);
    }

    let selectThemeHtml = '';
    Object.keys(themes).forEach(function(key) {
        selectThemeHtml += '<option value="' + e(key) + '">' + t(themes[key]) + '</option>';
    });
    document.getElementById('selectTheme').innerHTML = selectThemeHtml;

    window.addEventListener('beforeunload', function() {
        webSocketClose();
    });
    
    document.getElementById('alertLocalPlayback').getElementsByTagName('a')[0].addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        clickCheckLocalPlayerState(event);
    }, false);
    
    document.getElementById('errorLocalPlayback').getElementsByTagName('a')[0].addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        clickCheckLocalPlayerState(event);
    }, false);

    document.getElementById('localPlayer').addEventListener('click', function(event) {
        event.stopPropagation();
    });
    
    document.getElementById('localPlayer').addEventListener('canplay', function() {
        logDebug('localPlayer event: canplay');
        document.getElementById('alertLocalPlayback').classList.add('hide');
        document.getElementById('errorLocalPlayback').classList.add('hide');
    });
    document.getElementById('localPlayer').addEventListener('error', function() {
        logError('localPlayer event: error');
        document.getElementById('errorLocalPlayback').classList.remove('hide');
    });
}

//Init app
window.onerror = function(msg, url, line) {
    logError('JavaScript error: ' + msg + ' (' + url + ': ' + line + ')');
    if (settings.loglevel >= 4) {
        if (appInited === true) {
            showNotification(t('JavaScript error'), msg + ' (' + url + ': ' + line + ')', '', 'danger');
        }
        else {
            showAppInitAlert(t('JavaScript error') + ': ' + msg + ' (' + url + ': ' + line + ')');
        }
    }
    return true;
};

appInitStart();
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function setStateIcon(state) {
    if (websocketConnected === false || settings.mpdConnected === false) {
        domCache.mainMenu.classList.add('text-light');
        domCache.mainMenu.classList.remove('connected');
    }
    else {
        domCache.mainMenu.classList.add('connected');
        domCache.mainMenu.classList.remove('text-light');
    }
}

function toggleAlert(alertBox, state, msg) {
    let mpdState = document.getElementById(alertBox);
    if (state === false) {
        mpdState.innerHTML = '';
        mpdState.classList.add('hide');
    }
    else {
        mpdState.innerHTML = msg;
        mpdState.classList.remove('hide');
    }
}

function showNotification(notificationTitle, notificationText, notificationHtml, notificationType) {
    if (settings.notificationWeb === true) {
        let notification = new Notification(notificationTitle, {icon: 'assets/favicon.ico', body: notificationText});
        setTimeout(notification.close.bind(notification), 3000);
    } 
    if (settings.notificationPage === true || notificationType === 'danger' || notificationType === 'warning') {
        let alertBox;
        if (alertTimeout) {
            clearTimeout(alertTimeout);
        }
        if (!document.getElementById('alertBox')) {
            alertBox = document.createElement('div');
            alertBox.setAttribute('id', 'alertBox');
            alertBox.classList.add('toast');
        }
        else {
            alertBox = document.getElementById('alertBox');
        }
        
        let toast = '<div class="toast-header">';
        if (notificationType === 'success' ) {
            toast += '<span class="material-icons text-success mr-2">info</span>';
        }
        else if (notificationType === 'warning' ) {
            toast += '<span class="material-icons text-warning mr-2">warning</span>';
        }
        else {
            toast += '<span class="material-icons text-danger mr-2">error</span>';
        }
        toast += '<strong class="mr-auto">' + e(notificationTitle) + '</strong>' +
            '<button type="button" class="ml-2 mb-1 close">&times;</button></div>';
        if (notificationHtml !== '' || notificationText !== '') {
            toast += '<div class="toast-body">' + (notificationHtml === '' ? e(notificationText) : notificationHtml) + '</div>';
        }
        toast += '</div>';
        alertBox.innerHTML = toast;
        
        if (!document.getElementById('alertBox')) {
            document.getElementsByTagName('main')[0].append(alertBox);
            requestAnimationFrame(function() {
                let ab = document.getElementById('alertBox');
                if (ab) {
                    ab.classList.add('alertBoxActive');
                }
            });
        }
        alertBox.getElementsByTagName('button')[0].addEventListener('click', function() {
            hideNotification();
        }, false);

        alertTimeout = setTimeout(function() {
            hideNotification();
        }, 3000);
    }
    setStateIcon('newMessage');
    logMessage(notificationTitle, notificationText, notificationHtml, notificationType);
}

function logMessage(notificationTitle, notificationText, notificationHtml, notificationType) {
    if (notificationType === 'success') { notificationType = 'Info'; }
    else if (notificationType === 'warning') { notificationType = 'Warning'; }
    else if (notificationType === 'danger') { notificationType = 'Error'; }
    
    let overview = document.getElementById('logOverview');

    let append = true;
    let lastEntry = overview.firstElementChild;
    if (lastEntry) {
        if (lastEntry.getAttribute('data-title') === notificationTitle) {
            append = false;        
        }
    }

    let entry = document.createElement('div');
    entry.classList.add('text-light');
    entry.setAttribute('data-title', notificationTitle);
    let occurence = 1;
    if (append === false) {
        occurence += parseInt(lastEntry.getAttribute('data-occurence'));
    }
    entry.setAttribute('data-occurence', occurence);
    entry.innerHTML = '<small>' + localeDate() + '&nbsp;&ndash;&nbsp;' + t(notificationType) +
        (occurence > 1 ? '&nbsp;(' + occurence + ')' : '') + '</small>' +
        '<p>' + e(notificationTitle) +
        (notificationHtml === '' && notificationText === '' ? '' :
        '<br/>' + (notificationHtml === '' ? e(notificationText) : notificationHtml)) +
        '</p>';

    if (append === true) {
        overview.insertBefore(entry, overview.firstElementChild);
    }
    else {
        overview.replaceChild(entry, lastEntry);
    }
   
    let overviewEls = overview.getElementsByTagName('div');
    if (overviewEls.length > 10) {
        overviewEls[10].remove();
    }
}

//eslint-disable-next-line no-unused-vars
function clearLogOverview() {
    let overviewEls = document.getElementById('logOverview').getElementsByTagName('div');
    for (let i = overviewEls.length - 1; i >= 0; i--) {
        overviewEls[i].remove();
    }
    setStateIcon('noMessage');
}

function hideNotification() {
    if (alertTimeout) {
        clearTimeout(alertTimeout);
    }

    if (document.getElementById('alertBox')) {
        document.getElementById('alertBox').classList.remove('alertBoxActive');
        setTimeout(function() {
            let alertBox = document.getElementById('alertBox');
            if (alertBox) {
                alertBox.remove();
            }
        }, 750);
    }
}

function notificationsSupported() {
    return "Notification" in window;
}

function setElsState(tag, state, type) {
    let els = type === 'tag' ? document.getElementsByTagName(tag) : document.getElementsByClassName(tag);
    let elsLen = els.length;
    for (let i = 0; i < elsLen; i++) {
        if (els[i].classList.contains('close')) {
            continue;
        }
        if (state === 'disabled') {
            if (els[i].classList.contains('alwaysEnabled') === false) {
                if (els[i].getAttribute('disabled') === null) {
                    els[i].setAttribute('disabled', 'disabled');
                    els[i].classList.add('disabled');
                }
            }
        }
        else {
            if (els[i].classList.contains('disabled')) {
                els[i].removeAttribute('disabled');
                els[i].classList.remove('disabled');
            }
        }
    }
}

function toggleUI() {
    let state = 'disabled';
    if (websocketConnected === true && settings.mpdConnected === true) {
        state = 'enabled';
    }
    let enabled = state === 'disabled' ? false : true;
    if (enabled !== uiEnabled) {
        logDebug('Setting ui state to ' + state);
        setElsState('a', state, 'tag');
        setElsState('input', state, 'tag');
        setElsState('button', state, 'tag');
        setElsState('clickable', state, 'class');
        uiEnabled = enabled;
    }

    if (settings.mpdConnected === true) {
        toggleAlert('alertMpdState', false, '');
    }
    else {
        toggleAlert('alertMpdState', true, t('MPD disconnected'));
        logMessage(t('MPD disconnected'), '', '', 'danger');
    }

    if (websocketConnected === true) {
        toggleAlert('alertMympdState', false, '');
    }
    else {
        toggleAlert('alertMympdState', true, t('Websocket is disconnected'));
        logMessage(t('Websocket is disconnected'), '', '', 'danger');
    }
    setStateIcon();
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function moveOutput(output) {
    sendAPI("MPD_API_PARTITION_OUTPUT_MOVE", {"name": output});
}

function parsePartitionOutputsList(obj) {
    let outputs = document.getElementById('outputs').getElementsByTagName('button');
    let outputIds = [];
    for (let i = 0; i < outputs.length; i++) {
        outputIds.push(parseInt(outputs[i].getAttribute('data-output-id')));
    }

    let outputList = '';
    let nr = 0;
    for (let i = 0; i < obj.result.data.length; i++) {
        if (outputIds.includes(obj.result.data[i].id) === false) {
            outputList += '<tr data-output="' + encodeURI(obj.result.data[i].name) + '"><td>' +
                e(obj.result.data[i].name) + '</td></tr>';
            nr++;
        }
    }
    if (nr === 0) {
        outputList = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span>&nbsp;' +
            t('Empty list') + '</td></tr>';
    }
    document.getElementById('partitionOutputsList').innerHTML = outputList;
}

//eslint-disable-next-line no-unused-vars
function savePartition() {
    let formOK = true;
    
    let nameEl = document.getElementById('inputPartitionName');
    if (!validatePlnameEl(nameEl)) {
        formOK = false;
    }
    
    if (formOK === true) {
        sendAPI("MPD_API_PARTITION_NEW", {
            "name": nameEl.value
            }, showListPartitions, false);
    }
}

//eslint-disable-next-line no-unused-vars
function showNewPartition() {
    document.getElementById('listPartitions').classList.remove('active');
    document.getElementById('newPartition').classList.add('active');
    document.getElementById('listPartitionsFooter').classList.add('hide');
    document.getElementById('newPartitionFooter').classList.remove('hide');
    
    const nameEl = document.getElementById('inputPartitionName');
    nameEl.classList.remove('is-invalid');
    nameEl.value = '';
    nameEl.focus();
}

function showListPartitions() {
    document.getElementById('listPartitions').classList.add('active');
    document.getElementById('newPartition').classList.remove('active');
    document.getElementById('listPartitionsFooter').classList.remove('hide');
    document.getElementById('newPartitionFooter').classList.add('hide');
    document.getElementById('errorPartition').classList.add('hide');
    sendAPI("MPD_API_PARTITION_LIST", {}, parsePartitionList, false);
}

function deletePartition(partition) {
    sendAPI("MPD_API_PARTITION_RM", {"name": partition}, function(obj) {
        if (obj.error) {
            let el = document.getElementById('errorPartition');
            el.innerText = t(obj.error.message);
            el.classList.remove('hide');
        }
        sendAPI("MPD_API_PARTITION_LIST", {}, parsePartitionList, false);
    }, true);
}

function switchPartition(partition) {
    sendAPI("MPD_API_PARTITION_SWITCH", {"name": partition}, function(obj) {
        if (obj.error) {
            let el = document.getElementById('errorPartition');
            el.innerText = t(obj.error.message);
            el.classList.remove('hide');
        }
        sendAPI("MPD_API_PARTITION_LIST", {}, parsePartitionList, false);
        sendAPI("MPD_API_PLAYER_STATE", {}, parseState);
    }, true);
}

function parsePartitionList(obj) {
    if (obj.result.data.length > 0) {
        let partitionList = '';
        for (let i = 0; i < obj.result.data.length; i++) {
            partitionList += '<tr data-partition="' + encodeURI(obj.result.data[i].name) + '"><td class="' +
                (obj.result.data[i].name === settings.partition ? 'font-weight-bold' : '') +
                '">' + e(obj.result.data[i].name) + 
                (obj.result.data[i].name === settings.partition ? '&nbsp;(' + t('current') + ')' : '') +
                '</td>' +
                '<td data-col="Action">' +
                (obj.result.data[i].name === 'default' || obj.result.data[i].name === settings.partition  ? '' : 
                    '<a href="#" title="' + t('Delete') + '" data-action="delete" class="material-icons color-darkgrey">delete</a>') +
                (obj.result.data[i].name !== settings.partition ? '<a href="#" title="' + t('Switch to') + '" data-action="switch" class="material-icons color-darkgrey">check_circle</a>' : '') +
                '</td></tr>';
        }
        document.getElementById('listPartitionsList').innerHTML = partitionList;
    }
    else {
        document.getElementById('listPartitionsList').innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="2">' + t('Empty list') + '</td></tr>';
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function parsePlaylists(obj) {
    if (app.current.view === 'All') {
        document.getElementById('BrowsePlaylistsAllList').classList.remove('hide');
        document.getElementById('BrowsePlaylistsDetailList').classList.add('hide');
        document.getElementById('btnBrowsePlaylistsAll').parentNode.classList.add('hide');
        document.getElementById('playlistContentBtns').classList.add('hide');
        document.getElementById('smartPlaylistContentBtns').classList.add('hide');
        document.getElementById('btnAddSmartpls').parentNode.classList.remove('hide');
        document.getElementById('BrowseNavPlaylists').parentNode.classList.remove('hide');
    } else {
        if (obj.result.uri.indexOf('.') > -1 || obj.result.smartpls === true) {
            document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-ro', 'true')
            document.getElementById('playlistContentBtns').classList.add('hide');
            document.getElementById('smartPlaylistContentBtns').classList.remove('hide');
        }
        else {
            document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-ro', 'false');
            document.getElementById('playlistContentBtns').classList.remove('hide');
            document.getElementById('smartPlaylistContentBtns').classList.add('hide');
        }
        document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-uri', obj.result.uri);
        document.getElementById('BrowsePlaylistsDetailList').getElementsByTagName('caption')[0].innerHTML = 
            (obj.result.smartpls === true ? t('Smart playlist') : t('Playlist'))  + ': ' + obj.result.uri;
        document.getElementById('BrowsePlaylistsDetailList').classList.remove('hide');
        document.getElementById('BrowsePlaylistsAllList').classList.add('hide');
        document.getElementById('btnBrowsePlaylistsAll').parentNode.classList.remove('hide');
        document.getElementById('btnAddSmartpls').parentNode.classList.add('hide');
        document.getElementById('BrowseNavPlaylists').parentNode.classList.add('hide');
    }
            
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById(app.current.app + app.current.tab + app.current.view + 'List');
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    if (app.current.view === 'All') {
        for (let i = 0; i < nrItems; i++) {
            let uri = encodeURI(obj.result.data[i].uri);
            let row = document.createElement('tr');
            row.setAttribute('data-uri', uri);
            row.setAttribute('data-type', obj.result.data[i].Type);
            row.setAttribute('data-name', obj.result.data[i].name);
            row.setAttribute('tabindex', 0);
            row.innerHTML = '<td data-col="Type"><span class="material-icons">' + (obj.result.data[i].Type === 'smartpls' ? 'queue_music' : 'list') + '</span></td>' +
                            '<td>' + e(obj.result.data[i].name) + '</td>' +
                            '<td>'+ localeDate(obj.result.data[i].last_modified) + '</td>' +
                            '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
            if (i < tr.length) {
                activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
            }
            else {
                tbody.append(row);
            }
        }
        //document.getElementById('cardFooterBrowse').innerText = gtPage('Num playlists', obj.result.returnedEntities, obj.result.totalEntities);
    }
    else if (app.current.view === 'Detail') {
        for (let i = 0; i < nrItems; i++) {
            let uri = encodeURI(obj.result.data[i].uri);
            let row = document.createElement('tr');
            if (obj.result.smartpls === false) {
                row.setAttribute('draggable','true');
            }
            row.setAttribute('id','playlistTrackId' + obj.result.data[i].Pos);
            row.setAttribute('data-type', obj.result.data[i].Type);
            row.setAttribute('data-uri', uri);
            row.setAttribute('data-name', obj.result.data[i].Title);
            row.setAttribute('data-songpos', obj.result.data[i].Pos);
            row.setAttribute('tabindex', 0);
            obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
            let tds = '';
            for (let c = 0; c < settings.colsBrowsePlaylistsDetail.length; c++) {
                tds += '<td data-col="' + settings.colsBrowsePlaylistsDetail[c] + '">' + e(obj.result.data[i][settings.colsBrowsePlaylistsDetail[c]]) + '</td>';
            }
            tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
            row.innerHTML = tds;

            if (i < tr.length) {
                activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
            }
            else {
                tbody.append(row);
            }
        }
        //document.getElementById('cardFooterBrowse').innerText = gtPage('Num songs', obj.result.returnedEntities, obj.result.totalEntities);
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

    if (navigate === true) {
        focusTable(0);
    }

    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
    
    if (nrItems === 0) {
        if (app.current.view === 'All') {
            tbody.innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
                              '<td colspan="3">' + t('No playlists found') + '</td></tr>';
        }
        else {
            tbody.innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
                              '<td colspan="' + settings.colsBrowsePlaylistsDetail.length + '">' + t('Empty playlist') + '</td></tr>';
        }
    }
            
    document.getElementById(app.current.app + app.current.tab + app.current.view + 'List').classList.remove('opacity05');
}

//eslint-disable-next-line no-unused-vars
function playlistDetails(uri) {
    document.getElementById('BrowsePlaylistsAllList').classList.add('opacity05');
    appGoto('Browse', 'Playlists', 'Detail', '0/-/-/-/' + uri);
}

//eslint-disable-next-line no-unused-vars
function playlistClear() {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPD_API_PLAYLIST_CLEAR", {"uri": uri});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function playlistShuffle() {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPD_API_PLAYLIST_SHUFFLE", {"uri": uri});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function playlistSort(tag) {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPD_API_PLAYLIST_SORT", {"uri": uri, "tag": tag});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

function getAllPlaylists(obj, playlistSelect, playlistValue) {
    let nrItems = obj.result.returnedEntities;
    let playlists = '';
    if (playlistSelect === 'addToPlaylistPlaylist') {
        playlists = '<option value=""></option><option value="new">' + t('New playlist') + '</option>';
    }
    else if (playlistSelect === 'selectJukeboxPlaylist' || 
             playlistSelect === 'selectAddToQueuePlaylist' ||
             playlistSelect === 'selectTimerPlaylist') 
    {
        playlists = '<option value="Database">' + t('Database') + '</option>';
    }

    for (let i = 0; i < nrItems; i++) {
        if (playlistSelect === 'addToPlaylistPlaylist' && obj.result.data[i].Type === 'smartpls') {
            continue;
        }
        playlists += '<option value="' + e(obj.result.data[i].uri) + '"';
        if (playlistValue !== null && obj.result.data[i].uri === playlistValue) {
            playlists += ' selected';
        }
        playlists += '>' + e(obj.result.data[i].uri) + '</option>';
    }
    
    document.getElementById(playlistSelect).innerHTML = playlists;
}

//eslint-disable-next-line no-unused-vars
function updateSmartPlaylists(force) {
    sendAPI("MPDWORKER_API_SMARTPLS_UPDATE_ALL", {"force":force});
}

//eslint-disable-next-line no-unused-vars
function removeFromPlaylist(uri, pos) {
    pos--;
    sendAPI("MPD_API_PLAYLIST_RM_TRACK", {"uri": uri, "track": pos});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function toggleAddToPlaylistFrm() {
    let btn = document.getElementById('toggleAddToPlaylistBtn');
    toggleBtn('toggleAddToPlaylistBtn');
    if (btn.classList.contains('active')) {
        document.getElementById('addToPlaylistFrm').classList.remove('hide');
        document.getElementById('addStreamFooter').classList.add('hide');
        document.getElementById('addToPlaylistFooter').classList.remove('hide');
    }    
    else {
        document.getElementById('addToPlaylistFrm').classList.add('hide');
        document.getElementById('addStreamFooter').classList.remove('hide');
        document.getElementById('addToPlaylistFooter').classList.add('hide');
    }
}

function parseSmartPlaylist(obj) {
    let nameEl = document.getElementById('saveSmartPlaylistName');
    nameEl.value = obj.result.playlist;
    nameEl.classList.remove('is-invalid');
    document.getElementById('saveSmartPlaylistType').value = t(obj.result.type);
    document.getElementById('saveSmartPlaylistType').setAttribute('data-value', obj.result.type);
    document.getElementById('saveSmartPlaylistSearch').classList.add('hide');
    document.getElementById('saveSmartPlaylistSticker').classList.add('hide');
    document.getElementById('saveSmartPlaylistNewest').classList.add('hide');
    let tagList;
    if (settings.featTags) {
        tagList = '<option value="any">' + t('Any Tag') + '</option>';
    }
    tagList += '<option value="filename">' + t('Filename') + '</option>';
    for (let i = 0; i < settings.searchtags.length; i++) {
        tagList += '<option value="' + settings.searchtags[i] + '">' + t(settings.searchtags[i]) + '</option>';
    }
    let elSelectSaveSmartPlaylistTag = document.getElementById('selectSaveSmartPlaylistTag');
    elSelectSaveSmartPlaylistTag.innerHTML = tagList;
    if (obj.result.type === 'search') {
        document.getElementById('saveSmartPlaylistSearch').classList.remove('hide');
        document.getElementById('selectSaveSmartPlaylistTag').value = obj.result.tag;
        document.getElementById('inputSaveSmartPlaylistSearchstr').value = obj.result.searchstr;
        if (settings.featAdvsearch === true && obj.result.tag === 'expression') {
            elSelectSaveSmartPlaylistTag.parentNode.parentNode.classList.add('hide');
            elSelectSaveSmartPlaylistTag.innerHTML = '<option value="expression">expression</option>';
            elSelectSaveSmartPlaylistTag.value = 'expression';
        }
        else {
            document.getElementById('selectSaveSmartPlaylistTag').parentNode.parentNode.classList.remove('hide');
        }
    }
    else if (obj.result.type === 'sticker') {
        document.getElementById('saveSmartPlaylistSticker').classList.remove('hide');
        document.getElementById('selectSaveSmartPlaylistSticker').value = obj.result.sticker;
        document.getElementById('inputSaveSmartPlaylistStickerMaxentries').value = obj.result.maxentries;
        document.getElementById('inputSaveSmartPlaylistStickerMinvalue').value = obj.result.minvalue;
    }
    else if (obj.result.type === 'newest') {
        document.getElementById('saveSmartPlaylistNewest').classList.remove('hide');
        let timerange = obj.result.timerange / 24 / 60 / 60;
        document.getElementById('inputSaveSmartPlaylistNewestTimerange').value = timerange;
    }
    modalSaveSmartPlaylist.show();
    nameEl.focus();
}

//eslint-disable-next-line no-unused-vars
function saveSmartPlaylist() {
    let name = document.getElementById('saveSmartPlaylistName').value;
    let type = document.getElementById('saveSmartPlaylistType').getAttribute('data-value');
    let sortEl = document.getElementById('saveSmartPlaylistSort');
    let sort = sortEl.options[sortEl.selectedIndex].value;
    if (validatePlname(name) === true) {
        if (type === 'search') {
            let tagEl = document.getElementById('selectSaveSmartPlaylistTag');
            let tag = tagEl.options[tagEl.selectedIndex].value;
            let searchstr = document.getElementById('inputSaveSmartPlaylistSearchstr').value;
            sendAPI("MPD_API_SMARTPLS_SAVE", {"type": type, "playlist": name, "tag": tag, "searchstr": searchstr, "sort": sort});
        }
        else if (type === 'sticker') {
            let stickerEl = document.getElementById('selectSaveSmartPlaylistSticker');
            let sticker = stickerEl.options[stickerEl.selectedIndex].value;
            let maxentriesEl = document.getElementById('inputSaveSmartPlaylistStickerMaxentries');
            if (!validateInt(maxentriesEl)) {
                return;
            }
            let minvalueEl = document.getElementById('inputSaveSmartPlaylistStickerMinvalue');
            if (!validateInt(minvalueEl)) {
                return;
            }
            sendAPI("MPD_API_SMARTPLS_SAVE", {"type": type, "playlist": name, "sticker": sticker, "maxentries": parseInt(maxentriesEl.value), 
                "minvalue": parseInt(minvalueEl.value), "sort": sort});
        }
        else if (type === 'newest') {
            let timerangeEl = document.getElementById('inputSaveSmartPlaylistNewestTimerange');
            if (!validateInt(timerangeEl)) {
                return;
            }
            let timerange = parseInt(timerangeEl.value) * 60 * 60 * 24;
            sendAPI("MPD_API_SMARTPLS_SAVE", {"type": type, "playlist": name, "timerange": timerange, "sort": sort});
        }
        else {
            document.getElementById('saveSmartPlaylistType').classList.add('is-invalid');
            return;
        }
        modalSaveSmartPlaylist.hide();
        showNotification(t('Saved smart playlist %{name}', {"name": name}), '', '', 'success');
    }
    else {
        document.getElementById('saveSmartPlaylistName').classList.add('is-invalid');
    }
}

//eslint-disable-next-line no-unused-vars
function addSmartpls(type) {
    let obj = {"jsonrpc":"2.0", "id":0, "result": {"method":"MPD_API_SMARTPLS_GET"}};
    if (type === 'mostPlayed') {
        obj.result.playlist = settings.smartplsPrefix + (settings.smartplsPrefix !== '' ? '-' : '') + 'mostPlayed';
        obj.result.type = 'sticker';
        obj.result.sticker = 'playCount';
        obj.result.maxentries = 200;
        obj.result.minvalue = 10;
    }
    else if (type === 'newest') {
        obj.result.playlist = settings.smartplsPrefix + (settings.smartplsPrefix !== '' ? '-' : '') + 'newestSongs';
        obj.result.type = 'newest';
        obj.result.timerange = 14 * 24 * 60 * 60;
    }
    else if (type === 'bestRated') {
        obj.result.playlist = settings.smartplsPrefix + (settings.smartplsPrefix !== '' ? '-' : '') + 'bestRated';
        obj.result.type = 'sticker';
        obj.result.sticker = 'like';
        obj.result.maxentries = 200;
        obj.result.minvalue = 2;
    }
    parseSmartPlaylist(obj);
}

//eslint-disable-next-line no-unused-vars
function deletePlaylists() {
    let selectDeletePlaylists = document.getElementById('selectDeletePlaylists');
    let btnDeletePlaylists = document.getElementById('btnDeletePlaylists');
    btnWaiting(btnDeletePlaylists, true);
    sendAPI("MPD_API_PLAYLIST_RM_ALL", {"type": selectDeletePlaylists.options[selectDeletePlaylists.selectedIndex].value}, function() {
        btnWaiting(btnDeletePlaylists, false);
    });
}

//eslint-disable-next-line no-unused-vars
function showAddToPlaylistCurrentSong() {
    let uri = document.getElementById('currentTitle').getAttribute('data-uri');
    if (uri !== '') {
        showAddToPlaylist(uri, '');
    }
}

function showAddToPlaylist(uri, searchstr) {
    document.getElementById('addToPlaylistUri').value = uri;
    document.getElementById('addToPlaylistSearch').value = searchstr;
    document.getElementById('addToPlaylistPlaylist').innerHTML = '';
    document.getElementById('addToPlaylistNewPlaylist').value = '';
    document.getElementById('addToPlaylistNewPlaylistDiv').classList.add('hide');
    document.getElementById('addToPlaylistNewPlaylist').classList.remove('is-invalid');
    toggleBtn('toggleAddToPlaylistBtn',0);
    let streamUrl = document.getElementById('streamUrl')
    streamUrl.focus();
    streamUrl.value = '';
    streamUrl.classList.remove('is-invalid');
    if (uri !== 'stream') {
        document.getElementById('addStreamFooter').classList.add('hide');
        document.getElementById('addStreamFrm').classList.add('hide');
        document.getElementById('addToPlaylistFooter').classList.remove('hide');
        document.getElementById('addToPlaylistFrm').classList.remove('hide');
        document.getElementById('addToPlaylistCaption').innerText = t('Add to playlist');
    }
    else {
        document.getElementById('addStreamFooter').classList.remove('hide');
        document.getElementById('addStreamFrm').classList.remove('hide');
        document.getElementById('addToPlaylistFooter').classList.add('hide');
        document.getElementById('addToPlaylistFrm').classList.add('hide');
        document.getElementById('addToPlaylistCaption').innerText = t('Add stream');
    }
    modalAddToPlaylist.show();
    if (settings.featPlaylists) {
        sendAPI("MPD_API_PLAYLIST_LIST_ALL", {"offset": 0, "filter": "-"}, function(obj) {
            getAllPlaylists(obj, 'addToPlaylistPlaylist');
        });
    }
}

//eslint-disable-next-line no-unused-vars
function addToPlaylist() {
    let uri = decodeURI(document.getElementById('addToPlaylistUri').value);
    if (uri === 'stream') {
        uri = document.getElementById('streamUrl').value;
        if (uri === '' || uri.indexOf('http') === -1) {
            document.getElementById('streamUrl').classList.add('is-invalid');
            return;
        }
    }
    let plistEl = document.getElementById('addToPlaylistPlaylist');
    let plist = plistEl.options[plistEl.selectedIndex].value;
    if (plist === 'new') {
        let newPl = document.getElementById('addToPlaylistNewPlaylist').value;
        if (validatePlname(newPl) === true) {
            plist = newPl;
        } else {
            document.getElementById('addToPlaylistNewPlaylist').classList.add('is-invalid');
            return;
        }
    }
    if (plist !== '') {
        if (uri === 'SEARCH') {
            addAllFromSearchPlist(plist, null, false);
        }
        if (uri === 'ALBUM') {
            let expression = document.getElementById('addToPlaylistSearch').value;
            addAllFromSearchPlist(plist, expression, false);
        }
        else if (uri === 'DATABASE') {
            addAllFromBrowseDatabasePlist(plist);
        }
        else {
            sendAPI("MPD_API_PLAYLIST_ADD_TRACK", {"uri": uri, "plist": plist});
        }
        modalAddToPlaylist.hide();
    }
    else {
        document.getElementById('addToPlaylistPlaylist').classList.add('is-invalid');
    }
}

//eslint-disable-next-line no-unused-vars
function showRenamePlaylist(from) {
    document.getElementById('renamePlaylistTo').classList.remove('is-invalid');
    modalRenamePlaylist.show();
    document.getElementById('renamePlaylistFrom').value = from;
    document.getElementById('renamePlaylistTo').value = '';
}

//eslint-disable-next-line no-unused-vars
function renamePlaylist() {
    let from = document.getElementById('renamePlaylistFrom').value;
    let to = document.getElementById('renamePlaylistTo').value;
    if (to !== from && validatePlname(to) === true) {
        sendAPI("MPD_API_PLAYLIST_RENAME", {"from": from, "to": to});
        modalRenamePlaylist.hide();
    }
    else {
        document.getElementById('renamePlaylistTo').classList.add('is-invalid');
    }
}

//eslint-disable-next-line no-unused-vars
function showSmartPlaylist(playlist) {
    sendAPI("MPD_API_SMARTPLS_GET", {"playlist": playlist}, parseSmartPlaylist);
}

//eslint-disable-next-line no-unused-vars
function updateSmartPlaylist(playlist) {
    sendAPI("MPDWORKER_API_SMARTPLS_UPDATE", {"playlist": playlist});
}

//eslint-disable-next-line no-unused-vars
function updateSmartPlaylistClick() {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPDWORKER_API_SMARTPLS_UPDATE", {"playlist": uri});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function showDelPlaylist(uri) {
    document.getElementById('deletePlaylist').value = uri;
    modalDeletePlaylist.show();
}

//eslint-disable-next-line no-unused-vars
function delPlaylist() {
    let uri = document.getElementById('deletePlaylist').value;
    sendAPI("MPD_API_PLAYLIST_RM", {"uri": uri});
    modalDeletePlaylist.hide();
}

function playlistMoveTrack(from, to) {
    sendAPI("MPD_API_PLAYLIST_MOVE_TRACK", {"plist": app.current.search, "from": from, "to": to});
}

//eslint-disable-next-line no-unused-vars
function addSelectedItemToPlaylist() {
    let item = document.activeElement;
    if (item) {
        if (item.parentNode.parentNode.id === 'BrowsePlaylistsAllList') {
            return;
        }
        showAddToPlaylist(item.getAttribute('data-uri'), '');
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function b64EncodeUnicode(str) {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
        function toSolidBytes(match, p1) {
            return String.fromCharCode('0x' + p1);
    }));
}

function b64DecodeUnicode(str) {
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
}

function addMenuItem(href, text) {
    return '<a class="dropdown-item" href="#" data-href=\'' + b64EncodeUnicode(JSON.stringify(href)) + '\'>' + text +'</a>';
}

function hideMenu() {
    let menuEl = document.querySelector('[data-popover]');
    if (menuEl) {
        let m = new BSN.Popover(menuEl, {});
        m.hide();
        menuEl.removeAttribute('data-popover');
        if (menuEl.parentNode.parentNode.classList.contains('selected')) {
            focusTable(undefined, menuEl.parentNode.parentNode.parentNode.parentNode);
        }
        else if (app.current.app === 'Browse' && app.current.tab === 'Database') {
            focusTable(undefined, menuEl.parentNode.parentNode.parentNode.parentNode);
        }
    }
}

function showMenu(el, event) {
    event.preventDefault();
    event.stopPropagation();
    hideMenu();
    //if (el.getAttribute('data-init')) {
    //    return;
    //}
    if (el.parentNode.nodeName === 'TH') {
        showMenuTh(el);
    }
    else {
        showMenuTd(el);
    }
}

function showMenuTh(el) {
    let table = app.current.app + (app.current.tab !== undefined ? app.current.tab : '') + (app.current.view !== undefined ? app.current.view : '');
    let menu = '<form class="p-2" id="colChecklist' + table + '">';
    menu += setColsChecklist(table);
    menu += '<button class="btn btn-success btn-block btn-sm mt-2">' + t('Apply') + '</button>';
    menu += '</form>';
    new BSN.Popover(el, { trigger: 'click', delay: 0, dismissible: true, template: '<div class="popover" role="tooltip">' +
        '<div class="arrow"></div>' +
        '<div class="popover-content" id="' + table + 'ColsDropdown' + '">' + menu + '</div>' +
        '</div>', content: ' '});
    let popoverInit = el.Popover;
    if (el.getAttribute('data-init') === null) {
        el.setAttribute('data-init', 'true');
        el.addEventListener('shown.bs.popover', function(event) {
            event.target.setAttribute('data-popover', 'true');
            document.getElementById('colChecklist' + table).addEventListener('click', function(eventClick) {
                if (eventClick.target.nodeName === 'BUTTON' && eventClick.target.classList.contains('material-icons')) {
                    toggleBtnChk(eventClick.target);
                    eventClick.preventDefault();
                    eventClick.stopPropagation();
                }
                else if (eventClick.target.nodeName === 'BUTTON') {
                    eventClick.preventDefault();
                    saveCols(table);
                }
            }, false);
        }, false);
    }
    popoverInit.show();
}

function showMenuTd(el) {
    let type = el.getAttribute('data-type');
    let uri = decodeURI(el.getAttribute('data-uri'));
    let name = decodeURI(el.getAttribute('data-name'));
    let nextsongpos = 0;
    if (type === null || uri === '') {
        type = el.parentNode.getAttribute('data-type');
        uri = decodeURI(el.parentNode.getAttribute('data-uri'));
        name = el.parentNode.getAttribute('data-name');
    }
    if (type === null || uri === '') {
        type = el.parentNode.parentNode.getAttribute('data-type');
        uri = decodeURI(el.parentNode.parentNode.getAttribute('data-uri'));
        name = el.parentNode.parentNode.getAttribute('data-name');
    }
    
    if (lastState) {
        nextsongpos = lastState.nextSongPos;
    }

    let menu = '';
    if ((app.current.app === 'Browse' && app.current.tab === 'Filesystem') || app.current.app === 'Search' ||
        (app.current.app === 'Browse' && app.current.tab === 'Database')) {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            (type === 'song' ? addMenuItem({"cmd": "appendAfterQueue", "options": [type, uri, nextsongpos, name]}, t('Add after current playing song')) : '') +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (type !== 'plist' && type !== 'smartpls' && settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [uri, ""]}, t('Add to playlist')) : '') +
            (type === 'song' ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '') +
            (type === 'plist' || type === 'smartpls' ? addMenuItem({"cmd": "playlistDetails", "options": [uri]}, t('View playlist')) : '') +
            (type === 'dir' && settings.featBookmarks ? addMenuItem({"cmd": "showBookmarkSave", "options": [-1, name, uri, type]}, t('Add bookmark')) : '');
        if (app.current.tab === 'Filesystem') {
            menu += (type === 'dir' ? addMenuItem({"cmd": "updateDB", "options": [dirname(uri), true]}, t('Update directory')) : '') +
                (type === 'dir' ? addMenuItem({"cmd": "rescanDB", "options": [dirname(uri), true]}, t('Rescan directory')) : '');
        }
        if (app.current.app === 'Search') {
            //songs must be arragend in one album per folder
            let baseuri = dirname(uri);
            menu += '<div class="dropdown-divider"></div>' +
                '<a class="dropdown-item" id="advancedMenuLink" data-toggle="collapse" href="#advancedMenu"><span class="material-icons material-icons-small-left">keyboard_arrow_right</span>Album actions</a>' +
                '<div class="collapse" id="advancedMenu">' +
                    addMenuItem({"cmd": "appendQueue", "options": [type, baseuri, name]}, t('Append to queue')) +
                    addMenuItem({"cmd": "appendAfterQueue", "options": [type, baseuri, nextsongpos, name]}, t('Add after current playing song')) +
                    addMenuItem({"cmd": "replaceQueue", "options": [type, baseuri, name]}, t('Replace queue')) +
                    (settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [baseuri, ""]}, t('Add to playlist')) : '') +
                '</div>';
        }
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'All') {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (settings.smartpls === true && type === 'smartpls' ? addMenuItem({"cmd": "playlistDetails", "options": [uri]}, t('View playlist')) : addMenuItem({"cmd": "playlistDetails", "options": [uri]}, t('Edit playlist')))+
            (settings.smartpls === true && type === 'smartpls' ? addMenuItem({"cmd": "showSmartPlaylist", "options": [uri]}, t('Edit smart playlist')) : '') +
            (settings.smartpls === true && type === 'smartpls' ? addMenuItem({"cmd": "updateSmartPlaylist", "options": [uri]}, t('Update smart playlist')) : '') +
            addMenuItem({"cmd": "showRenamePlaylist", "options": [uri]}, t('Rename playlist')) + 
            addMenuItem({"cmd": "showDelPlaylist", "options": [uri]}, t('Delete playlist'));
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
        let x = document.getElementById('BrowsePlaylistsDetailList');
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (x.getAttribute('data-ro') === 'false' ? addMenuItem({"cmd": "removeFromPlaylist", "options": [x.getAttribute('data-uri'), 
                    el.parentNode.parentNode.getAttribute('data-songpos')]}, t('Remove')) : '') +
            (settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [uri, ""]}, t('Add to playlist')) : '') +
            (uri.indexOf('http') === -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '');
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'Current') {
        menu += addMenuItem({"cmd": "delQueueSong", "options": ["single", el.parentNode.parentNode.getAttribute('data-trackid')]}, t('Remove')) +
            addMenuItem({"cmd": "delQueueSong", "options": ["range", 0, el.parentNode.parentNode.getAttribute('data-songpos')]}, t('Remove all upwards')) +
            addMenuItem({"cmd": "delQueueSong", "options": ["range", (parseInt(el.parentNode.parentNode.getAttribute('data-songpos'))-1), -1]}, t('Remove all downwards')) +
            (uri.indexOf('http') === -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '');
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [uri, ""]}, t('Add to playlist')) : '') +
            (uri.indexOf('http') === -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '');
    }

    new BSN.Popover(el, { trigger: 'click', delay: 0, dismissible: true, template: '<div class="popover" role="tooltip">' +
        '<div class="arrow"></div>' +
        '<div class="popover-content">' + menu + '</div>' +
        '</div>', content: ' '});
    let popoverInit = el.Popover;
    if (el.getAttribute('data-init') === null) {
        el.setAttribute('data-init', 'true');
        el.addEventListener('shown.bs.popover', function(event) {
            event.target.setAttribute('data-popover', 'true');
            document.getElementsByClassName('popover-content')[0].addEventListener('click', function(eventClick) {
                eventClick.preventDefault();
                eventClick.stopPropagation();
                if (eventClick.target.nodeName === 'A') {
                    let dh = eventClick.target.getAttribute('data-href');
                    if (dh) {
                        let cmd = JSON.parse(b64DecodeUnicode(dh));
                        parseCmd(event, cmd);
                        hideMenu();
                    }
                }
            }, false);
            document.getElementsByClassName('popover-content')[0].addEventListener('keydown', function(eventKey) {
                eventKey.preventDefault();
                eventKey.stopPropagation();
                if (eventKey.key === 'ArrowDown' || eventKey.key === 'ArrowUp') {
                    let menuItemsHtml = this.getElementsByTagName('a');
                    let menuItems = Array.prototype.slice.call(menuItemsHtml);
                    let idx = menuItems.indexOf(document.activeElement);
                    do {
                        idx = eventKey.key === 'ArrowUp' ? (idx > 1 ? idx - 1 : 0)
                                                 : eventKey.key === 'ArrowDown' ? ( idx < menuItems.length - 1 ? idx + 1 : idx)
                                                                            : idx;
                        if ( idx === 0 || idx === menuItems.length -1 ) {
                            break;
                        }
                    } while ( !menuItems[idx].offsetHeight )
                    menuItems[idx] && menuItems[idx].focus();
                }
                else if (eventKey.key === 'Enter') {
                    eventKey.target.click();
                }
                else if (eventKey.key === 'Escape') {
                    hideMenu();
                }
            }, false);
            let collapseLink = document.getElementById('advancedMenuLink');
            if (collapseLink) {
                collapseLink.addEventListener('click', function() {
                    let icon = this.getElementsByTagName('span')[0];
                    if (icon.innerText === 'keyboard_arrow_right') {
                        icon.innerText = 'keyboard_arrow_down';
                    }
                    else {
                        icon.innerText = 'keyboard_arrow_right';
                    }
                }, false);
                new BSN.Collapse(collapseLink);
            }
            document.getElementsByClassName('popover-content')[0].firstChild.focus();
        }, false);
    }
    popoverInit.show();
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function parseUpdateQueue(obj) {
    //Set playstate
    if (obj.result.state === 1) {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].innerText = 'play_arrow';
        }
        playstate = 'stop';
        domCache.progressBar.style.transition = 'none';
        domCache.progressBar.style.width = '0px';
        setTimeout(function() {
            domCache.progressBar.style.transition = progressBarTransition;
        }, 10);
    }
    else if (obj.result.state === 2) {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            if (settings.footerStop === true) {
                domCache.btnsPlay[i].innerText = 'stop';
            }
            else {
                domCache.btnsPlay[i].innerText = 'pause';
            }
        }
        playstate = 'play';
    }
    else {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].innerText = 'play_arrow';
        }
	playstate = 'pause';
    }

    if (obj.result.queueLength === 0) {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].setAttribute('disabled', 'disabled');
        }
    }
    else {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].removeAttribute('disabled');
        }
    }

    mediaSessionSetState();
    mediaSessionSetPositionState(obj.result.totalTime, obj.result.elapsedTime);

    domCache.badgeQueueItems.innerText = obj.result.queueLength;
    
    if (obj.result.nextSongPos === -1 && settings.jukeboxMode === false) {
        domCache.btnNext.setAttribute('disabled', 'disabled');
    }
    else {
        domCache.btnNext.removeAttribute('disabled');
    }
    
    if (obj.result.songPos <= 0) {
        domCache.btnPrev.setAttribute('disabled', 'disabled');
    }
    else {
        domCache.btnPrev.removeAttribute('disabled');
    }
}

function getQueue() {
    if (app.current.search.length >= 2) {
        sendAPI("MPD_API_QUEUE_SEARCH", {"filter": app.current.filter, "offset": app.current.page, "searchstr": app.current.search, "cols": settings.colsQueueCurrent}, parseQueue, false);
    }
    else {
        sendAPI("MPD_API_QUEUE_LIST", {"offset": app.current.page, "cols": settings.colsQueueCurrent}, parseQueue, false);
    }
}

function parseQueue(obj) {
    if (obj.result.offset < app.current.page) {
        gotoPage(obj.result.offset);
        return;
    }

    if (obj.result.totalTime && obj.result.totalTime > 0 && obj.result.totalEntities <= settings.maxElementsPerPage ) {
        //document.getElementById('cardFooterQueue').innerText = t('Num songs', obj.result.totalEntities) + ' – ' + beautifyDuration(obj.result.totalTime);
    }
    else if (obj.result.totalEntities > 0) {
        //document.getElementById('cardFooterQueue').innerText = t('Num songs', obj.result.totalEntities);
    }
    else {
        //document.getElementById('cardFooterQueue').innerText = '';
    }

    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('QueueCurrentList');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    table.setAttribute('data-version', obj.result.queueVersion);
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    for (let i = 0; i < nrItems; i++) {
        obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        obj.result.data[i].Pos++;
        let row = document.createElement('tr');
        row.setAttribute('draggable', 'true');
        row.setAttribute('data-trackid', obj.result.data[i].id);
        row.setAttribute('id','queueTrackId' + obj.result.data[i].id);
        row.setAttribute('data-songpos', obj.result.data[i].Pos);
        row.setAttribute('data-duration', obj.result.data[i].Duration);
        row.setAttribute('data-uri', obj.result.data[i].uri);
        row.setAttribute('tabindex', 0);
        let tds = '';
        for (let c = 0; c < settings.colsQueueCurrent.length; c++) {
            tds += '<td data-col="' + settings.colsQueueCurrent[c] + '">' + e(obj.result.data[i][settings.colsQueueCurrent[c]]) + '</td>';
        }
        tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

    let colspan = settings['colsQueueCurrent'].length;
    colspan--;

    if (obj.result.method === 'MPD_API_QUEUE_SEARCH' && nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t('No results, please refine your search') + '</td></tr>';
    }
    else if (obj.result.method === 'MPD_API_QUEUE_ADD_TRACK' && nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t('Empty queue') + '</td></tr>';
    }

    if (navigate === true) {
        focusTable(activeRow);
    }
    
    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
    document.getElementById('QueueCurrentList').classList.remove('opacity05');
}

function parseLastPlayed(obj) {
    //document.getElementById('cardFooterQueue').innerText = t('Num songs', obj.result.totalEntities);
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('QueueLastPlayedList');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    for (let i = 0; i < nrItems; i++) {
        obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        obj.result.data[i].LastPlayed = localeDate(obj.result.data[i].LastPlayed);
        let row = document.createElement('tr');
        row.setAttribute('data-uri', obj.result.data[i].uri);
        row.setAttribute('data-name', obj.result.data[i].Title);
        row.setAttribute('data-type', 'song');
        row.setAttribute('tabindex', 0);
        let tds = '';
        for (let c = 0; c < settings.colsQueueLastPlayed.length; c++) {
            tds += '<td data-col="' + settings.colsQueueLastPlayed[c] + '">' + e(obj.result.data[i][settings.colsQueueLastPlayed[c]]) + '</td>';
        }
        tds += '<td data-col="Action">';
        if (obj.result.data[i].uri !== '') {
            tds += '<a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a>';
        }
        tds += '</td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }                    

    let colspan = settings['colsQueueLastPlayed'].length;
    colspan--;
    
    if (nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="' + colspan + '">' + t('Empty list') + '</td></tr>';
    }

    if (navigate === true) {
        focusTable(activeRow);
    }

    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
    document.getElementById('QueueLastPlayedList').classList.remove('opacity05');
}

//eslint-disable-next-line no-unused-vars
function queueSelectedItem(append) {
    let item = document.activeElement;
    if (item) {
        if (item.parentNode.parentNode.id === 'QueueCurrentList') {
            return;
        }
        if (append === true) {
            appendQueue(item.getAttribute('data-type'), item.getAttribute('data-uri'), item.getAttribute('data-name'));
        }
        else {
            replaceQueue(item.getAttribute('data-type'), item.getAttribute('data-uri'), item.getAttribute('data-name'));
        }
    }
}

//eslint-disable-next-line no-unused-vars
function dequeueSelectedItem() {
    let item = document.activeElement;
    if (item) {
        if (item.parentNode.parentNode.id !== 'QueueCurrentList') {
            return;
        }
        delQueueSong('single', item.getAttribute('data-trackid'));
    }
}

function appendQueue(type, uri, name) {
    switch(type) {
        case 'song':
        case 'dir':
            sendAPI("MPD_API_QUEUE_ADD_TRACK", {"uri": uri});
            showNotification(t('%{name} added to queue', {"name": name}), '', '', 'success');
            break;
        case 'plist':
            sendAPI("MPD_API_QUEUE_ADD_PLAYLIST", {"plist": uri});
            showNotification(t('%{name} added to queue', {"name": name}), '', '', 'success');
            break;
    }
}

//eslint-disable-next-line no-unused-vars
function appendAfterQueue(type, uri, to, name) {
    switch(type) {
        case 'song':
            sendAPI("MPD_API_QUEUE_ADD_TRACK_AFTER", {"uri": uri, "to": to});
            to++;
            showNotification(t('%{name} added to queue position %{to}', {"name": name, "to": to}), '', '', 'success');
            break;
    }
}

function replaceQueue(type, uri, name) {
    switch(type) {
        case 'song':
        case 'dir':
            sendAPI("MPD_API_QUEUE_REPLACE_TRACK", {"uri": uri});
            showNotification(t('Queue replaced with %{name}', {"name": name}), '', '', 'success');
            break;
        case 'plist':
            sendAPI("MPD_API_QUEUE_REPLACE_PLAYLIST", {"plist": uri});
            showNotification(t('Queue replaced with %{name}', {"name": name}), '', '', 'success');
            break;
    }
}

//eslint-disable-next-line no-unused-vars
function addToQueue() {
    let formOK = true;
    let inputAddToQueueQuantityEl = document.getElementById('inputAddToQueueQuantity');
    if (!validateInt(inputAddToQueueQuantityEl)) {
        formOK = false;
    }
    
    let selectAddToQueueMode = document.getElementById('selectAddToQueueMode');
    let jukeboxMode = selectAddToQueueMode.options[selectAddToQueueMode.selectedIndex].value

    let selectAddToQueuePlaylist = document.getElementById('selectAddToQueuePlaylist');
    let jukeboxPlaylist = selectAddToQueuePlaylist.options[selectAddToQueuePlaylist.selectedIndex].value;
    
    if (jukeboxMode === '1' && settings.featSearchwindow === false && jukeboxPlaylist === 'Database') {
        document.getElementById('warnJukeboxPlaylist2').classList.remove('hide');
        formOK = false;
    }
    
    if (formOK === true) {
        sendAPI("MPD_API_QUEUE_ADD_RANDOM", {
            "mode": jukeboxMode,
            "playlist": jukeboxPlaylist,
            "quantity": document.getElementById('inputAddToQueueQuantity').value
        });
        modalAddToQueue.hide();
    }
}

//eslint-disable-next-line no-unused-vars
function saveQueue() {
    let plName = document.getElementById('saveQueueName').value;
    if (validatePlname(plName) === true) {
        sendAPI("MPD_API_QUEUE_SAVE", {"plist": plName});
        modalSaveQueue.hide();
    }
    else {
        document.getElementById('saveQueueName').classList.add('is-invalid');
    }
}

function delQueueSong(mode, start, end) {
    if (mode === 'range') {
        sendAPI("MPD_API_QUEUE_RM_RANGE", {"start": start, "end": end});
    }
    else if (mode === 'single') {
        sendAPI("MPD_API_QUEUE_RM_TRACK", { "track": start});
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function saveScript() {
    let formOK = true;
    
    let nameEl = document.getElementById('inputScriptName');
    if (!validatePlnameEl(nameEl)) {
        formOK = false;
    }
    
    let orderEl = document.getElementById('inputScriptOrder');
    if (!validateInt(orderEl)) {
        formOK = false;
    }
    
    if (formOK === true) {
        let args = [];
        let argSel = document.getElementById('selectScriptArguments');
        for (let i = 0; i < argSel.options.length; i++) {
            args.push(argSel.options[i].text);
        }
        sendAPI("MYMPD_API_SCRIPT_SAVE", {
            "oldscript": document.getElementById('inputOldScriptName').value,
            "script": nameEl.value,
            "order": parseInt(orderEl.value),
            "content": document.getElementById('textareaScriptContent').value,
            "arguments": args
            }, showListScripts, false);
    }
}

function addScriptArgument() {
    let el = document.getElementById('inputScriptArgument');
    if (validatePlnameEl(el)) {
        let o = document.createElement('option');
        o.text = el.value;
        document.getElementById('selectScriptArguments').appendChild(o);
        el.value = '';
    }
}

function removeScriptArgument(ev) {
    let el = document.getElementById('inputScriptArgument');
    el.value = ev.target.text;
    ev.target.remove();
    el.focus();  
}

//eslint-disable-next-line no-unused-vars
function showEditScript(script) {
    document.getElementById('listScripts').classList.remove('active');
    document.getElementById('editScript').classList.add('active');
    document.getElementById('listScriptsFooter').classList.add('hide');
    document.getElementById('editScriptFooter').classList.remove('hide');
    
    document.getElementById('inputScriptName').classList.remove('is-invalid');
    document.getElementById('inputScriptOrder').classList.remove('is-invalid');
    document.getElementById('inputScriptArgument').classList.remove('is-invalid');
    
    if (script !== '') {
        sendAPI("MYMPD_API_SCRIPT_GET", {"script": script}, parseEditScript, false);
    }
    else {
        document.getElementById('inputOldScriptName').value = '';
        document.getElementById('inputScriptName').value = '';
        document.getElementById('inputScriptOrder').value = '1';
        document.getElementById('inputScriptArgument').value = '';
        document.getElementById('selectScriptArguments').innerText = '';
        document.getElementById('textareaScriptContent').value = '';
    }
}

function parseEditScript(obj) {
    document.getElementById('inputOldScriptName').value = obj.result.script;
    document.getElementById('inputScriptName').value = obj.result.script;
    document.getElementById('inputScriptOrder').value = obj.result.metadata.order;
    document.getElementById('inputScriptArgument').value = '';
    let selSA = document.getElementById('selectScriptArguments');
    selSA.innerText = '';
    for (let i = 0; i < obj.result.metadata.arguments.length; i++) {
        let o = document.createElement('option');
        o.innerText = obj.result.metadata.arguments[i];
        selSA.appendChild(o);
    }
    document.getElementById('textareaScriptContent').value = obj.result.content;
}

function showListScripts() {
    document.getElementById('listScripts').classList.add('active');
    document.getElementById('editScript').classList.remove('active');
    document.getElementById('listScriptsFooter').classList.remove('hide');
    document.getElementById('editScriptFooter').classList.add('hide');
    sendAPI("MYMPD_API_SCRIPT_LIST", {"all": true}, parseScriptList);
}

function deleteScript(script) {
    sendAPI("MYMPD_API_SCRIPT_DELETE", {"script": script}, function() {
        getScriptList(true);
    }, false);
}

function getScriptList(all) {
    sendAPI("MYMPD_API_SCRIPT_LIST", {"all": all}, parseScriptList, false);
}

function parseScriptList(obj) {
    let timerActions = document.createElement('optgroup');
    timerActions.setAttribute('data-value', 'script');
    timerActions.setAttribute('label', t('Script'));
    let scriptMaxListLen = 4;
    let scriptListMain = ''; //list in main menu
    let scriptList = ''; //list in scripts dialog
    let scriptListLen = obj.result.data.length;
    if (scriptListLen > 0) {
        obj.result.data.sort(function(a, b) {
            return a.metadata.order - b.metadata.order;
        });
        let mi = 0;
        for (let i = 0; i < scriptListLen; i++) {
            let arglist = '';
            if (obj.result.data[i].metadata.arguments.length > 0) {
                for (let j = 0; j < obj.result.data[i].metadata.arguments.length; j++) {
                    obj.result.data[i].metadata.arguments[j] = e(obj.result.data[i].metadata.arguments[j]);
                }
                arglist = '"' + obj.result.data[i].metadata.arguments.join('","') + '"';
            }
            if (obj.result.data[i].metadata.order > 0) {
                if (mi === 0) {
                    scriptListMain = scriptListLen > scriptMaxListLen ? '' : '<div class="dropdown-divider"></div>';
                }
                mi++;
                
                scriptListMain += '<a class="dropdown-item text-light alwaysEnabled" href="#" data-href=\'{"script": "' + 
                    e(obj.result.data[i].name) + '", "arguments": [' + arglist + ']}\'>' + e(obj.result.data[i].name) + '</a>';
                
            }
            scriptList += '<tr data-script="' + encodeURI(obj.result.data[i].name) + '"><td>' + e(obj.result.data[i].name) + '</td>' +
                '<td data-col="Action">' +
                    (settings.featScripteditor === true ? 
                        '<a href="#" title="' + t('Delete') + '" data-action="delete" class="material-icons color-darkgrey">delete</a>' : '') +
                    '<a href="#" title="' + t('Execute') + '" data-action="execute" class="material-icons color-darkgrey" ' +
                    ' data-href=\'{"script": "' + e(obj.result.data[i].name) + '", "arguments": [' + arglist + ']}\'>play_arrow</a>' +
                '</td></tr>';
            timerActions.innerHTML += '<option data-arguments=\'{"arguments":[' + arglist + ']}\' value="' + 
                e(obj.result.data[i].name) + '">' + e(obj.result.data[i].name) + '</option>';
        }
        document.getElementById('listScriptsList').innerHTML = scriptList;
    }
    else {
        document.getElementById('listScriptsList').innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="2">' + t('Empty list') + '</td></tr>';
    }
    document.getElementById('scripts').innerHTML = scriptListMain;
        
    if (scriptListLen > scriptMaxListLen) {
        document.getElementById('navScripting').classList.remove('hide');
        document.getElementById('scripts').classList.add('collapse', 'menu-indent');
    }
    else {
        document.getElementById('navScripting').classList.add('hide');
        document.getElementById('scripts').classList.remove('collapse', 'menu-indent');
    }

    document.getElementById('selectTriggerScript').innerHTML = timerActions.innerHTML;
    
    let old = document.getElementById('selectTimerAction').querySelector('optgroup[data-value="script"]');
    if (old) {
        old.replaceWith(timerActions);
    }
    else {
        document.getElementById('selectTimerAction').appendChild(timerActions);
    }
}

function execScript(href) {
    let cmd = JSON.parse(href);
    if (cmd.arguments.length === 0) {
        sendAPI("MYMPD_API_SCRIPT_EXECUTE", {"script": cmd.script, "arguments": {}});
    }
    else {
        let arglist ='';
        for (let i = 0; i < cmd.arguments.length; i++) {
            arglist += '<div class="form-group row">' +
                  '<label class="col-sm-4 col-form-label" for="inputScriptArg' + i + '">' + e(cmd.arguments[i]) +'</label>' +
                  '<div class="col-sm-8">' +
                     '<input name="' + e(cmd.arguments[i]) + '" id="inputScriptArg' + i + '" type="text" class="form-control border-secondary" value="">' +
                  '</div>' +
                '</div>';

        }
        document.getElementById('execScriptArguments').innerHTML = arglist;
        document.getElementById('modalExecScriptScriptname').value = cmd.script;
        modalExecScript.show();
    }
}

//eslint-disable-next-line no-unused-vars
function execScriptArgs() {
    let script = document.getElementById('modalExecScriptScriptname').value;
    let args = {};
    let inputs = document.getElementById('execScriptArguments').getElementsByTagName('input');
    for (let i = 0; i < inputs.length; i++) {
        args[inputs[i].name] = inputs[i].value;
    }
    sendAPI("MYMPD_API_SCRIPT_EXECUTE", {"script": script, "arguments": args});
    modalExecScript.hide();
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function search(x) {
    if (settings.featAdvsearch) {
        let expression = '(';
        let crumbs = domCache.searchCrumb.children;
        for (let i = 0; i < crumbs.length; i++) {
            expression += '(' + decodeURI(crumbs[i].getAttribute('data-filter')) + ')';
            if (x !== '') expression += ' AND ';
        }
        if (x !== '') {
            let match = document.getElementById('searchMatch');
            expression += '(' + app.current.filter + ' ' + match.options[match.selectedIndex].value + ' \'' + x +'\'))';
        }
        else
            expression += ')';
        if (expression.length <= 2)
            expression = '';
        appGoto('Search', undefined, undefined, '0/' + app.current.filter + '/' + app.current.sort + '/-/' + expression);
    }
    else
        appGoto('Search', undefined, undefined, '0/' + app.current.filter + '/' + app.current.sort + '/-/' + x);
}

function parseSearch(obj) {
    //document.getElementById('panel-heading-search').innerText = gtPage('Num songs', obj.result.returnedEntities, obj.result.totalEntities);
    //document.getElementById('cardFooterSearch').innerText = gtPage('Num songs', obj.result.returnedEntities, obj.result.totalEntities);
    
    if (obj.result.returnedEntities > 0) {
        document.getElementById('searchAddAllSongs').removeAttribute('disabled');
        document.getElementById('searchAddAllSongsBtn').removeAttribute('disabled');
    } 
    else {
        document.getElementById('searchAddAllSongs').setAttribute('disabled', 'disabled');
        document.getElementById('searchAddAllSongsBtn').setAttribute('disabled', 'disabled');
    }
    parseFilesystem(obj);
}

function saveSearchAsSmartPlaylist() {
    parseSmartPlaylist({"jsonrpc":"2.0","id":0,"result":{"method":"MPD_API_SMARTPLS_GET", 
        "playlist":"",
        "type":"search",
        "tag": settings.featAdvsearch === true ? 'expression' : app.current.filter,
        "searchstr": app.current.search}});
}

function addAllFromSearchPlist(plist, searchstr, replace) {
    if (searchstr === null) {
        searchstr = app.current.search;    
    }
    if (settings.featAdvsearch) {
        sendAPI("MPD_API_DATABASE_SEARCH_ADV", {"plist": plist, 
            "sort": "", 
            "sortdesc": false, 
            "expression": searchstr,
            "offset": 0, 
            "cols": settings.colsSearch, 
            "replace": replace});
    }
    else {
        sendAPI("MPD_API_DATABASE_SEARCH", {"plist": plist, 
            "filter": app.current.filter, 
            "searchstr": searchstr,
            "offset": 0, 
            "cols": settings.colsSearch, 
            "replace": replace});
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function saveConnection() {
    let formOK = true;
    let mpdHostEl = document.getElementById('inputMpdHost');
    let mpdPortEl = document.getElementById('inputMpdPort');
    let mpdPassEl = document.getElementById('inputMpdPass');
    let musicDirectoryEl  = document.getElementById('selectMusicDirectory');
    let musicDirectory = musicDirectoryEl.options[musicDirectoryEl.selectedIndex].value;
    
    if (musicDirectory === 'custom') {
        let musicDirectoryValueEl  = document.getElementById('inputMusicDirectory');
        if (!validatePath(musicDirectoryValueEl)) {
            formOK = false;        
        }
        musicDirectory = musicDirectoryValueEl.value;
    }    
    
    if (mpdPortEl.value === '') {
        mpdPortEl.value = '6600';
    }
    if (mpdHostEl.value.indexOf('/') !== 0) {
        if (!validateInt(mpdPortEl)) {
            formOK = false;        
        }
        if (!validateHost(mpdHostEl)) {
            formOK = false;        
        }
    }
    if (formOK === true) {
        sendAPI("MYMPD_API_CONNECTION_SAVE", {"mpdHost": mpdHostEl.value, "mpdPort": mpdPortEl.value, "mpdPass": mpdPassEl.value, "musicDirectory": musicDirectory}, getSettings);
        modalConnection.hide();    
    }
}

function getSettings(onerror) {
    if (settingsLock === false) {
        settingsLock = true;
        sendAPI("MYMPD_API_SETTINGS_GET", {}, getMpdSettings, onerror);
    }
}

function getMpdSettings(obj) {
    if (obj !== '' && obj.result) {
        settingsNew = obj.result;
        document.getElementById('splashScreenAlert').innerText = t('Fetch MPD settings');
        sendAPI("MPD_API_SETTINGS_GET", {}, joinSettings, true);
    }
    else {
        settingsParsed = 'error';
        if (appInited === false) {
            showAppInitAlert(obj === '' ? t('Can not parse settings') : t(obj.error.message));
        }
        return false;
    }
}

function joinSettings(obj) {
    if (obj !== '' && obj.result) {
        for (let key in obj.result) {
            settingsNew[key] = obj.result[key];
        }
    }
    else {
        settingsParsed = 'error';
        if (appInited === false) {
            showAppInitAlert(obj === '' ? t('Can not parse settings') : t(obj.error.message));
        }
        settingsNew.mpdConnected = false;
    }
    settings = Object.assign({}, settingsNew);
    settingsLock = false;
    parseSettings();
    toggleUI();
    sendAPI("MPD_API_URLHANDLERS", {}, parseUrlhandlers,false);
    btnWaiting(document.getElementById('btnApplySettings'), false);
}

function parseUrlhandlers(obj) {
    let storagePlugins = '';
    for (let i = 0; i < obj.result.data.length; i++) {
        switch(obj.result.data[i]) {
            case 'http://':
            case 'https://':
            case 'nfs://':
            case 'smb://':
                storagePlugins += '<option value="' + obj.result.data[i] + '">' + obj.result.data[i] + '</option>';
                break;
        }
    }
    document.getElementById('selectMountUrlhandler').innerHTML = storagePlugins;
}

function checkConsume() {
    let stateConsume = document.getElementById('btnConsume').classList.contains('active') ? true : false;
    let stateJukeboxMode = getBtnGroupValue('btnJukeboxModeGroup');
    if (stateJukeboxMode > 0 && stateConsume === false) {
        document.getElementById('warnConsume').classList.remove('hide');
    }
    else {
        document.getElementById('warnConsume').classList.add('hide');
    }
}

function parseSettings() {
    if (settings.locale === 'default') {
        locale = navigator.language || navigator.userLanguage;
    }
    else {
        locale = settings.locale;
    }
    
    if (isMobile === true) {    
        document.getElementById('inputScaleRatio').value = scale;
    }

    let setTheme = settings.theme;
    if (settings.theme === 'theme-autodetect') {
        setTheme = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'theme-dark' : 'theme-default';
    }    

    Object.keys(themes).forEach(function(key) {
        if (key === setTheme) {
            domCache.body.classList.add(key);
        }
        else {
            domCache.body.classList.remove(key);
        }
    });
    
    document.getElementById('selectTheme').value = settings.theme;
    
    if (settings.mpdConnected === true) {
        parseMPDSettings();
    }
    
    if (settings.mpdHost.indexOf('/') !== 0) {
        document.getElementById('mpdInfo_host').innerText = settings.mpdHost + ':' + settings.mpdPort;
    }
    else {
        document.getElementById('mpdInfo_host').innerText = settings.mpdHost;
    }
    
    document.getElementById('inputMpdHost').value = settings.mpdHost;
    document.getElementById('inputMpdPort').value = settings.mpdPort;
    document.getElementById('inputMpdPass').value = settings.mpdPass;

    let btnNotifyWeb = document.getElementById('btnNotifyWeb');
    document.getElementById('warnNotifyWeb').classList.add('hide');
    if (notificationsSupported()) {
        if (Notification.permission !== 'granted') {
            if (settings.notificationWeb === true) {
                document.getElementById('warnNotifyWeb').classList.remove('hide');
            }
            settings.notificationWeb = false;
        }
        if (Notification.permission === 'denied') {
            document.getElementById('warnNotifyWeb').classList.remove('hide');
        }
        toggleBtnChk('btnNotifyWeb', settings.notificationWeb);
        btnNotifyWeb.removeAttribute('disabled');
    }
    else {
        btnNotifyWeb.setAttribute('disabled', 'disabled');
        toggleBtnChk('btnNotifyWeb', false);
    }
    
    toggleBtnChk('btnNotifyPage', settings.notificationPage);
    toggleBtnChk('btnMediaSession', settings.mediaSession);
    toggleBtnChkCollapse('btnFeatLocalplayer', 'collapseLocalplayer', settings.featLocalplayer);
    toggleBtnChk('btnFeatTimer', settings.featTimer);
    toggleBtnChk('btnBookmarks', settings.featBookmarks);
    toggleBtnChk('btnFeatLyrics', settings.featLyrics);

    if (settings.streamUrl === '') {
        document.getElementById('selectStreamMode').value = 'port';
        document.getElementById('inputStreamUrl').value = settings.streamPort;
    }
    else {
        document.getElementById('selectStreamMode').value = 'url';
        document.getElementById('inputStreamUrl').value = settings.streamUrl;
    }
    toggleBtnChkCollapse('btnCoverimage', 'collapseAlbumart', settings.coverimage);

    document.getElementById('inputBookletName').value = settings.bookletName;
    
    document.getElementById('selectLocale').value = settings.locale;
    document.getElementById('inputCoverimageName').value = settings.coverimageName;

    document.getElementById('inputCoverimageSize').value = settings.coverimageSize;
    document.getElementById('inputCoverimageSizeSmall').value = settings.coverimageSizeSmall;

    document.documentElement.style.setProperty('--mympd-coverimagesize', settings.coverimageSize + "px");
    document.documentElement.style.setProperty('--mympd-coverimagesizesmall', settings.coverimageSizeSmall + "px");
    document.documentElement.style.setProperty('--mympd-highlightcolor', settings.highlightColor);
    
    document.getElementById('inputHighlightColor').value = settings.highlightColor;
    document.getElementById('inputBgColor').value = settings.bgColor;
    document.getElementsByTagName('body')[0].style.backgroundColor = settings.bgColor;
    
    document.getElementById('highlightColorPreview').style.backgroundColor = settings.highlightColor;
    document.getElementById('bgColorPreview').style.backgroundColor = settings.bgColor;

    toggleBtnChkCollapse('btnBgCover', 'collapseBackground', settings.bgCover);
    document.getElementById('inputBgCssFilter').value = settings.bgCssFilter;    

    let albumartbg = document.querySelectorAll('.albumartbg');
    for (let i = 0; i < albumartbg.length; i++) {
	albumartbg[i].style.filter = settings.bgCssFilter;
    }

    toggleBtnChkCollapse('btnLoveEnable', 'collapseLove', settings.love);
    document.getElementById('inputLoveChannel').value = settings.loveChannel;
    document.getElementById('inputLoveMessage').value = settings.loveMessage;
    
    document.getElementById('inputMaxElementsPerPage').value = settings.maxElementsPerPage;
    toggleBtnChk('btnStickers', settings.stickers);
    document.getElementById('inputLastPlayedCount').value = settings.lastPlayedCount;
    
    toggleBtnChkCollapse('btnSmartpls', 'collapseSmartpls', settings.smartpls);
    
    let features = ["featLocalplayer", "featSyscmds", "featMixramp", "featCacert", "featBookmarks", 
        "featRegex", "featTimer", "featLyrics", "featScripting", "featScripteditor"];
    for (let j = 0; j < features.length; j++) {
        let Els = document.getElementsByClassName(features[j]);
        let ElsLen = Els.length;
        let displayEl = settings[features[j]] === true ? '' : 'none';
        for (let i = 0; i < ElsLen; i++) {
            Els[i].style.display = displayEl;
        }
    }
    
    let readonlyEls = document.getElementsByClassName('warnReadonly');
    for (let i = 0; i < readonlyEls.length; i++) {
        if (settings.readonly === false) {
            readonlyEls[i].classList.add('hide');
        }
        else {
            readonlyEls[i].classList.remove('hide');
        }
    }
    if (settings.readonly === true) {
        document.getElementById('btnBookmarks').setAttribute('disabled', 'disabled');
        document.getElementsByClassName('groupClearCovercache')[0].classList.add('hide');
    }
    else {
        document.getElementById('btnBookmarks').removeAttribute('disabled');
        document.getElementsByClassName('groupClearCovercache')[0].classList.remove('hide');
    }
    
    let timerActions = '<optgroup data-value="player" label="' + t('Playback') + '">' +
        '<option value="startplay">' + t('Start playback') + '</option>' +
        '<option value="stopplay">' + t('Stop playback') + '</option>' +
        '</optgroup>';

    if (settings.featSyscmds === true) {
        let syscmdsMaxListLen = 4;
        let syscmdsList = '';
        let syscmdsListLen = settings.syscmdList.length;
        if (syscmdsListLen > 0) {
            timerActions += '<optgroup data-value="syscmd" label="' + t('System command') + '">';
            syscmdsList = syscmdsListLen > syscmdsMaxListLen ? '' : '<div class="dropdown-divider"></div>';
            for (let i = 0; i < syscmdsListLen; i++) {
                if (settings.syscmdList[i] === 'HR') {
                    syscmdsList += '<div class="dropdown-divider"></div>';
                }
                else {
                    syscmdsList += '<a class="dropdown-item text-light alwaysEnabled" href="#" data-href=\'{"cmd": "execSyscmd", "options": ["' + 
                        e(settings.syscmdList[i]) + '"]}\'>' + e(settings.syscmdList[i]) + '</a>';
                    timerActions += '<option value="' + e(settings.syscmdList[i]) + '">' + e(settings.syscmdList[i]) + '</option>';
                }
            }
        }
        document.getElementById('syscmds').innerHTML = syscmdsList;
        timerActions += '</optgroup>';
        
        if (syscmdsListLen > syscmdsMaxListLen) {
            document.getElementById('navSyscmds').classList.remove('hide');
            document.getElementById('syscmds').classList.add('collapse', 'menu-indent');
        }
        else {
            document.getElementById('navSyscmds').classList.add('hide');
            document.getElementById('syscmds').classList.remove('collapse', 'menu-indent');
        }
    }
    else {
        document.getElementById('syscmds').innerHTML = '';
    }

    if (settings.featScripting === true) {
        getScriptList(true);
    }
    else {
        document.getElementById('scripts').innerHTML = '';
    }

    document.getElementById('selectTimerAction').innerHTML = timerActions;
    
    //dropdownMainMenu = new BSN.Dropdown(document.getElementById('mainMenu'));
    
    toggleBtnGroupValueCollapse(document.getElementById('btnJukeboxModeGroup'), 'collapseJukeboxMode', settings.jukeboxMode);
    document.getElementById('selectJukeboxUniqueTag').value = settings.jukeboxUniqueTag;
    document.getElementById('inputJukeboxQueueLength').value = settings.jukeboxQueueLength;
    document.getElementById('inputJukeboxLastPlayed').value = settings.jukeboxLastPlayed;
    
    if (settings.jukeboxMode === 0) {
        document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
        document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
    }
    else if (settings.jukeboxMode === 2) {
        document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
        document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
        document.getElementById('selectJukeboxPlaylist').value = 'Database';
    }
    else if (settings.jukeboxMode === 1) {
        document.getElementById('inputJukeboxQueueLength').removeAttribute('disabled');
        document.getElementById('selectJukeboxPlaylist').removeAttribute('disabled');
    }

    document.getElementById('inputSmartplsPrefix').value = settings.smartplsPrefix;
    document.getElementById('inputSmartplsInterval').value = settings.smartplsInterval / 60 / 60;
    document.getElementById('selectSmartplsSort').value = settings.smartplsSort;

    if (settings.featLocalplayer === true) {
        setLocalPlayerUrl();
    }
    
    if (settings.musicDirectory === 'auto') {
        document.getElementById('selectMusicDirectory').value = settings.musicDirectory;
        document.getElementById('inputMusicDirectory').value = settings.musicDirectoryValue !== undefined ? settings.musicDirectoryValue : '';
        document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
    }
    else if (settings.musicDirectory === 'none') {
        document.getElementById('selectMusicDirectory').value = settings.musicDirectory;
        document.getElementById('inputMusicDirectory').value = '';
        document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
    }
    else {
        document.getElementById('selectMusicDirectory').value = 'custom';
        document.getElementById('inputMusicDirectory').value = settings.musicDirectoryValue;
        document.getElementById('inputMusicDirectory').removeAttribute('readonly');
    }

    if (app.current.app === 'Queue' && app.current.tab === 'Current') {
        getQueue();
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
        appRoute();
    }
    else if (app.current.app === 'Search') {
        appRoute();
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Filesystem') {
        appRoute();
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
        appRoute();
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Database' && app.current.search !== '') {
        appRoute();
    }

    i18nHtml(document.getElementsByTagName('body')[0]);

    checkConsume();

    if (settings.mediaSession === true && 'mediaSession' in navigator) {
        navigator.mediaSession.setActionHandler('play', clickPlay);
        navigator.mediaSession.setActionHandler('pause', clickPlay);
        navigator.mediaSession.setActionHandler('stop', clickStop);
        navigator.mediaSession.setActionHandler('seekbackward', seekRelativeBackward);
        navigator.mediaSession.setActionHandler('seekforward', seekRelativeForward);
        navigator.mediaSession.setActionHandler('previoustrack', clickPrev);
        navigator.mediaSession.setActionHandler('nexttrack', clickNext);
        
        if (!navigator.mediaSession.setPositionState) {
            logDebug('mediaSession.setPositionState not supported by browser');
        }
    }
    else {
        logDebug('mediaSession not supported by browser');
    }

    settingsParsed = 'true';
}

function parseMPDSettings() {
    toggleBtnChk('btnRandom', settings.random);
    toggleBtnChk('btnConsume', settings.consume);
    toggleBtnChk('btnRepeat', settings.repeat);
    toggleBtnChk('btnAutoPlay', settings.autoPlay);

    toggleBtnGroupValue(document.getElementById('btnSingleGroup'), settings.single);
    toggleBtnGroupValue(document.getElementById('btnReplaygainGroup'), settings.replaygain);

    document.getElementById('partitionName').innerText = settings.partition;
    
    document.getElementById('inputCrossfade').value = settings.crossfade;
    document.getElementById('inputMixrampdb').value = settings.mixrampdb;
    document.getElementById('inputMixrampdelay').value = settings.mixrampdelay;
    
    if (settings.featLibrary === true && settings.publish === true) {
        settings['featBrowse'] = true;    
    }
    else {
        settings['featBrowse'] = false;
    }

    let features = ['featStickers', 'featSmartpls', 'featPlaylists', 'featTags', 'featCoverimage', 'featAdvsearch',
        'featLove', 'featSingleOneshot', 'featBrowse', 'featMounts', 'featNeighbors',
        'featPartitions'];
    for (let j = 0; j < features.length; j++) {
        let Els = document.getElementsByClassName(features[j]);
        let ElsLen = Els.length;
        let displayEl = settings[features[j]] === true ? '' : 'none';
        if (features[j] === 'featCoverimage' && settings.coverimage === false) {
            displayEl = 'none';
        }
        for (let i = 0; i < ElsLen; i++) {
            Els[i].style.display = displayEl;
        }
    }
    
    if (settings.featPlaylists === false && settings.smartpls === true) {
        document.getElementById('warnSmartpls').classList.remove('hide');
    }
    else {
        document.getElementById('warnSmartpls').classList.add('hide');
    }
    
    if (settings.featPlaylists === true && settings.readonly === false) {
        document.getElementById('btnSmartpls').removeAttribute('disabled');
    }
    else {
        document.getElementById('btnSmartpls').setAttribute('disabled', 'disabled');
    }

    if (settings.featStickers === false && settings.stickers === true) {
        document.getElementById('warnStickers').classList.remove('hide');
    }
    else {
        document.getElementById('warnStickers').classList.add('hide');
    }
    
    if (settings.featStickers === false || settings.stickers === false || settings.featStickerCache === false) {
        document.getElementById('warnPlaybackStatistics').classList.remove('hide');
        document.getElementById('inputJukeboxLastPlayed').setAttribute('disabled', 'disabled');
    }
    else {
        document.getElementById('warnPlaybackStatistics').classList.add('hide');
        document.getElementById('inputJukeboxLastPlayed').removeAttribute('disabled');
    }
    
    if (settings.featLove === false && settings.love === true) {
        document.getElementById('warnScrobbler').classList.remove('hide');
    }
    else {
        document.getElementById('warnScrobbler').classList.add('hide');
    }
    
    if (settings.featLibrary === false && settings.coverimage === true) {
        document.getElementById('warnAlbumart').classList.remove('hide');
    }
    else {
        document.getElementById('warnAlbumart').classList.add('hide');
    }
    if (settings.musicDirectoryValue === '' && settings.musicDirectory !== 'none') {
        document.getElementById('warnMusicDirectory').classList.remove('hide');
    }
    else {
        document.getElementById('warnMusicDirectory').classList.add('hide');
    }

    document.getElementById('warnJukeboxPlaylist').classList.add('hide');

    if (settings.bgCover === true && settings.featCoverimage === true && settings.coverimage === true) {
        setBackgroundImage(lastSongObj.uri);
    }
    else {
        clearBackgroundImage();
    }

    let triggerEventList = '';
    Object.keys(settings.triggers).forEach(function(key) {
        triggerEventList += '<option value="' + e(settings.triggers[key]) + '">' + t(key) + '</option>';
    });
    document.getElementById('selectTriggerEvent').innerHTML = triggerEventList;
    
    settings.tags.sort();
    settings.searchtags.sort();
    settings.browsetags.sort();
    filterCols('colsSearch');
    filterCols('colsQueueCurrent');
    filterCols('colsQueueLastPlayed');
    filterCols('colsBrowsePlaylistsDetail');
    filterCols('colsBrowseFilesystem');
    filterCols('colsBrowseDatabaseDetail');
    filterCols('colsPlayback');
    
    if (settings.featTags === false) {
        app.apps.Browse.active = 'Filesystem';
        app.apps.Search.state = '0/filename/-/-/';
        app.apps.Queue.state = '0/filename/-/-/';
        settings.colsQueueCurrent = ["Pos", "Title", "Duration"];
        settings.colsQueueLastPlayed = ["Pos", "Title", "LastPlayed"];
        settings.colsSearch = ["Title", "Duration"];
        settings.colsBrowseFilesystem = ["Type", "Title", "Duration"];
        settings.colsBrowseDatabase = ["Track", "Title", "Duration"];
        settings.colsPlayback = [];
    }
    else {
        let pbtl = '';
        for (let i = 0; i < settings.colsPlayback.length; i++) {
            pbtl += '<div id="current' + settings.colsPlayback[i]  + '" data-tag="' + settings.colsPlayback[i] + '" ' +
                    (settings.colsPlayback[i] === 'Lyrics' ? '' : 'data-name="' + (lastSongObj[settings.colsPlayback[i]] ? encodeURI(lastSongObj[settings.colsPlayback[i]]) : '') + '"') +
                    '>' +
                    '<small>' + t(settings.colsPlayback[i]) + '</small>' +
                    '<p';
            if (settings.browsetags.includes(settings.colsPlayback[i])) {
                pbtl += ' class="clickable"';
            }
            pbtl += '>';
            if (settings.colsPlayback[i] === 'Duration') {
                pbtl += (lastSongObj[settings.colsPlayback[i]] ? beautifySongDuration(lastSongObj[settings.colsPlayback[i]]) : '');
            }
            else if (settings.colsPlayback[i] === 'LastModified') {
                pbtl += (lastSongObj[settings.colsPlayback[i]] ? localeDate(lastSongObj[settings.colsPlayback[i]]) : '');
            }
            else if (settings.colsPlayback[i] === 'Fileformat') {
                pbtl += (lastState ? fileformat(lastState.audioFormat) : '');
            }
            else {
                pbtl += (lastSongObj[settings.colsPlayback[i]] ? e(lastSongObj[settings.colsPlayback[i]]) : '');
            }
            pbtl += '</p></div>';
        }
        document.getElementById('cardPlaybackTags').innerHTML = pbtl;
        let cl = document.getElementById('currentLyrics');
        if (cl && lastSongObj.uri) {
            let el = cl.getElementsByTagName('small')[0];
            el.classList.add('clickable');
            el.addEventListener('click', function(event) {
                event.target.parentNode.children[1].classList.toggle('expanded');
            }, false);
            getLyrics(lastSongObj.uri, cl.getElementsByTagName('p')[0]);
        }
    }

    if (settings.tags.includes('Title')) {
        app.apps.Search.state = '0/any/Title/-/';
    }
    
    if (!settings.tags.includes('AlbumArtist')) {
        app.apps.Browse.tabs.Database.state = '0/Artist/Artist/' + settings.dbDefaultTag + '/';
    }
    
    if (settings.featPlaylists === true) {
        sendAPI("MPD_API_PLAYLIST_LIST_ALL", {"offset": 0, "filter": "-"}, function(obj) {
            getAllPlaylists(obj, 'selectJukeboxPlaylist', settings.jukeboxPlaylist);
        });
    }
    else {
        document.getElementById('selectJukeboxPlaylist').innerHTML = '<option value="Database">' + t('Database') + '</option>';
    }

    setCols('QueueCurrent');
    setCols('Search');
    setCols('QueueLastPlayed');
    setCols('BrowseFilesystem');
    setCols('BrowsePlaylistsDetail');
    setCols('BrowseDatabaseDetail');
    setCols('Playback');

    addTagList('BrowseDatabaseByTagDropdown', 'browsetags');
    addTagList('BrowseNavPlaylistsDropdown', 'browsetags');
    addTagList('BrowseNavFilesystemDropdown', 'browsetags');
    
    addTagList('searchqueuetags', 'searchtags');
    addTagList('searchtags', 'searchtags');
    addTagList('searchDatabaseTags', 'browsetags');
    addTagList('databaseSortTagsList', 'browsetags');
    addTagList('dropdownSortPlaylistTags', 'tags');
    addTagList('saveSmartPlaylistSort', 'tags');
    
    addTagListSelect('selectSmartplsSort', 'tags');
    addTagListSelect('saveSmartPlaylistSort', 'tags');
    addTagListSelect('selectJukeboxUniqueTag', 'browsetags');
    
    initTagMultiSelect('inputEnabledTags', 'listEnabledTags', settings.allmpdtags, settings.tags);
    initTagMultiSelect('inputSearchTags', 'listSearchTags', settings.tags, settings.searchtags);
    initTagMultiSelect('inputBrowseTags', 'listBrowseTags', settings.tags, settings.browsetags);
    initTagMultiSelect('inputGeneratePlsTags', 'listGeneratePlsTags', settings.browsetags, settings.generatePlsTags);
}

//eslint-disable-next-line no-unused-vars
function resetSettings() {
    sendAPI("MYMPD_API_SETTINGS_RESET", {}, getSettings);
}

//eslint-disable-next-line no-unused-vars
function saveSettings(closeModal) {
    let formOK = true;

    let inputCrossfade = document.getElementById('inputCrossfade');
    if (!inputCrossfade.getAttribute('disabled')) {
        if (!validateInt(inputCrossfade)) {
            formOK = false;
        }
    }

    let inputJukeboxQueueLength = document.getElementById('inputJukeboxQueueLength');
    if (!validateInt(inputJukeboxQueueLength)) {
        formOK = false;
    }

    let inputJukeboxLastPlayed = document.getElementById('inputJukeboxLastPlayed');
    if (!validateInt(inputJukeboxLastPlayed)) {
        formOK = false;
    }
    
    let selectStreamModeEl = document.getElementById('selectStreamMode');
    let streamUrl = '';
    let streamPort = '';
    let inputStreamUrl = document.getElementById('inputStreamUrl');
    if (selectStreamModeEl.options[selectStreamModeEl.selectedIndex].value === 'port') {
        streamPort = inputStreamUrl.value;
        if (!validateInt(inputStreamUrl)) {
            formOK = false;
        }
    }
    else {
        streamUrl = inputStreamUrl.value;
        if (!validateStream(inputStreamUrl)) {
            formOK = false;
        }
    }

    let inputCoverimageSizeSmall = document.getElementById('inputCoverimageSizeSmall');
    if (!validateInt(inputCoverimageSizeSmall)) {
        formOK = false;
    }

    let inputCoverimageSize = document.getElementById('inputCoverimageSize');
    if (!validateInt(inputCoverimageSize)) {
        formOK = false;
    }
    
    let inputCoverimageName = document.getElementById('inputCoverimageName');
    if (!validateFilenameList(inputCoverimageName)) {
        formOK = false;
    }
    
    let inputBookletName = document.getElementById('inputBookletName');
    if (!validateFilename(inputBookletName)) {
        formOK = false;
    }
    
    let inputMaxElementsPerPage = document.getElementById('inputMaxElementsPerPage');
    if (!validateInt(inputMaxElementsPerPage)) {
        formOK = false;
    }
    
    if (isMobile === true) {
        let inputScaleRatio = document.getElementById('inputScaleRatio');
        if (!validateFloat(inputScaleRatio)) {
            formOK = false;
        }
        else {
            scale = parseFloat(inputScaleRatio.value);
            setViewport(true);
        }
    }

    if (parseInt(inputMaxElementsPerPage.value) > 200) {
        formOK = false;
    }
    
    let inputLastPlayedCount = document.getElementById('inputLastPlayedCount');
    if (!validateInt(inputLastPlayedCount)) {
        formOK = false;
    }
    
    if (document.getElementById('btnLoveEnable').classList.contains('active')) {
        let inputLoveChannel = document.getElementById('inputLoveChannel');
        let inputLoveMessage = document.getElementById('inputLoveMessage');
        if (!validateNotBlank(inputLoveChannel) || !validateNotBlank(inputLoveMessage)) {
            formOK = false;
        }
    }

    if (settings.featMixramp === true) {
        let inputMixrampdb = document.getElementById('inputMixrampdb');
        if (!inputMixrampdb.getAttribute('disabled')) {
            if (!validateFloat(inputMixrampdb)) {
                formOK = false;
            } 
        }
        let inputMixrampdelay = document.getElementById('inputMixrampdelay');
        if (!inputMixrampdelay.getAttribute('disabled')) {
            if (inputMixrampdelay.value === 'nan') {
                inputMixrampdelay.value = '-1';
            }
            if (!validateFloat(inputMixrampdelay)) {
                formOK = false;
            }
        }
    }
    
    let inputSmartplsInterval = document.getElementById('inputSmartplsInterval');
    if (!validateInt(inputSmartplsInterval)) {
        formOK = false;
    }
    let smartplsInterval = document.getElementById('inputSmartplsInterval').value * 60 * 60;

    let singleState = getBtnGroupValue('btnSingleGroup');
    let jukeboxMode = getBtnGroupValue('btnJukeboxModeGroup');
    let replaygain = getBtnGroupValue('btnReplaygainGroup');
    let jukeboxUniqueTag = document.getElementById('selectJukeboxUniqueTag');
    let jukeboxUniqueTagValue = jukeboxUniqueTag.options[jukeboxUniqueTag.selectedIndex].value;

    let selectJukeboxPlaylist = document.getElementById('selectJukeboxPlaylist');
    let jukeboxPlaylist = selectJukeboxPlaylist.options[selectJukeboxPlaylist.selectedIndex].value;
    
    if (jukeboxMode === '2') {
        jukeboxUniqueTagValue = 'Album';
    }
    
    if (jukeboxMode === '1' && settings.featSearchwindow === false && jukeboxPlaylist === 'Database') {
        formOK = false;
        document.getElementById('warnJukeboxPlaylist').classList.remove('hide');
    }
    
    if (formOK === true) {
        let selectLocale = document.getElementById('selectLocale');
        let selectTheme = document.getElementById('selectTheme');
        sendAPI("MYMPD_API_SETTINGS_SET", {
            "consume": (document.getElementById('btnConsume').classList.contains('active') ? 1 : 0),
            "random": (document.getElementById('btnRandom').classList.contains('active') ? 1 : 0),
            "single": parseInt(singleState),
            "repeat": (document.getElementById('btnRepeat').classList.contains('active') ? 1 : 0),
            "replaygain": replaygain,
            "crossfade": document.getElementById('inputCrossfade').value,
            "mixrampdb": (settings.featMixramp === true ? document.getElementById('inputMixrampdb').value : settings.mixrampdb),
            "mixrampdelay": (settings.featMixramp === true ? document.getElementById('inputMixrampdelay').value : settings.mixrampdelay),
            "notificationWeb": (document.getElementById('btnNotifyWeb').classList.contains('active') ? true : false),
            "notificationPage": (document.getElementById('btnNotifyPage').classList.contains('active') ? true : false),
            "mediaSession": (document.getElementById('btnMediaSession').classList.contains('active') ? true : false),
            "jukeboxMode": parseInt(jukeboxMode),
            "jukeboxPlaylist": jukeboxPlaylist,
            "jukeboxQueueLength": parseInt(document.getElementById('inputJukeboxQueueLength').value),
            "jukeboxLastPlayed": parseInt(document.getElementById('inputJukeboxLastPlayed').value),
            "jukeboxUniqueTag": jukeboxUniqueTagValue,
            "autoPlay": (document.getElementById('btnAutoPlay').classList.contains('active') ? true : false),
            "bgCover": (document.getElementById('btnBgCover').classList.contains('active') ? true : false),
            "bgColor": document.getElementById('inputBgColor').value,
            "bgCssFilter": document.getElementById('inputBgCssFilter').value,
            "featLocalplayer": (document.getElementById('btnFeatLocalplayer').classList.contains('active') ? true : false),
            "streamUrl": streamUrl,
            "streamPort": parseInt(streamPort),
            "coverimage": (document.getElementById('btnCoverimage').classList.contains('active') ? true : false),
            "coverimageName": document.getElementById('inputCoverimageName').value,
            "coverimageSize": document.getElementById('inputCoverimageSize').value,
            "coverimageSizeSmall": document.getElementById('inputCoverimageSizeSmall').value,
            "locale": selectLocale.options[selectLocale.selectedIndex].value,
            "love": (document.getElementById('btnLoveEnable').classList.contains('active') ? true : false),
            "loveChannel": document.getElementById('inputLoveChannel').value,
            "loveMessage": document.getElementById('inputLoveMessage').value,
            "bookmarks": (document.getElementById('btnBookmarks').classList.contains('active') ? true : false),
            "maxElementsPerPage": document.getElementById('inputMaxElementsPerPage').value,
            "stickers": (document.getElementById('btnStickers').classList.contains('active') ? true : false),
            "lastPlayedCount": document.getElementById('inputLastPlayedCount').value,
            "smartpls": (document.getElementById('btnSmartpls').classList.contains('active') ? true : false),
            "smartplsPrefix": document.getElementById('inputSmartplsPrefix').value,
            "smartplsInterval": smartplsInterval,
            "smartplsSort": document.getElementById('selectSmartplsSort').value,
            "taglist": getTagMultiSelectValues(document.getElementById('listEnabledTags'), false),
            "searchtaglist": getTagMultiSelectValues(document.getElementById('listSearchTags'), false),
            "browsetaglist": getTagMultiSelectValues(document.getElementById('listBrowseTags'), false),
            "generatePlsTags": getTagMultiSelectValues(document.getElementById('listGeneratePlsTags'), false),
            "theme": selectTheme.options[selectTheme.selectedIndex].value,
            "highlightColor": document.getElementById('inputHighlightColor').value,
            "timer": (document.getElementById('btnFeatTimer').classList.contains('active') ? true : false),
            "bookletName": document.getElementById('inputBookletName').value,
            "lyrics": (document.getElementById('btnFeatLyrics').classList.contains('active') ? true : false)
        }, getSettings);
        if (closeModal === true) {
            modalSettings.hide();
        }
        else {
            btnWaiting(document.getElementById('btnApplySettings'), true);
        }
    }
}

function getTagMultiSelectValues(taglist, translated) {
    let values = [];
    let chkBoxes = taglist.getElementsByTagName('button');
    for (let i = 0; i < chkBoxes.length; i++) {
        if (chkBoxes[i].classList.contains('active')) {
            if (translated === true) {
                values.push(t(chkBoxes[i].name));
            }
            else {
                values.push(chkBoxes[i].name);
            }
        }
    }
    if (translated === true) {
        return values.join(', ');
    }
    return values.join(',');
}

function initTagMultiSelect(inputId, listId, allTags, enabledTags) {
    let values = [];
    let list = '';
    for (let i = 0; i < allTags.length; i++) {
        if (enabledTags.includes(allTags[i])) {
            values.push(t(allTags[i]));
        }
        list += '<div class="form-check">' +
            '<button class="btn btn-secondary btn-xs clickable material-icons material-icons-small' + 
            (enabledTags.includes(allTags[i]) ? ' active' : '') + '" name="' + allTags[i] + '">' +
            (enabledTags.includes(allTags[i]) ? 'check' : 'radio_button_unchecked') + '</button>' +
            '<label class="form-check-label" for="' + allTags[i] + '">&nbsp;&nbsp;' + t(allTags[i]) + '</label>' +
            '</div>';
    }
    document.getElementById(listId).innerHTML = list;

    let inputEl = document.getElementById(inputId);
    inputEl.value = values.join(', ');
    if (inputEl.getAttribute('data-init') === 'true') {
        return;
    }
    inputEl.setAttribute('data-init', 'true');
    document.getElementById(listId).addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'BUTTON') {
            toggleBtnChk(event.target);
            event.target.parentNode.parentNode.parentNode.previousElementSibling.value = getTagMultiSelectValues(event.target.parentNode.parentNode, true);
        }
    });
}

function filterCols(x) {
    let tags = settings.tags.slice();
    if (settings.featTags === false) {
        tags.push('Title');
    }
    tags.push('Duration');
    if (x === 'colsQueueCurrent' || x === 'colsBrowsePlaylistsDetail' || x === 'colsQueueLastPlayed') {
        tags.push('Pos');
    }
    else if (x === 'colsBrowseFilesystem') {
        tags.push('Type');
    }
    if (x === 'colsQueueLastPlayed') {
        tags.push('LastPlayed');
    }
    if (x === 'colsPlayback') {
        tags.push('Filetype');
        tags.push('Fileformat');
        tags.push('LastModified');
        if (settings.featLyrics === true) {
            tags.push('Lyrics');
        }
    }
    let cols = [];
    for (let i = 0; i < settings[x].length; i++) {
        if (tags.includes(settings[x][i])) {
            cols.push(settings[x][i]);
        }
    }
    settings[x] = cols;
    logDebug('Columns for ' + x + ': ' + cols);
}

//eslint-disable-next-line no-unused-vars
function toggleBtnNotifyWeb() {
    let btnNotifyWeb = document.getElementById('btnNotifyWeb');
    let notifyWebState = btnNotifyWeb.classList.contains('active') ? true : false;
    if (notificationsSupported()) {
        if (notifyWebState === false) {
            Notification.requestPermission(function (permission) {
                if (!('permission' in Notification)) {
                    Notification.permission = permission;
                }
                if (permission === 'granted') {
                    toggleBtnChk('btnNotifyWeb', true);
                    settings.notificationWeb = true;
                    document.getElementById('warnNotifyWeb').classList.add('hide');
                } 
                else {
                    toggleBtnChk('btnNotifyWeb', false);
                    settings.notificationWeb = false;
                    document.getElementById('warnNotifyWeb').classList.remove('hide');
                }
            });
        }
        else {
            toggleBtnChk('btnNotifyWeb', false);
            settings.notificationWeb = false;
            document.getElementById('warnNotifyWeb').classList.add('hide');
        }
    }
    else {
        toggleBtnChk('btnNotifyWeb', false);
        settings.notificationWeb = false;
    }
}

//eslint-disable-next-line no-unused-vars
function setPlaySettings(el) {
    if (el.parentNode.classList.contains('btn-group')) {
        toggleBtnGroup(el);
    }
    else {
        toggleBtnChk(el);
    }
    if (el.parentNode.id === 'playDropdownBtnJukeboxModeGroup') {
        if (el.parentNode.getElementsByClassName('active')[0].getAttribute('data-value') !== '0') {
            toggleBtnChk('playDropdownBtnConsume', true);            
        }
    }
    else if (el.id === 'playDropdownBtnConsume') {
        if (el.classList.contains('active') === false) {
            toggleBtnGroupValue(document.getElementById('playDropdownBtnJukeboxModeGroup'), 0);
        }
    }

    savePlaySettings();
}

function showPlayDropdown() {
    toggleBtnChk(document.getElementById('playDropdownBtnRandom'), settings.random);
    toggleBtnChk(document.getElementById('playDropdownBtnConsume'), settings.consume);
    toggleBtnChk(document.getElementById('playDropdownBtnRepeat'), settings.repeat);
    toggleBtnChk(document.getElementById('playDropdownBtnRandom'), settings.random);
    toggleBtnGroupValue(document.getElementById('playDropdownBtnSingleGroup'), settings.single);
    toggleBtnGroupValue(document.getElementById('playDropdownBtnJukeboxModeGroup'), settings.jukeboxMode);
}

function savePlaySettings() {
    let singleState = document.getElementById('playDropdownBtnSingleGroup').getElementsByClassName('active')[0].getAttribute('data-value');
    let jukeboxMode = document.getElementById('playDropdownBtnJukeboxModeGroup').getElementsByClassName('active')[0].getAttribute('data-value');
    sendAPI("MYMPD_API_SETTINGS_SET", {
        "consume": (document.getElementById('playDropdownBtnConsume').classList.contains('active') ? 1 : 0),
        "random": (document.getElementById('playDropdownBtnRandom').classList.contains('active') ? 1 : 0),
        "single": parseInt(singleState),
        "repeat": (document.getElementById('playDropdownBtnRepeat').classList.contains('active') ? 1 : 0),
        "jukeboxMode": parseInt(jukeboxMode)
        }, getSettings);
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function songDetails(uri) {
    sendAPI("MPD_API_DATABASE_SONGDETAILS", {"uri": uri}, parseSongDetails);
    modalSongDetails.show();
}

function parseFingerprint(obj) {
    let textarea = document.createElement('textarea');
    textarea.value = obj.result.fingerprint;
    textarea.classList.add('form-control', 'text-monospace', 'small');
    let fpTd = document.getElementById('fingerprint');
    fpTd.innerHTML = '';
    fpTd.appendChild(textarea);
}

function parseSongDetails(obj) {
    let modal = document.getElementById('modalSongDetails');
    modal.getElementsByClassName('album-cover')[0].style.backgroundImage = 'url("' + subdir + '/albumart/' + obj.result.uri + '"), url("' + subdir + '/assets/coverimage-loading.svg")';
    
    let elH1s = modal.getElementsByTagName('h1');
    for (let i = 0; i < elH1s.length; i++) {
        elH1s[i].innerText = obj.result.Title;
    }
    
    let songDetailsHTML = '';
    for (let i = 0; i < settings.tags.length; i++) {
        if (settings.tags[i] === 'Title' || obj.result[settings.tags[i]] === '-') {
            continue;
        }
        songDetailsHTML += '<tr><th>' + t(settings.tags[i]) + '</th><td data-tag="' + settings.tags[i] + '" data-name="' + encodeURI(obj.result[settings.tags[i]]) + '">';
        if (settings.browsetags.includes(settings.tags[i]) && obj.result[settings.tags[i]] !== '-') {
            songDetailsHTML += '<a class="text-success" href="#">' + e(obj.result[settings.tags[i]]) + '</a>';
        }
        else {
            songDetailsHTML += obj.result[settings.tags[i]];
        }
        songDetailsHTML += '</td></tr>';
    }
    songDetailsHTML += '<tr><th>' + t('Duration') + '</th><td>' + beautifyDuration(obj.result.Duration) + '</td></tr>';
    if (settings.featLibrary === true && settings.publish === true) {
        songDetailsHTML += '<tr><th>' + t('Filename') + '</th><td><a class="breakAll text-success" href="/browse/music/' + 
            encodeURI(obj.result.uri) + '" target="_blank" title="' + e(obj.result.uri) + '">' + 
            e(basename(obj.result.uri, true)) + '</a></td></tr>';
    }
    else {
        songDetailsHTML += '<tr><th>' + t('Filename') + '</th><td class="breakAll"><span title="' + e(obj.result.uri) + '">' + 
            e(basename(obj.result.uri, true)) + '</span></td></tr>';
    }
    songDetailsHTML += '<tr><th>' + t('Filetype') + '</th><td>' + filetype(obj.result.uri) + '</td></tr>';
    songDetailsHTML += '<tr><th>' + t('LastModified') + '</th><td>' + localeDate(obj.result.LastModified) + '</td></tr>';
    if (settings.featFingerprint === true) {
        songDetailsHTML += '<tr><th>' + t('Fingerprint') + '</th><td class="breakAll" id="fingerprint"><a class="text-success" data-uri="' + 
            encodeURI(obj.result.uri) + '" id="calcFingerprint" href="#">' + t('Calculate') + '</a></td></tr>';
    }
    if (obj.result.booklet === true && settings.publish === true) {
        songDetailsHTML += '<tr><th>' + t('Booklet') + '</th><td><a class="text-success" href="/browse/music/' + dirname(obj.result.uri) + '/' + settings.bookletName + '" target="_blank">' + t('Download') + '</a></td></tr>';
    }
    if (settings.featStickers === true) {
        songDetailsHTML += '<tr><th colspan="2" class="pt-3"><h5>' + t('Statistics') + '</h5></th></tr>' +
            '<tr><th>' + t('Play count') + '</th><td>' + obj.result.playCount + '</td></tr>' +
            '<tr><th>' + t('Skip count') + '</th><td>' + obj.result.skipCount + '</td></tr>' +
            '<tr><th>' + t('Last played') + '</th><td>' + (obj.result.lastPlayed === 0 ? t('never') : localeDate(obj.result.lastPlayed)) + '</td></tr>' +
            '<tr><th>' + t('Last skipped') + '</th><td>' + (obj.result.lastSkipped === 0 ? t('never') : localeDate(obj.result.lastSkipped)) + '</td></tr>' +
            '<tr><th>' + t('Like') + '</th><td>' +
              '<div class="btn-group btn-group-sm">' +
                '<button title="' + t('Dislike song') + '" id="btnVoteDown2" data-href=\'{"cmd": "voteSong", "options": [0]}\' class="btn btn-sm btn-light material-icons">thumb_down</button>' +
                '<button title="' + t('Like song') + '" id="btnVoteUp2" data-href=\'{"cmd": "voteSong", "options": [2]}\' class="btn btn-sm btn-light material-icons">thumb_up</button>' +
              '</div>' +
            '</td></tr>';
    }
    
    document.getElementById('tbodySongDetails').innerHTML = songDetailsHTML;
    setVoteSongBtns(obj.result.like, obj.result.uri);
    
    if (settings.featLyrics === true) {
        getLyrics(obj.result.uri, document.getElementById('lyricsText'));
    }

    let showPictures = false;
    if (obj.result.images.length > 0 && settings.featLibrary === true && settings.publish === true) {
        showPictures = true;
    }
    else if (settings.coverimage === true) {
        showPictures = true;
    }
    
    let pictureEls = document.getElementsByClassName('featPictures');
    for (let i = 0; i < pictureEls.length; i++) {
        if (showPictures === true) {
            pictureEls[i].classList.remove('hide');
        }
        else {
            pictureEls[i].classList.add('hide');
        }
    }
    
    if (showPictures === true) {
        //add uri to image list to get embedded albumart
        let images = [ subdir + '/albumart/' + obj.result.uri ];
        //add all but coverfiles to image list
        for (let i = 0; i < obj.result.images.length; i++) {
            if (isCoverfile(obj.result.images[i]) === false) {
                images.push(subdir + '/browse/music/' + obj.result.images[i]);
            }
        }
    
        let carousel = '<div id="songPicsCarousel" class="carousel slide" data-ride="carousel">' +
            '<ol class="carousel-indicators">';
        for (let i = 0; i < images.length; i++) {
            carousel += '<li data-target="#songPicsCarousel" data-slide-to="' + i + '"' +
                (i === 0 ? ' class="active"' : '') + '></li>';
        }    
        carousel += '</ol>' +
            '<div class="carousel-inner" role="listbox">';
        for (let i = 0; i < images.length; i++) {
            carousel += '<div class="carousel-item' + (i === 0 ? ' active' : '') + '"><div></div></div>';
        }
        carousel += '</div>' +
            '<a class="carousel-control-prev" href="#songPicsCarousel" data-slide="prev">' +
                '<span class="carousel-control-prev-icon"></span>' +
            '</a>' +
            '<a class="carousel-control-next" href="#songPicsCarousel" data-slide="next">' +
                '<span class="carousel-control-next-icon"></span>' +
            '</a>' +
            '</div>';
    
        document.getElementById('tabSongPics').innerHTML = carousel;
        let carouselItems = document.getElementById('tabSongPics').getElementsByClassName('carousel-item');
        for (let i = 0; i < carouselItems.length; i++) {
            carouselItems[i].children[0].style.backgroundImage = 'url("' + encodeURI(images[i]) + '")';
        }
        let myCarousel = document.getElementById('songPicsCarousel');
        //eslint-disable-next-line no-undef, no-unused-vars
        let myCarouselInit = new BSN.Carousel(myCarousel, {
            interval: false,
            pause: false
        });
    }
    else {
        document.getElementById('tabSongPics').innerText = '';
    }
}

function isCoverfile(uri) {
    let filename = basename(uri).toLowerCase();
    let fileparts = filename.split('.');
    
    let extensions = ['png', 'jpg', 'jpeg', 'svg', 'webp', 'tiff', 'bmp'];
    let coverimageNames = settings.coverimageName.split(',');
    for (let i = 0; i < coverimageNames.length; i++) {
        let name = coverimageNames[i].trim();
        if (filename === name) {
            return true;
        }
        if (fileparts[1]) {
            if (name === fileparts[0] && extensions.includes(fileparts[1])) {
                return true;
            }
        }
    }
    return false;
}

function getLyrics(uri, el) {
    el.classList.add('opacity05');
    let ajaxRequest=new XMLHttpRequest();
    
    ajaxRequest.open('GET', subdir + '/lyrics/' + uri, true);
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState === 4) {
            el.innerText = ajaxRequest.responseText === 'No lyrics found' ? t(ajaxRequest.responseText) : ajaxRequest.responseText;
            el.classList.remove('opacity05');
        }
    };
    ajaxRequest.send();
}

//eslint-disable-next-line no-unused-vars
function loveSong() {
    sendAPI("MPD_API_LOVE", {});
}

//eslint-disable-next-line no-unused-vars
function voteSong(vote) {
    let uri = decodeURI(domCache.currentTitle.getAttribute('data-uri'));
    if (uri === '') {
        return;
    }
        
    if (vote === 2 && domCache.btnVoteUp.classList.contains('highlight')) {
        vote = 1;
    }
    else if (vote === 0 && domCache.btnVoteDown.classList.contains('highlight')) {
        vote = 1;
    }
    sendAPI("MPD_API_LIKE", {"uri": uri, "like": vote});
    setVoteSongBtns(vote, uri);
}

function setVoteSongBtns(vote, uri) {
    domCache.btnVoteUp2 = document.getElementById('btnVoteUp2');
    domCache.btnVoteDown2 = document.getElementById('btnVoteDown2');

    if (uri === '' || uri.indexOf('://') > -1) {
        domCache.btnVoteUp.setAttribute('disabled', 'disabled');
        domCache.btnVoteDown.setAttribute('disabled', 'disabled');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.setAttribute('disabled', 'disabled');
            domCache.btnVoteDown2.setAttribute('disabled', 'disabled');
        }
    } else {
        domCache.btnVoteUp.removeAttribute('disabled');
        domCache.btnVoteDown.removeAttribute('disabled');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.removeAttribute('disabled');
            domCache.btnVoteDown2.removeAttribute('disabled');
        }
    }
    
    if (vote === 0) {
        domCache.btnVoteUp.classList.remove('highlight');
        domCache.btnVoteDown.classList.add('highlight');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.remove('highlight');
            domCache.btnVoteDown2.classList.add('highlight');
        }
    } else if (vote === 1) {
        domCache.btnVoteUp.classList.remove('highlight');
        domCache.btnVoteDown.classList.remove('highlight');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.remove('highlight');
            domCache.btnVoteDown2.classList.remove('highlight');
        }
    } else if (vote === 2) {
        domCache.btnVoteUp.classList.add('highlight');
        domCache.btnVoteDown.classList.remove('highlight');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.add('highlight');
            domCache.btnVoteDown2.classList.remove('highlight');
        }
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function parseStats(obj) {
    document.getElementById('mpdstats_artists').innerText =  obj.result.artists;
    document.getElementById('mpdstats_albums').innerText = obj.result.albums;
    document.getElementById('mpdstats_songs').innerText = obj.result.songs;
    document.getElementById('mpdstats_dbPlaytime').innerText = beautifyDuration(obj.result.dbPlaytime);
    document.getElementById('mpdstats_playtime').innerText = beautifyDuration(obj.result.playtime);
    document.getElementById('mpdstats_uptime').innerText = beautifyDuration(obj.result.uptime);
    document.getElementById('mpdstats_mympd_uptime').innerText = beautifyDuration(obj.result.myMPDuptime);
    document.getElementById('mpdstats_dbUpdated').innerText = localeDate(obj.result.dbUpdated);
    document.getElementById('mympdVersion').innerText = obj.result.mympdVersion;
    document.getElementById('mpdInfo_version').innerText = obj.result.mpdVersion;
    document.getElementById('mpdInfo_libmpdclientVersion').innerText = obj.result.libmpdclientVersion;
    document.getElementById('mpdInfo_libmympdclientVersion').innerText = obj.result.libmympdclientVersion;
}

function getServerinfo() {
    let ajaxRequest=new XMLHttpRequest();
    ajaxRequest.open('GET', subdir + '/api/serverinfo', true);
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState === 4) {
            let obj = JSON.parse(ajaxRequest.responseText);
            document.getElementById('wsIP').innerText = obj.result.ip;
            document.getElementById('wsMongooseVersion').innerText = obj.result.version;
        }
    };
    ajaxRequest.send();
}

function parseOutputs(obj) {
    let btns = '';
    let nr = 0;
    for (let i = 0; i < obj.result.numOutputs; i++) {
        if (obj.result.data[i].plugin !== 'dummy') {
            nr++;
            btns += '<button id="btnOutput' + obj.result.data[i].id +'" data-output-name="' + encodeURI(obj.result.data[i].name) + '" data-output-id="' + obj.result.data[i].id + '" class="btn btn-secondary btn-block';
            if (obj.result.data[i].state === 1) {
                btns += ' active';
            }
            btns += '"><span class="material-icons float-left">volume_up</span> ' + e(obj.result.data[i].name);
            if (Object.keys(obj.result.data[i].attributes).length > 0) {
                btns += '<a class="material-icons float-right text-white" title="' + t('Edit attributes') + '">settings</a>';
            }
            else {
                btns += '<a class="material-icons float-right text-white" title="' + t('Show attributes') + '">settings</a>';
            }
            btns += '</button>';
        }
    }
    if (nr === 0) {
        btns = '<span class="material-icons">error_outline</span> ' + t('No outputs');
    }
    domCache.outputs.innerHTML = btns;
}

function showListOutputAttributes(outputName) {
    sendAPI("MPD_API_PLAYER_OUTPUT_LIST", {}, function(obj) {
        modalOutputAttributes.show();
        let output;
        for (let i = 0; i < obj.result.data.length; i++) {
            if (obj.result.data[i].name === outputName) {
                output = obj.result.data[i];
                break;
            }
        }
        document.getElementById('modalOutputAttributesId').value = e(output.id);        
        let list = '<tr><td>' + t('Name') + '</td><td>' + e(output.name) + '</td></tr>' +
            '<tr><td>' + t('State') + '</td><td>' + (output.state === 1 ? t('enabled') : t('disabled')) + '</td></tr>' +
            '<tr><td>' + t('Plugin') + '</td><td>' + e(output.plugin) + '</td></tr>';
        Object.keys(output.attributes).forEach(function(key) {
            list += '<tr><td>' + e(key) + '</td><td><input name="' + e(key) + '" class="form-control border-secondary" type="text" value="' + 
                e(output.attributes[key]) + '"/></td></tr>';
        });
        document.getElementById('outputAttributesList').innerHTML = list;
    });
}

//eslint-disable-next-line no-unused-vars
function saveOutputAttributes() {
    let params = {};
    params.outputId =  parseInt(document.getElementById('modalOutputAttributesId').value);
    params.attributes = {};
    let el = document.getElementById('outputAttributesList').getElementsByTagName('input');
    for (let i = 0; i < el.length; i++) {
        params.attributes[el[i].name] = el[i].value;
    }
    sendAPI('MPD_API_PLAYER_OUTPUT_ATTRIBUTS_SET', params);
    modalOutputAttributes.hide();
}

function setCounter(currentSongId, totalTime, elapsedTime) {
    currentSong.totalTime = totalTime;
    currentSong.elapsedTime = elapsedTime;
    currentSong.currentSongId = currentSongId;

    const progressPx = Math.ceil(domCache.progress.offsetWidth * elapsedTime / totalTime);
    if (progressPx === 0) {
        domCache.progressBar.style.transition = 'none';
    }
    domCache.progressBar.style.width = progressPx + 'px'; 
    if (progressPx === 0) {    
        setTimeout(function() {
            domCache.progressBar.style.transition = progressBarTransition;
        }, 10);
    }

    let counterText = beautifySongDuration(elapsedTime) + "&nbsp;/&nbsp;" + beautifySongDuration(totalTime);
    domCache.counter.innerHTML = counterText;
    
    //Set playing track in queue view
    if (lastState) {
        if (lastState.currentSongId !== currentSongId) {
            let tr = document.getElementById('queueTrackId' + lastState.currentSongId);
            if (tr) {
                let durationTd = tr.querySelector('[data-col=Duration]');
                if (durationTd) {
                    durationTd.innerText = tr.getAttribute('data-duration');
                }
                let posTd = tr.querySelector('[data-col=Pos]');
                if (posTd) {
                    posTd.classList.remove('material-icons');
                    posTd.innerText = tr.getAttribute('data-songpos');
                }
                tr.classList.remove('font-weight-bold');
            }
        }
    }
    let tr = document.getElementById('queueTrackId' + currentSongId);
    if (tr) {
        let durationTd = tr.querySelector('[data-col=Duration]');
        if (durationTd) {
            durationTd.innerHTML = counterText;
        }
        let posTd = tr.querySelector('[data-col=Pos]');
        if (posTd) {
            if (!posTd.classList.contains('material-icons')) {
                posTd.classList.add('material-icons');
                posTd.innerText = 'play_arrow';
            }
        }
        tr.classList.add('font-weight-bold');
    }
    
    if (progressTimer) {
        clearTimeout(progressTimer);
    }
    if (playstate === 'play') {
        progressTimer = setTimeout(function() {
            currentSong.elapsedTime ++;
            requestAnimationFrame(function() {
                setCounter(currentSong.currentSongId, currentSong.totalTime, currentSong.elapsedTime);
            });
        }, 1000);
    }
}

function parseState(obj) {
    if (JSON.stringify(obj.result) === JSON.stringify(lastState)) {
        toggleUI();
        return;
    }

    //Set play and queue state
    parseUpdateQueue(obj);
    
    //Set volume
    parseVolume(obj);

    //Set play counters
    setCounter(obj.result.currentSongId, obj.result.totalTime, obj.result.elapsedTime);
    
    //Get current song
    if (!lastState || lastState.currentSongId !== obj.result.currentSongId ||
        lastState.queueVersion !== obj.result.queueVersion)
    {
        sendAPI("MPD_API_PLAYER_CURRENT_SONG", {}, songChange);
    }
    //clear playback card if no current song
    if (obj.result.songPos === '-1') {
        domCache.currentTitle.innerText = 'Not playing';
        document.title = 'myMPD';
        let footerTitle = document.getElementById('footerTitle');
        footerTitle.innerText = '';
        footerTitle.removeAttribute('title');
        footerTitle.classList.remove('clickable');
        clearCurrentCover();
        if (settings.bgCover === true) {
            clearBackgroundImage();
        }
        let pb = document.getElementById('cardPlaybackTags').getElementsByTagName('p');
        for (let i = 0; i < pb.length; i++) {
            pb[i].innerText = '';
        }
    }
    else {
        let cff = document.getElementById('currentFileformat');
        if (cff) {
            cff.getElementsByTagName('p')[0].innerText = fileformat(obj.result.audioFormat);
        }
    }

    lastState = obj.result;                    
    
    if (settings.mpdConnected === false || uiEnabled === false) {
        getSettings(true);
    }
}

function parseVolume(obj) {
    if (obj.result.volume === -1) {
        domCache.volumePrct.innerText = t('Volumecontrol disabled');
        domCache.volumeControl.classList.add('hide');
    } 
    else {
        domCache.volumeControl.classList.remove('hide');
        domCache.volumePrct.innerText = obj.result.volume + ' %';
        if (obj.result.volume === 0) {
            domCache.volumeMenu.innerText = 'volume_off';
        }
        else if (obj.result.volume < 50) {
            domCache.volumeMenu.innerText = 'volume_down';
        }
        else {
            domCache.volumeMenu.innerText = 'volume_up';
        }
    }
    domCache.volumeBar.value = obj.result.volume;
}

function setBackgroundImage(url) {
    if (url === undefined) {
        clearBackgroundImage();
        return;
    }
    let old = document.querySelectorAll('.albumartbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '-10') {
            old[i].remove();
        }
        else {
            old[i].style.zIndex = '-10';
            old[i].style.opacity = '0';
            //old[i].style.filter = '';
        }
    }
    let div = document.createElement('div');
    div.classList.add('albumartbg');
    div.style.filter = settings.bgCssFilter;
    div.style.backgroundImage = 'url("' + subdir + '/albumart/' + url + '")';
    div.style.opacity = 0;
    let body = document.getElementsByTagName('body')[0];
    body.insertBefore(div, body.firstChild);

    let img = new Image();
    img.onload = function() {
        document.querySelector('.albumartbg').style.opacity = 1;
    };
    img.src = subdir + '/albumart/' + url;
}

function clearBackgroundImage() {
    let old = document.querySelectorAll('.albumartbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '-10') {
            old[i].remove();        
        }
        else {
            old[i].style.zIndex = '-10';
            old[i].style.opacity = '0';
            //old[i].style.filter = '';
        }
    }
}

function setCurrentCover(url) {
    _setCurrentCover(url, domCache.currentCover);
    _setCurrentCover(url, domCache.footerCover);
}

function _setCurrentCover(url, el) {
    if (url === undefined) {
        clearCurrentCover();
        return;
    }
    let old = el.querySelectorAll('.coverbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '2') {
            old[i].remove();        
        }
        else {
            old[i].style.zIndex = '2';
        }
    }

    let div = document.createElement('div');
    div.classList.add('coverbg');
    div.style.backgroundImage = 'url("' + subdir + '/albumart/' + url + '")';
    div.style.opacity = 0;
    el.insertBefore(div, el.firstChild);

    let img = new Image();
    img.onload = function() {
        el.querySelector('.coverbg').style.opacity = 1;
    };
    img.src = subdir + '/albumart/' + url;
}

function clearCurrentCover(el) {
    _clearCurrentCover(domCache.currentCover);
    _clearCurrentCover(domCache.footerCover);
}

function _clearCurrentCover(el) {
    let old = el.querySelectorAll('.coverbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '2') {
            old[i].remove();        
        }
        else {
            old[i].style.zIndex = '2';
            old[i].style.opacity = '0';
        }
    }
}

function songChange(obj) {
    let curSong = obj.result.Title + ':' + obj.result.Artist + ':' + obj.result.Album + ':' + obj.result.uri + ':' + obj.result.currentSongId;
    if (lastSong === curSong) {
        return;
    }
    let textNotification = '';
    let htmlNotification = '';
    let pageTitle = '';

    mediaSessionSetMetadata(obj.result.Title, obj.result.Artist, obj.result.Album, obj.result.uri);
    
    setCurrentCover(obj.result.uri);
    if (settings.bgCover === true && settings.featCoverimage === true) {
        setBackgroundImage(obj.result.uri);
    }

    if (obj.result.Artist !== undefined && obj.result.Artist.length > 0 && obj.result.Artist !== '-') {
        textNotification += obj.result.Artist;
        htmlNotification += obj.result.Artist;
        pageTitle += obj.result.Artist + ' - ';
        domCache.footerArtist.innerText = obj.result.Artist;
        domCache.footerArtist.setAttribute('data-name', encodeURI(obj.result.Artist));
        domCache.footerArtist.classList.add('clickable');
    }
    else {
        domCache.footerArtist.innerText = '';
        domCache.footerArtist.setAttribute('data-name', '');
        domCache.footerArtist.classList.remove('clickable');
    }

    if (obj.result.Album !== undefined && obj.result.Album.length > 0 && obj.result.Album !== '-') {
        textNotification += ' - ' + obj.result.Album;
        htmlNotification += '<br/>' + obj.result.Album;
        domCache.footerAlbum.innerText = obj.result.Album;
        domCache.footerAlbum.setAttribute('data-name', encodeURI(obj.result.Album));
        domCache.footerAlbum.classList.add('clickable');
    }
    else {
        domCache.footerAlbum.innerText = '';
        domCache.footerAlbum.setAttribute('data-name', '');
        domCache.footerAlbum.classList.remove('clickable');
    }

    if (obj.result.Title !== undefined && obj.result.Title.length > 0) {
        pageTitle += obj.result.Title;
        domCache.currentTitle.innerText = obj.result.Title;
        domCache.currentTitle.setAttribute('data-uri', encodeURI(obj.result.uri));
        domCache.footerTitle.innerText = obj.result.Title;
        domCache.footerTitle.classList.add('clickable');
    }
    else {
        domCache.currentTitle.innerText = '';
        domCache.currentTitle.setAttribute('data-uri', '');
        domCache.footerTitle.innerText = '';
        domCache.footerTitle.setAttribute('data-name', '');
        domCache.footerTitle.classList.remove('clickable');        
    }
    document.title = 'myMPD: ' + pageTitle;
    domCache.footerCover.title = pageTitle;
    
    if (obj.result.uri !== undefined && obj.result.uri !== '' && obj.result.uri.indexOf('://') === -1) {
        footerTitle.classList.add('clickable');
    }
    else {
        footerTitle.classList.remove('clickable');
    }

    if (obj.result.uri !== undefined) {
        if (settings.featStickers === true) {
            setVoteSongBtns(obj.result.like, obj.result.uri);
        }
        obj.result['Filetype'] = filetype(obj.result.uri);
    }
    else {
        obj.result['Filetype'] = '';
    }
    
    if (lastState) {
        obj.result['Fileformat'] = fileformat(lastState.audioFormat);
    }
    else {
        obj.result['Fileformat'] = '';
    }

    for (let i = 0; i < settings.colsPlayback.length; i++) {
        let c = document.getElementById('current' + settings.colsPlayback[i]);
        if (c && settings.colsPlayback[i] === 'Lyrics') {
            getLyrics(obj.result.uri, c.getElementsByTagName('p')[0]);
        }
        else if (c) {
            let value = obj.result[settings.colsPlayback[i]];
            if (value === undefined) {
                value = '';
            }
            if (settings.colsPlayback[i] === 'Duration') {
                value = beautifySongDuration(value);
            }
            else if (settings.colsPlayback[i] === 'LastModified') {
                value = localeDate(value);
            }
            c.getElementsByTagName('p')[0].innerText = value;
            c.setAttribute('data-name', encodeURI(value));
        }
    }
    
    //Update Artist in queue view for http streams
    let playingTr = document.getElementById('queueTrackId' + obj.result.currentSongId);
    if (playingTr) {
        playingTr.getElementsByTagName('td')[1].innerText = obj.result.Title;
    }

    if (playstate === 'play') {
        showNotification(obj.result.Title, textNotification, htmlNotification, 'success');
    }
    
    lastSong = curSong;
    lastSongObj = obj.result;
}

//eslint-disable-next-line no-unused-vars
function gotoTagList() {
    appGoto(app.current.app, app.current.tab, app.current.view, '0/-/-/-/');
}

//eslint-disable-next-line no-unused-vars
function volumeStep(dir) {
    let inc = dir === 'up' ? settings.volumeStep : 0 - settings.volumeStep;
    chVolume(inc);
}

function chVolume(increment) {
    let newValue = parseInt(domCache.volumeBar.value) + increment;
    if (newValue < 0)  {
        newValue = 0;
    }
    else if (newValue > 100) {
        newValue = 100;
    }
    domCache.volumeBar.value = newValue;
    sendAPI("MPD_API_PLAYER_VOLUME_SET", {"volume": newValue});
}

//eslint-disable-next-line no-unused-vars
function clickTitle() {
    let uri = decodeURI(domCache.currentTitle.getAttribute('data-uri'));
    if (uri !== '' && uri.indexOf('://') === -1) {
        songDetails(uri);
    }
}

function mediaSessionSetPositionState(duration, position) {
    if (settings.mediaSession === true && 'mediaSession' in navigator && navigator.mediaSession.setPositionState) {
        if (position < duration) {
            //streams have position > duration
            navigator.mediaSession.setPositionState({
                duration: duration,
                position: position
            });
        }
    }
}

function mediaSessionSetState() {
    if (settings.mediaSession === true && 'mediaSession' in navigator) {
        if (playstate === 'play') {
            navigator.mediaSession.playbackState = 'playing';
        }
        else {
            navigator.mediaSession.playbackState = 'paused';
        }
    }
}

function mediaSessionSetMetadata(title, artist, album, url) {
    if (settings.mediaSession === true && 'mediaSession' in navigator) {
        let hostname = window.location.hostname;
        let protocol = window.location.protocol;
        let port = window.location.port;
        let artwork = protocol + '//' + hostname + (port !== '' ? ':' + port : '') + subdir + '/albumart/' + url;

        if (settings.coverimage === true) {
            //eslint-disable-next-line no-undef
            navigator.mediaSession.metadata = new MediaMetadata({
                title: title,
                artist: artist,
                album: album,
                artwork: [{src: artwork}]
            });
        }
        else {
            //eslint-disable-next-line no-undef
            navigator.mediaSession.metadata = new MediaMetadata({
                title: title,
                artist: artist,
                album: album
            });
        }
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function focusTable(rownr, table) {
    if (table === undefined) {
        table = document.getElementById(app.current.app + (app.current.tab !== undefined ? app.current.tab : '') + (app.current.view !== undefined ? app.current.view : '') + 'List');
    }

    if (app.current.app === 'Browse' && app.current.tab === 'Database' &&
            app.current.view === 'List') 
    {
        const tables = document.getElementsByClassName('card-grid');
        if (tables.length === 0 ) {
            return; 
        }
        table = tables[0];
        for (let i = 0; i < tables.length; i++) {
            if (tables[i].classList.contains('selected')) {
                table = tables[i];
                break;
            }
        }
        table.focus();
        return;
    }

    if (table !== null) {
        let sel = table.getElementsByClassName('selected');
        if (rownr === undefined) {
            if (sel.length === 0) {
                let row = table.getElementsByTagName('tbody')[0].rows[0];
                row.focus();
                row.classList.add('selected');
            }
            else {
                sel[0].focus();
            }
        }
        else {
            if (sel && sel.length > 0) {
                sel[0].classList.remove('selected');
            }
            let rows = table.getElementsByTagName('tbody')[0].rows;
            let rowsLen = rows.length;
            if (rowsLen < rownr) {
                rownr = 0;
            }
            if (rowsLen > rownr) {
                rows[rownr].focus();
                rows[rownr].classList.add('selected');
            }
        }
        //insert goto parent row
        if (table.id === 'BrowseFilesystemList') {
            let tbody = table.getElementsByTagName('tbody')[0];
            if (tbody.rows.length > 0 && tbody.rows[0].getAttribute('data-type') !== 'parentDir' && app.current.search !== '') {
                let nrCells = table.getElementsByTagName('thead')[0].rows[0].cells.length;
                let uri = app.current.search.replace(/\/?([^/]+)$/,'');
                let row = tbody.insertRow(0);
                row.setAttribute('data-type', 'parentDir');
                row.setAttribute('tabindex', 0);
                row.setAttribute('data-uri', encodeURI(uri));
                row.innerHTML = '<td colspan="' + nrCells + '">..</td>';
            }
        }
        scrollFocusIntoView();
    }
}

function scrollFocusIntoView() {
    let el = document.activeElement;
    let posY = el.getBoundingClientRect().top;
    let height = el.offsetHeight;
    let headerHeight = el.parentNode.parentNode.offsetTop;
    if (window.innerHeight > window.innerWidth) {
        headerHeight += domCache.header.offsetHeight;
    }
    let footerHeight = domCache.footer.offsetHeight;
    let parentHeight = window.innerHeight - headerHeight - footerHeight;
    let treshold = height / 2;
    //console.log('posY: ' + posY);
    //console.log('height: ' + height);
    //console.log('treshold: ' + treshold);
    //console.log('parentHeight: ' + parentHeight);
    //console.log('headerHeight:' + headerHeight);
    //console.log('footerHeight:' + footerHeight);
    if (posY <= headerHeight + treshold) {
        //console.log('0, - height');
        window.scrollBy(0, - height);
    }
    else if (posY + height > parentHeight - treshold) {
        //console.log('0, height');
        window.scrollBy(0, height);
    }
}

function navigateTable(table, keyCode) {
    let cur = document.activeElement;
    if (cur) {
        let next = null;
        let handled = false;
        if (keyCode === 'ArrowDown') {
            next = cur.nextElementSibling;
            handled = true;
        }
        else if (keyCode === 'ArrowUp') {
            next = cur.previousElementSibling;
            handled = true;
        }
        else if (keyCode === ' ') {
            let popupBtn = cur.lastChild.firstChild;
            if (popupBtn.nodeName === 'A') {
                popupBtn.click();
            }
            handled = true;
        }
        else if (keyCode === 'Enter') {
            cur.firstChild.click();
            handled = true;
        }
        else if (keyCode === 'Escape') {
            cur.blur();
            cur.classList.remove('selected');
            handled = true;
        }
        if (handled === true) {
            event.preventDefault();
            event.stopPropagation();
        }
        if (next) {
            cur.classList.remove('selected');
            next.classList.add('selected');
            next.focus();
            scrollFocusIntoView();
        }
    }
}

function dragAndDropTable(table) {
    let tableBody=document.getElementById(table).getElementsByTagName('tbody')[0];
    tableBody.addEventListener('dragstart', function(event) {
        if (event.target.nodeName === 'TR') {
            event.target.classList.add('opacity05');
            event.dataTransfer.setDragImage(event.target, 0, 0);
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('Text', event.target.getAttribute('id'));
            dragEl = event.target.cloneNode(true);
        }
    }, false);
    tableBody.addEventListener('dragleave', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let target = event.target;
        if (event.target.nodeName === 'TD') {
            target = event.target.parentNode;
        }
        if (target.nodeName === 'TR') {
            target.classList.remove('dragover');
        }
    }, false);
    tableBody.addEventListener('dragover', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let tr = tableBody.getElementsByClassName('dragover');
        let trLen = tr.length;
        for (let i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        let target = event.target;
        if (event.target.nodeName === 'TD') {
            target = event.target.parentNode;
        }
        if (target.nodeName === 'TR') {
            target.classList.add('dragover');
        }
        event.dataTransfer.dropEffect = 'move';
    }, false);
    tableBody.addEventListener('dragend', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let tr = tableBody.getElementsByClassName('dragover');
        let trLen = tr.length;
        for (let i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        if (document.getElementById(event.dataTransfer.getData('Text'))) {
            document.getElementById(event.dataTransfer.getData('Text')).classList.remove('opacity05');
        }
    }, false);
    tableBody.addEventListener('drop', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let target = event.target;
        if (event.target.nodeName === 'TD') {
            target = event.target.parentNode;
        }
        let oldSongpos = document.getElementById(event.dataTransfer.getData('Text')).getAttribute('data-songpos');
        let newSongpos = target.getAttribute('data-songpos');
        document.getElementById(event.dataTransfer.getData('Text')).remove();
        dragEl.classList.remove('opacity05');
        tableBody.insertBefore(dragEl, target);
        let tr = tableBody.getElementsByClassName('dragover');
        let trLen = tr.length;
        for (let i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        document.getElementById(table).classList.add('opacity05');
        if (app.current.app === 'Queue' && app.current.tab === 'Current') {
            sendAPI("MPD_API_QUEUE_MOVE_TRACK", {"from": oldSongpos, "to": newSongpos});
        }
        else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
            playlistMoveTrack(oldSongpos, newSongpos);
        }
    }, false);
}

function dragAndDropTableHeader(table) {
    let tableHeader;
    if (document.getElementById(table + 'List')) {
        tableHeader = document.getElementById(table + 'List').getElementsByTagName('tr')[0];
    }
    else {
        tableHeader = table.getElementsByTagName('tr')[0];
        table = 'BrowseDatabase';
    }

    tableHeader.addEventListener('dragstart', function(event) {
        if (event.target.nodeName === 'TH') {
            event.target.classList.add('opacity05');
            event.dataTransfer.setDragImage(event.target, 0, 0);
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('Text', event.target.getAttribute('data-col'));
            dragEl = event.target.cloneNode(true);
        }
    }, false);
    tableHeader.addEventListener('dragleave', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        if (event.target.nodeName === 'TH') {
            event.target.classList.remove('dragover-th');
        }
    }, false);
    tableHeader.addEventListener('dragover', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        let th = tableHeader.getElementsByClassName('dragover-th');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-th');
        }
        if (event.target.nodeName === 'TH') {
            event.target.classList.add('dragover-th');
        }
        event.dataTransfer.dropEffect = 'move';
    }, false);
    tableHeader.addEventListener('dragend', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        let th = tableHeader.getElementsByClassName('dragover-th');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-th');
        }
        if (this.querySelector('[data-col=' + event.dataTransfer.getData('Text') + ']')) {
            this.querySelector('[data-col=' + event.dataTransfer.getData('Text') + ']').classList.remove('opacity05');
        }
    }, false);
    tableHeader.addEventListener('drop', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        this.querySelector('[data-col=' + event.dataTransfer.getData('Text') + ']').remove();
        dragEl.classList.remove('opacity05');
        tableHeader.insertBefore(dragEl, event.target);
        let th = tableHeader.getElementsByClassName('dragover-th');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-th');
        }
        if (document.getElementById(table + 'List')) {
            document.getElementById(table + 'List').classList.add('opacity05');
            saveCols(table);
        }
        else {
            saveCols(table, this.parentNode.parentNode);
        }
    }, false);
}

function setColTags(table) {
    let tags = settings.tags.slice();
    if (settings.featTags === false) {
        tags.push('Title');
    }
    tags.push('Duration');
    if (table === 'QueueCurrent' || table === 'BrowsePlaylistsDetail' || table === 'QueueLastPlayed') {
        tags.push('Pos');
    }
    if (table === 'BrowseFilesystem') {
        tags.push('Type');
    }
    if (table === 'QueueLastPlayed') {
        tags.push('LastPlayed');
    }
    if (table === 'Playback') {
        tags.push('Filetype');
        tags.push('Fileformat');
        tags.push('LastModified');
        if (settings.featLyrics === true) {
            tags.push('Lyrics');
        }
    }
    
    tags.sort();
    return tags;
}

function setColsChecklist(table) {
    let tagChks = '';
    let tags = setColTags(table);
    for (let i = 0; i < tags.length; i++) {
        if (table === 'Playback' && tags[i] === 'Title') {
            continue;
        }
        tagChks += '<div>' +
            '<button class="btn btn-secondary btn-xs clickable material-icons material-icons-small' +
            (settings['cols' + table].includes(tags[i]) ? ' active' : '') + '" name="' + tags[i] + '">' +
            (settings['cols' + table].includes(tags[i]) ? 'check' : 'radio_button_unchecked') + '</button>' +
            '<label class="form-check-label" for="' + tags[i] + '">&nbsp;&nbsp;' + t(tags[i]) + '</label>' +
            '</div>';
    }
    return tagChks;
}

function setCols(table, className) {
    let colsChkList = document.getElementById(table + 'ColsDropdown');
    if (colsChkList) {
        colsChkList.firstChild.innerHTML = setColsChecklist(table);
    }
    let sort = app.current.sort;
    
    if (table === 'Search' && app.apps.Search.state === '0/any/Title/-/') {
        if (settings.tags.includes('Title')) {
            sort = 'Title';
        }
        else if (settings.featTags === false) {
            sort = 'Filename';
        }
        else {
            sort = '-';
        }
    }
    
    if (table !== 'Playback') {
        let heading = '';
        for (let i = 0; i < settings['cols' + table].length; i++) {
            let h = settings['cols' + table][i];
            heading += '<th draggable="true" data-col="' + h  + '">';
            if (h === 'Track' || h === 'Pos') {
                h = '#';
            }
            heading += t(h);

            if (table === 'Search' && (h === sort || '-' + h === sort) ) {
                let sortdesc = false;
                if (app.current.sort.indexOf('-') === 0) {
                    sortdesc = true;
                }
                heading += '<span class="sort-dir material-icons pull-right">' + (sortdesc === true ? 'arrow_drop_up' : 'arrow_drop_down') + '</span>';
            }
            heading += '</th>';
        }
        if (settings.featTags === true) {
            heading += '<th data-col="Action"><a href="#" class="text-secondary align-middle material-icons material-icons-small">settings</a></th>';
        }
        else {
            heading += '<th></th>';
        }

        if (className === undefined) {
            document.getElementById(table + 'List').getElementsByTagName('tr')[0].innerHTML = heading;
        }
        else {
            let tbls = document.querySelectorAll(className);
            for (let i = 0; i < tbls.length; i++) {
                tbls[i].getElementsByTagName('tr')[0].innerHTML = heading;
            }
        }
    }
}

function saveCols(table, tableEl) {
    let colsDropdown = document.getElementById(table + 'ColsDropdown');
    let header;
    if (tableEl === undefined) {
        header = document.getElementById(table + 'List').getElementsByTagName('tr')[0];
    }
    else if (typeof(tableEl) === 'string') {
        header = document.querySelector(tableEl).getElementsByTagName('tr')[0];
    }
    else {
        header = tableEl.getElementsByTagName('tr')[0];
    }
    if (colsDropdown) {
        let colInputs = colsDropdown.firstChild.getElementsByTagName('button');
        for (let i = 0; i < colInputs.length; i++) {
            if (colInputs[i].getAttribute('name') === null) {
                continue;
            }
            let th = header.querySelector('[data-col=' + colInputs[i].name + ']');
            if (colInputs[i].classList.contains('active') === false) {
                if (th) {
                    th.remove();
                }
            } 
            else if (!th) {
                th = document.createElement('th');
                th.innerText = colInputs[i].name;
                th.setAttribute('data-col', colInputs[i].name);
                header.insertBefore(th, header.lastChild);
            }
        }
    }
    
    let params = {"table": "cols" + table, "cols": []};
    let ths = header.getElementsByTagName('th');
    for (let i = 0; i < ths.length; i++) {
        let name = ths[i].getAttribute('data-col');
        if (name !== 'Action' && name !== null) {
            params.cols.push(name);
        }
    }
    sendAPI("MYMPD_API_COLS_SAVE", params, getSettings);
}

//eslint-disable-next-line no-unused-vars
function saveColsPlayback(table) {
    let colInputs = document.getElementById(table + 'ColsDropdown').firstChild.getElementsByTagName('button');
    let header = document.getElementById('cardPlaybackTags');

    for (let i = 0; i < colInputs.length -1; i++) {
        let th = document.getElementById('current' + colInputs[i].name);
        if (colInputs[i].classList.contains('active') === false) {
            if (th) {
                th.remove();
            }
        } 
        else if (!th) {
            th = document.createElement('div');
            th.innerHTML = '<small>' + t(colInputs[i].name) + '</small><p></p>';
            th.setAttribute('id', 'current' + colInputs[i].name);
            th.setAttribute('data-tag', colInputs[i].name);
            header.appendChild(th);
        }
    }
    
    let params = {"table": "cols" + table, "cols": []};
    let ths = header.getElementsByTagName('div');
    for (let i = 0; i < ths.length; i++) {
        let name = ths[i].getAttribute('data-tag');
        if (name) {
            params.cols.push(name);
        }
    }
    sendAPI("MYMPD_API_COLS_SAVE", params, getSettings);
}

function replaceTblRow(row, el) {
    let menuEl = row.querySelector('[data-popover]');
    let result = false;
    if (menuEl) {
        hideMenu();
    }
    if (row.classList.contains('selected')) {
        el.classList.add('selected');
        el.focus();
        result = true;
    }
    row.replaceWith(el);
    return result;
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
var themes = {
    "theme-autodetect": "Autodetect",
    "theme-default": "Default",
    "theme-dark": "Dark",
    "theme-light": "Light"
};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function deleteTimer(timerid) {
    sendAPI("MYMPD_API_TIMER_RM", {"timerid": timerid}, showListTimer);
}

//eslint-disable-next-line no-unused-vars
function toggleTimer(target, timerid) {
    if (target.classList.contains('active')) {
        target.classList.remove('active');
        sendAPI("MYMPD_API_TIMER_TOGGLE", {"timerid": timerid, "enabled": false}, showListTimer);
    }
    else {
        target.classList.add('active');
        sendAPI("MYMPD_API_TIMER_TOGGLE", {"timerid": timerid, "enabled": true}, showListTimer);
    }
}

//eslint-disable-next-line no-unused-vars
function saveTimer() {
    let formOK = true;
    let nameEl = document.getElementById('inputTimerName');
    if (!validateNotBlank(nameEl)) {
        formOK = false;
    }
    let minOneDay = false;
    let weekdayBtns = ['btnTimerMon', 'btnTimerTue', 'btnTimerWed', 'btnTimerThu', 'btnTimerFri', 'btnTimerSat', 'btnTimerSun'];
    let weekdays = [];
    for (let i = 0; i < weekdayBtns.length; i++) {
        let checked = document.getElementById(weekdayBtns[i]).classList.contains('active') ? true : false;
        weekdays.push(checked);
        if (checked === true) {
            minOneDay = true;
        }
    }
    if (minOneDay === false) {
        formOK = false;
        document.getElementById('invalidTimerWeekdays').style.display = 'block';
    }
    else {
        document.getElementById('invalidTimerWeekdays').style.display = 'none';
    }
    let selectTimerAction = document.getElementById('selectTimerAction');
    let selectTimerPlaylist = document.getElementById('selectTimerPlaylist');
    let selectTimerHour = document.getElementById('selectTimerHour');
    let selectTimerMinute = document.getElementById('selectTimerMinute');
    let jukeboxMode = document.getElementById('btnTimerJukeboxModeGroup').getElementsByClassName('active')[0].getAttribute('data-value');

    if (selectTimerAction.selectedIndex === -1) {
        formOK = false;
        selectTimerAction.classList.add('is-invalid');
    }

    if (jukeboxMode === '0' &&
        selectTimerPlaylist.options[selectTimerPlaylist.selectedIndex].value === 'Database'&&
        selectTimerAction.options[selectTimerAction.selectedIndex].value === 'startplay')
    {
        formOK = false;
        document.getElementById('btnTimerJukeboxModeGroup').classList.add('is-invalid');
    }
    
    if (formOK === true) {
        let args = {};
        let argEls = document.getElementById('timerActionScriptArguments').getElementsByTagName('input');
        for (let i = 0; i < argEls.length; i ++) {
            args[argEls[i].getAttribute('data-name')] = argEls[i].value;
        }
        sendAPI("MYMPD_API_TIMER_SAVE", {
            "timerid": parseInt(document.getElementById('inputTimerId').value),
            "name": nameEl.value,
            "enabled": (document.getElementById('btnTimerEnabled').classList.contains('active') ? true : false),
            "startHour": parseInt(selectTimerHour.options[selectTimerHour.selectedIndex].value),
            "startMinute": parseInt(selectTimerMinute.options[selectTimerMinute.selectedIndex].value),
            "weekdays": weekdays,
            "action": selectTimerAction.options[selectTimerAction.selectedIndex].parentNode.getAttribute('data-value'),
            "subaction": selectTimerAction.options[selectTimerAction.selectedIndex].value,
            "volume": parseInt(document.getElementById('inputTimerVolume').value), 
            "playlist": selectTimerPlaylist.options[selectTimerPlaylist.selectedIndex].value,
            "jukeboxMode": parseInt(jukeboxMode),
            "arguments": args
            }, showListTimer);
    }
}

//eslint-disable-next-line no-unused-vars
function showEditTimer(timerid) {
    document.getElementById('timerActionPlay').classList.add('hide');
    document.getElementById('timerActionScript').classList.add('hide');
    document.getElementById('listTimer').classList.remove('active');
    document.getElementById('editTimer').classList.add('active');
    document.getElementById('listTimerFooter').classList.add('hide');
    document.getElementById('editTimerFooter').classList.remove('hide');
        
    if (timerid !== 0) {
        sendAPI("MYMPD_API_TIMER_GET", {"timerid": timerid}, parseEditTimer);
    }
    else {
        sendAPI("MPD_API_PLAYLIST_LIST_ALL", {}, function(obj2) { 
            getAllPlaylists(obj2, 'selectTimerPlaylist', 'Database');
        });
        document.getElementById('inputTimerId').value = '0';
        document.getElementById('inputTimerName').value = '';
        toggleBtnChk('btnTimerEnabled', true);
        document.getElementById('selectTimerHour').value = '12';
        document.getElementById('selectTimerMinute').value = '0';
        document.getElementById('selectTimerAction').value = 'startplay';
        document.getElementById('inputTimerVolume').value = '50';
        document.getElementById('selectTimerPlaylist').value = 'Database';
        toggleBtnGroupValue(document.getElementById('btnTimerJukeboxModeGroup'), 1);
        let weekdayBtns = ['btnTimerMon', 'btnTimerTue', 'btnTimerWed', 'btnTimerThu', 'btnTimerFri', 'btnTimerSat', 'btnTimerSun'];
        for (let i = 0; i < weekdayBtns.length; i++) {
            toggleBtnChk(weekdayBtns[i], false);
        }
        document.getElementById('timerActionPlay').classList.remove('hide');
    }
    document.getElementById('inputTimerName').focus();
    removeIsInvalid(document.getElementById('editTimerForm'));    
    document.getElementById('invalidTimerWeekdays').style.display = 'none';
}

function parseEditTimer(obj) {
    let playlistValue = obj.result.playlist;
    sendAPI("MPD_API_PLAYLIST_LIST_ALL", {}, function(obj2) { 
        getAllPlaylists(obj2, 'selectTimerPlaylist', playlistValue);
    });
    document.getElementById('inputTimerId').value = obj.result.timerid;
    document.getElementById('inputTimerName').value = obj.result.name;
    toggleBtnChk('btnTimerEnabled', obj.result.enabled);
    document.getElementById('selectTimerHour').value = obj.result.startHour;
    document.getElementById('selectTimerMinute').value = obj.result.startMinute;
    document.getElementById('selectTimerAction').value = obj.result.subaction;
    selectTimerActionChange(obj.result.arguments);
    document.getElementById('inputTimerVolume').value = obj.result.volume;
    toggleBtnGroupValue(document.getElementById('btnTimerJukeboxModeGroup'), obj.result.jukeboxMode);
    let weekdayBtns = ['btnTimerMon', 'btnTimerTue', 'btnTimerWed', 'btnTimerThu', 'btnTimerFri', 'btnTimerSat', 'btnTimerSun'];
    for (let i = 0; i < weekdayBtns.length; i++) {
        toggleBtnChk(weekdayBtns[i], obj.result.weekdays[i]);
    }
}

function selectTimerActionChange(values) {
    let el = document.getElementById('selectTimerAction');
    
    if (el.options[el.selectedIndex].value === 'startplay') {
        document.getElementById('timerActionPlay').classList.remove('hide');
        document.getElementById('timerActionScript').classList.add('hide');
    }
    else if (el.options[el.selectedIndex].parentNode.getAttribute('data-value') === 'script') {
        document.getElementById('timerActionScript').classList.remove('hide');
        document.getElementById('timerActionPlay').classList.add('hide');
        showTimerScriptArgs(el.options[el.selectedIndex], values);
    }
    else {
        document.getElementById('timerActionPlay').classList.add('hide');
        document.getElementById('timerActionScript').classList.add('hide');
    }
}

function showTimerScriptArgs(option, values) {
    if (values === undefined) {
        values = {};
    }
    let args = JSON.parse(option.getAttribute('data-arguments'));
    let list = '';
    for (let i = 0; i < args.arguments.length; i++) {
        list += '<div class="form-group row">' +
                  '<label class="col-sm-4 col-form-label" for="timerActionScriptArguments' + i + '">' + e(args.arguments[i]) + '</label>' +
                  '<div class="col-sm-8">' +
                    '<input name="timerActionScriptArguments' + i + '" class="form-control border-secondary" type="text" value="' +
                    (values[args.arguments[i]] ? e(values[args.arguments[i]]) : '') + '"' +
                    'data-name="' + args.arguments[i] + '">' +
                  '</div>' +
                '</div>';
    }
    if (args.arguments.length === 0) {
        list = 'No arguments';
    }
    document.getElementById('timerActionScriptArguments').innerHTML = list;
}

function showListTimer() {
    document.getElementById('listTimer').classList.add('active');
    document.getElementById('editTimer').classList.remove('active');
    document.getElementById('listTimerFooter').classList.remove('hide');
    document.getElementById('editTimerFooter').classList.add('hide');
    sendAPI("MYMPD_API_TIMER_LIST", {}, parseListTimer);
}

function parseListTimer(obj) {
    let tbody = document.getElementById('listTimer').getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    
    let activeRow = 0;
    let weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    for (let i = 0; i < obj.result.returnedEntities; i++) {
        let row = document.createElement('tr');
        row.setAttribute('data-id', obj.result.data[i].timerid);
        let tds = '<td>' + e(obj.result.data[i].name) + '</td>' +
                  '<td><button name="enabled" class="btn btn-secondary btn-xs clickable material-icons material-icons-small' +
                  (obj.result.data[i].enabled === true ? ' active' : '') + '">' +
                  (obj.result.data[i].enabled === true ? 'check' : 'radio_button_unchecked') + '</button></td>' +
                  '<td>' + zeroPad(obj.result.data[i].startHour, 2) + ':' + zeroPad(obj.result.data[i].startMinute,2) + ' ' + t('on') + ' ';
        let days = [];
        for (let j = 0; j < 7; j++) {
            if (obj.result.data[i].weekdays[j] === true) {
                days.push(t(weekdays[j]))
            }
        }
        tds += days.join(', ')  + '</td><td>' + prettyTimerAction(obj.result.data[i].action, obj.result.data[i].subaction) + '</td>' +
               '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">delete</a></td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= obj.result.returnedEntities; i --) {
        tr[i].remove();
    }

    if (obj.result.returnedEntities === 0) {
        tbody.innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="4">' + t('Empty list') + '</td></tr>';
    }     
}

function prettyTimerAction(action, subaction) {
    if (action === 'player' && subaction === 'startplay') {
        return t('Start playback');
    }
    if (action === 'player' && subaction === 'stopplay') {
        return t('Stop playback');
    }
    if (action === 'syscmd') {
        return t('System command') + ': ' + e(subaction);
    }
    if (action === 'script') {
        return t('Script') + ': ' + e(subaction);
    }
    return e(action) + ': ' + e(subaction);
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function saveTrigger() {
    let formOK = true;
    
    let nameEl = document.getElementById('inputTriggerName');
    if (!validatePlnameEl(nameEl)) {
        formOK = false;
    }
    
    if (formOK === true) {
        let args = {};
        let argEls = document.getElementById('triggerActionScriptArguments').getElementsByTagName('input');
        for (let i = 0; i < argEls.length; i ++) {
            args[argEls[i].getAttribute('data-name')] = argEls[i].value;
        }

        sendAPI("MPD_API_TRIGGER_SAVE", {
            "id": parseInt(document.getElementById('inputTriggerId').value),
            "name": nameEl.value,
            "event": getSelectValue('selectTriggerEvent'),
            "script": getSelectValue('selectTriggerScript'),
            "arguments": args
            }, showListTrigger, false);
    }
}

//eslint-disable-next-line no-unused-vars
function showEditTrigger(id) {
    document.getElementById('listTrigger').classList.remove('active');
    document.getElementById('newTrigger').classList.add('active');
    document.getElementById('listTriggerFooter').classList.add('hide');
    document.getElementById('newTriggerFooter').classList.remove('hide');
    
    const nameEl = document.getElementById('inputTriggerName');
    nameEl.classList.remove('is-invalid');
    nameEl.value = '';
    nameEl.focus();
    document.getElementById('inputTriggerId').value = '-1';
    document.getElementById('selectTriggerEvent').selectedIndex = 0;
    document.getElementById('selectTriggerScript').selectedIndex = 0;
    if (id > -1) {
        sendAPI("MPD_API_TRIGGER_GET", {"id": id}, parseTriggerEdit, false);
    }
    else {
        selectTriggerActionChange();
    }
}

function parseTriggerEdit(obj) {
    document.getElementById('inputTriggerId').value = obj.result.id;
    document.getElementById('inputTriggerName').value = obj.result.name;
    document.getElementById('selectTriggerEvent').value = obj.result.event;
    document.getElementById('selectTriggerScript').value = obj.result.script;
    selectTriggerActionChange(obj.result.arguments);
}

function selectTriggerActionChange(values) {
    let el = document.getElementById('selectTriggerScript');
    showTriggerScriptArgs(el.options[el.selectedIndex], values);
}

function showTriggerScriptArgs(option, values) {
    if (values === undefined) {
        values = {};
    }
    let args = JSON.parse(option.getAttribute('data-arguments'));
    let list = '';
    for (let i = 0; i < args.arguments.length; i++) {
        list += '<div class="form-group row">' +
                  '<label class="col-sm-4 col-form-label" for="triggerActionScriptArguments' + i + '">' + e(args.arguments[i]) + '</label>' +
                  '<div class="col-sm-8">' +
                    '<input name="triggerActionScriptArguments' + i + '" class="form-control border-secondary" type="text" value="' +
                    (values[args.arguments[i]] ? e(values[args.arguments[i]]) : '') + '"' +
                    'data-name="' + args.arguments[i] + '">' +
                  '</div>' +
                '</div>';
    }
    if (args.arguments.length === 0) {
        list = 'No arguments';
    }
    document.getElementById('triggerActionScriptArguments').innerHTML = list;
}

function showListTrigger() {
    document.getElementById('listTrigger').classList.add('active');
    document.getElementById('newTrigger').classList.remove('active');
    document.getElementById('listTriggerFooter').classList.remove('hide');
    document.getElementById('newTriggerFooter').classList.add('hide');
    sendAPI("MPD_API_TRIGGER_LIST", {}, parseTriggerList, false);
}

function deleteTrigger(id) {
    sendAPI("MPD_API_TRIGGER_DELETE", {"id": id}, function() {
        sendAPI("MPD_API_TRIGGER_LIST", {}, parseTriggerList, false);
    }, true);
}

function parseTriggerList(obj) {
    if (obj.result.data.length > 0) {
        let triggerList = '';
        for (let i = 0; i < obj.result.data.length; i++) {
            triggerList += '<tr data-trigger-id="' + encodeURI(obj.result.data[i].id) + '"><td class="' +
                (obj.result.data[i].name === settings.trigger ? 'font-weight-bold' : '') +
                '">' + e(obj.result.data[i].name) + 
                '</td>' +
                '<td>' + t(obj.result.data[i].eventName) + '</td>' +
                '<td>' + e(obj.result.data[i].script) + '</td>' +
                '<td data-col="Action">' +
                (obj.result.data[i].name === 'default' || obj.result.data[i].name === settings.trigger  ? '' : 
                    '<a href="#" title="' + t('Delete') + '" data-action="delete" class="material-icons color-darkgrey">delete</a>') +
                '</td></tr>';
        }
        document.getElementById('listTriggerList').innerHTML = triggerList;
    }
    else {
        document.getElementById('listTriggerList').innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="2">' + t('Empty list') + '</td></tr>';
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function removeIsInvalid(el) {
    let els = el.querySelectorAll('.is-invalid');
    for (let i = 0; i < els.length; i++) {
        els[i].classList.remove('is-invalid');
    }
}

function getSelectValue(selectId) {
    let el = document.getElementById(selectId);
    return el.options[el.selectedIndex].value;
}

function alignDropdown(el) {
    const x = getXpos(el.children[0]);
    
    if (x < domCache.body.offsetWidth * 0.66) {
        if (el.id === 'navState') {
            el.classList.remove('dropdown');
            el.classList.add('dropright');
        }
        else {
            el.getElementsByClassName('dropdown-menu')[0].classList.remove('dropdown-menu-right');
        }
    }
    else {
        el.getElementsByClassName('dropdown-menu')[0].classList.add('dropdown-menu-right');
        el.classList.add('dropdown');
        el.classList.remove('dropright');
    }
}

function getXpos(el) {
    var xPos = 0;
    while (el) {
        xPos += (el.offsetLeft - el.scrollLeft + el.clientLeft);
        el = el.offsetParent;
    }
    return xPos;
}

function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

function dirname(uri) {
    return uri.replace(/\/[^/]*$/, '');
}

function basename(uri, removeQuery) {
    if (removeQuery === true) {
        return uri.split('/').reverse()[0].split(/[?#]/)[0];
    }
    else {
        return uri.split('/').reverse()[0];
    }
}

function filetype(uri) {
    if (uri === undefined) {
        return '';
    }
    let ext = uri.split('.').pop().toUpperCase();
    switch (ext) {
        case 'MP3':  return ext + ' - MPEG-1 Audio Layer III';
        case 'FLAC': return ext + ' - Free Lossless Audio Codec';
        case 'OGG':  return ext + ' - Ogg Vorbis';
        case 'OPUS': return ext + ' - Opus Audio';
        case 'WAV':  return ext + ' - WAVE Audio File';
        case 'WV':   return ext + ' - WavPack';
        case 'AAC':  return ext + ' - Advancded Audio Coding';
        case 'MPC':  return ext + ' - Musepack';
        case 'MP4':  return ext + ' - MPEG-4';
        case 'APE':  return ext + ' - Monkey Audio ';
        case 'WMA':  return ext + ' - Windows Media Audio';
        default:     return ext;
    }
}

function fileformat(audioformat) {
    return audioformat.bits + t('bits') + ' - ' + audioformat.sampleRate / 1000 + t('kHz');
}

function scrollToPosY(pos) {
    document.body.scrollTop = pos; // For Safari
    document.documentElement.scrollTop = pos; // For Chrome, Firefox, IE and Opera
}

function doSetFilterLetter(x) {
    let af = document.getElementById(x + 'Letters').getElementsByClassName('active')[0];
    if (af) {
        af.classList.remove('active');
    }
    let filter = app.current.filter;
    if (filter === '0') {
        filter = '#';
    }
    
    document.getElementById(x).innerHTML = '<span class="material-icons">filter_list</span>' + (filter !== '-' ? ' ' + filter : '');
    
    if (filter !== '-') {
        let btns = document.getElementById(x + 'Letters').getElementsByTagName('button');
        let btnsLen = btns.length;
        for (let i = 0; i < btnsLen; i++) {
            if (btns[i].innerText === filter) {
                btns[i].classList.add('active');
                break;
            }
        }
    }
}

function addFilterLetter(x) {
    let filter = '<button class="mr-1 mb-1 btn btn-sm btn-secondary material-icons material-icons-small">delete</button>' +
        '<button class="mr-1 mb-1 btn btn-sm btn-secondary">#</button>';
    for (let i = 65; i <= 90; i++) {
        filter += '<button class="mr-1 mb-1 btn-sm btn btn-secondary">' + String.fromCharCode(i) + '</button>';
    }

    let letters = document.getElementById(x);
    letters.innerHTML = filter;
    
    letters.addEventListener('click', function(event) {
        switch (event.target.innerText) {
            case 'delete':
                filter = '-';
                break;
            case '#':
                filter = '0';
                break;
            default:
                filter = event.target.innerText;
        }
        appGoto(app.current.app, app.current.tab, app.current.view, '0/' + filter + '/' + app.current.sort + '/' + 
            app.current.tag + '/' + app.current.search);
    }, false);
}

function selectTag(btnsEl, desc, setTo) {
    let btns = document.getElementById(btnsEl);
    let aBtn = btns.querySelector('.active')
    if (aBtn) {
        aBtn.classList.remove('active');
    }
    aBtn = btns.querySelector('[data-tag=' + setTo + ']');
    if (aBtn) {
        aBtn.classList.add('active');
        if (desc !== undefined) {
            document.getElementById(desc).innerText = aBtn.innerText;
            document.getElementById(desc).setAttribute('data-phrase', aBtn.innerText);
        }
    }
}

function addTagList(el, list) {
    let tagList = '';
    if (list === 'searchtags') {
        if (settings.featTags === true) {
            tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="any">' + t('Any Tag') + '</button>';
        }
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="filename">' + t('Filename') + '</button>';
    }
    for (let i = 0; i < settings[list].length; i++) {
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="' + settings[list][i] + '">' + t(settings[list][i]) + '</button>';
    }
    if (el === 'BrowseNavFilesystemDropdown' || el === 'BrowseNavPlaylistsDropdown') {
        tagList = '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Database">Database</button>';
    }
    if (el === 'BrowseDatabaseByTagDropdown' || el === 'BrowseNavFilesystemDropdown' || el === 'BrowseNavPlaylistsDropdown') {
        if (el === 'BrowseDatabaseByTagDropdown') {
            tagList += '<div class="dropdown-divider"></div>';
        }
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block' + (el === 'BrowseNavPlaylistsDropdown' ? ' active' : '') + '" data-tag="Playlists">' + t('Playlists') + '</button>' +
            '<button type="button" class="btn btn-secondary btn-sm btn-block' + (el === 'BrowseNavFilesystemDropdown' ? ' active' : '') + '" data-tag="Filesystem">' + t('Filesystem') + '</button>'
    }
    else if (el === 'databaseSortTagsList') {
        if (settings.tags.includes('Date')) {
            tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Date">' + t('Date') + '</button>';
        }
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Last-Modified">' + t('Last modified') + '</button>';
    }
    document.getElementById(el).innerHTML = tagList;
}

function addTagListSelect(el, list) {
    let tagList = '';
    if (el === 'saveSmartPlaylistSort' || el === 'selectSmartplsSort') {
        tagList += '<option value="">' + t('Disabled') + '</option>';
        tagList += '<option value="shuffle">' + t('Shuffle') + '</option>';
        tagList += '<optgroup label="' + t('Sort by tag') + '">';
        tagList += '<option value="filename">' + t('Filename') + '</option>';
    }
    else if (el === 'selectJukeboxUniqueTag' && settings.browsetags.includes('Title') === false) {
        //Title tag should be always in the list
        tagList = '<option value="Title">' + t('Song') + '</option>';
    }
    for (let i = 0; i < settings[list].length; i++) {
        tagList += '<option value="' + settings[list][i] + '">' + t(settings[list][i]) + '</option>';
    }
    if (el === 'saveSmartPlaylistSort' || el === 'selectSmartplsSort') {
        tagList += '</optgroup>';
    }
    document.getElementById(el).innerHTML = tagList;
}

//eslint-disable-next-line no-unused-vars
function openModal(modal) {
    window[modal].show();
}

//eslint-disable-next-line no-unused-vars
function openDropdown(dropdown) {
    window[dropdown].toggle();
}

//eslint-disable-next-line no-unused-vars
function focusSearch() {
    if (app.current.app === 'Queue') {
        document.getElementById('searchqueuestr').focus();
    }
    else if (app.current.app === 'Search') {
        domCache.searchstr.focus();
    }
    else {
        appGoto('Search');
    }
}

function btnWaiting(btn, waiting) {
    if (waiting === true) {
        let spinner = document.createElement('span');
        spinner.classList.add('spinner-border', 'spinner-border-sm', 'mr-2');
        btn.insertBefore(spinner, btn.firstChild);
        btn.setAttribute('disabled', 'disabled');
    }
    else {
        btn.removeAttribute('disabled');
        if (btn.firstChild.nodeName === 'SPAN') {
            btn.firstChild.remove();
        }
    }
}

function toggleBtnGroupValue(btngrp, value) {
    let btns = btngrp.getElementsByTagName('button');
    let b = btns[0];
    let valuestr = value;
    if (isNaN(value) === false) {
        valuestr = value.toString();
    }
    for (let i = 0; i < btns.length; i++) {
        if (btns[i].getAttribute('data-value') === valuestr) {
            btns[i].classList.add('active');
            b = btns[i];
        }
        else {
            btns[i].classList.remove('active');
        }
    }
    return b;
}

function toggleBtnGroupValueCollapse(btngrp, collapse, value) {
    let activeBtn = toggleBtnGroupValue(btngrp, value);
    if (activeBtn.getAttribute('data-collapse') === 'show') {
        document.getElementById(collapse).classList.add('show');
    }
    else {
        document.getElementById(collapse).classList.remove('show');
    }
}

function toggleBtnGroup(btn) {
    let b = btn;
    if (typeof btn === 'string') {
        b = document.getElementById(btn);
    }
    let btns = b.parentNode.getElementsByTagName('button');
    for (let i = 0; i < btns.length; i++) {
        if (btns[i] === b) {
            btns[i].classList.add('active');
        }
        else {
            btns[i].classList.remove('active');
        }
    }
    return b;
}

function getBtnGroupValue(btnGroup) {
    let activeBtn = document.getElementById(btnGroup).getElementsByClassName('active');
    if (activeBtn.length === 0) {
        activeBtn = document.getElementById(btnGroup).getElementsByTagName('button');    
    }
    return activeBtn[0].getAttribute('data-value');
}

//eslint-disable-next-line no-unused-vars
function toggleBtnGroupCollapse(btn, collapse) {
    let activeBtn = toggleBtnGroup(btn);
    if (activeBtn.getAttribute('data-collapse') === 'show') {
        if (document.getElementById(collapse).classList.contains('show') === false) {
            window[collapse].show();
        }
    }
    else {
        window[collapse].hide();
    }
}

function toggleBtn(btn, state) {
    let b = btn;
    if (typeof btn === 'string') {
        b = document.getElementById(btn);
    }
    if (!b) {
        return;
    }
    if (state === undefined) {
        //toggle state
        state = b.classList.contains('active') ? false : true;
    }

    if (state === true || state === 1) {
        b.classList.add('active');
    }
    else {
        b.classList.remove('active');
    }
}

function toggleBtnChk(btn, state) {
    let b = btn;
    if (typeof btn === 'string') {
        b = document.getElementById(btn);
    }
    if (!b) {
        return;
    }
    if (state === undefined) {
        //toggle state
        state = b.classList.contains('active') ? false : true;
    }

    if (state === true || state === 1) {
        b.classList.add('active');
        b.innerText = 'check';
        return true;
    }
    else {
        b.classList.remove('active');
        b.innerText = 'radio_button_unchecked';
        return false;
    }
}

function toggleBtnChkCollapse(btn, collapse, state) {
    let checked = toggleBtnChk(btn, state);
    if (checked === true) {
        document.getElementById(collapse).classList.add('show');
    }
    else{
        document.getElementById(collapse).classList.remove('show');
    }
}

function setPagination(total, returned) {
    let cat = app.current.app + (app.current.tab === undefined ? '': app.current.tab);
    let totalPages = Math.ceil(total / settings.maxElementsPerPage);
    if (totalPages === 0) {
        totalPages = 1;
    }
    let p = [ document.getElementById(cat + 'PaginationTop'), document.getElementById(cat + 'PaginationBottom') ];
    
    for (let i = 0; i < p.length; i++) {
        let prev = p[i].children[0];
        let page = p[i].children[1].children[0];
        let pages = p[i].children[1].children[1];
        let next = p[i].children[2];
    
        page.innerText = (app.current.page / settings.maxElementsPerPage + 1) + ' / ' + totalPages;
        if (totalPages > 1) {
            page.removeAttribute('disabled');
            let pl = '';
            for (let j = 0; j < totalPages; j++) {
                pl += '<button data-page="' + (j * settings.maxElementsPerPage) + '" type="button" class="mr-1 mb-1 btn-sm btn btn-secondary">' +
                      ( j + 1) + '</button>';
            }
            pages.innerHTML = pl;
            page.classList.remove('nodropdown');
        }
        else if (total === -1) {
            page.setAttribute('disabled', 'disabled');
            page.innerText = (app.current.page / settings.maxElementsPerPage + 1);
            page.classList.add('nodropdown');
        }
        else {
            page.setAttribute('disabled', 'disabled');
            page.classList.add('nodropdown');
        }
        
        if (total > app.current.page + settings.maxElementsPerPage || total === -1 && returned >= settings.maxElementsPerPage) {
            next.removeAttribute('disabled');
            p[i].classList.remove('hide');
            document.getElementById(cat + 'ButtonsBottom').classList.remove('hide');
        }
        else {
            next.setAttribute('disabled', 'disabled');
            p[i].classList.add('hide');
            document.getElementById(cat + 'ButtonsBottom').classList.add('hide');
        }
    
        if (app.current.page > 0) {
            prev.removeAttribute('disabled');
            p[i].classList.remove('hide');
            document.getElementById(cat + 'ButtonsBottom').classList.remove('hide');
        }
        else {
            prev.setAttribute('disabled', 'disabled');
        }
    }
}

function genId(x) {
    return 'id' + x.replace(/[^\w-]/g, '');
}

function parseCmd(event, href) {
    event.preventDefault();
    let cmd = href;
    if (typeof(href) === 'string') {
        cmd = JSON.parse(href);
    }

    if (typeof window[cmd.cmd] === 'function') {
        switch(cmd.cmd) {
            case 'sendAPI':
                sendAPI(cmd.options[0].cmd, {}); 
                break;
            case 'toggleBtn':
            case 'toggleBtnChk':
            case 'toggleBtnGroup':
            case 'toggleBtnGroupCollapse':
            case 'setPlaySettings':
                window[cmd.cmd](event.target, ... cmd.options);
                break;
            case 'toggleBtnChkCollapse':
                window[cmd.cmd](event.target, undefined, ... cmd.options);
                break;
            default:
                window[cmd.cmd](... cmd.options);
        }
    }
    else {
        logError('Can not execute cmd: ' + cmd);
    }
}

function gotoPage(x) {
    switch (x) {
        case 'next':
            app.current.page += settings.maxElementsPerPage;
            break;
        case 'prev':
            app.current.page -= settings.maxElementsPerPage;
            if (app.current.page < 0) {
                app.current.page = 0;
            }
            break;
        default:
            app.current.page = x;
    }
    appGoto(app.current.app, app.current.tab, app.current.view, app.current.page + '/' + app.current.filter + '/' + 
        app.current.sort + '/' + app.current.tag + '/' + app.current.search);
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function validateFilenameString(str) {
    if (str === '') {
        return false;
    }
    else if (str.match(/^[\w-.]+$/) !== null) {
        return true;
    }
    else {
        return false;
    }
}

function validateFilename(el) {
    if (validateFilenameString(el.value) === false) {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateFilenameList(el) {
    el.classList.remove('is-invalid');
    
    let filenames = el.value.split(',');
    for (let i = 0; i < filenames.length; i++) {
        if (validateFilenameString(filenames[i].trim()) === false) {
            el.classList.add('is-invalid');
            return false;
        }
    }
    return true;
}

function validatePath(el) {
    if (el.value === '') {
        el.classList.add('is-invalid');
        return false;
    }
    else if (el.value.match(/^\/[/.\w-]+$/) !== null) {
        el.classList.remove('is-invalid');
        return true;
    }
    else {
        el.classList.add('is-invalid');
        return false;
    }
}

function validatePlnameEl(el) {
    if (validatePlname(el.value) === false) {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validatePlname(x) {
    if (x === '') {
        return false;
    }
    else if (x.match(/\/|\r|\n|"|'/) === null) {
        return true;
    }
    else {
        return false;
    }
}

function validateNotBlank(el) {
    let value = el.value.replace(/\s/g, '');
    if (value === '') {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateInt(el) {
    let value = el.value.replace(/\d/g, '');
    if (value !== '') {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateFloat(el) {
    let value = el.value.replace(/[\d-.]/g, '');
    if (value !== '') {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateStream(el) {
    if (el.value.indexOf('://') > -1) {
        el.classList.remove('is-invalid');
        return true;
    }
    else {
        el.classList.add('is-invalid');
        return false;
    }
}

function validateHost(el) {
    if (el.value.match(/^([\w-.]+)$/) !== null) {
        el.classList.remove('is-invalid');
        return true;
    }
    else {
        el.classList.add('is-invalid');
        return false;
    }
}
