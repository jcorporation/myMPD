"use strict";
/*!
  * Native JavaScript for Bootstrap v3.0.3 (https://thednp.github.io/bootstrap.native/)
  * Copyright 2015-2020 © dnp_theme
  * Licensed under MIT (https://github.com/thednp/bootstrap.native/blob/master/LICENSE)
  */
(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
  typeof define === 'function' && define.amd ? define(factory) :
  (global = global || self, global.BSN = factory());
}(this, function () { 'use strict';

  function hasClass(element,classNAME) {
    return element.classList.contains(classNAME)
  }

  function removeClass(element,classNAME) {
    element.classList.remove(classNAME);
  }

  function on (element, event, handler, options) {
    options = options || false;
    element.addEventListener(event, handler, options);
  }

  function off (element, event, handler, options) {
    options = options || false;
    element.removeEventListener(event, handler, options);
  }

  function one (element, event, handler, options) {
    on(element, event, function handlerWrapper(e){
      if (e.target === element) {
        handler(e);
        off(element, event, handlerWrapper, options);
      }
    }, options);
  }

  var transitionEndEvent = 'webkitTransition' in document.body.style ? 'webkitTransitionEnd' : 'transitionend';

  var supportTransition = 'webkitTransition' in document.body.style || 'transition' in document.body.style;

  var transitionDuration = 'webkitTransition' in document.body.style ? 'webkitTransitionDuration' : 'transitionDuration';

  function getElementTransitionDuration (element) {
    var duration = supportTransition ? window.getComputedStyle(element)[transitionDuration] : 0;
    duration = parseFloat(duration);
    duration = typeof duration === 'number' && !isNaN(duration) ? duration * 1000 : 0;
    return duration;
  }

  function emulateTransitionEnd (element,handler){
    var called = 0, duration = getElementTransitionDuration(element);
    duration ? one(element, transitionEndEvent, function(e){ !called && handler(e), called = 1; })
             : setTimeout(function() { !called && handler(), called = 1; }, 17);
  }

  function queryElement (selector, parent) {
    var lookUp = parent && parent instanceof Element ? parent : document;
    return selector instanceof Element ? selector : lookUp.querySelector(selector);
  }

  function tryWrapper (fn,origin){
    try{ fn(); }
    catch(e){
      console.error((origin + ": " + e));
    }
  }

  function bootstrapCustomEvent (eventName, componentName, related) {
    var OriginalCustomEvent = new CustomEvent( eventName + '.bs.' + componentName, {cancelable: true});
    OriginalCustomEvent.relatedTarget = related;
    return OriginalCustomEvent;
  }
  function dispatchCustomEvent (customEvent){
    this && this.dispatchEvent(customEvent);
  }

  function Alert(element) {
    var self = this,
      alert,
      closeCustomEvent = bootstrapCustomEvent('close','alert'),
      closedCustomEvent = bootstrapCustomEvent('closed','alert');
    function triggerHandler() {
      hasClass(alert,'fade') ? emulateTransitionEnd(alert,transitionEndHandler) : transitionEndHandler();
    }
    function clickHandler(e) {
      alert = e && e.target.closest(".alert");
      element = queryElement('[data-dismiss="alert"]',alert);
      element && alert && (element === e.target || element.contains(e.target)) && self.close();
    }
    function transitionEndHandler() {
      off(element, 'click', clickHandler);
      alert.parentNode.removeChild(alert);
      dispatchCustomEvent.call(alert,closedCustomEvent);
    }
    self.close = function () {
      if ( alert && element && hasClass(alert,'show') ) {
        dispatchCustomEvent.call(alert,closeCustomEvent);
        if ( closeCustomEvent.defaultPrevented ) { return; }
        self.dispose();
        removeClass(alert,'show');
        triggerHandler();
      }
    };
    self.dispose = function () {
      off(element, 'click', clickHandler);
      delete element.Alert;
    };
    tryWrapper(function (){
      element = queryElement(element);
      alert = element.closest('.alert');
      element.Alert && element.Alert.dispose();
      if ( !element.Alert ) {
        on(element, 'click', clickHandler);
      }
      self.element = element;
      element.Alert = self;
    },"BSN.Alert");
  }

  function addClass(element,classNAME) {
    element.classList.add(classNAME);
  }

  function Button(element) {
    var self = this, labels,
        changeCustomEvent = bootstrapCustomEvent('change', 'button');
    function toggle(e) {
      var input,
          label = e.target.tagName === 'LABEL' ? e.target
                : e.target.closest('LABEL') ? e.target.closest('LABEL') : null;
      input = label && label.getElementsByTagName('INPUT')[0];
      if ( !input ) { return; }
      dispatchCustomEvent.call(input, changeCustomEvent);
      dispatchCustomEvent.call(element, changeCustomEvent);
      if ( input.type === 'checkbox' ) {
        if ( changeCustomEvent.defaultPrevented ) { return; }
        if ( !input.checked ) {
          addClass(label,'active');
          input.getAttribute('checked');
          input.setAttribute('checked','checked');
          input.checked = true;
        } else {
          removeClass(label,'active');
          input.getAttribute('checked');
          input.removeAttribute('checked');
          input.checked = false;
        }
        if (!element.toggled) {
          element.toggled = true;
        }
      }
      if ( input.type === 'radio' && !element.toggled ) {
        if ( changeCustomEvent.defaultPrevented ) { return; }
        if ( !input.checked || (e.screenX === 0 && e.screenY == 0) ) {
          addClass(label,'active');
          addClass(label,'focus');
          input.setAttribute('checked','checked');
          input.checked = true;
          element.toggled = true;
          Array.from(labels).map(function (otherLabel){
            var otherInput = otherLabel.getElementsByTagName('INPUT')[0];
            if ( otherLabel !== label && hasClass(otherLabel,'active') )  {
              dispatchCustomEvent.call(otherInput, changeCustomEvent);
              removeClass(otherLabel,'active');
              otherInput.removeAttribute('checked');
              otherInput.checked = false;
            }
          });
        }
      }
      setTimeout( function () { element.toggled = false; }, 50 );
    }
    function keyHandler(e) {
      var key = e.which || e.keyCode;
      key === 32 && e.target === document.activeElement && toggle(e);
    }
    function preventScroll(e) {
      var key = e.which || e.keyCode;
      key === 32 && e.preventDefault();
    }
    function focusToggle(e) {
      var action = e.type === 'focusin' ? addClass : removeClass;
      if (e.target.tagName === 'INPUT' ) {
        action(e.target.closest('.btn'),'focus');
      }
    }
    function toggleEvents(action) {
      action( element, 'click', toggle );
      action( element, 'keyup', keyHandler ), action( element, 'keydown', preventScroll );
      action( element, 'focusin', focusToggle), action( element, 'focusout', focusToggle);
    }
    self.dispose = function () {
      toggleEvents(off);
      delete element.Button;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Button && element.Button.dispose();
      labels = element.getElementsByClassName('btn');
      if (!labels.length) { return; }
      if ( !element.Button ) {
        toggleEvents(on);
      }
      element.toggled = false;
      element.Button = self;
      Array.from(labels).map(function (btn){
        !hasClass(btn,'active')
          && queryElement('input:checked',btn)
          && addClass(btn,'active');
        hasClass(btn,'active')
          && !queryElement('input:checked',btn)
          && removeClass(btn,'active');
      });
    },"BSN.Button");
  }

  var touchEvents = { start: 'touchstart', end: 'touchend', move:'touchmove', cancel:'touchcancel' };

  var mouseHoverEvents = ('onmouseleave' in document) ? [ 'mouseenter', 'mouseleave'] : [ 'mouseover', 'mouseout' ];

  var supportPassive = (function () {
    var result = false;
    try {
      var opts = Object.defineProperty({}, 'passive', {
        get: function() {
          result = true;
        }
      });
      one(document, 'DOMContentLoaded', function (){}, opts);
    } catch (e) {}
    return result;
  })();

  var passiveHandler = supportPassive ? { passive: true } : false;

  function isElementInScrollRange(element) {
    var bcr = element.getBoundingClientRect(),
        viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    return bcr.top <= viewportHeight && bcr.bottom >= 0;
  }

  function Carousel (element,options) {
    options = options || {};
    var self = this,
      vars, ops,
      slideCustomEvent, slidCustomEvent,
      slides, leftArrow, rightArrow, indicator, indicators;
    function pauseHandler() {
      if ( ops.interval !==false && !hasClass(element,'paused') ) {
        addClass(element,'paused');
        !vars.isSliding && ( clearInterval(vars.timer), vars.timer = null );
      }
    }
    function resumeHandler() {
      if ( ops.interval !== false && hasClass(element,'paused') ) {
        removeClass(element,'paused');
        !vars.isSliding && ( clearInterval(vars.timer), vars.timer = null );
        !vars.isSliding && self.cycle();
      }
    }
    function indicatorHandler(e) {
      e.preventDefault();
      if (vars.isSliding) { return; }
      var eventTarget = e.target;
      if ( eventTarget && !hasClass(eventTarget,'active') && eventTarget.getAttribute('data-slide-to') ) {
        vars.index = parseInt( eventTarget.getAttribute('data-slide-to'));
      } else { return false; }
      self.slideTo( vars.index );
    }
    function controlsHandler(e) {
      e.preventDefault();
      if (vars.isSliding) { return; }
      var eventTarget = e.currentTarget || e.srcElement;
      if ( eventTarget === rightArrow ) {
        vars.index++;
      } else if ( eventTarget === leftArrow ) {
        vars.index--;
      }
      self.slideTo( vars.index );
    }
    function keyHandler(ref) {
      var which = ref.which;
      if (vars.isSliding) { return; }
      switch (which) {
        case 39:
          vars.index++;
          break;
        case 37:
          vars.index--;
          break;
        default: return;
      }
      self.slideTo( vars.index );
    }
    function toggleEvents(action) {
      if ( ops.pause && ops.interval ) {
        action( element, mouseHoverEvents[0], pauseHandler );
        action( element, mouseHoverEvents[1], resumeHandler );
        action( element, touchEvents.start, pauseHandler, passiveHandler );
        action( element, touchEvents.end, resumeHandler, passiveHandler );
      }
      ops.touch && slides.length > 1 && action( element, touchEvents.start, touchDownHandler, passiveHandler );
      rightArrow && action( rightArrow, 'click', controlsHandler );
      leftArrow && action( leftArrow, 'click', controlsHandler );
      indicator && action( indicator, 'click', indicatorHandler );
      ops.keyboard && action( window, 'keydown', keyHandler );
    }
    function toggleTouchEvents(action) {
      action( element, touchEvents.move, touchMoveHandler, passiveHandler );
      action( element, touchEvents.end, touchEndHandler, passiveHandler );
    }
    function touchDownHandler(e) {
      if ( vars.isTouch ) { return; }
      vars.touchPosition.startX = e.changedTouches[0].pageX;
      if ( element.contains(e.target) ) {
        vars.isTouch = true;
        toggleTouchEvents(on);
      }
    }
    function touchMoveHandler(e) {
      if ( !vars.isTouch ) { e.preventDefault(); return; }
      vars.touchPosition.currentX = e.changedTouches[0].pageX;
      if ( e.type === 'touchmove' && e.changedTouches.length > 1 ) {
        e.preventDefault();
        return false;
      }
    }
    function touchEndHandler (e) {
      if ( !vars.isTouch || vars.isSliding ) { return }
      vars.touchPosition.endX = vars.touchPosition.currentX || e.changedTouches[0].pageX;
      if ( vars.isTouch ) {
        if ( (!element.contains(e.target) || !element.contains(e.relatedTarget) )
            && Math.abs(vars.touchPosition.startX - vars.touchPosition.endX) < 75 ) {
          return false;
        } else {
          if ( vars.touchPosition.currentX < vars.touchPosition.startX ) {
            vars.index++;
          } else if ( vars.touchPosition.currentX > vars.touchPosition.startX ) {
            vars.index--;
          }
          vars.isTouch = false;
          self.slideTo(vars.index);
        }
        toggleTouchEvents(off);
      }
    }
    function setActivePage(pageIndex) {
      Array.from(indicators).map(function (x){removeClass(x,'active');});
      indicators[pageIndex] && addClass(indicators[pageIndex], 'active');
    }
    function transitionEndHandler(e){
      if (vars.touchPosition){
        var next = vars.index,
            timeout = e && e.target !== slides[next] ? e.elapsedTime*1000+100 : 20,
            activeItem = self.getActiveIndex(),
            orientation = vars.direction === 'left' ? 'next' : 'prev';
        vars.isSliding && setTimeout(function () {
          if (vars.touchPosition){
            vars.isSliding = false;
            addClass(slides[next],'active');
            removeClass(slides[activeItem],'active');
            removeClass(slides[next],("carousel-item-" + orientation));
            removeClass(slides[next],("carousel-item-" + (vars.direction)));
            removeClass(slides[activeItem],("carousel-item-" + (vars.direction)));
            dispatchCustomEvent.call(element, slidCustomEvent);
            if ( !document.hidden && ops.interval && !hasClass(element,'paused') ) {
              self.cycle();
            }
          }
        }, timeout);
      }
    }
    self.cycle = function () {
      if (vars.timer) {
        clearInterval(vars.timer);
        vars.timer = null;
      }
      vars.timer = setInterval(function () {
        var idx = vars.index || self.getActiveIndex();
        isElementInScrollRange(element) && (idx++, self.slideTo( idx ) );
      }, ops.interval);
    };
    self.slideTo = function (next) {
      if (vars.isSliding) { return; }
      var activeItem = self.getActiveIndex(), orientation;
      if ( activeItem === next ) {
        return;
      } else if  ( (activeItem < next ) || (activeItem === 0 && next === slides.length -1 ) ) {
        vars.direction = 'left';
      } else if  ( (activeItem > next) || (activeItem === slides.length - 1 && next === 0 ) ) {
        vars.direction = 'right';
      }
      if ( next < 0 ) { next = slides.length - 1; }
      else if ( next >= slides.length ){ next = 0; }
      orientation = vars.direction === 'left' ? 'next' : 'prev';
      slideCustomEvent = bootstrapCustomEvent('slide', 'carousel', slides[next]);
      slidCustomEvent = bootstrapCustomEvent('slid', 'carousel', slides[next]);
      dispatchCustomEvent.call(element, slideCustomEvent);
      if (slideCustomEvent.defaultPrevented) { return; }
      vars.index = next;
      vars.isSliding = true;
      clearInterval(vars.timer);
      vars.timer = null;
      setActivePage( next );
      if ( getElementTransitionDuration(slides[next]) && hasClass(element,'slide') ) {
        addClass(slides[next],("carousel-item-" + orientation));
        slides[next].offsetWidth;
        addClass(slides[next],("carousel-item-" + (vars.direction)));
        addClass(slides[activeItem],("carousel-item-" + (vars.direction)));
        emulateTransitionEnd(slides[next], transitionEndHandler);
      } else {
        addClass(slides[next],'active');
        slides[next].offsetWidth;
        removeClass(slides[activeItem],'active');
        setTimeout(function () {
          vars.isSliding = false;
          if ( ops.interval && element && !hasClass(element,'paused') ) {
            self.cycle();
          }
          dispatchCustomEvent.call(element, slidCustomEvent);
        }, 100 );
      }
    };
    self.getActiveIndex = function () { return Array.from(slides).indexOf(element.getElementsByClassName('carousel-item active')[0]) || 0; };
    self.dispose = function () {
      var itemClasses = ['left','right','prev','next'];
      Array.from(slides).map(function (slide,idx) {
        hasClass(slide,'active') && setActivePage( idx );
        itemClasses.map(function (cls) { return removeClass(slide,("carousel-item-" + cls)); });
      });
      clearInterval(vars.timer);
      toggleEvents(off);
      vars = {};
      ops = {};
      delete element.Carousel;
    };
    tryWrapper(function (){
      element = queryElement( element );
      element.Carousel && element.Carousel.dispose();
      slides = element.getElementsByClassName('carousel-item');
      leftArrow = element.getElementsByClassName('carousel-control-prev')[0];
      rightArrow = element.getElementsByClassName('carousel-control-next')[0];
      indicator = element.getElementsByClassName('carousel-indicators')[0];
      indicators = indicator && indicator.getElementsByTagName( "LI" ) || [];
      if (slides.length < 2) { return }
      var
        intervalAttribute = element.getAttribute('data-interval'),
        intervalData = intervalAttribute === 'false' ? 0 : parseInt(intervalAttribute),
        touchData = element.getAttribute('data-touch') === 'false' ? 0 : 1,
        pauseData = element.getAttribute('data-pause') === 'hover' || false,
        keyboardData = element.getAttribute('data-keyboard') === 'true' || false,
        intervalOption = options.interval,
        touchOption = options.touch;
      ops = {};
      ops.keyboard = options.keyboard === true || keyboardData;
      ops.pause = (options.pause === 'hover' || pauseData) ? 'hover' : false;
      ops.touch = touchOption || touchData;
      ops.interval = typeof intervalOption === 'number' ? intervalOption
                  : intervalOption === false || intervalData === 0 || intervalData === false ? 0
                  : isNaN(intervalData) ? 5000
                  : intervalData;
      if (self.getActiveIndex()<0) {
        slides.length && addClass(slides[0],'active');
        indicators.length && setActivePage(0);
      }
      vars = {};
      vars.direction = 'left';
      vars.index = 0;
      vars.timer = null;
      vars.isSliding = false;
      vars.isTouch = false;
      vars.touchPosition = {
        startX : 0,
        currentX : 0,
        endX : 0
      };
      toggleEvents(on);
      if ( ops.interval ){ self.cycle(); }
      element.Carousel = self;
    },"BSN.Carousel");
  }

  function Collapse(element,options) {
    options = options || {};
    var self = this;
    var accordion = null,
        collapse = null,
        activeCollapse,
        activeElement,
        showCustomEvent,
        shownCustomEvent,
        hideCustomEvent,
        hiddenCustomEvent;
    function openAction(collapseElement, toggle) {
      dispatchCustomEvent.call(collapseElement, showCustomEvent);
      if ( showCustomEvent.defaultPrevented ) { return; }
      collapseElement.isAnimating = true;
      addClass(collapseElement,'collapsing');
      removeClass(collapseElement,'collapse');
      collapseElement.style.height = (collapseElement.scrollHeight) + "px";
      emulateTransitionEnd(collapseElement, function () {
        collapseElement.isAnimating = false;
        collapseElement.setAttribute('aria-expanded','true');
        toggle.setAttribute('aria-expanded','true');
        removeClass(collapseElement,'collapsing');
        addClass(collapseElement, 'collapse');
        addClass(collapseElement,'show');
        collapseElement.style.height = '';
        dispatchCustomEvent.call(collapseElement, shownCustomEvent);
      });
    }
    function closeAction(collapseElement, toggle) {
      dispatchCustomEvent.call(collapseElement, hideCustomEvent);
      if ( hideCustomEvent.defaultPrevented ) { return; }
      collapseElement.isAnimating = true;
      collapseElement.style.height = (collapseElement.scrollHeight) + "px";
      removeClass(collapseElement,'collapse');
      removeClass(collapseElement,'show');
      addClass(collapseElement,'collapsing');
      collapseElement.offsetWidth;
      collapseElement.style.height = '0px';
      emulateTransitionEnd(collapseElement, function () {
        collapseElement.isAnimating = false;
        collapseElement.setAttribute('aria-expanded','false');
        toggle.setAttribute('aria-expanded','false');
        removeClass(collapseElement,'collapsing');
        addClass(collapseElement,'collapse');
        collapseElement.style.height = '';
        dispatchCustomEvent.call(collapseElement, hiddenCustomEvent);
      });
    }
    self.toggle = function (e) {
      if (e && e.target.tagName === 'A' || element.tagName === 'A') {e.preventDefault();}
      if (element.contains(e.target) || e.target === element) {
        if (!hasClass(collapse,'show')) { self.show(); }
        else { self.hide(); }
      }
    };
    self.hide = function () {
      if ( collapse.isAnimating ) { return; }
      closeAction(collapse,element);
      addClass(element,'collapsed');
    };
    self.show = function () {
      if ( accordion ) {
        activeCollapse = accordion.getElementsByClassName("collapse show")[0];
        activeElement = activeCollapse && (queryElement(("[data-target=\"#" + (activeCollapse.id) + "\"]"),accordion)
                      || queryElement(("[href=\"#" + (activeCollapse.id) + "\"]"),accordion) );
      }
      if ( !collapse.isAnimating ) {
        if ( activeElement && activeCollapse !== collapse ) {
          closeAction(activeCollapse,activeElement);
          addClass(activeElement,'collapsed');
        }
        openAction(collapse,element);
        removeClass(element,'collapsed');
      }
    };
    self.dispose = function () {
      off(element, 'click', self.toggle);
      delete element.Collapse;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Collapse && element.Collapse.dispose();
      var accordionData = element.getAttribute('data-parent');
      showCustomEvent = bootstrapCustomEvent('show', 'collapse');
      shownCustomEvent = bootstrapCustomEvent('shown', 'collapse');
      hideCustomEvent = bootstrapCustomEvent('hide', 'collapse');
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'collapse');
      collapse = queryElement(options.target || element.getAttribute('data-target') || element.getAttribute('href'));
      collapse.isAnimating = false;
      accordion = element.closest(options.parent || accordionData);
      if ( !element.Collapse ) {
        on(element, 'click', self.toggle);
      }
      element.Collapse = self;
    },"BSN.Collapse");
  }

  var mouseClickEvents = { down: 'mousedown', up: 'mouseup' };

  var support3DTransform = 'webkitPerspective' in document.body.style || 'perspective' in document.body.style;

  var supportTransform = 'webkitTransform' in document.body.style || 'transform' in document.body.style;

  function setFocus (element){
    element.focus ? element.focus() : element.setActive();
  }
  function getScroll () {
    return {
      y : window.pageYOffset || document.documentElement.scrollTop,
      x : window.pageXOffset || document.documentElement.scrollLeft
    }
  }
  function styleTip (link,element,position,parent) {
    var tipPositions = /\b(top|bottom|left|right)+/,
        elementDimensions = { w : element.offsetWidth, h: element.offsetHeight },
        windowWidth = (document.documentElement.clientWidth || document.body.clientWidth),
        windowHeight = (document.documentElement.clientHeight || document.body.clientHeight),
        rect = link.getBoundingClientRect(),
        scroll = parent === document.body ? getScroll() : { x: parent.offsetLeft + parent.scrollLeft, y: parent.offsetTop + parent.scrollTop },
        linkDimensions = { w: rect.right - rect.left, h: rect.bottom - rect.top },
        isPopover = hasClass(element,'popover'),
        arrow = queryElement('.arrow',element),
        halfTopExceed = rect.top + linkDimensions.h/2 - elementDimensions.h/2 < 0,
        halfLeftExceed = rect.left + linkDimensions.w/2 - elementDimensions.w/2 < 0,
        halfRightExceed = rect.left + elementDimensions.w/2 + linkDimensions.w/2 >= windowWidth,
        halfBottomExceed = rect.top + elementDimensions.h/2 + linkDimensions.h/2 >= windowHeight,
        topExceed = rect.top - elementDimensions.h < 0,
        leftExceed = rect.left - elementDimensions.w < 0,
        bottomExceed = rect.top + elementDimensions.h + linkDimensions.h >= windowHeight,
        rightExceed = rect.left + elementDimensions.w + linkDimensions.w >= windowWidth;
    position = (position === 'left' || position === 'right') && leftExceed && rightExceed ? 'top' : position;
    position = position === 'top' && topExceed ? 'bottom' : position;
    position = position === 'bottom' && bottomExceed ? 'top' : position;
    position = position === 'left' && leftExceed ? 'right' : position;
    position = position === 'right' && rightExceed ? 'left' : position;
    var topPosition,
      leftPosition,
      arrowTop,
      arrowLeft,
      arrowWidth,
      arrowHeight;
    element.className.indexOf(position) === -1 && (element.className = element.className.replace(tipPositions,position));
    arrowWidth = arrow.offsetWidth; arrowHeight = arrow.offsetHeight;
    if ( position === 'left' || position === 'right' ) {
      if ( position === 'left' ) {
        leftPosition = rect.left + scroll.x - elementDimensions.w - ( isPopover ? arrowWidth : 0 );
      } else {
        leftPosition = rect.left + scroll.x + linkDimensions.w;
      }
      if (halfTopExceed) {
        topPosition = rect.top + scroll.y;
        arrowTop = linkDimensions.h/2 - arrowWidth;
      } else if (halfBottomExceed) {
        topPosition = rect.top + scroll.y - elementDimensions.h + linkDimensions.h;
        arrowTop = elementDimensions.h - linkDimensions.h/2 - arrowWidth;
      } else {
        topPosition = rect.top + scroll.y - elementDimensions.h/2 + linkDimensions.h/2;
        arrowTop = elementDimensions.h/2 - (isPopover ? arrowHeight*0.9 : arrowHeight/2);
      }
    } else if ( position === 'top' || position === 'bottom' ) {
      if ( position === 'top') {
        topPosition =  rect.top + scroll.y - elementDimensions.h - ( isPopover ? arrowHeight : 0 );
      } else {
        topPosition = rect.top + scroll.y + linkDimensions.h;
      }
      if (halfLeftExceed) {
        leftPosition = 0;
        arrowLeft = rect.left + linkDimensions.w/2 - arrowWidth;
      } else if (halfRightExceed) {
        leftPosition = windowWidth - elementDimensions.w*1.01;
        arrowLeft = elementDimensions.w - ( windowWidth - rect.left ) + linkDimensions.w/2 - arrowWidth/2;
      } else {
        leftPosition = rect.left + scroll.x - elementDimensions.w/2 + linkDimensions.w/2;
        arrowLeft = elementDimensions.w/2 - ( isPopover ? arrowWidth : arrowWidth/2 );
      }
    }
    element.style.top = topPosition + 'px';
    element.style.left = leftPosition + 'px';
    arrowTop && (arrow.style.top = arrowTop + 'px');
    arrowLeft && (arrow.style.left = arrowLeft + 'px');
  }

  function Dropdown(element,option) {
    var self = this,
        showCustomEvent,
        shownCustomEvent,
        hideCustomEvent,
        hiddenCustomEvent,
        relatedTarget = null,
        parent, menu, menuItems = [],
        persist;
    function preventEmptyAnchor(anchor) {
      (anchor.href && anchor.href.slice(-1) === '#' || anchor.parentNode && anchor.parentNode.href
        && anchor.parentNode.href.slice(-1) === '#') && this.preventDefault();
    }
    function toggleDismiss() {
      var action = element.open ? on : off;
      action(document, 'click', dismissHandler);
      action(document, 'keydown', preventScroll);
      action(document, 'keyup', keyHandler);
      action(document, 'focus', dismissHandler, true);
    }
    function dismissHandler(e) {
      if (e.target.getAttribute === undefined)
          { return; }
      var eventTarget = e.target,
            hasData = eventTarget && (eventTarget.getAttribute('data-toggle')
                                  || eventTarget.parentNode && eventTarget.parentNode.getAttribute
                                  && eventTarget.parentNode.getAttribute('data-toggle'));
      if ( e.type === 'focus' && (eventTarget === element || eventTarget === menu || menu.contains(eventTarget) ) ) {
        return;
      }
      if ( (eventTarget === menu || menu.contains(eventTarget)) && (persist || hasData) ) { return; }
      else {
        relatedTarget = eventTarget === element || element.contains(eventTarget) ? element : null;
        self.hide();
      }
      preventEmptyAnchor.call(e,eventTarget);
    }
    function clickHandler(e) {
      relatedTarget = element;
      self.show();
      preventEmptyAnchor.call(e,e.target);
    }
    function preventScroll(e) {
      var key = e.which || e.keyCode;
      if( key === 38 || key === 40 ) { e.preventDefault(); }
    }
    function keyHandler(ref) {
      var which = ref.which;
      var keyCode = ref.keyCode;
      var key = which || keyCode,
          activeItem = document.activeElement,
          isSameElement = activeItem === element,
          isInsideMenu = menu.contains(activeItem),
          isMenuItem = activeItem.parentNode === menu || activeItem.parentNode.parentNode === menu;
      var idx = menuItems.indexOf(activeItem);
      if ( isMenuItem ) {
          do {
            idx = isSameElement ? 0
                                : key === 38 ? (idx>1?idx-1:0)
                                : key === 40 ? (idx<menuItems.length-1?idx+1:idx) : idx;
            if ( idx === 0 || idx === menuItems[length]-1)
              { break; }
          } while ( !menuItems[idx].offsetHeight )
          menuItems[idx] && setFocus(menuItems[idx]);
      }
      if ( (menuItems.length && isMenuItem
            || !menuItems.length && (isInsideMenu || isSameElement)
            || !isInsideMenu )
            && element.open && key === 27
      ) {
        self.toggle();
        relatedTarget = null;
      }
    }
    self.show = function () {
      showCustomEvent = bootstrapCustomEvent('show', 'dropdown', relatedTarget);
      dispatchCustomEvent.call(parent, showCustomEvent);
      if ( showCustomEvent.defaultPrevented ) { return; }
      addClass(menu,'show');
      addClass(parent,'show');
      element.setAttribute('aria-expanded',true);
      element.open = true;
      off(element, 'click', clickHandler);
      setTimeout(function () {
        setFocus( menu.getElementsByTagName('INPUT')[0] || (menuItems.length && menuItems[0]) || element );
        toggleDismiss();
        shownCustomEvent = bootstrapCustomEvent( 'shown', 'dropdown', relatedTarget);
        dispatchCustomEvent.call(parent, shownCustomEvent);
      },1);
    };
    self.hide = function () {
      hideCustomEvent = bootstrapCustomEvent('hide', 'dropdown', relatedTarget);
      dispatchCustomEvent.call(parent, hideCustomEvent);
      if ( hideCustomEvent.defaultPrevented ) { return; }
      removeClass(menu,'show');
      removeClass(parent,'show');
      element.setAttribute('aria-expanded',false);
      element.open = false;
      toggleDismiss();
      setFocus(element);
      setTimeout(function () {
        element.Dropdown && on(element, 'click', clickHandler);
      },1);
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'dropdown', relatedTarget);
      dispatchCustomEvent.call(parent, hiddenCustomEvent);
    };
    self.toggle = function () {
      if (hasClass(parent,'show') && element.open) { self.hide(); }
      else { self.show(); }
    };
    self.dispose = function () {
      if (hasClass(parent,'show') && element.open) { self.hide(); }
      off(element, 'click', clickHandler);
      delete element.Dropdown;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Dropdown && element.Dropdown.dispose();
      parent = element.parentNode;
      menu = queryElement('.dropdown-menu', parent);
      Array.from(menu.children).map(function (child){
        Array.from(child.children).map(function(child2){
          child2.tagName === 'A' && menuItems.push(child2);
        });
        child.tagName === 'A' && menuItems.push(child);
      });
      if ( !element.Dropdown ) {
        !('tabindex' in menu) && menu.setAttribute('tabindex', '0');
        on(element, 'click', clickHandler);
      }
      persist = option === true || element.getAttribute('data-persist') === 'true' || false;
      element.open = false;
      element.Dropdown = self;
    },"BSN.Dropdown");
  }

  function Modal(element,options) {
    options = options || {};
    var self = this, modal,
      showCustomEvent,
      shownCustomEvent,
      hideCustomEvent,
      hiddenCustomEvent,
      relatedTarget = null,
      scrollBarWidth,
      overlay,
      overlayDelay,
      fixedItems,
      ops = {};
    function setScrollbar() {
      var openModal = hasClass(document.body,'modal-open'),
          bodyPad = parseInt(getComputedStyle(document.body).paddingRight),
          bodyOverflow = document.documentElement.clientHeight !== document.documentElement.scrollHeight
                      || document.body.clientHeight !== document.body.scrollHeight,
          modalOverflow = modal.clientHeight !== modal.scrollHeight;
      scrollBarWidth = measureScrollbar();
      modal.style.paddingRight = !modalOverflow && scrollBarWidth ? (scrollBarWidth + "px") : '';
      document.body.style.paddingRight = modalOverflow || bodyOverflow ? ((bodyPad + (openModal ? 0:scrollBarWidth)) + "px") : '';
      fixedItems.length && fixedItems.map(function (fixed){
        var itemPad = getComputedStyle(fixed).paddingRight;
        fixed.style.paddingRight = modalOverflow || bodyOverflow ? ((parseInt(itemPad) + (openModal?0:scrollBarWidth)) + "px") : ((parseInt(itemPad)) + "px");
      });
    }
    function resetScrollbar() {
      document.body.style.paddingRight = '';
      modal.style.paddingRight = '';
      fixedItems.length && fixedItems.map(function (fixed){
        fixed.style.paddingRight = '';
      });
    }
    function measureScrollbar() {
      var scrollDiv = document.createElement('div'), widthValue;
      scrollDiv.className = 'modal-scrollbar-measure';
      document.body.appendChild(scrollDiv);
      widthValue = scrollDiv.offsetWidth - scrollDiv.clientWidth;
      document.body.removeChild(scrollDiv);
      return widthValue;
    }
    function createOverlay() {
      var newOverlay = document.createElement('div');
      overlay = queryElement('.modal-backdrop');
      if ( overlay === null ) {
        newOverlay.setAttribute('class', 'modal-backdrop' + (ops.animation ? ' fade' : ''));
        overlay = newOverlay;
        document.body.appendChild(overlay);
      }
      return overlay;
    }
    function removeOverlay () {
      overlay = queryElement('.modal-backdrop');
      if ( overlay && !document.getElementsByClassName('modal show')[0] ) {
        document.body.removeChild(overlay); overlay = null;
      }
      overlay === null && (removeClass(document.body,'modal-open'), resetScrollbar());
    }
    function toggleEvents(action) {
      action(window, 'resize', self.update, passiveHandler);
      action(modal, 'click', dismissHandler);
      action(document, 'keydown', keyHandler);
    }
    function beforeShow() {
      modal.style.display = 'block';
      setScrollbar();
      !document.getElementsByClassName('modal show')[0] && addClass(document.body,'modal-open');
      addClass(modal,'show');
      modal.setAttribute('aria-hidden', false);
      hasClass(modal,'fade') ? emulateTransitionEnd(modal, triggerShow) : triggerShow();
    }
    function triggerShow() {
      setFocus(modal);
      modal.isAnimating = false;
      toggleEvents(on);
      shownCustomEvent = bootstrapCustomEvent('shown', 'modal', relatedTarget);
      dispatchCustomEvent.call(modal, shownCustomEvent);
    }
    function triggerHide(force) {
      modal.style.display = '';
      element && (setFocus(element));
      overlay = queryElement('.modal-backdrop');
      if (force !== 1 && overlay && hasClass(overlay,'show') && !document.getElementsByClassName('modal show')[0]) {
        removeClass(overlay,'show');
        emulateTransitionEnd(overlay,removeOverlay);
      } else {
        removeOverlay();
      }
      toggleEvents(off);
      modal.isAnimating = false;
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'modal');
      dispatchCustomEvent.call(modal, hiddenCustomEvent);
    }
    function clickHandler(e) {
      if ( modal.isAnimating ) { return; }
      var clickTarget = e.target,
          modalID = "#" + (modal.getAttribute('id')),
          targetAttrValue = clickTarget.getAttribute('data-target') || clickTarget.getAttribute('href'),
          elemAttrValue = element.getAttribute('data-target') || element.getAttribute('href');
      if ( !hasClass(modal,'show')
          && (clickTarget === element && targetAttrValue === modalID
          || element.contains(clickTarget) && elemAttrValue === modalID) ) {
        modal.modalTrigger = element;
        relatedTarget = element;
        self.show();
        e.preventDefault();
      }
    }
    function keyHandler(ref) {
      var which = ref.which;
      if (!modal.isAnimating && ops.keyboard && which == 27 && hasClass(modal,'show') ) {
        self.hide();
      }
    }
    function dismissHandler(e) {
      if ( modal.isAnimating ) { return; }
      var clickTarget = e.target,
          hasData = clickTarget.getAttribute('data-dismiss') === 'modal',
          parentWithData = clickTarget.closest('[data-dismiss="modal"]');
      if ( hasClass(modal,'show') && ( parentWithData || hasData
          || clickTarget === modal && ops.backdrop !== 'static' ) ) {
        self.hide(); relatedTarget = null;
        e.preventDefault();
      }
    }
    self.toggle = function () {
      if ( hasClass(modal,'show') ) {self.hide();} else {self.show();}
    };
    self.show = function () {
      if (hasClass(modal, 'show') && !!modal.isAnimating ) {return}
      showCustomEvent = bootstrapCustomEvent('show', 'modal', relatedTarget);
      dispatchCustomEvent.call(modal, showCustomEvent);
      if ( showCustomEvent.defaultPrevented ) { return; }
      modal.isAnimating = true;
      var currentOpen = document.getElementsByClassName('modal show')[0];
      if (currentOpen && currentOpen !== modal) {
        currentOpen.modalTrigger && currentOpen.modalTrigger.Modal.hide();
        currentOpen.Modal && currentOpen.Modal.hide();
      }
      if ( ops.backdrop ) {
        overlay = createOverlay();
      }
      if ( overlay && !currentOpen && !hasClass(overlay,'show') ) {
        overlay.offsetWidth;
        overlayDelay = getElementTransitionDuration(overlay);
        addClass(overlay, 'show');
      }
      !currentOpen ? setTimeout( beforeShow, overlay && overlayDelay ? overlayDelay:0 ) : beforeShow();
    };
    self.hide = function (force) {
      if ( !hasClass(modal,'show') ) {return}
      hideCustomEvent = bootstrapCustomEvent( 'hide', 'modal');
      dispatchCustomEvent.call(modal, hideCustomEvent);
      if ( hideCustomEvent.defaultPrevented ) { return; }
      modal.isAnimating = true;
      removeClass(modal,'show');
      modal.setAttribute('aria-hidden', true);
      hasClass(modal,'fade') && force !== 1 ? emulateTransitionEnd(modal, triggerHide) : triggerHide();
    };
    self.setContent = function (content) {
      queryElement('.modal-content',modal).innerHTML = content;
    };
    self.update = function () {
      if (hasClass(modal,'show')) {
        setScrollbar();
      }
    };
    self.dispose = function () {
      self.hide(1);
      if (element) {off(element, 'click', clickHandler); delete element.Modal; }
      else {delete modal.Modal;}
    };
    tryWrapper(function (){
      element = queryElement(element);
      var checkModal = queryElement( element.getAttribute('data-target') || element.getAttribute('href') );
      modal = hasClass(element,'modal') ? element : checkModal;
      fixedItems = Array.from(document.getElementsByClassName('fixed-top'))
                        .concat(Array.from(document.getElementsByClassName('fixed-bottom')));
      if ( hasClass(element, 'modal') ) { element = null; }
      element && element.Modal && element.Modal.dispose();
      modal && modal.Modal && modal.Modal.dispose();
      ops.keyboard = options.keyboard === false || modal.getAttribute('data-keyboard') === 'false' ? false : true;
      ops.backdrop = options.backdrop === 'static' || modal.getAttribute('data-backdrop') === 'static' ? 'static' : true;
      ops.backdrop = options.backdrop === false || modal.getAttribute('data-backdrop') === 'false' ? false : ops.backdrop;
      ops.animation = hasClass(modal, 'fade') ? true : false;
      ops.content = options.content;
      modal.isAnimating = false;
      if ( element && !element.Modal ) {
        on(element, 'click', clickHandler);
      }
      if ( ops.content ) {
        self.setContent( ops.content.trim() );
      }
      if (element) {
        modal.modalTrigger = element;
        element.Modal = self;
      } else {
        modal.Modal = self;
      }
    },"BSN.Modal");
  }

  function Popover(element,options) {
    options = options || {};
    var self = this;
    var popover = null,
        timer = 0,
        isIphone = /(iPhone|iPod|iPad)/.test(navigator.userAgent),
        titleString,
        contentString,
        ops = {};
    var triggerData,
        animationData,
        placementData,
        dismissibleData,
        delayData,
        containerData,
        closeBtn,
        showCustomEvent,
        shownCustomEvent,
        hideCustomEvent,
        hiddenCustomEvent,
        containerElement,
        containerDataElement,
        modal,
        navbarFixedTop,
        navbarFixedBottom,
        placementClass;
    function dismissibleHandler(e) {
      if (popover !== null && e.target === queryElement('.close',popover)) {
        self.hide();
      }
    }
    function getContents() {
      return {
        0 : options.title || element.getAttribute('data-title') || null,
        1 : options.content || element.getAttribute('data-content') || null
      }
    }
    function removePopover() {
      ops.container.removeChild(popover);
      timer = null; popover = null;
    }
    function createPopover() {
      titleString = getContents()[0] || null;
      contentString = getContents()[1];
      contentString = !!contentString ? contentString.trim() : null;
      popover = document.createElement('div');
      var popoverArrow = document.createElement('div');
      addClass(popoverArrow,'arrow');
      popover.appendChild(popoverArrow);
      if ( contentString !== null && ops.template === null ) {
        popover.setAttribute('role','tooltip');
        if (titleString !== null) {
          var popoverTitle = document.createElement('h3');
          addClass(popoverTitle,'popover-header');
          popoverTitle.innerHTML = ops.dismissible ? titleString + closeBtn : titleString;
          popover.appendChild(popoverTitle);
        }
        var popoverBodyMarkup = document.createElement('div');
        addClass(popoverBodyMarkup,'popover-body');
        popoverBodyMarkup.innerHTML = ops.dismissible && titleString === null ? contentString + closeBtn : contentString;
        popover.appendChild(popoverBodyMarkup);
      } else {
        var popoverTemplate = document.createElement('div');
        popoverTemplate.innerHTML = ops.template.trim();
        popover.className = popoverTemplate.firstChild.className;
        popover.innerHTML = popoverTemplate.firstChild.innerHTML;
        var popoverHeader = queryElement('.popover-header',popover),
            popoverBody = queryElement('.popover-body',popover);
        titleString && popoverHeader && (popoverHeader.innerHTML = titleString.trim());
        contentString && popoverBody && (popoverBody.innerHTML = contentString.trim());
      }
      ops.container.appendChild(popover);
      popover.style.display = 'block';
      !hasClass(popover, 'popover') && addClass(popover, 'popover');
      !hasClass(popover, ops.animation) && addClass(popover, ops.animation);
      !hasClass(popover, placementClass) && addClass(popover, placementClass);
    }
    function showPopover() {
      !hasClass(popover,'show') && ( addClass(popover,'show') );
    }
    function updatePopover() {
      styleTip(element, popover, ops.placement, ops.container);
    }
    function forceFocus () {
      if (popover === null) { element.focus(); }
    }
    function toggleEvents(action) {
      if (ops.trigger === 'hover') {
        action( element, mouseClickEvents.down, self.show );
        action( element, mouseHoverEvents[0], self.show );
        if (!ops.dismissible) { action( element, mouseHoverEvents[1], self.hide ); }
      } else if ('click' == ops.trigger) {
        action( element, ops.trigger, self.toggle );
      } else if ('focus' == ops.trigger) {
        isIphone && action( element, 'click', forceFocus );
        action( element, ops.trigger, self.toggle );
      }
    }
    function touchHandler(e){
      if ( popover && popover.contains(e.target) || e.target === element || element.contains(e.target)) ; else {
        self.hide();
      }
    }
    function dismissHandlerToggle(action) {
      if (ops.dismissible) {
        action( document, 'click', dismissibleHandler );
      } else {
        'focus' == ops.trigger && action( element, 'blur', self.hide );
        'hover' == ops.trigger && action( document, touchEvents.start, touchHandler, passiveHandler );
      }
      action( window, 'resize', self.hide, passiveHandler );
    }
    function showTrigger() {
      dismissHandlerToggle(on);
      dispatchCustomEvent.call(element, shownCustomEvent);
    }
    function hideTrigger() {
      dismissHandlerToggle(off);
      removePopover();
      dispatchCustomEvent.call(element, hiddenCustomEvent);
    }
    self.toggle = function () {
      if (popover === null) { self.show(); }
      else { self.hide(); }
    };
    self.show = function () {
      clearTimeout(timer);
      timer = setTimeout( function () {
        if (popover === null) {
          dispatchCustomEvent.call(element, showCustomEvent);
          if ( showCustomEvent.defaultPrevented ) { return; }
          createPopover();
          updatePopover();
          showPopover();
          !!ops.animation ? emulateTransitionEnd(popover, showTrigger) : showTrigger();
        }
      }, 20 );
    };
    self.hide = function () {
      clearTimeout(timer);
      timer = setTimeout( function () {
        if (popover && popover !== null && hasClass(popover,'show')) {
          dispatchCustomEvent.call(element, hideCustomEvent);
          if ( hideCustomEvent.defaultPrevented ) { return; }
          removeClass(popover,'show');
          !!ops.animation ? emulateTransitionEnd(popover, hideTrigger) : hideTrigger();
        }
      }, ops.delay );
    };
    self.dispose = function () {
      self.hide();
      toggleEvents(off);
      delete element.Popover;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Popover && element.Popover.dispose();
      triggerData = element.getAttribute('data-trigger');
      animationData = element.getAttribute('data-animation');
      placementData = element.getAttribute('data-placement');
      dismissibleData = element.getAttribute('data-dismissible');
      delayData = element.getAttribute('data-delay');
      containerData = element.getAttribute('data-container');
      closeBtn = '<button type="button" class="close">×</button>';
      showCustomEvent = bootstrapCustomEvent('show', 'popover');
      shownCustomEvent = bootstrapCustomEvent('shown', 'popover');
      hideCustomEvent = bootstrapCustomEvent('hide', 'popover');
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'popover');
      containerElement = queryElement(options.container);
      containerDataElement = queryElement(containerData);
      modal = element.closest('.modal');
      navbarFixedTop = element.closest('.fixed-top');
      navbarFixedBottom = element.closest('.fixed-bottom');
      ops.template = options.template ? options.template : null;
      ops.trigger = options.trigger ? options.trigger : triggerData || 'hover';
      ops.animation = options.animation && options.animation !== 'fade' ? options.animation : animationData || 'fade';
      ops.placement = options.placement ? options.placement : placementData || 'top';
      ops.delay = parseInt(options.delay || delayData) || 200;
      ops.dismissible = options.dismissible || dismissibleData === 'true' ? true : false;
      ops.container = containerElement ? containerElement
                             : containerDataElement ? containerDataElement
                             : navbarFixedTop ? navbarFixedTop
                             : navbarFixedBottom ? navbarFixedBottom
                             : modal ? modal : document.body;
      placementClass = "bs-popover-" + (ops.placement);
      var popoverContents = getContents();
      titleString = popoverContents[0];
      contentString = popoverContents[1];
      if ( !contentString && !ops.template ) { return; }
      if ( !element.Popover ) {
        toggleEvents(on);
      }
      element.Popover = self;
    },"BSN.Popover");
  }

  function Tab(element,options) {
    options = options || {};
    var self = this,
      heightData,
      tabs, dropdown,
      showCustomEvent,
      shownCustomEvent,
      hideCustomEvent,
      hiddenCustomEvent,
      next,
      tabsContentContainer = false,
      activeTab,
      activeContent,
      nextContent,
      containerHeight,
      equalContents,
      nextHeight,
      animateHeight;
    function triggerEnd() {
      tabsContentContainer.style.height = '';
      removeClass(tabsContentContainer,'collapsing');
      tabs.isAnimating = false;
    }
    function triggerShow() {
      if (tabsContentContainer) {
        if ( equalContents ) {
          triggerEnd();
        } else {
          setTimeout(function () {
            tabsContentContainer.style.height = nextHeight + "px";
            tabsContentContainer.offsetWidth;
            emulateTransitionEnd(tabsContentContainer, triggerEnd);
          },50);
        }
      } else {
        tabs.isAnimating = false;
      }
      shownCustomEvent = bootstrapCustomEvent('shown', 'tab', activeTab);
      dispatchCustomEvent.call(next, shownCustomEvent);
    }
    function triggerHide() {
      if (tabsContentContainer) {
        activeContent.style.float = 'left';
        nextContent.style.float = 'left';
        containerHeight = activeContent.scrollHeight;
      }
      showCustomEvent = bootstrapCustomEvent('show', 'tab', activeTab);
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'tab', next);
      dispatchCustomEvent.call(next, showCustomEvent);
      if ( showCustomEvent.defaultPrevented ) { return; }
      addClass(nextContent,'active');
      removeClass(activeContent,'active');
      if (tabsContentContainer) {
        nextHeight = nextContent.scrollHeight;
        equalContents = nextHeight === containerHeight;
        addClass(tabsContentContainer,'collapsing');
        tabsContentContainer.style.height = containerHeight + "px";
        tabsContentContainer.offsetHeight;
        activeContent.style.float = '';
        nextContent.style.float = '';
      }
      if ( hasClass(nextContent, 'fade') ) {
        setTimeout(function () {
          addClass(nextContent,'show');
          emulateTransitionEnd(nextContent,triggerShow);
        },20);
      } else { triggerShow(); }
      dispatchCustomEvent.call(activeTab, hiddenCustomEvent);
    }
    function getActiveTab() {
      var activeTabs = tabs.getElementsByClassName('active'), activeTab;
      if ( activeTabs.length === 1 && !hasClass(activeTabs[0].parentNode,'dropdown') ) {
        activeTab = activeTabs[0];
      } else if ( activeTabs.length > 1 ) {
        activeTab = activeTabs[activeTabs.length-1];
      }
      return activeTab;
    }
    function getActiveContent() { return queryElement(getActiveTab().getAttribute('href')) }
    function clickHandler(e) {
      e.preventDefault();
      next = e.currentTarget;
      !tabs.isAnimating && self.show();
    }
    self.show = function () {
      next = next || element;
      if (!hasClass(next,'active')) {
        nextContent = queryElement(next.getAttribute('href'));
        activeTab = getActiveTab();
        activeContent = getActiveContent();
        hideCustomEvent = bootstrapCustomEvent( 'hide', 'tab', next);
        dispatchCustomEvent.call(activeTab, hideCustomEvent);
        if (hideCustomEvent.defaultPrevented) { return; }
        tabs.isAnimating = true;
        removeClass(activeTab,'active');
        activeTab.setAttribute('aria-selected','false');
        addClass(next,'active');
        next.setAttribute('aria-selected','true');
        if ( dropdown ) {
          if ( !hasClass(element.parentNode,'dropdown-menu') ) {
            if (hasClass(dropdown,'active')) { removeClass(dropdown,'active'); }
          } else {
            if (!hasClass(dropdown,'active')) { addClass(dropdown,'active'); }
          }
        }
        if (hasClass(activeContent, 'fade')) {
          removeClass(activeContent,'show');
          emulateTransitionEnd(activeContent, triggerHide);
        } else { triggerHide(); }
      }
    };
    self.dispose = function () {
      off(element, 'click', clickHandler);
      delete element.Tab;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Tab && element.Tab.dispose();
      heightData = element.getAttribute('data-height');
      tabs = element.closest('.nav');
      dropdown = tabs && queryElement('.dropdown-toggle',tabs);
      animateHeight = !supportTransition || (options.height === false || heightData === 'false') ? false : true;
      tabs.isAnimating = false;
      if ( !element.Tab ) {
        on(element, 'click', clickHandler);
      }
      if (animateHeight) { tabsContentContainer = getActiveContent().parentNode; }
      element.Tab = self;
    },'BSN.Tab');
  }

  function Toast(element,options) {
    options = options || {};
    var self = this,
        toast, timer = 0,
        animationData,
        autohideData,
        delayData,
        showCustomEvent,
        hideCustomEvent,
        shownCustomEvent,
        hiddenCustomEvent,
        ops = {};
    function showComplete() {
      removeClass( toast, 'showing' );
      addClass( toast, 'show' );
      dispatchCustomEvent.call(toast,shownCustomEvent);
      if (ops.autohide) { self.hide(); }
    }
    function hideComplete() {
      addClass( toast, 'hide' );
      dispatchCustomEvent.call(toast,hiddenCustomEvent);
    }
    function close () {
      removeClass( toast,'show' );
      ops.animation ? emulateTransitionEnd(toast, hideComplete) : hideComplete();
    }
    function disposeComplete() {
      clearTimeout(timer);
      off(element, 'click', self.hide);
      delete element.Toast;
    }
    self.show = function () {
      if (toast && !hasClass(toast,'show')) {
        dispatchCustomEvent.call(toast,showCustomEvent);
        if (showCustomEvent.defaultPrevented) { return; }
        ops.animation && addClass( toast,'fade' );
        removeClass( toast,'hide' );
        toast.offsetWidth;
        addClass( toast,'showing' );
        ops.animation ? emulateTransitionEnd(toast, showComplete) : showComplete();
      }
    };
    self.hide = function (noTimer) {
      if (toast && hasClass(toast,'show')) {
        dispatchCustomEvent.call(toast,hideCustomEvent);
        if(hideCustomEvent.defaultPrevented) { return; }
        noTimer ? close() : (timer = setTimeout( close, ops.delay));
      }
    };
    self.dispose = function () {
      ops.animation ? emulateTransitionEnd(toast, disposeComplete) : disposeComplete();
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Toast && element.Toast.dispose();
      toast = element.closest('.toast');
      animationData = element.getAttribute('data-animation');
      autohideData = element.getAttribute('data-autohide');
      delayData = element.getAttribute('data-delay');
      showCustomEvent = bootstrapCustomEvent('show', 'toast');
      hideCustomEvent = bootstrapCustomEvent('hide', 'toast');
      shownCustomEvent = bootstrapCustomEvent('shown', 'toast');
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'toast');
      ops.animation = options.animation === false || animationData === 'false' ? 0 : 1;
      ops.autohide = options.autohide === false || autohideData === 'false' ? 0 : 1;
      ops.delay = parseInt(options.delay || delayData) || 500;
      if ( !element.Toast ) {
        on(element, 'click', self.hide);
      }
      element.Toast = self;
    },'BSN.Toast');
  }

  var componentsInit = {};

  var initCallback = function (lookUp){
    lookUp = lookUp || document;
    var initializeDataAPI = function( Constructor, collection ){
      Array.from(collection).map(function (x){ return new Constructor(x); });
    };
    for (var component in componentsInit) {
      initializeDataAPI( componentsInit[component][0], lookUp.querySelectorAll (componentsInit[component][1]) );
    }
  };
  var removeDataAPI = function (lookUp) {
    lookUp = lookUp || document;
    var removeElementDataAPI = function( ConstructorName, collection ){
      Array.from(collection).map(function (x){ return x[ConstructorName].dispose(); });
    };
    for (var component in componentsInit) {
      removeElementDataAPI( component, lookUp.querySelectorAll (componentsInit[component][1]) );
    }
  };

  function ScrollSpy(element,options) {
    options = options || {};
    var self = this,
      vars,
      targetData,
      offsetData,
      spyTarget,
      scrollTarget,
      ops = {};
    function updateTargets(){
      var links = spyTarget.getElementsByTagName('A');
      if (vars.length !== links.length) {
        vars.items = [];
        vars.targets = [];
        Array.from(links).map(function (link){
          var href = link.getAttribute('href'),
            targetItem = href && href.charAt(0) === '#' && href.slice(-1) !== '#' && queryElement(href);
          if ( targetItem ) {
            vars.items.push(link);
            vars.targets.push(targetItem);
          }
        });
        vars.length = links.length;
      }
    }
    function updateItem(index) {
      var item = vars.items[index],
        targetItem = vars.targets[index],
        dropmenu = hasClass(item,'dropdown-item') && item.closest('.dropdown-menu'),
        dropLink = dropmenu && dropmenu.previousElementSibling,
        nextSibling = item.nextElementSibling,
        activeSibling = nextSibling && nextSibling.getElementsByClassName('active').length,
        targetRect = vars.isWindow && targetItem.getBoundingClientRect(),
        isActive = hasClass(item,'active') || false,
        topEdge = (vars.isWindow ? targetRect.top + vars.scrollOffset : targetItem.offsetTop) - ops.offset,
        bottomEdge = vars.isWindow ? targetRect.bottom + vars.scrollOffset - ops.offset
                   : vars.targets[index+1] ? vars.targets[index+1].offsetTop - ops.offset
                   : element.scrollHeight,
        inside = activeSibling || vars.scrollOffset >= topEdge && bottomEdge > vars.scrollOffset;
       if ( !isActive && inside ) {
        addClass(item,'active');
        if (dropLink && !hasClass(dropLink,'active') ) {
          addClass(dropLink,'active');
        }
        dispatchCustomEvent.call(element, bootstrapCustomEvent( 'activate', 'scrollspy', vars.items[index]));
      } else if ( isActive && !inside ) {
        removeClass(item,'active');
        if (dropLink && hasClass(dropLink,'active') && !item.parentNode.getElementsByClassName('active').length ) {
          removeClass(dropLink,'active');
        }
      } else if ( isActive && inside || !inside && !isActive ) {
        return;
      }
    }
    function updateItems() {
      updateTargets();
      vars.scrollOffset = vars.isWindow ? getScroll().y : element.scrollTop;
      vars.items.map(function (l,idx){ return updateItem(idx); });
    }
    function toggleEvents(action) {
      action( scrollTarget, 'scroll', self.refresh, passiveHandler );
      action( window, 'resize', self.refresh, passiveHandler );
    }
    self.refresh = function () {
      updateItems();
    };
    self.dispose = function () {
      toggleEvents(off);
      delete element.ScrollSpy;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.ScrollSpy && element.ScrollSpy.dispose();
      targetData = element.getAttribute('data-target');
      offsetData = element.getAttribute('data-offset');
      spyTarget = queryElement(options.target || targetData);
      scrollTarget = element.offsetHeight < element.scrollHeight ? element : window;
      if (!spyTarget) { return }
      ops.target = spyTarget;
      ops.offset = parseInt(options.offset || offsetData) || 10;
      vars = {};
      vars.length = 0;
      vars.items = [];
      vars.targets = [];
      vars.isWindow = scrollTarget === window;
      if ( !element.ScrollSpy ) {
        toggleEvents(on);
      }
      self.refresh();
      element.ScrollSpy = self;
    },"BSN.ScrollSpy");
  }

  function Tooltip(element,options) {
    options = options || {};
    var self = this,
        tooltip = null, timer = 0, titleString,
        animationData,
        placementData,
        delayData,
        containerData,
        showCustomEvent,
        shownCustomEvent,
        hideCustomEvent,
        hiddenCustomEvent,
        containerElement,
        containerDataElement,
        modal,
        navbarFixedTop,
        navbarFixedBottom,
        placementClass,
        ops = {};
    function getTitle() {
      return element.getAttribute('title')
          || element.getAttribute('data-title')
          || element.getAttribute('data-original-title')
    }
    function removeToolTip() {
      ops.container.removeChild(tooltip);
      tooltip = null; timer = null;
    }
    function createToolTip() {
      titleString = getTitle();
      if ( titleString ) {
        tooltip = document.createElement('div');
        if (ops.template) {
          var tooltipMarkup = document.createElement('div');
          tooltipMarkup.innerHTML = ops.template.trim();
          tooltip.className = tooltipMarkup.firstChild.className;
          tooltip.innerHTML = tooltipMarkup.firstChild.innerHTML;
          queryElement('.tooltip-inner',tooltip).innerHTML = titleString.trim();
        } else {
          var tooltipArrow = document.createElement('div');
          addClass(tooltipArrow,'arrow');
          tooltip.appendChild(tooltipArrow);
          var tooltipInner = document.createElement('div');
          addClass(tooltipInner,'tooltip-inner');
          tooltip.appendChild(tooltipInner);
          tooltipInner.innerHTML = titleString;
        }
        tooltip.style.left = '0';
        tooltip.style.top = '0';
        tooltip.setAttribute('role','tooltip');
        !hasClass(tooltip, 'tooltip') && addClass(tooltip, 'tooltip');
        !hasClass(tooltip, ops.animation) && addClass(tooltip, ops.animation);
        !hasClass(tooltip, placementClass) && addClass(tooltip, placementClass);
        ops.container.appendChild(tooltip);
      }
    }
    function updateTooltip() {
      styleTip(element, tooltip, ops.placement, ops.container);
    }
    function showTooltip() {
      !hasClass(tooltip,'show') && ( addClass(tooltip,'show') );
    }
    function touchHandler(e){
      if ( tooltip && tooltip.contains(e.target) || e.target === element || element.contains(e.target)) ; else {
        self.hide();
      }
    }
    function showAction() {
      on( document, touchEvents.start, touchHandler, passiveHandler );
      on( window, 'resize', self.hide, passiveHandler );
      dispatchCustomEvent.call(element, shownCustomEvent);
    }
    function hideAction() {
      off( document, touchEvents.start, touchHandler, passiveHandler );
      off( window, 'resize', self.hide, passiveHandler );
      removeToolTip();
      dispatchCustomEvent.call(element, hiddenCustomEvent);
    }
    function toggleEvents(action) {
      action(element, mouseClickEvents.down, self.show);
      action(element, mouseHoverEvents[0], self.show);
      action(element, mouseHoverEvents[1], self.hide);
    }
    self.show = function () {
      clearTimeout(timer);
      timer = setTimeout( function () {
        if (tooltip === null) {
          dispatchCustomEvent.call(element, showCustomEvent);
          if (showCustomEvent.defaultPrevented) { return; }
          if(createToolTip() !== false) {
            updateTooltip();
            showTooltip();
            !!ops.animation ? emulateTransitionEnd(tooltip, showAction) : showAction();
          }
        }
      }, 20 );
    };
    self.hide = function () {
      clearTimeout(timer);
      timer = setTimeout( function () {
        if (tooltip && hasClass(tooltip,'show')) {
          dispatchCustomEvent.call(element, hideCustomEvent);
          if (hideCustomEvent.defaultPrevented) { return; }
          removeClass(tooltip,'show');
          !!ops.animation ? emulateTransitionEnd(tooltip, hideAction) : hideAction();
        }
      }, ops.delay);
    };
    self.toggle = function () {
      if (!tooltip) { self.show(); }
      else { self.hide(); }
    };
    self.dispose = function () {
      toggleEvents(off);
      self.hide();
      element.setAttribute('title', element.getAttribute('data-original-title'));
      element.removeAttribute('data-original-title');
      delete element.Tooltip;
    };
    tryWrapper(function (){
      element = queryElement(element);
      element.Tooltip && element.Tooltip.dispose();
      animationData = element.getAttribute('data-animation');
      placementData = element.getAttribute('data-placement');
      delayData = element.getAttribute('data-delay');
      containerData = element.getAttribute('data-container');
      showCustomEvent = bootstrapCustomEvent('show', 'tooltip');
      shownCustomEvent = bootstrapCustomEvent('shown', 'tooltip');
      hideCustomEvent = bootstrapCustomEvent('hide', 'tooltip');
      hiddenCustomEvent = bootstrapCustomEvent('hidden', 'tooltip');
      containerElement = queryElement(options.container);
      containerDataElement = queryElement(containerData);
      modal = element.closest('.modal');
      navbarFixedTop = element.closest('.fixed-top');
      navbarFixedBottom = element.closest('.fixed-bottom');
      ops.animation = options.animation && options.animation !== 'fade' ? options.animation : animationData || 'fade';
      ops.placement = options.placement ? options.placement : placementData || 'top';
      ops.template = options.template ? options.template : null;
      ops.delay = parseInt(options.delay || delayData) || 200;
      ops.container = containerElement ? containerElement
                             : containerDataElement ? containerDataElement
                             : navbarFixedTop ? navbarFixedTop
                             : navbarFixedBottom ? navbarFixedBottom
                             : modal ? modal : document.body;
      placementClass = "bs-tooltip-" + (ops.placement);
      titleString = getTitle();
      if ( !titleString ) { return; }
      if (!element.Tooltip) {
        element.setAttribute('data-original-title',titleString);
        element.removeAttribute('title');
        toggleEvents(on);
      }
      element.Tooltip = self;
    },'BSN.Tooltip');
  }

  componentsInit.Alert = [ Alert, '[data-dismiss="alert"]'];
  componentsInit.Button = [ Button, '[data-toggle="buttons"]' ];
  componentsInit.Carousel = [ Carousel, '[data-ride="carousel"]' ];
  componentsInit.Collapse = [ Collapse, '[data-toggle="collapse"]' ];
  componentsInit.Dropdown = [ Dropdown, '[data-toggle="dropdown"]'];
  componentsInit.Modal = [ Modal, '[data-toggle="modal"]' ];
  componentsInit.Popover = [ Popover, '[data-toggle="popover"],[data-tip="popover"]' ];
  componentsInit.ScrollSpy = [ ScrollSpy, '[data-spy="scroll"]' ];
  componentsInit.Tab = [ Tab, '[data-toggle="tab"]' ];
  componentsInit.Toast = [ Toast, '[data-dismiss="toast"]' ];
  componentsInit.Tooltip = [ Tooltip, '[data-toggle="tooltip"],[data-tip="tooltip"]' ];
  document.body ? initCallback() : one( document, 'DOMContentLoaded', initCallback );

  var version = "3.0.3";

  var indexMympd = {
    Alert: Alert,
    Button: Button,
    Carousel: Carousel,
    Collapse: Collapse,
    Dropdown: Dropdown,
    Modal: Modal,
    Popover: Popover,
    Tab: Tab,
    Toast: Toast,
    initCallback: initCallback,
    removeDataAPI: removeDataAPI,
    componentsInit: componentsInit,
    Version: version
  };

  return indexMympd;

}));
var locales=[{"code":"de-DE","desc":"Deutsch"},{"code":"en-US","desc":"English"},{"code":"es-VE","desc":"Español"},{"code":"fi-FI","desc":"Finnish"},{"code":"ko-KR","desc":"한국어"},{"code":"nl-NL","desc":"Nederlands"}];var phrases={"%{name} added to queue":{"de-DE":"%{name} hinzugefügt","es-VE":"%{name} agregado a la cola de reproducción","fi-FI":"%{name} lisätty jonoon","ko-KR":"순서에 %{name} 추가함","nl-NL":"%{name} toegevoegd"},"%{name} added to queue position %{to}":{"de-DE":"%{name} an Warteschlangenposition %{to} hinzugefügt","es-VE":"%{name} agregado a la cola de reproducción en la posición %{to}","fi-FI":"%{name} lisätty jonossa kohtaan %{to}","ko-KR":"%{to} 순서 위치에 %{name} 추가함","nl-NL":"%{name} toegevoegd aan wachtrijpositie %{to}"},"About":{"de-DE":"Über myMPD","es-VE":"Acerca de","fi-FI":"Tietoja","ko-KR":"정보","nl-NL":"Over myMPD"},"Action":{"de-DE":"Aktion","es-VE":"Acción","fi-FI":"Toiminto","ko-KR":"기능","nl-NL":"Aktie"},"Add":{"de-DE":"Hinzufügen","es-VE":"Agregar","fi-FI":"Lisää","ko-KR":"추가","nl-NL":"Toevoegen"},"Add after current playing song":{"de-DE":"Nach aktuellem Lied hinzufügen","es-VE":"Añadir despues de la canción actual","fi-FI":"Lisää soivan kappaleen jälkeen","ko-KR":"지금 연주 중인 곡 다음에 추가","nl-NL":"Als volgende afspelen"},"Add all to playlist":{"de-DE":"Alles zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar todo a lista de reproducción","fi-FI":"Lisää kaikki soittolistaan","ko-KR":"연주목록에 모두 추가","nl-NL":"Alle aan afspeellijst toevoegen"},"Add all to queue":{"de-DE":"Alles zur Warteschlange hinzufügen","es-VE":"Agregar todo a cola de reproducción","fi-FI":"Lisää kaikki jonoon","ko-KR":"순서에 모두 추가","nl-NL":"Alle aan wachtrij toevoegen"},"Add bookmark":{"de-DE":"Lesezeichen hinzufügen","es-VE":"Agregar marcador","fi-FI":"Lisää kirjanmerkki","ko-KR":"즐겨찾기 추가","nl-NL":"Voeg bladwijzer toe"},"Add random":{"de-DE":"Zufällig hinzufügen","es-VE":"Agregar aleatorio","fi-FI":"Lisää satunnainen","ko-KR":"무작위 추가","nl-NL":"Voeg willekeurige toe"},"Add smart playlist":{"de-DE":"Neue intelligente Wiedergabeliste","es-VE":"Agregar Lista de reproducción inteligente","fi-FI":"Lisää älykäs soittolista","ko-KR":"스마트 연주목록 추가","nl-NL":"Slimme afspeellijst toevoegen"},"Add stream":{"de-DE":"Stream hinzufügen","es-VE":"Agregar fuente","fi-FI":"Lisää streami","ko-KR":"스트리밍 서비스 추가","nl-NL":"Stream toevoegen"},"Add to home screen":{"de-DE":"Zum Startbildschirm hinzufügen","es-VE":"Agregar a pantalla de inicio","fi-FI":"Lisää aloitus näkymään","ko-KR":"홈 화면에 추가","nl-NL":"Aan startscherm toevoegen"},"Add to homescreen":{"de-DE":"Zum Homescreen hinzufügen"},"Add to playlist":{"de-DE":"Zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar a lista de reproducción","fi-FI":"Lisää soittolistaan","ko-KR":"연주목록에 추가","nl-NL":"Aan afspeellijst toevoegen"},"Add to queue":{"de-DE":"Zu Warteschlange hinzufügen","es-VE":"Agregar a la cola de reproducción","fi-FI":"Lisää jonoon","ko-KR":"순서에 추가","nl-NL":"Aan wachtrij toevoegen"},"Added %{uri} to playlist %{playlist}":{"de-DE":"%{uri} zu Wiedergabeliste %{playlist} hinzugefügt","es-VE":"%{uri} agregado a lista de reproducción %{playlist}","fi-FI":"%{uri} lisätty soittolistaan %{playlist}","ko-KR":"%{uri}의 %{playlist} 연주목록 추가에 실패함","nl-NL":"%{uri} aan afspeellijst %{playlist} toegevoegd"},"Added all songs":{"de-DE":"Alle Lieder hinzugefügt","es-VE":"Agregadas todas las canciones","fi-FI":"Kaikki kappaleet lisätty","ko-KR":"모든 곡을 추가함","nl-NL":"Alle nummers toegevoegd"},"Added songs to %{playlist}":{"de-DE":"Lieder zur Wiedergabeliste %{playlist} hinzugefügt","es-VE":"Canciones agregadas a la lista de reproducción %{playlist}","fi-FI":"Kappaleet lisätty soittolistaan %{playlist}","ko-KR":"%{playlist}에 곡 추가함","nl-NL":"Nummers aan %{playlist} toegevoegd"},"Added songs to queue":{"de-DE":"Lieder zur Warteschlange hinzugefügt","es-VE":"Canciones agregadas a la cola de reproducción","fi-FI":"Kappaleet lisätty jonoon","ko-KR":"순서에 곡 추가함","nl-NL":"Nummer aan wachtrij toegevoegd"},"Added stream %{streamUri} to queue":{"de-DE":"Stream %{streamUri} zu Warteschlange hinzugefügt","es-VE":"Agregar Fuente %{streamUri} a la cola de reproducción","fi-FI":"Streami %{streamUri} lisätty jonoon","ko-KR":"%{streamUri} 스트리밍을 순서에 추가함","nl-NL":"Stream %{streamUri} aan wachtrij toevoegen"},"Adding random songs to queue failed":{"de-DE":"Zufällige Lieder konnten nicht zur Warteschlange hinzugefügt werden","es-VE":"Error al agregar canciones aleatorias a la cola de reproducción","fi-FI":"Satunnaisten kappaleiden lisääminen jonoon epäonnistui","ko-KR":"순서에 무작위 곡 추가 안 됨","nl-NL":"Toevoegen willekeurig nummer mislukt"},"Adding timer failed":{"de-DE":"Timer konnte nicht hinzugefügt werden","es-VE":"Fallo al agregar Temporizador","fi-FI":"Ajastimen lisäys epäonnistui","ko-KR":"타이머를 추가할 수 없음","nl-NL":"Toevoegen timer mislukt"},"Advanced":{"de-DE":"Erweitert","es-VE":"Avanzado","fi-FI":"Lisäasetukset","ko-KR":"고급","nl-NL":"Geavanceerd"},"Album":{"de-DE":"Album","es-VE":"Álbum","fi-FI":"Albumi","ko-KR":"음반","nl-NL":"Album"},"AlbumArtist":{"de-DE":"Album Interpret","en-US":"Albumartist","es-VE":"Artista álbum","fi-FI":"Albumi Esittäjä","ko-KR":"음반 연주가","nl-NL":"Albumartiest"},"AlbumArtistSort":{"de-DE":"Album Interpret","es-VE":"Artista álbum","fi-FI":"AlbumiArtistiJärjestely","ko-KR":"음반 연주가 정렬","nl-NL":"Albumartiest"},"AlbumSort":{"de-DE":"Album","es-VE":"Álbum","fi-FI":"AlbumiJärjestely","ko-KR":"음반 정렬","nl-NL":"Album"},"Albumart":{"de-DE":"Albumcover","es-VE":"Carátula del álbum","fi-FI":"Albumcover","ko-KR":"음반 표지","nl-NL":"Albumcover"},"Albums":{"de-DE":"Alben","es-VE":"Álbumes","fi-FI":"Albumit","ko-KR":"음반","nl-NL":"Albums"},"Any Tag":{"de-DE":"Alle Tags","es-VE":"Cualquier etiqueta","fi-FI":"Mikä tahansa tagi","ko-KR":"모든 태그","nl-NL":"Alle tags"},"Appearance":{"de-DE":"Design","es-VE":"Apariencia","fi-FI":"Ulkoasu","ko-KR":"외관","nl-NL":"Uiterlijk"},"Append item to playlist":{"de-DE":"Ausgewähltes Element zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar elemento a lista de reproducción","fi-FI":"Lisää kohde soittolistaan","ko-KR":"연주목록에 항목 추가","nl-NL":"Selectie aan afspeellijst toevoegen"},"Append item to queue":{"de-DE":"Ausgewähltes Element an Warteschlange anhängen","es-VE":"Agregar elemento a la cola de reproducción","fi-FI":"Lisää kohde jonoon","ko-KR":"순서에 항목 추가","nl-NL":"Selectie aan wachtrij toevoegen"},"Append to queue":{"de-DE":"An Warteschlange anhängen","es-VE":"Añadir a la cola de reproducción","fi-FI":"Lisää jonoon","ko-KR":"순서에 추가","nl-NL":"Aan wachtrij toevoegen"},"Apply":{"de-DE":"Anwenden","es-VE":"Aplicar","fi-FI":"Käytä","ko-KR":"적용","nl-NL":"Toepassen"},"Applying settings":{"de-DE":"Einstellungen werden angewendet","es-VE":"Aplicando configuraciones","fi-FI":"Asetuksia otetaan käyttöön","ko-KR":"설정 적용","nl-NL":"Instellingen toepassen"},"Arguments":{"de-DE":"Parameter","ko-KR":"변수","nl-NL":"Argumenten"},"Artist":{"de-DE":"Künstler","es-VE":"Artista","fi-FI":"Artisti","ko-KR":"연주가","nl-NL":"Artiest"},"ArtistSort":{"de-DE":"Künstler","es-VE":"Artista","fi-FI":"ArtistiJärjestely","ko-KR":"연주가 정렬","nl-NL":"Artiest"},"Artists":{"de-DE":"Interpreten","es-VE":"Artistas","fi-FI":"Artistit","ko-KR":"연주가","nl-NL":"Artiesten"},"Author":{"de-DE":"Autor","es-VE":"Autor","fi-FI":"Luoja","ko-KR":"저자","nl-NL":"Auteur"},"Auto":{"de-DE":"Auto","es-VE":"Auto","fi-FI":"Auto","ko-KR":"자동","nl-NL":"Auto"},"Autodetect":{"de-DE":"Automatisch","es-VE":"Auto detectar","fi-FI":"Automaattinen tunnistus","ko-KR":"자동 감지","nl-NL":"Automatisch"},"Autoplay":{"de-DE":"Automatische Wiedergabe","es-VE":"Reproducción automática","fi-FI":"Automaattitoisto","ko-KR":"자동 연주","nl-NL":"Auto-afspelen"},"Backend uri":{"de-DE":"Einzuhängende URL","es-VE":"URL Back-End","fi-FI":"Järjestelmä uri","ko-KR":"백엔드 URL","nl-NL":"Backend-url"},"Background":{"de-DE":"Hintergrund","es-VE":"Fondo","fi-FI":"Tausta","ko-KR":"배경","nl-NL":"Achtergrond"},"Background color":{"de-DE":"Hintergrundfarbe","es-VE":"Color de fondo","fi-FI":"Taustaväri","ko-KR":"배경색","nl-NL":"Achtergrondkleur"},"Best rated":{"de-DE":"Am Besten bewertet","es-VE":"Mejor calificado","fi-FI":"Paras arvostelu","ko-KR":"최고 평점","nl-NL":"Best beoordeeld"},"Booklet":{"de-DE":"Booklet","es-VE":"Folleto","fi-FI":"Booklet","ko-KR":"책자","nl-NL":"Boekje"},"Booklet filename":{"de-DE":"Booklet Dateiname","es-VE":"Archivo de folleto","fi-FI":"Bookletin tiedostonimi","ko-KR":"책자 파일 이름","nl-NL":"Bestandsnaam boekje"},"Bookmark URI":{"de-DE":"Lesezeichen URL","es-VE":"URL de marcador","fi-FI":"Kirjanmerkin URL","ko-KR":"즐겨찾기 주소","nl-NL":"Url bladwijzer"},"Bookmark name":{"de-DE":"Name","es-VE":"Nombre de marcador","fi-FI":"Kirjanmerkin nimi","ko-KR":"즐겨찾기 이름","nl-NL":"Naam"},"Bookmarks":{"de-DE":"Lesezeichen","es-VE":"Marcadores","fi-FI":"Kirjanmerkit","ko-KR":"즐겨찾기","nl-NL":"Bladwijzers"},"Browse":{"de-DE":"Durchsuchen","es-VE":"Explorar","fi-FI":"Selaa","ko-KR":"열기","nl-NL":"Browse"},"Browse directories":{"de-DE":"Verzeichnisse anzeigen","es-VE":"Explorar directorios","fi-FI":"Selaa kansioita","ko-KR":"디렉터리 열기","nl-NL":"Browse bestanden"},"Browser default":{"de-DE":"Browsereinstellung","es-VE":"Por defecto del navegador","fi-FI":"Selaimen asetus","ko-KR":"기본 열기","nl-NL":"Browserinstelling"},"CSS filter":{"de-DE":"CSS Filter","es-VE":"Filtro CSS","fi-FI":"CSS suodatin","ko-KR":"CSS 필터","nl-NL":"CSS filter"},"Calculate":{"de-DE":"Berechne Fingerabdruck","es-VE":"Calcular","fi-FI":"Laske","ko-KR":"계산","nl-NL":"Bereken"},"Can not crop the queue":{"de-DE":"Die Warteschlange konnte nicht abgeschnitten werden","fi-FI":"Ei voi rajata jonoa","ko-KR":"순서에 남길 수 없음","nl-NL":"Kan wachtrij niet inkorten"},"Can not delete home icon":{"de-DE":"Icon konnte nicht gelöscht werden"},"Can not get home icon":{"de-DE":"Konnte Homeicon nicht abrufen"},"Can not move home icon":{"de-DE":"Homeicon konnte nicht verschoben werden"},"Can not open scriptfile":{"de-DE":"Skript konnte nicht geöffnet werden","ko-KR":"스크립트 파일을 열 수 없음","nl-NL":"Kan script niet openen"},"Can not parse settings":{"de-DE":"Einstellungen können nicht geladen werden","es-VE":"Error al leer configuraciones","fi-FI":"Asetusten käsittely ei onnistu","ko-KR":"설정을 분석할 수 없음","nl-NL":"Laden instellingen mislukt "},"Can not parse smart playlist file":{"de-DE":"Intelligente Wiedergabeliste konnte nicht geparsed werden","es-VE":"No se puede interpretar el archivo de lista de reproducción inteligente","fi-FI":"Älykkään soittolista tiedoston käsittely ei onnistu","ko-KR":"스마트 연주목록 파일을 분석할 수 없음","nl-NL":"Kan slimme afspeellijst niet inlezen"},"Can not read smart playlist file":{"de-DE":"Intelligente Wiedergabeliste konnte nicht eingelesen werden","es-VE":"No se puede leer el archivo de lista de reproducción inteligente","fi-FI":"Älykkään soittolista tiedoston luku ei onnistu","ko-KR":"스마트 연주목록 파일을 읽을 수 없음","nl-NL":"Kan slimme afspeellijst niet lezen"},"Can not save home icon":{"de-DE":"Icon konnte nicht gespeichert werden"},"Can't access music directory":{"de-DE":"Musik Verzeichnis ist nicht verfügbar","es-VE":"No se puede acceder al directorio de música","fi-FI":"Musiikkikansiota ei pysty avaamaan","ko-KR":"음원 디렉터리에 접근할 수 없음","nl-NL":"Map niet toegankelijk"},"Can't create mympd_script thread":{"de-DE":"Konnte mympd_script Thread nicht erstellen","ko-KR":"mympd_script 스레드를 만들 수 없음","nl-NL":"Kan mympd_script Thread niet maken"},"Can't save setting %{setting}":{"de-DE":"%{setting} konnte nicht gespeichert werden","es-VE":"Error al guardar la configuración: %{setting}","fi-FI":"Ei voi tallentaa asetusta %{setting}","ko-KR":"%{setting} 설정 저장할 수 없음","nl-NL":"Kan instelling %{setting} niet saven"},"Cancel":{"de-DE":"Abbrechen","es-VE":"Cancelar","fi-FI":"Peruuta","ko-KR":"취소","nl-NL":"Annuleren"},"Clear":{"de-DE":"Löschen","es-VE":"Limpiar","fi-FI":"Tyhjennä","ko-KR":"지우기","nl-NL":"Wissen"},"Clear app cache and reload":{"de-DE":"Browser Cache löschen und neu laden","es-VE":"Borrar caché de la app y recargar","fi-FI":"Tyhjennä ohjelman välimuisti ja lataa uudelleen","ko-KR":"앱 캐시를 지우고 다시 읽기","nl-NL":"Wis app-cache en herlaad"},"Clear covercache":{"de-DE":"Covercache löschen","es-VE":"Limpiar Covercache","fi-FI":"Tyhjennä Covercache","ko-KR":"표지 캐시 지우기","nl-NL":"Wis covercache"},"Clear playlist":{"de-DE":"Playlist leeren","es-VE":"Limpiar lista de reproducción","fi-FI":"Tyhjää soittolista","ko-KR":"연주목록 비우기","nl-NL":"Wis afspeellijst"},"Clear queue":{"de-DE":"Warteschlange leeren","es-VE":"Borrar cola de reproducción","fi-FI":"Tyhjennä jono","ko-KR":"순서 비우기","nl-NL":"Wachtrij wissen"},"Clearing bookmarks failed":{"de-DE":"Löschen aller Lesezeichen fehlgeschlagen","es-VE":"Error al borrar marcadores","fi-FI":"Kirjanmerkkien tyhjentäminen epäonnistui","ko-KR":"즐겨찾기 지우기 안 됨","nl-NL":"Wissen bladwijzers mislukt"},"Close":{"de-DE":"Schließen","es-VE":"Cerrar","fi-FI":"Sulje","ko-KR":"닫기","nl-NL":"Sluit"},"Comment":{"de-DE":"Kommentar","es-VE":"Comentario","fi-FI":"Kommenttti","ko-KR":"설명","nl-NL":"Commentaar"},"Composer":{"de-DE":"Komponist","es-VE":"Compositor","fi-FI":"Säveltäjä","ko-KR":"작곡가","nl-NL":"Componist"},"Conductor":{"de-DE":"Dirigent","es-VE":"Director","fi-FI":"Kapelllimestari","ko-KR":"지휘자","nl-NL":"Dirigent"},"Connect to websocket":{"de-DE":"Websocketverbindung wird hergestellt","es-VE":"Conectando a websocket","fi-FI":"Yhdistetään websockettiin","ko-KR":"웹소켓에 연결","nl-NL":"Verbinden met websocket"},"Connected to MPD":{"de-DE":"Verbindung zu MPD hergestellt","es-VE":"Conectado a MPD","fi-FI":"Yhdistetty MPD:hen","ko-KR":"MPD로 연결됨","nl-NL":"Verbonden met MPD"},"Connected to myMPD":{"de-DE":"Verbindung zu myMPD hergestellt","es-VE":"Conectado a myMPD","fi-FI":"Yhdistetty myMPD:hen","ko-KR":"myMPD로 연결됨","nl-NL":"Verbonden met myMPD"},"Connecting to stream...":{"de-DE":"Verbinde...","es-VE":"Conectando fuente...","fi-FI":"Yhdistetään...","ko-KR":"스트리밍에 연결 중...","nl-NL":"Verbinden..."},"Connection":{"de-DE":"Verbindung","es-VE":"Conexión","fi-FI":"Yhteys","ko-KR":"연결","nl-NL":"Verbinding"},"Consume":{"de-DE":"Konsumieren","es-VE":"Consumir","fi-FI":"Kuluta","ko-KR":"써버리기","nl-NL":"Consumeren"},"Consume must be enabled":{"de-DE":"Konsumieren muss aktiviert sein","es-VE":"Modo Consumir debe estar habilitado","fi-FI":"Kulutuksen oltava päällä","ko-KR":"소비를 선택해야 함","nl-NL":"Consumeren moet zijn ingeschakeld"},"Could not delete script":{"de-DE":"Skript konnte nicht gelöscht werden","ko-KR":"스크립트를 지울 수 없음","nl-NL":"Kan script niet deleten"},"Could not delete trigger":{"de-DE":"Konnte Trigger nicht löschen","ko-KR":"트리거를 지울 수 없음","nl-NL":"Kan trigger niet deleten"},"Could not save script":{"de-DE":"Skript konnte nicht gespeichert werden","ko-KR":"스크립트를 저장할 수 없음","nl-NL":"Kan script niet saven"},"Could not save trigger":{"de-DE":"Konnte Trigger nicht speichern","ko-KR":"트리거를 저장할 수 없음","nl-NL":"Kan trigger niet saven"},"Create Playlist":{"de-DE":"Neue Wiedergabeliste erstellen","es-VE":"Crear lista de reproducción","fi-FI":"Luo soittolista","ko-KR":"연주목록 만들기","nl-NL":"Maak afspeellijst"},"Crop":{"de-DE":"Abschneiden","es-VE":"Cortar","fi-FI":"Rajaa","ko-KR":"잘라내기","nl-NL":"Inkorten"},"Crop queue":{"de-DE":"Warteschlange abschneiden","es-VE":"Cortar cola de reproducción","fi-FI":"Rajaa jono","ko-KR":"순서 남기기","nl-NL":"Wachtrij inkorten"},"Crossfade":{"de-DE":"Crossfade","es-VE":"Fundido cruzado","fi-FI":"Crossfade","ko-KR":"크로스페이드","nl-NL":"Crossfade"},"Current partition":{"de-DE":"Momentane Partition","ko-KR":"현재 파티션","nl-NL":"Huidige partitie"},"DB play time":{"de-DE":"Datenbank Wiedergabedauer","es-VE":"Tiempo de reproducción BD","fi-FI":"Tietokannan toistoaika","ko-KR":"DB 연주 시간","nl-NL":"DB speeltijd"},"DB updated":{"de-DE":"Datenbank zuletzt aktualisiert","es-VE":"BD actualizada","fi-FI":"Tietokanta päivitettty","ko-KR":"DB 업데이트됨","nl-NL":"DB geüpdatet"},"Dark":{"de-DE":"Dunkel","es-VE":"Oscuro","fi-FI":"Tumma","ko-KR":"어둠","nl-NL":"Donker"},"Database":{"de-DE":"Datenbank","es-VE":"Base de datos","fi-FI":"Tietokanta","ko-KR":"데이터 베이스","nl-NL":"Database"},"Database statistics":{"de-DE":"Datenbank Statistiken","es-VE":"Estadísticas de Base de datos","fi-FI":"Tietokanta tilastot","ko-KR":"데이터베이스 통계","nl-NL":"Database statistieken"},"Database successfully updated":{"de-DE":"Datenbank erfolgreich aktualisiert","es-VE":"Base de datos actualizada exitosamente","fi-FI":"Tietokannan päivitys onnistui","ko-KR":"데이터베이스 업데이트됨","nl-NL":"Database geüpdatet"},"Database update finished":{"de-DE":"Datenbankaktualisierung beendet","es-VE":"Finalizó la actualización de la base de datos","fi-FI":"Tietokannan päivitys valmis","ko-KR":"데이터베이스 업데이트 마침","nl-NL":"Update database klaar"},"Database update started":{"de-DE":"Datenbankaktualisierung gestartet","es-VE":"Inició la actualización de la base de datos","fi-FI":"Tietokannan päivitys aloitettu","ko-KR":"데이터베이스 업데이트 시작됨","nl-NL":"Updaten database gestart"},"Date":{"de-DE":"Datum","es-VE":"Año","fi-FI":"Päiväys","ko-KR":"날짜","nl-NL":"Datum"},"Days":{"de-DE":"Tage","en-US":"Days","es-VE":"Dias","fi-FI":"Päivää","ko-KR":"일","nl-NL":"Dagen"},"Default":{"de-DE":"Standard","es-VE":"Por defecto","fi-FI":"Vakio","ko-KR":"기본","nl-NL":"Standaard"},"Definition":{"de-DE":"Definition","es-VE":"Definición","fi-FI":"Määritelmä","ko-KR":"결정","nl-NL":"Definitie"},"Delete":{"de-DE":"Löschen","es-VE":"Eliminar","fi-FI":"Poista","ko-KR":"지우기","nl-NL":"Delete"},"Delete all playlists":{"de-DE":"Alle Wiedergabelisten löschen","es-VE":"Eliminar todas las listas de reproducción","fi-FI":"Poista kaikki soittolistat","ko-KR":"모든 연주목록 지움","nl-NL":"Delete alle afspeellijsten"},"Delete all smart playlists":{"de-DE":"Alle Intelligenten Wiedergabelisten löschen","es-VE":"Eliminar todas las listas de reproducción inteligentes","fi-FI":"Poista kaikki älykkäät soittolistat","ko-KR":"모든 스마트 연주목록 지움","nl-NL":"Delete alle afspeellijsten"},"Delete empty playlists":{"de-DE":"Alle leere Wiedergabelisten löschen","es-VE":"Eliminar listas de reproducción vacias","fi-FI":"Poista tyhjät soittolistat","ko-KR":"빈 연주목록 지움","nl-NL":"Delete lege afspeellijsten"},"Delete home icon":{"de-DE":"Löschen"},"Delete playlist":{"de-DE":"Wiedergabeliste löschen","es-VE":"Eliminar lista de reproducción","fi-FI":"Poista soittolista","ko-KR":"연주목록 지우기","nl-NL":"Delete afspeellijst"},"Delete playlists":{"de-DE":"Wiedergabelisten löschen","es-VE":"Eliminar listas de reproducción","fi-FI":"Poista soittolistat","ko-KR":"연주목록 지움","nl-NL":"Delete afspeellijsten"},"Deleting bookmark failed":{"de-DE":"Lesezeichen konnte nicht gelöscht werden","es-VE":"Error al eliminar marcador","fi-FI":"Kirjanmerkin poisto epäonnistui","ko-KR":"즐겨찾기 지우기 안 됨","nl-NL":"Verwijderen bladwijzer mislukt"},"Deleting smart playlist failed":{"de-DE":"Intelligente Wiedergabeliste konnte nicht gelöscht werden","es-VE":"Error al eliminar lista de reproducción inteligente","fi-FI":"Älykkään soittolista poisto epäonnistui","ko-KR":"스마트 연주목록 지우기 안 됨","nl-NL":"Verwijderen slimme afspeellijst mislukt"},"Dependent on the size of your music collection this can take a while":{"de-DE":"Der Aktualisierungsvorgang kann einige Zeit in Anspruch nehmen","es-VE":"Dependiendo del tamaño de su colección de música, esto puede llevar un tiempo","fi-FI":"Riippuen musiikkikokoelman koosta, tässä voi mennä hetki","ko-KR":"음원 크기에 따라 시간이 걸릴 수 있습니다","nl-NL":"Afhankelijk van de grootte van de muziekcollectie kan dit even duren"},"Descending":{"de-DE":"Absteigend","es-VE":"Descendiente","fi-FI":"Laskeva","ko-KR":"내림차순","nl-NL":"Aflopend"},"Details":{"de-DE":"Details","ko-KR":"상세","nl-NL":"Details"},"Disabled":{"de-DE":"Deaktiviert","es-VE":"Desactivado","fi-FI":"Poistettu käytöstä","ko-KR":"사용 안 함","nl-NL":"Uitgeschakeld"},"Disc":{"de-DE":"Disc","es-VE":"Disco","fi-FI":"Levy","ko-KR":"디스크","nl-NL":"Disc"},"Disc 1":{"de-DE":"Disc 1","nl-NL":"Disc 1"},"Dislike song":{"de-DE":"Schlechtes Lied","es-VE":"No me gusta esta canción","fi-FI":"Dissaa kappaletta","ko-KR":"곡 좋아하지 않음","nl-NL":"Dislike nummer"},"Download":{"de-DE":"Herunterladen","es-VE":"Descargar","fi-FI":"Lataa","ko-KR":"내려받기","nl-NL":"Download"},"Download booklet":{"de-DE":"Booklet herunterladen","nl-NL":"Download boekje"},"Duplicate home icon":{"de-DE":"Kopieren"},"Duration":{"de-DE":"Länge","es-VE":"Duración","fi-FI":"Kesto","ko-KR":"길이","nl-NL":"Duur"},"Edit attributes":{"de-DE":"Eigenschaften editieren","ko-KR":"속성 수정","nl-NL":"Pas parameters aan"},"Edit home icon":{"de-DE":"Bearbeiten"},"Edit playlist":{"de-DE":"Wiegergabeliste bearbeiten","es-VE":"Editar lista de reproducción","fi-FI":"Muokkaa soittolistaa","ko-KR":"연주목록 편집","nl-NL":"Bewerk afspeellijst"},"Edit smart playlist":{"de-DE":"Intelligente Wiedergabeliste bearbeiten","es-VE":"Editar lista de reproducción inteligente","fi-FI":"Muokkaa älykästä soittolistaa","ko-KR":"스마트 연주목록 편집","nl-NL":"Bewerk slimme afspeellijst"},"Editing scripts is disabled":{"de-DE":"Das Editieren von Skripts ist deaktiviert","ko-KR":"스크립트 편집 사용 안 함","nl-NL":"Bewerken scripts is uitgeschakeld"},"Empty list":{"de-DE":"Leere Liste","es-VE":"Lista vacía","fi-FI":"Tyhjä lista","ko-KR":"목록 비우기","nl-NL":"Lege lijst"},"Empty playlist":{"de-DE":"Leere Wiedergabeliste","es-VE":"Lista de reproducción vacía","fi-FI":"Tyhjä soittolista","ko-KR":"연주목록 비우기","nl-NL":"Lege afspeellijst"},"Empty queue":{"de-DE":"Leere Warteschlange","es-VE":"Cola de reproducción vavía","fi-FI":"Tyhjä jono","ko-KR":"순서 비우기","nl-NL":"Lege wachtrij"},"Enable jukebox if playlist is database":{"de-DE":"Jukebox muss aktiviert sein, wenn als Wiedergabeliste die Datenbank ausgewählt ist.","es-VE":"Habilite Jukebox si la lista de reproducción es la base de datos","fi-FI":"Salli jukeboksi jos soittolista tietokanta","ko-KR":"연주목록이 데이터베이스이면 뮤직박스 사용함","nl-NL":"Schakel jukebox in wanneer database als afspeellijst is geselecteerd"},"Enabled":{"de-DE":"Aktiv","es-VE":"Habilitado","fi-FI":"Päällä","ko-KR":"사용함","nl-NL":"Ingeschakeld"},"Enforce uniqueness":{"de-DE":"Erzwinge Eindeutigkeit","es-VE":"Hacer cumplir la singularidad","fi-FI":"Pakota yksilöllisyys","ko-KR":"유일성 강제","nl-NL":"Gelijkenis op basis van"},"Error":{"de-DE":"Fehler","es-VE":"Error","fi-FI":"Virhe","ko-KR":"오류","nl-NL":"Fout"},"Error executing script %{script}":{"de-DE":"Fehler beim Ausführen des Skripts %{script}","ko-KR":"스크립트 %{script} 실행 오류","nl-NL":"Fout bij uitvoeren script %{script}"},"Error executing script %{script}: Can not open or read script file":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Skript Datei kann nicht geöffnet oder gelesen werden","ko-KR":"스크립트 %{script} 실행 오류: 스크립트 파일을 열거나 읽을 수 없음","nl-NL":"Fout bij uitvoeren script %{script}: Kan script niet openen of lezen"},"Error executing script %{script}: Error in garbage collector":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Fehler im Garbage Collector","ko-KR":"스크립트 %{script} 실행 오류: 가비지 수집 오류","nl-NL":"Fout bij uitvoeren script %{script}: Fout in garbage collector"},"Error executing script %{script}: Error while running the message handler":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Fehler bei der Ausführung des Messagehandlers","ko-KR":"스크립트 %{script} 실행 오류: 메시지 처리 실행 오류","nl-NL":"Fout bij uitvoeren script %{script}: Fout tijdens uitvoeren van message handler"},"Error executing script %{script}: Memory allocation error":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Speicherzuweisungsfehler","ko-KR":"스크립트 %{script} 실행 오류: 메모리 할당 오류","nl-NL":"Fout bij uitvoeren script %{script}: Geheugentoewijzingsfout"},"Error executing script %{script}: Runtime error":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Laufzeitfehler","ko-KR":"스크립트 %{script} 실행 오류: 런타임 오류","nl-NL":"Fout bij uitvoeren script %{script}: Runtime-fout"},"Error executing script %{script}: Syntax error during precompilation":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Syntax Fehler","ko-KR":"스크립트 %{script} 실행 오류: 전처리 컴파일 문법 오류","nl-NL":"Fout bij uitvoeren script %{script}: syntaxisfout tijdens precompilatie"},"Error in response to command: %{command}":{"de-DE":"Fehler beim Ausführen von %{command}","es-VE":"Error en respuesta al comando: %{command}","fi-FI":"Virhe komennolla %{command}","ko-KR":"명령어 오류: %{command}","nl-NL":"Uitvoerfout in: %{command}"},"Error loading stream":{"de-DE":"Fehler beim Laden des Streams","ko-KR":"스트리밍 읽기 오류","nl-NL":"Fout bij laden stream"},"Event":{"de-DE":"Ereignis","ko-KR":"이벤트","nl-NL":"Gebeurtenis"},"Execute":{"de-DE":"Ausführen","ko-KR":"실행","nl-NL":"Uitvoeren"},"Execute home icon action":{"de-DE":"Ausführen"},"Execute script":{"de-DE":"Skript ausführen","ko-KR":"스크립트 실행","nl-NL":"Voer script uit"},"Failed to execute cmd %{cmd}":{"de-DE":"Fehler beim Ausführen des Systembefehls %{cmd}","es-VE":"Error al ejecutar el comando: %{cmd}","fi-FI":"Komennon %{cmd} suorittaminen epäonnistui","ko-KR":"%{cmd} 명령어 실행 안 됨","nl-NL":"Uitvoeren mislukt cmd %{cmd}"},"Failed to open bookmarks file":{"de-DE":"Lesezeichen Datei konnte nicht geöffnet werden","es-VE":"Error al abrir el archivo de marcadores","fi-FI":"Kirjanmerkki tiedoston avaaminen epäonnistui","ko-KR":"즐겨찾기 파일 열기 안 됨","nl-NL":"Openen bladwijzer mislukt"},"Failed to save playlist":{"de-DE":"Wiedergabeliste konnte nicht gespeichert werden","es-VE":"Error al guardar lista de reproducción","fi-FI":"Soittolistan tallennus epäonnistui","ko-KR":"연주목록 저장 안 됨","nl-NL":"Saven afspeellijst mislukt"},"Failed to send love message to channel":{"de-DE":"Lieblingslied Nachricht konnte nicht gesendet werden","es-VE":"Error al enviar Me gusta al canal","fi-FI":"Rakkausviestin lähetys kanavalle epäonnistui","ko-KR":"채널에 애청곡 메시지 보내기 안 됨","nl-NL":"Versturen favoriet mislukt"},"Failed to set like, invalid like value":{"de-DE":"Wertung konnte nicht gesetzt werden, ungültiger Wert","es-VE":"Error al establecer me gusta, no válido","fi-FI":"Tykkäystä ei voitu asettaa, virheellinen tykkäys arvo","ko-KR":"잘못된 값으로 좋아요 설정 안 됨","nl-NL":"Like mislukt, ongeldige waarde"},"Failed to set like, invalid song uri":{"de-DE":"Wertung konnte nicht gesetzt werden, ungültige Lied URL","es-VE":"Error al establecer me gusta, URI de canción inválido","fi-FI":"Tykkäystä ei voitu asettaa, virheellinen kappaleen URI","ko-KR":"잘못된 곡 주소로 좋아요 설정 안 됨","nl-NL":"Like mislukt, ongeldige url"},"Fetch MPD settings":{"de-DE":"Lade MPD Einstellungen","es-VE":"Cargando configuraciones de myMPD","fi-FI":"Haetaan MPD asetukset","ko-KR":"MPD 설정 가져오기","nl-NL":"MPD-instellingen laden"},"Fetch myMPD settings":{"de-DE":"Lade myMPD Einstellungen","es-VE":"Cargando configuraciones de myMPD","fi-FI":"Noudetaan myMPD asetukset","ko-KR":"myMPD 설정 가져오기","nl-NL":"myMPD-instellingen laden"},"Fileformat":{"de-DE":"Dateiformat","es-VE":"Formato","fi-FI":"Tiedostomuoto","ko-KR":"파일 포맷","nl-NL":"Bestandsformaat"},"Filename":{"de-DE":"Dateiname","es-VE":"Archivo","fi-FI":"Tiedostonimi","ko-KR":"파일 이름","nl-NL":"Bestandsnaam"},"Filesystem":{"de-DE":"Dateisystem","es-VE":"Sistema de archivos","fi-FI":"Tiedostojärjestelmä","ko-KR":"파일 시스템","nl-NL":"Bestanden"},"Filetype":{"de-DE":"Dateityp","es-VE":"Tipo","fi-FI":"Tiedostotyyppi","ko-KR":"파일 형식","nl-NL":"Bestandstype"},"Filling jukebox queue failed, disabling jukebox":{"de-DE":"Jukebox Warteschlange konnte nicht aufgefüllt werden, Jukebox wurde deaktiviert","ko-KR":"뮤직박스 순서를 채울 수 없어 사용 안 함","nl-NL":"Vullen van de jukebox-wachtrij mislukt, jukebox wordt uitgeschakeld"},"Fingerprint":{"de-DE":"Fingerabdruck","es-VE":"Huella","fi-FI":"Sormenjälki","ko-KR":"지문","nl-NL":"Fingerprint"},"Fingerprint command not supported":{"de-DE":"Fingerprint Befehl ist nicht unterstützt","es-VE":"Comando de huella no soportado","fi-FI":"Sormenjälki komento ei tuettu","ko-KR":"지문 명령어 지원 안 됨","nl-NL":"Fingerprint commando niet ondersteund"},"Focus search":{"de-DE":"Gehe zur Suche","es-VE":"Centrar en búsqueda","fi-FI":"Tarkenna haku","ko-KR":"찾기로 가기","nl-NL":"Naar Zoeken"},"Focus table":{"de-DE":"In Tabelle navigieren","es-VE":"Centrar en tabla","fi-FI":"Tarkenna taulu","ko-KR":"목록에서 찾기","nl-NL":"In tabel navigeren"},"Force smart playlist update":{"de-DE":"Aktualisierung der intelligenten Wiedergabelisten erzwingen","ko-KR":"스마트 연주목록 강제 업데이트","nl-NL":"Forceer update smart playlist"},"Force update":{"de-DE":"Erzwinge Aktualisierung","ko-KR":"강제 업데이트","nl-NL":"Forceer update"},"Fri":{"de-DE":"Fr","es-VE":"Vie","fi-FI":"Pe","ko-KR":"금","nl-NL":"Vr"},"From":{"de-DE":"Von","es-VE":"De","fi-FI":"Mistä","ko-KR":"원래","nl-NL":"Van"},"Fullscreen":{"de-DE":"Vollbild","ko-KR":"전체 화면","nl-NL":"Schermvullend"},"General":{"de-DE":"Allgemein","es-VE":"General","fi-FI":"Yleinen","ko-KR":"일반","nl-NL":"Algemeen"},"Generate smart playlist per":{"de-DE":"Erstelle intelligente Wiedergabelisten für","es-VE":"Generar lista de reproducción inteligente por","fi-FI":"Luo älykäs soittolista perustuen","ko-KR":"스마트 연주목록 생성","nl-NL":"Genereer slimme afspeellijst op basis van"},"Genre":{"de-DE":"Genre","es-VE":"Género","fi-FI":"Genre","ko-KR":"장르","nl-NL":"Genre"},"Goto browse database":{"de-DE":"Gehe zu Datenbank durchsuchen","es-VE":"Ir a explorar base de datos","fi-FI":"Siirry tietokannan selaamiseen","ko-KR":"데이터베이스 열기로 가기","nl-NL":"Database openen"},"Goto browse filesystem":{"de-DE":"Gehe zu Dateisystem","es-VE":"Ir a explorar sistema de archivos","fi-FI":"Siirry tiedostojärjelmän selaukseen","ko-KR":"파일 시스템 열기로 가기","nl-NL":"Bestandssysteem openen"},"Goto browse playlists":{"de-DE":"Gehe zu Wiedergabelisten","es-VE":"Ir a explorar listas de reproducción","fi-FI":"Siirry soittolistojen selaukseen","ko-KR":"연주목록 열기로 가기","nl-NL":"Afspeellijsten openen"},"Goto last played":{"de-DE":"Gehe zu Zuletzt gespielt","es-VE":"Ir a última reproducción","fi-FI":"Siirry viimeksi soitettuun","ko-KR":"앞선 연주로 가기","nl-NL":"Laatst afgespeeld openen"},"Goto playback":{"de-DE":"Gehe zu Wiedergabe","es-VE":"Ir a lista de reproducción","fi-FI":"Siirry toistoon","ko-KR":"연주로 가기","nl-NL":"Afspelen openen"},"Goto playing song":{"de-DE":"Gehe zum aktuell gespielten Lied","ko-KR":"연주 곡으로 가기","nl-NL":"xxx"},"Goto queue":{"de-DE":"Gehe zu Warteschlange","es-VE":"Ir a cola de reproducción","fi-FI":"Siirry jonoon","ko-KR":"순서로 가기","nl-NL":"Wachtrij openen"},"Goto search":{"de-DE":"Gehe zur Suche","es-VE":"Ir a buscar","fi-FI":"Siirry hakuun","ko-KR":"찾기로 가기","nl-NL":"Zoeken openen"},"Grouping":{"de-DE":"Grupierung","es-VE":"Agrupación","fi-FI":"Ryhmittely","ko-KR":"묶음","nl-NL":"Groepering"},"HTTP Port":{"de-DE":"HTTP Port","ko-KR":"HTTP 포트","nl-NL":"HTTP-poort"},"HTTPS Port":{"de-DE":"HTTPS Port","ko-KR":"HTTPS 포트","nl-NL":"HTTPS-poort"},"Highlight color":{"de-DE":"Highlight Farbe","es-VE":"Color de realce","fi-FI":"Valintaväri","ko-KR":"강조색","nl-NL":"Accentkleur"},"Home":{"de-DE":"Startseite"},"Homepage":{"de-DE":"Homepage","es-VE":"Página de Inicio","fi-FI":"Kotisivu","ko-KR":"홈페이지","nl-NL":"Website"},"Hours":{"de-DE":"Std","en-US":"Hrs","es-VE":"Horas","fi-FI":"Tuntia","ko-KR":"시간","nl-NL":"h"},"IP-Address":{"de-DE":"IP-Adresse","es-VE":"Dirección IP","fi-FI":"IP-osoite","ko-KR":"IP 주소","nl-NL":"IP-adres"},"Info":{"de-DE":"Hinweis","es-VE":"Info","fi-FI":"Tietoa","ko-KR":"정보","nl-NL":"Info"},"Initializing myMPD":{"de-DE":"Initialisiere myMPD","es-VE":"Inicializando myMPD","fi-FI":"Käynnistetään myMPD","ko-KR":"myMPD 초기화","nl-NL":"Voorbereiden myMPD"},"Invalid API request":{"de-DE":"Ungültiger API Befehl","es-VE":"Solicitud API incorrecta","fi-FI":"Virheellinen API pyyntö","ko-KR":"잘못된 API 요구","nl-NL":"Ongeldig API-verzoek"},"Invalid CSS filter":{"de-DE":"Ungültiger CSS Filter","es-VE":"Filtro CSS inválido","fi-FI":"Virheellinen CSS suodatin","ko-KR":"잘못된 CSS 필터","nl-NL":"Ongeldig CSS-filter"},"Invalid MPD host":{"de-DE":"Ungültiger MPD Host","es-VE":"Servidor MPD inválido","fi-FI":"Virheellinen MPD isäntä","ko-KR":"잘못된 MPD 호스트","nl-NL":"Ongeldige MPD host"},"Invalid MPD password":{"de-DE":"Ungültiges MPD Passwort","es-VE":"Contraseña MPD inválida","fi-FI":"Virheellinen MPD salasana","ko-KR":"잘못된 MPD 비밀번호","nl-NL":"Ongeldig MPD wachtwoord"},"Invalid MPD port":{"de-DE":"Ungültiger MPD Port","es-VE":"Puerto MPD inválido","fi-FI":"Virheellinen MPD Portti","ko-KR":"잘못된 MPD 포트","nl-NL":"Ongeldige MPD poort"},"Invalid URI":{"de-DE":"Ungültige URL","es-VE":"URL Inválida","fi-FI":"Epäkelpo URI","ko-KR":"잘못된 주소","nl-NL":"Ongeldige url"},"Invalid backend uri":{"de-DE":"Ungültige einzuhängende URL","es-VE":"URL de Back-End inválida","fi-FI":"Virheellinen järjestelmä uri","ko-KR":"잘못된 백엔드 URL","nl-NL":"Ongeldige backend-url"},"Invalid channel name":{"de-DE":"Ungültiger Channel name","es-VE":"Nombre de canal inválido","fi-FI":"Virheellinen kanavanimi","ko-KR":"잘못된 채널 이름","nl-NL":"ongeldige naam"},"Invalid color":{"de-DE":"Ungültige Farbe","es-VE":"Color inválido","fi-FI":"Virheellinen väri","ko-KR":"잘못된 색상","nl-NL":"Ongeldige kleur"},"Invalid column":{"de-DE":"Ungültiger Spaltenname","fi-FI":"Väärä sarake","ko-KR":"잘못된 열","nl-NL":"Onjuiste kolom"},"Invalid filename":{"de-DE":"Ungültiger Dateiname","es-VE":"Nombre de archivo inválido","fi-FI":"Väärä tiedostonimi","ko-KR":"잘못된 파일 이름","nl-NL":"Ongeldige bestandsnaam"},"Invalid message":{"de-DE":"Ungültige Zeichen in Nachricht","es-VE":"Mensaje inválido","fi-FI":"Virheellinen viesti","ko-KR":"잘못된 메시지","nl-NL":"Ongeldig bericht"},"Invalid mount point":{"de-DE":"Ungültiger Einhängepunkt","es-VE":"Punto de montaje inválido","fi-FI":"Virheellinen liityntäköhta","ko-KR":"잘못된 마운트 위치","nl-NL":"Ongeldig aankoppelpunt"},"Invalid music directory":{"de-DE":"Ungültiges Musikverzeichnis","es-VE":"Directorio de música inválido","fi-FI":"Virheellinen musiikkikansio","ko-KR":"잘못된 음원 디렉터리","nl-NL":"Ongeldige muziekmap"},"Invalid name":{"de-DE":"Ungültiger Name","es-VE":"Nombre inválido","fi-FI":"Virheellinen nimi","ko-KR":"잘못된 이름","nl-NL":"Ongeldige naam"},"Invalid number":{"de-DE":"Ungültige Zahl","es-VE":"Número inválido","fi-FI":"Virheellinen numero","ko-KR":"잘못된 숫자","nl-NL":"Ongeldig getal"},"Invalid partition name":{"de-DE":"Ungültiger Partition Name","ko-KR":"잘못된 파티션 이름","nl-NL":"Ongeldige partitienaam"},"Invalid prefix":{"de-DE":"Ungültiger Prefix","es-VE":"Prefijo inválido","fi-FI":"Virheellinen etuliite","ko-KR":"잘못된 덧붙임","nl-NL":"Ongeldig voorvoegsel"},"Invalid scale ratio":{"de-DE":"Ungültiger Skalierungswert","ko-KR":"잘못된 크기 비율","nl-NL":"Ongeldige schaalverhouding"},"Invalid script API request":{"de-DE":"Ungültiger Script-API Aufruf","ko-KR":"잘못된 스크립트 API 요청","nl-NL":"Ongeldige script-API-verzoek"},"Invalid script argument":{"de-DE":"Ungültiger Skriptparameter","ko-KR":"잘못된 스크립트 변수","nl-NL":"Ongeldig scriptargument"},"Invalid script name":{"de-DE":"Ungültiger Skriptname","ko-KR":"잘못된 스크립트 이름","nl-NL":"Ongeldige script naam"},"Invalid script order":{"de-DE":"Ungültige Skriptreihenfolge","ko-KR":"잘못된 스크립트 순서","nl-NL":"Ongeldige scriptvolgorde"},"Invalid size":{"de-DE":"Ungültige Größe","es-VE":"Tamaño inválido","fi-FI":"Virheellinen koko","ko-KR":"잘못된 크기","nl-NL":"Ongeldige grootte"},"Invalid trigger name":{"de-DE":"Ungültiger Trigger Name","ko-KR":"잘못된 트리거 이름","nl-NL":"Ongeldige triggernaam"},"Invalid type":{"de-DE":"Ungültiger Typ","es-VE":"Tipo inválido","fi-FI":"Väärä tyyppi","ko-KR":"잘못된 형식","nl-NL":"Ongeldig type"},"JavaScript error":{"de-DE":"JavaScript Fehler","es-VE":"Error de JavaScript","fi-FI":"JavaScript virhe","ko-KR":"자바스크립트 오류","nl-NL":"JavaScript fout"},"JavaScript is disabled":{"de-DE":"JavaScript ist deaktiviert","es-VE":"JavaScript esta deshabilitado","fi-FI":"JavaScript poistettu käytöstä","ko-KR":"자바스크립트 사용 안 함","nl-NL":"JavaScript uitgeschakeld"},"Jukebox":{"de-DE":"Jukebox","es-VE":"Jukebox","fi-FI":"Jukebox","ko-KR":"뮤직박스","nl-NL":"Jukebox"},"Jukebox mode":{"de-DE":"Jukebox Modus","es-VE":"Modo Jukebox","fi-FI":"Jukebox tila","ko-KR":"뮤직박스 모드","nl-NL":"Jukebox-modus"},"Keep queue length":{"de-DE":"Warteschlangenlänge","es-VE":"Mantener longitud de cola de reproducción","fi-FI":"Pidä jonon pituus","ko-KR":"순서 길이 유지","nl-NL":"Aantal in wachtrij"},"Label":{"de-DE":"Herausgeber","es-VE":"Etiqueta","fi-FI":"Julkaisija","ko-KR":"음반사","nl-NL":"Label"},"Last modified":{"de-DE":"Zuletzt geändert","es-VE":"Últ. modificación","fi-FI":"Viimeksi muokattu","ko-KR":"앞서 수정함","nl-NL":"Laatst gewijzigd"},"Last played":{"de-DE":"Zuletzt gespielt","es-VE":"Última reproducción","fi-FI":"Viimeksi soitettu","ko-KR":"앞서 연주함","nl-NL":"Laatst afgespeeld"},"Last played list count":{"de-DE":"Anzahl zuletzt gespielte Lieder","es-VE":"Conteo reproducción de última lista","fi-FI":"Viimeksi soitettujen listan koko","ko-KR":"앞선 연주 목록 개수","nl-NL":"Aantal laatst afgespeelde nummers"},"Last played older than (hours)":{"de-DE":"Zuletzte gespielt, vor mehr als (Stunden)","es-VE":"Última reproducción mas viejo que (horas)","fi-FI":"Viimeksi toistettu vanhempi kuin (Stunden)","ko-KR":"이전에 연주됨 (시간)","nl-NL":"Laatst afgespeeld, ouder dan (uur)"},"Last skipped":{"de-DE":"Zuletzt übersprungen","es-VE":"Última omisión","fi-FI":"Viimeksi ohitettu","ko-KR":"앞서 건너뜀","nl-NL":"Laatst overgeslagen"},"LastModified":{"de-DE":"Zuletzt geändert","en-US":"Last modified","es-VE":"Últ. modif.","fi-FI":"ViimeksiMuokattu","ko-KR":"마지막 수정","nl-NL":"Laatst gewijzigd"},"LastPlayed":{"de-DE":"Zuletzt gespielt","es-VE":"Última reproducción","fi-FI":"ViimeksiSoitettu","ko-KR":"앞서 연주함","nl-NL":"Laatst afgespeeld"},"Leaving playlist as it is":{"de-DE":"Wiedergabeliste wird nicht verändert","es-VE":"Dejando la lista de reproducción como está","fi-FI":"Soittolista jätetään entiselleen","ko-KR":"연주목록을 그대로 둠","nl-NL":"Afspeellijst niet gewijzigd"},"Libmpdclient version":{"de-DE":"Libmpdclient Version","es-VE":"Versión Libmpdclient","fi-FI":"Libmpdclient Versio","ko-KR":"Libmpdclient 버전","nl-NL":"Versie libmpdclient"},"Libmympdclient version":{"de-DE":"Libmympdclient Version","es-VE":"Versión Libmympdclient","fi-FI":"Libmympdclient Versio","ko-KR":"Libmympdclient 버전","nl-NL":"Versie libmympdclient"},"Ligature":{"de-DE":"Ligatur"},"Light":{"de-DE":"Hell","es-VE":"Claro","fi-FI":"Vaalea","ko-KR":"밝음","nl-NL":"Licht"},"Like":{"de-DE":"Wertung","es-VE":"Me gusta","fi-FI":"Tykkää","ko-KR":"좋아요","nl-NL":"Like"},"Like song":{"de-DE":"Gutes Lied","es-VE":"Me gusta esta canción","fi-FI":"Tykkää kappaleesta","ko-KR":"곡 좋아요","nl-NL":"Like nummer"},"Local playback":{"de-DE":"Lokale Wiedergabe","es-VE":"Reproducción local","fi-FI":"Paikallinen toisto","ko-KR":"로컬 연주","nl-NL":"Lokale weergave"},"Locale":{"de-DE":"Sprache","es-VE":"Idioma","fi-FI":"Kielivalinta","ko-KR":"언어","nl-NL":"Taal"},"Love song":{"de-DE":"Lieblingslied","es-VE":"Me encanta esta canción","fi-FI":"Rakkauslaulu","ko-KR":"애청곡","nl-NL":"Favoriet"},"Lyrics":{"de-DE":"Liedtext","es-VE":"Letras","fi-FI":"Sanoitukset","ko-KR":"가사","nl-NL":"Songtekst"},"MPD channel":{"de-DE":"MPD Channel","es-VE":"Canal MPD","fi-FI":"MPD kanava","ko-KR":"MPD 채널","nl-NL":"MPD-kanaal"},"MPD channel not found":{"de-DE":"MPD Channel nicht gefunden","es-VE":"Canal MPD no encontrado","fi-FI":"MPD kanavaa ei löytynyt","ko-KR":"MPD 채널 없음","nl-NL":"MPD-kanaal niet gevonden"},"MPD connection":{"de-DE":"MPD Verbindung","es-VE":"Conexión MPD","fi-FI":"MPD Yhteys","ko-KR":"MPD 연결","nl-NL":"MPD-verbinding"},"MPD connection error: %{error}":{"de-DE":"MPD Verbindungsfehler: %{error}","es-VE":"Error de conexión MPD: %{error}","fi-FI":"MPD yhteysvirhe: %{error}","ko-KR":"MPD 연결 오류: %{error}","nl-NL":"MPD verbindingsfout: %{error}"},"MPD disconnected":{"de-DE":"MPD nicht verbunden","es-VE":"MPD desconectado","fi-FI":"MPD yhteys katkaistu","ko-KR":"MPD 연결 끊어짐","nl-NL":"MPD niet verbonden"},"MPD host":{"de-DE":"MPD Host","es-VE":"Servidor MPD","fi-FI":"MPD isäntä","ko-KR":"MPD 호스트","nl-NL":"MPD host"},"MPD password":{"de-DE":"MPD Passwort","es-VE":"Contraseña MPD","fi-FI":"MPD Salasana","ko-KR":"MPD 비밀번호","nl-NL":"MPD wachtwoord"},"MPD port":{"de-DE":"MPD Port","es-VE":"Puerto MPD","fi-FI":"MPD Portti","ko-KR":"MPD 포트","nl-NL":"MPD-poort"},"MPD stickers are disabled":{"de-DE":"MPD Sticker sind deaktiviert","es-VE":"Los Stickers MPD están deshabilitados","fi-FI":"MPD Stickerit pois käytöstä","ko-KR":"MPD 스티커 사용 안 함","nl-NL":"MPD-stickers uitgeschakeld"},"MPD uptime":{"de-DE":"MPD Uptime","es-VE":"Tiempo de actividad MPD","fi-FI":"MPD Uptime","ko-KR":"MPD 가동 시간","nl-NL":"MPD uptime"},"MUSICBRAINZ_ALBUMARTISTID":{"de-DE":"Musicbrainz AlbumArtist ID","es-VE":"Musicbrainz AlbumArtist ID","fi-FI":"Musicbrainz AlbumiArtisti ID","ko-KR":"뮤직브레인즈 음반 연주자 ID","nl-NL":"Musicbrainz AlbumArtist ID"},"MUSICBRAINZ_ALBUMID":{"de-DE":"Musicbrainz Album ID","es-VE":"Musicbrainz Album ID","fi-FI":"Musicbrainz Albumi ID","ko-KR":"뮤직브레인즈 음반 ID","nl-NL":"Musicbrainz Album ID"},"MUSICBRAINZ_ARTISTID":{"de-DE":"Musicbrainz Künstler ID","es-VE":"Musicbrainz Artist ID","fi-FI":"Musicbrainz artisti ID","ko-KR":"뮤직브레인즈 연주자 ID","nl-NL":"Musicbrainz Ariest ID"},"MUSICBRAINZ_RELEASETRACKID":{"de-DE":"Musicbrainz Release Track ID","es-VE":"Musicbrainz Release Track ID","fi-FI":"Musicbrainz Release Track ID","ko-KR":"뮤직브레인즈 발표 곡 ID","nl-NL":"Musicbrainz Release Track ID"},"MUSICBRAINZ_TRACKID":{"de-DE":"Musicbrainz Track ID","es-VE":"Musicbrainz Track ID","fi-FI":"Musicbrainz Track ID","ko-KR":"뮤직브레인즈 곡 ID","nl-NL":"Musicbrainz Track ID"},"MUSICBRAINZ_WORKID":{"de-DE":"Musicbrainz Werk ID","es-VE":"Musicbrainz Work ID","fi-FI":"Musicbrainz Työ ID","ko-KR":"뮤직브레인즈 작품 ID","nl-NL":"Musicbrainz Werk ID"},"Max. songs":{"de-DE":"Max. Lieder","es-VE":"Canciones max.","fi-FI":"Max. kappaleet","ko-KR":"최대 곡","nl-NL":"Max. nummers"},"Media session support":{"de-DE":"Media Session Unterstützung","es-VE":"Soporte de sesión de medios","fi-FI":"Media Session tuki","ko-KR":"미디어 세션 지원","nl-NL":"Mediasessie ondersteuning"},"Message":{"de-DE":"Nachricht","es-VE":"Mensaje","fi-FI":"Viesti","ko-KR":"메시지","nl-NL":"Bericht"},"Min. value":{"de-DE":"Min. Wert","es-VE":"Valor min.","fi-FI":"Min. arvo","ko-KR":"최소 값","nl-NL":"Min. waarde"},"Minimum one weekday must be selected":{"de-DE":"Es muss mindestens ein Wochentag ausgewählt sein.","es-VE":"Debe seleccionar al menos un dia de la semana","fi-FI":"Vähintään yksi päivä pitää valita","ko-KR":"최소 일주일 선택해야 함","nl-NL":"Selecteer minimaal 1 weekdag"},"Minutes":{"de-DE":"Min","en-US":"Min","es-VE":"Min","fi-FI":"Min","ko-KR":"분","nl-NL":"min"},"Mixramp DB":{"de-DE":"Mixramp DB","es-VE":"Mixramp dB","fi-FI":"Mixramp DB","ko-KR":"Mixramp DB","nl-NL":"Mixramp DB"},"Mixramp delay":{"de-DE":"Mixramp Verzögerung","es-VE":"Retraso Mixramp","fi-FI":"Mixramp viive","ko-KR":"Mixramp 지연","nl-NL":"Mixramp-vertraging"},"Mon":{"de-DE":"Mo","es-VE":"Lun","fi-FI":"Ma","ko-KR":"월","nl-NL":"Ma"},"Mongoose version":{"de-DE":"Mongoose Version","es-VE":"Versión Mongoose","fi-FI":"Mongoose Versio","ko-KR":"Mongoose 버전","nl-NL":"Versie Mongoose"},"Most played":{"de-DE":"Am Öftesten gespielt","es-VE":"Más reproducido","fi-FI":"Eniten soitettu","ko-KR":"자주 연주","nl-NL":"Meest afgespeeld"},"Mount point":{"de-DE":"Einhängepunkt","es-VE":"Punto de monaje","fi-FI":"Liityntäkohta","ko-KR":"마운트 위치","nl-NL":"Aankoppelpunt"},"Mounts":{"de-DE":"Einhängepunkte","es-VE":"Montar","fi-FI":"Liitokset","ko-KR":"마운트","nl-NL":"Aankoppelpunten"},"Move an output to this partition":{"de-DE":"Verschiebe ein Ausgabegerät zu dieser Partition","ko-KR":"출력을 이 파티션으로 옮김","nl-NL":"Verplaats output naar deze partitie"},"Music directory":{"de-DE":"Musikverzeichnis","es-VE":"Directorio de música","fi-FI":"Musiikkikansio","ko-KR":"음원 디렉터리","nl-NL":"Muziekmap"},"Music directory not found":{"de-DE":"Musikverzeichnis nicht gefunden","es-VE":"Directorio de música no encontrado","fi-FI":"Musiikkikansiota ei löydy","ko-KR":"음원 디렉터리 없음","nl-NL":"Muziekmap niet gevonden"},"Must be a number":{"de-DE":"Muss eine Zahl sein","es-VE":"Debe ser un número","fi-FI":"Pitää olla numero","ko-KR":"숫자여야 함","nl-NL":"Moet een getal zijn"},"Must be a number and equal or greater than zero":{"de-DE":"Muss eine Zahl größergleich 0 sein","es-VE":"Debe ser un número igual o mayor a cero","fi-FI":"Pitää olla numero joka on nolla tai suurempi","ko-KR":"숫자이고 0과 같거나 커야 함","nl-NL":"Getal moet gelijk of groter zijn dan 0"},"Must be a number and greater than zero":{"de-DE":"Muss eine Zahl größer als 0 sein","es-VE":"Debe ser un número mayor a cero","fi-FI":"Tarvii olla numero joka on suurempi kuin 0","ko-KR":"0보다 큰 숫자여야 함","nl-NL":"Moet een getal zijn en groter dan 0"},"Must be a number smaller or equal 200":{"de-DE":"Muss eine Zahl kleinergleich 200 sein","es-VE":"Debe ser un número menor o igual a 200","fi-FI":"Tarvii olla luku joka on pienempi tai yhtäsuuri kuin 200","ko-KR":"200이하의 숫자여야 함","nl-NL":"Getal moet kleiner zijn dan 200"},"Name":{"de-DE":"Name","es-VE":"Nombre","fi-FI":"Nimi","ko-KR":"이름","nl-NL":"Naam"},"Neighbors are disabled":{"de-DE":"Kein Neighbor Plugin aktiviert","fi-FI":"Naapurit lisäosa poissa käytöstä","ko-KR":"Neighbors 사용 안 함","nl-NL":"Neighbor-plugin uitgeschakeld"},"New mount":{"de-DE":"Neuer Einhängepunkt","es-VE":"Nuevo punto de montaje","fi-FI":"Uusi liitos","ko-KR":"새로운 마운트","nl-NL":"Nieuw aankoppelpunt"},"New partition":{"de-DE":"Neue Partition","ko-KR":"새 파티션","nl-NL":"Nieuwe partitie"},"New playlist":{"de-DE":"Neue Wiedergabeliste","es-VE":"Nueva lista de reproducción","fi-FI":"Uusi soittolista","ko-KR":"새 연주목록","nl-NL":"Nieuwe afspeellijst"},"New script":{"de-DE":"Neues Skript","ko-KR":"새 스크립트","nl-NL":"Nieuw script"},"New timer":{"de-DE":"Neuer Timer","es-VE":"Nuevo Temporizador","fi-FI":"Uusi ajastin","ko-KR":"새로운 타이머","nl-NL":"Nieuwe Timer"},"New trigger":{"de-DE":"Neuer Trigger","ko-KR":"새 트리거","nl-NL":"Nieuwe trigger"},"Newest songs":{"de-DE":"Neueste Lieder","es-VE":"Canciones mas recientes","fi-FI":"Uusimmat kappaleet","ko-KR":"새 곡","nl-NL":"Nieuwste nummers"},"Next page":{"de-DE":"Nächste Seite","es-VE":"Página siguiente","fi-FI":"Seuraava sivu","ko-KR":"다음 페이지","nl-NL":"Volgende pagina"},"Next song":{"de-DE":"Nächstes Lied","es-VE":"Canción siguiente","fi-FI":"Seuraava kappale","ko-KR":"다음 곡","nl-NL":"Volgende nummer"},"No action selected":{"de-DE":"Keine Aktion ausgewählt","ko-KR":"기능 선택 안 됨","nl-NL":"Geen actie geselecteerd"},"No albumart found by mpd":{"de-DE":"MPD konnte keine Cover finden","es-VE":"No se encontró carátula por MPD","fi-FI":"MPD ei löytäny albumi taidetta","ko-KR":"MPD가 음반 표지를 찾을 수 없음","nl-NL":"Geen albumcover gevonden door MPD"},"No bookmarks found":{"de-DE":"Keine Lesezeichen gefunden","es-VE":"No se encontraron marcadores","fi-FI":"Kirjanmerkkejä ei löytynyt","ko-KR":"즐겨찾기를 찾을 수 없음","nl-NL":"Geen bladwijzers gevonden"},"No current song":{"de-DE":"Kein Lied ausgwählt","es-VE":"No hay canción actual","fi-FI":"Ei toistettavaa kappaletta","ko-KR":"지금 곡 없음","nl-NL":"Geen nummer gekozen"},"No lyrics found":{"de-DE":"Kein Songtext gefunden","fi-FI":"Sanoituksia ei löydy","ko-KR":"가사 없음","nl-NL":"Geen songteksten gevonden"},"No mixed content,  MPD stream must be served over https:":{"de-DE":"Mixed Content: MPD stream muss über https ausgeliefert werden:","ko-KR":"혼합된 컨텐트는 안되며, MPD 스트리밍 서비스는 https:를 통해야 합니다.","nl-NL":"Geen gemengde inhoud, MPD-stream moet via https worden weergegeven:"},"No mpd state for script execution submitted":{"de-DE":"Es wurde kein MPD Status für die Skriptausführung mitgeliefert","ko-KR":"스크립트 실행을 위한 MPD 상태 없음","nl-NL":"Geen MPD-status voor uitvoering script gegeven"},"No outputs":{"de-DE":"Keine Ausgabegeräte","ko-KR":"출력 없음","nl-NL":"Geen output"},"No playlists found":{"de-DE":"Keine Wiedergabelisten gefunden","es-VE":"No se encontraron Listas de reproducción","fi-FI":"Soittolistoja ei löydy","ko-KR":"연주목록 찾을 수 없음","nl-NL":"Geen afspeellijsten gevonden"},"No response for method %{method}":{"de-DE":"Keine Rückmeldung für Aufruf %{method}","es-VE":"Sin respuesta para el método %{method}","fi-FI":"Ei vastausta metodiin %{method}","ko-KR":"%{method} 응답 없음","nl-NL":"Geen antwoord op methode %{method}"},"No results, please refine your search":{"de-DE":"Keine Ergebnisse, bitte passe die Suche an","es-VE":"Sin resultados, cambie los parámetros de búsqueda","fi-FI":"Ei tuloksia, tarkista hakuehdot","ko-KR":"결과가 없으므로, 맞게 찾아야 함","nl-NL":"Geen hits, gebruik andere zoekterm"},"No search expression defined":{"de-DE":"Kein Suchausdruck angegeben","es-VE":"Ninguna expresión de búsqueda definida","fi-FI":"Hakutermiä ei määritetty","ko-KR":"찾을 문구 없음","nl-NL":"Zoekopdracht niet gedefinieerd"},"No search tag defined and advanced search is disabled":{"de-DE":"Kein Such-Tag definiert und erweiterte Suche ist deaktiviert.","ko-KR":"검색 태그가 없고 정의되지 않고 고급 검색을 사용 안 함","nl-NL":"Geen zoektag gedefinieerd en geavanceerd zoeken is uitgeschakeld"},"No such directory":{"de-DE":"Verzeichnis nicht gefunden","es-VE":"No se encontró ese directorio","fi-FI":"Kansiota ei ole","ko-KR":"그런 디렉터리가 없음","nl-NL":"Map niet gevonden"},"None":{"de-DE":"Keines","es-VE":"Ninguno","fi-FI":"Ei mitään","ko-KR":"없음","nl-NL":"Geen"},"Notifications":{"de-DE":"Hinweise","es-VE":"Notificaciones","fi-FI":"Ilmoitukset","ko-KR":"알림","nl-NL":"Notificaties"},"Notifications are blocked":{"de-DE":"Benachrichtungen sind nicht erlaubt","es-VE":"Las Notificaciones están bloqueadas","fi-FI":"Ilmoitukset on estetty","ko-KR":"알림 차단됨","nl-NL":"Meldingen zijn geblokkeerd"},"Num entries":{"de-DE":"%{smart_count} Eintrag |||| %{smart_count} Einträge","en-US":"%{smart_count} Entry |||| %{smart_count} Entries","es-VE":"%{smart_count} Entrada |||| %{smart_count} Entradas","fi-FI":"%{smart_count} Kohde |||| %{smart_count} Kohdetta","ko-KR":"%{smart_count} 항목 |||| %{smart_count} 항목","nl-NL":"%{smart_count} entry |||| %{smart_count} entries"},"Num playlists":{"de-DE":"%{smart_count} Wiedergabeliste |||| %{smart_count} Wiedergabelisten","en-US":"%{smart_count} Playlist |||| %{smart_count} Playlists","es-VE":"%{smart_count} Lista de reproducción |||| %{smart_count} Listas de reproducción","fi-FI":"%{smart_count} Soittolista |||| %{smart_count} Soittolistaa","ko-KR":"%{smart_count} 연주목록 |||| %{smart_count} 연주목록","nl-NL":"%{smart_count} afspeellijst |||| %{smart_count} afspeellijsten"},"Num songs":{"de-DE":"%{smart_count} Lied |||| %{smart_count} Lieder","en-US":"%{smart_count} Song |||| %{smart_count} Songs","es-VE":"%{smart_count} Canción |||| %{smart_count} Canciones","fi-FI":"%{smart_count} Kappale |||| %{smart_count} Kappaletta","ko-KR":"%{smart_count} 곡 |||| %{smart_count} 곡","nl-NL":"%{smart_count} nummer |||| %{smart_count} nummers"},"Off":{"de-DE":"Deaktiviert","es-VE":"Apagado","fi-FI":"Pois","ko-KR":"끄기","nl-NL":"Uit"},"On":{"de-DE":"Aktiv","es-VE":"On","fi-FI":"Päällä","ko-KR":"켜기","nl-NL":"Aan"},"On page notifications":{"de-DE":"Integrierte Hinweise","es-VE":"Notificaciones en la Página","fi-FI":"Sivun ilmoitukset","ko-KR":"페이지에 알림","nl-NL":"Meldingen op pagina"},"Oneshot":{"de-DE":"Oneshot","es-VE":"Oneshot","fi-FI":"Oneshot","ko-KR":"1회","nl-NL":"Oneshot"},"Open about":{"de-DE":"Öffne Über myMPD","es-VE":"Abrir acerca de ","fi-FI":"Avaa tiedot","ko-KR":"정보 열기","nl-NL":"Over myMPD openen"},"Open fullscreen":{"de-DE":"Öffnet den Vollbildmodus","ko-KR":"전체 화면 열기","nl-NL":"Open schermvullend"},"Open local player":{"de-DE":"Lokale Wiedergabe","es-VE":"Abrir reproductor local","fi-FI":"Avaa paikallinen soitin","ko-KR":"로컬 연주기 열기","nl-NL":"Lokaal afspelen"},"Open main menu":{"de-DE":"Öffne Hauptmenü","es-VE":"Abrir menú principal","fi-FI":"Avaa päävalikko","ko-KR":"주 메뉴로 가기","nl-NL":"Hoofdmenu openen"},"Open settings":{"de-DE":"Einstellungen","es-VE":"Abrir configuraciones","fi-FI":"Avaa asetukset","ko-KR":"설정 열기","nl-NL":"Instellingen"},"Open song details":{"de-DE":"Lieddetails","es-VE":"Abrir detalles de canción","fi-FI":"Avaa kappaleen tiedot","ko-KR":"곡 정보 열기","nl-NL":"Nummerdetails"},"Open volume menu":{"de-DE":"Öffne Lautstärkemenü","es-VE":"Abrir menú de volumen","fi-FI":"Avaa äänenvoimakkuus valikko","ko-KR":"음량 메뉴 열기","nl-NL":"Volumeregeing openen"},"Options":{"de-DE":"Optionen"},"Order":{"de-DE":"Reihenfolge","es-VE":"Orden","fi-FI":"Järjestys","ko-KR":"순서","nl-NL":"Volgorde"},"Other features":{"de-DE":"Weitere Features","es-VE":"Más funciones","fi-FI":"Muut ominaisuudet","ko-KR":"다른 기능","nl-NL":"Overige functies"},"Output":{"de-DE":"Ausgabegerät","ko-KR":"출력","nl-NL":"Output"},"Output attributes":{"de-DE":"Ausgabeeigenschaften","ko-KR":"출력 속성","nl-NL":"Outputparameters"},"Pagination":{"de-DE":"Seitenumbruch","es-VE":"Paginación","fi-FI":"Rivien määrä","ko-KR":"페이지 매기기","nl-NL":"Paginagrootte"},"Partition":{"de-DE":"Partition","ko-KR":"파티션","nl-NL":"Partitie"},"Partition name":{"de-DE":"Partition Name","ko-KR":"파티션 이름","nl-NL":"Naam partitie"},"Partitions":{"de-DE":"Partitionen","ko-KR":"파티션","nl-NL":"Partities"},"Performer":{"de-DE":"Aufführender","es-VE":"Interprete","fi-FI":"Esittäjä","ko-KR":"연주자","nl-NL":"Uitvoerend artiest"},"Picture":{"de-DE":"Bild"},"Pictures":{"de-DE":"Bilder","es-VE":"Imágenes","fi-FI":"Kuvat","ko-KR":"그림","nl-NL":"Foto's "},"Play count":{"de-DE":"Wie oft gespielt","es-VE":"Conteo reproducciones","fi-FI":"Soittokerrat","ko-KR":"연주 횟수","nl-NL":"Aantal x afgespeeld"},"Play time":{"de-DE":"Wiedergabedauer","es-VE":"Tiempo de reproducción","fi-FI":"Toisto aika","ko-KR":"연주 시간","nl-NL":"Gespeelde tijd"},"Playback":{"de-DE":"Wiedergabe","es-VE":"Reproducción","fi-FI":"Toisto","ko-KR":"연주","nl-NL":"Afspelen"},"Playback statistics":{"de-DE":"Wiedergabestatistiken","es-VE":"Estadísticas de reproducción","fi-FI":"Toistotilastot","ko-KR":"연주 통계","nl-NL":"Afspeelgegevens"},"Playback statistics are disabled":{"de-DE":"Wiedergabestatistiken sind deaktiviert","es-VE":"Las estadísticas de reproducción están deshabilitadas","fi-FI":"Toistotilastot ovat pois päältä","ko-KR":"연주 통계 사용 안 함","nl-NL":"Afspeelstatistieken uitgeschakeld"},"Playlist":{"de-DE":"Wiedergabeliste","es-VE":"Lista de reproducción","fi-FI":"Soittolista","ko-KR":"연주목록","nl-NL":"Afspeellijst"},"Playlist is too small to shuffle":{"de-DE":"Wiedergabeliste ist zu klein um sie zu mischen","es-VE":"La lista de reproducción es muy pequeña para mezclar aleatoriamente","fi-FI":"Soittolista on liian pieni sekoitettavaksi","ko-KR":"연주목록이 너무 작아 뒤섞을 수 없음","nl-NL":"Afspeellijst te klein om te shufflen"},"Playlist is too small to sort":{"de-DE":"Wiedergabeliste ist zu klein um sie zu sortieren","es-VE":"Wiedergabeliste ist zu klein um sie zu sortieren","fi-FI":"Soittolista on liian pieni järjestettäväksi","ko-KR":"연주목록이 너무 작아 정렬할 수 없음","nl-NL":"Afspeellijst te klein om te sorteren"},"Playlist name":{"de-DE":"Wiedergabelistenname","es-VE":"Nombre de lista de reproducción","fi-FI":"Soittolistan nimi","ko-KR":"연주목록 이름","nl-NL":"Naam afspeellijst"},"Playlist to small, disabling jukebox unique constraints temporarily":{"de-DE":"Die Wiedergabeliste ist zu klein, die Jukebox Regeln werden deaktiviert","ko-KR":"연주목록이 작아서, 임시로 뮤직박스의 하나 제한 사용 안 함","nl-NL":"Afspeellijst te klein, jukebox-voorwaarden worden tijdelijk uitgeschakeld"},"Playlists":{"de-DE":"Wiedergabelisten","es-VE":"Listas de reproducción","fi-FI":"Soittolistat","ko-KR":"연주목록","nl-NL":"Afspeellijsten"},"Playlists are disabled":{"de-DE":"Wiedergabelisten sind deaktiviert","es-VE":"Listas de reproducción deshabilitadas","fi-FI":"Soittolistat ovat pois päältä","ko-KR":"연주목록 사용 안 함","nl-NL":"Afspeellijsten uitgeschakeld"},"Playlists deleted":{"de-DE":"Wiedergabeliste wurde gelöscht","es-VE":"Listas de reproducción eliminadas","fi-FI":"Soittolistat poistettu","ko-KR":"연주목록 지워짐","nl-NL":"Afspeellijsten gedeletet"},"Please choose playlist":{"de-DE":"Bitte Wiedergabeliste auswählen","es-VE":"Seleccione lista de reproducción","fi-FI":"Valitse soittolista","ko-KR":"연주목록을 선택합니다","nl-NL":"Kies afspeellijst"},"Plugin":{"de-DE":"Plugin","ko-KR":"플러그인","nl-NL":"Plug-in"},"Port":{"de-DE":"Port","es-VE":"Puerto","fi-FI":"Portti","ko-KR":"포트","nl-NL":"Poort"},"Pos":{"de-DE":"Pos","es-VE":"Pos","fi-FI":"Pos","ko-KR":"위치","nl-NL":"Pos"},"Preview":{"de-DE":"Vorschau","es-VE":"Previsualizar","fi-FI":"Esikatselu","ko-KR":"미리 보기","nl-NL":"Voorbeeld"},"Previous page":{"de-DE":"Vorige Seite","es-VE":"Página anterior","fi-FI":"Edellinen sivu","ko-KR":"이전 페이지","nl-NL":"Vorige pagina"},"Previous song":{"de-DE":"Voriges Lied","es-VE":"Canción anterior","fi-FI":"Edellinen kappale","ko-KR":"이전 곡","nl-NL":"Vorig nummer"},"Protocol version":{"de-DE":"Protokoll Version","es-VE":"Versión de protocolo","fi-FI":"Protokolla Versio","ko-KR":"프로토콜 버전","nl-NL":"Versie protocol"},"Quantity":{"de-DE":"Anzahl","es-VE":"Cantidad","fi-FI":"Määrä","ko-KR":"갯수","nl-NL":"Aantal"},"Queue":{"de-DE":"Warteschlange","es-VE":"Cola de reproducción","fi-FI":"Jono","ko-KR":"순서","nl-NL":"Wachtrij"},"Queue replaced with %{name}":{"de-DE":"Warteschlange mit %{name} ersetzt","es-VE":"Cola de reproducción reemplazada con %{name}","fi-FI":"Jono korvattu %{name}:lla","ko-KR":"%{name} 순서 바꿈","nl-NL":"Wachtrij vervangen door %{name}"},"Random":{"de-DE":"Zufall","es-VE":"Aleatorio","fi-FI":"Satunnainen","ko-KR":"무작위","nl-NL":"Willekeurig"},"Reload":{"de-DE":"Neu laden","es-VE":"Recargar","fi-FI":"Lataa uudelleen","ko-KR":"다시 읽기","nl-NL":"Herladen"},"Remote scripting is disabled":{"de-DE":"Remotescripting ist deaktiviert","ko-KR":"원격 스크립트 사용 안 함","nl-NL":"Scripten op afstand uitgeschakeld"},"Remove":{"de-DE":"Entfernen","es-VE":"Remover","fi-FI":"Poista","ko-KR":"지우기","nl-NL":"Verwijder"},"Remove all downwards":{"de-DE":"Aller Lieder darunter entfernen","es-VE":"Remover todo hacia abajo","fi-FI":"Poista kaikki alempana","ko-KR":"아래로 지우기","nl-NL":"Verwijder alle hieronder"},"Remove all upwards":{"de-DE":"Alle Lieder darüber entfernen","es-VE":"Remover todo hacia arriba","fi-FI":"Poista kaikki ylempänä","ko-KR":"위로 지우기","nl-NL":"Verwijder alle hierboven"},"Remove item from queue":{"de-DE":"Ausgewähltes Element aus Warteschlange entfernen","es-VE":"Eliminar elemento de la cola de reproducción","fi-FI":"Poista jonosta","ko-KR":"순서에서 항목 지우기","nl-NL":"Verwijder selectie uit wachtrij"},"Rename playlist":{"de-DE":"Wiedergabeliste umbenennen","es-VE":"Renombrar lista de reproducción","fi-FI":"Nimeä soittolista uudelleen","ko-KR":"연주목록 이름 바꾸기","nl-NL":"Hernoem afspeellijst"},"Renaming playlist failed":{"de-DE":"Wiedergabeliste konnte nicht umbenannt werden","es-VE":"Error al renombrar lista de reproducción","fi-FI":"Soittolistan nimeäminen epäonnistui","ko-KR":"연주목록 이름 바꾸기 안 됨","nl-NL":"Hernoemen afspeellijst mislukt"},"Repeat":{"de-DE":"Wiederholen","es-VE":"Repetir","fi-FI":"Uudelleentoisto","ko-KR":"다시","nl-NL":"Herhalen"},"Replace queue":{"de-DE":"Warteschlange ersetzen","es-VE":"Reemplazar cola de reproducción","fi-FI":"Korvaa jono","ko-KR":"순서 바꾸기","nl-NL":"Vervang wachtrij"},"Replace queue with item":{"de-DE":"Warteschlange mit ausgewähltem Element ersetzen","es-VE":"Reemplazar cola de reproducción con esto","fi-FI":"Korvaa jono kohteella","ko-KR":"순서에 항목 대체","nl-NL":"Vervang wachtrij met selectie"},"Replaygain":{"de-DE":"Lautstärkeanpassung","es-VE":"Volver a reproducir","fi-FI":"Replaygain","ko-KR":"리플레이게인","nl-NL":"Replaygain"},"Rescan database":{"de-DE":"Datenbank neu einlesen","es-VE":"Reescanear base de datos","fi-FI":"Lue tietokanta uudelleen","ko-KR":"데이터베이스 다시 검색","nl-NL":"Herscan database"},"Rescan directory":{"de-DE":"Verzeichnis neu einlesen","es-VE":"Reescanear directorio","fi-FI":"Lue kansio uudelleen","ko-KR":"디렉터리 다시 검색","nl-NL":"Herscan map"},"Reset":{"de-DE":"Zurücksetzen","es-VE":"Restablecer","fi-FI":"Nollaa","ko-KR":"다시 설정","nl-NL":"Reset"},"Reset settings":{"de-DE":"Einstellungen zurücksetzen","es-VE":"Restablecer configuraciones","fi-FI":"Nollaa asetukset","ko-KR":"다시 설정 하기","nl-NL":"Reset instellingen"},"Sat":{"de-DE":"Sa","es-VE":"Sáb","fi-FI":"La","ko-KR":"토","nl-NL":"Za"},"Save":{"de-DE":"Speichern","es-VE":"Guardar","fi-FI":"Tallenna","ko-KR":"저장","nl-NL":"Saven"},"Save as smart playlist":{"de-DE":"Als intelligente Wiedergabeliste speichern","es-VE":"Guardar como lista de reproducción inteligente","fi-FI":"Tallenna älykkäänä soittolistana","ko-KR":"스마트 연주목록 저장","nl-NL":"Save als slimme afspeellijst"},"Save bookmark":{"de-DE":"Lesezeichen speichern","es-VE":"Guardad marcador","fi-FI":"Tallenna kirjanmerkki","ko-KR":"즐겨찾기 저장","nl-NL":"Save bladwijzer"},"Save queue":{"de-DE":"Warteschlange speichern","es-VE":"Guardar cola de reproducción","fi-FI":"Tallenna Jono","ko-KR":"순서 저장","nl-NL":"Save wachtrij"},"Save smart playlist":{"de-DE":"Intelligente Wiedergabeliste sichern","es-VE":"Guardar lista de reproducción inteligente","fi-FI":"Tallenna älykäs soittolista","ko-KR":"스마트 연주목록 저장","nl-NL":"Save slimme afspeellijst"},"Saved smart playlist %{name}":{"de-DE":"Intelligente Wiedergabeliste %{name} gespeichert","es-VE":"Lista de reproducción inteligente guardada: %{name}","fi-FI":"Älykäs soittolista %{name} tallennettu","ko-KR":"%{name} 스마트 연주목록 저장함","nl-NL":"Slimme afspeellijst %{name} opgeslagen"},"Saving bookmark failed":{"de-DE":"Lesezeichen konnte nicht gespeichert werden","es-VE":"Error al guardar marcador","fi-FI":"Kirjanmerkin tallennus epäonnistui","ko-KR":"즐겨찾기 저장 안 됨","nl-NL":"Saven bladwijzer mislukt"},"Scale ratio":{"de-DE":"Skalierungswert","ko-KR":"크기 비율","nl-NL":"Schaalverhouding"},"Script":{"de-DE":"Skript","ko-KR":"스크립트","nl-NL":"Script"},"Script %{script} executed successfully":{"de-DE":"Skript %{script} erfolgreich gestartet","ko-KR":"스크립트 %{script} 실행 성공","nl-NL":"Script %{script} succesvol uitgevoerd"},"Script arguments":{"de-DE":"Skriptparameter","ko-KR":"스크립트 변수","nl-NL":"Scriptargumenten"},"Script name":{"de-DE":"Skriptname","ko-KR":"스크립트 이름","nl-NL":"Script naam"},"Scripting is disabled":{"de-DE":"Skripte sind deaktiviert","ko-KR":"스크립트 사용 안 함","nl-NL":"Scripten is uitgeschakeld"},"Scripts":{"de-DE":"Skripte","ko-KR":"스크립트","nl-NL":"Scripts"},"Scrobbled love":{"de-DE":"Lieblingslied wurde gescrobbelt","es-VE":"Me gusta recomendado","fi-FI":"Scrobbled rakkaus","ko-KR":"애청곡 추천","nl-NL":"Favoriet werd gescrobbeld"},"Scrobbler integration":{"de-DE":"Scrobbler Integration","es-VE":"Scrobbler Integration","fi-FI":"Scrobbler Integration","ko-KR":"추천 통합","nl-NL":"Scrobbler-integratie"},"Search":{"de-DE":"Suchen","es-VE":"Buscar","fi-FI":"Etsi","ko-KR":"찾기","nl-NL":"Zoeken"},"Search queue":{"de-DE":"Warteschlange durchsuchen","es-VE":"Buscar cola de reproducción","fi-FI":"Etsi jonosta","ko-KR":"순서 찾기","nl-NL":"Zoek in wachtrij"},"Searching...":{"de-DE":"Suche...","es-VE":"Buscando...","fi-FI":"Etsitään...","ko-KR":"찾는 중...","nl-NL":"Zoek..."},"Seconds":{"de-DE":"Sek","en-US":"Sec","es-VE":"Seg","fi-FI":"Sekuntia","ko-KR":"초","nl-NL":"sec"},"Select tag to display":{"de-DE":"Tag für Anzeige auswählen","ko-KR":"표시할 태그 선택","nl-NL":"Kies tag om  weer te geven"},"Select tag to search":{"de-DE":"Tag zum Suchen auswählen","es-VE":"Seleccionar etiqueta para buscar","fi-FI":"Valitse etsittävä tagi","ko-KR":"찾을 태그 선택","nl-NL":"Selecteer tag om te zoeken"},"Send love message":{"de-DE":"Sende Lieblingslied","es-VE":"Enviar mensaje de Me gusta","fi-FI":"Lähetä rakkausviesti","ko-KR":"애청 메시지 보내기","nl-NL":"Stuur favoriet"},"Settings":{"de-DE":"Einstellungen","es-VE":"Ajustes","fi-FI":"Asetukset","ko-KR":"설정","nl-NL":"Instellingen"},"Shortcut":{"de-DE":"Tastenkürzel","es-VE":"Acceso directo","fi-FI":"Pikalinkki","ko-KR":"단축키","nl-NL":"Sneltoets"},"Shortcuts":{"de-DE":"Tastenkombinationen","es-VE":"Accesos directos","fi-FI":"Pikalinkki","ko-KR":"단축키","nl-NL":"Sneltoetsen"},"Show attributes":{"de-DE":"Eigenschaften anzeigen","ko-KR":"속성 보기","nl-NL":"Toon parameters"},"Shuffle":{"de-DE":"Mischen","es-VE":"Aleatorio","fi-FI":"Sekoita","ko-KR":"뒤섞기","nl-NL":"Shuffle"},"Shuffle playlist":{"de-DE":"Wiedergabeliste mischen","es-VE":"Mezclar aleatoriamente la lista de reproducción","fi-FI":"Sekoita soittolista","ko-KR":"연주목록 뒤섞기","nl-NL":"Shuffle afspeellijst"},"Shuffle queue":{"de-DE":"Warteschlange mischen","es-VE":"Cola de reproducción aleatoria","fi-FI":"Sekoita Jono","ko-KR":"순서 뒤섞기","nl-NL":"Wachtrij shufflen"},"Shuffled playlist succesfully":{"de-DE":"Wiedergabeliste erfolgreich gemischt","es-VE":"Lista de reproducción mezclada aleatoriamente","fi-FI":"Soittolista sekoitetttu onnistuneesti","ko-KR":"연주목록을 뒤섞음","nl-NL":"Afspeellijst geshuffled"},"Single":{"de-DE":"Nur ein Lied","es-VE":"Individual","fi-FI":"Yksittäistoisto","ko-KR":"한 곡만","nl-NL":"Single"},"Size in px":{"de-DE":"Größe in PX","es-VE":"Tamaño en px","fi-FI":"koko pikseleinä","ko-KR":"픽셀 크기","nl-NL":"Grootte in px"},"Size normal":{"de-DE":"Normale Größe","es-VE":"Tamaño normal","fi-FI":"Normaali koko","ko-KR":"일반 크기","nl-NL":"Standaard formaat"},"Size small":{"de-DE":"Kleine Größe","es-VE":"Tamaño pequeño","fi-FI":"Pieni koko","ko-KR":"작은 크기","nl-NL":"Klein formaat"},"Skip count":{"de-DE":"Wie oft übersprungen","es-VE":"Conteo omisiones","fi-FI":"Ohitus laskuri","ko-KR":"건너뛴 횟수","nl-NL":"Aantal x geskipt"},"Smart playlist":{"de-DE":"Intelligente Wiedergabeliste","es-VE":"Lista de reproducción inteligente","fi-FI":"Älykäs soittolista","ko-KR":"스마트 연주목록","nl-NL":"Slimmme afspeellijst"},"Smart playlist %{playlist} updated":{"de-DE":"Intelligente Wiedergabeliste %{playlist} aktualisiert","es-VE":"Lista de reproducción %{playlist} actualizada","fi-FI":"Älykäs soittolista %{playlist} päivitetty","ko-KR":"%{playlist} 스마트 연주목록 업데이트함","nl-NL":"Slimmme afspeellijst %{playlist} geüpdatet"},"Smart playlists":{"de-DE":"Intelligente Wiedergabelisten","es-VE":"Listas de reproducción inteligentes","fi-FI":"Älykkäät soittolistat","ko-KR":"스마트 연주목록","nl-NL":"Slimmme afspeellijsten"},"Smart playlists are disabled":{"de-DE":"Intelligente Wiedergabelisten sind deaktiviert","ko-KR":"스마트 연주목록 사용 안 함","nl-NL":"Smart playlists uitgeschakeld"},"Smart playlists prefix":{"de-DE":"Prefix von Intelligenten Wiedergabelisten","es-VE":"Prefijo de listas de reproducción inteligente","fi-FI":"Älykkäiden soittolistojen etuliite","ko-KR":"스마트 연주목록 덧붙임","nl-NL":"Voorvoegsel slimme afspeellijsten"},"Smart playlists update failed":{"de-DE":"Intelligente Wiedergabelisten konnten nicht aktualisiert werden","es-VE":"Error Actualizando listas de reproducción inteligentes","fi-FI":"Älykkäiden soittolistojen päivitys epäonnistui","ko-KR":"스마트 연주목록 업데이트 안 됨","nl-NL":"Updaten slimmme afspeellijsten mislukt"},"Smart playlists update started":{"de-DE":"Aktualisierung der intelligenten Wiedergabelisten gestartet","ko-KR":"스마트 연주목록 업데이트 시작","nl-NL":"Smart playlists wordt geupdatet"},"Smart playlists updated":{"de-DE":"Intelligente Wiedergabelisten wurden aktualisiert","es-VE":"Listas de reproducción inteligentes actualizadas","fi-FI":"Älykkäät soittolistat päivitetty","ko-KR":"스마트 연주목록 업데이트됨","nl-NL":"Slimmme afspeellijsten geüpdatet"},"Song":{"de-DE":"Lied","es-VE":"Canción","fi-FI":"Kappale","ko-KR":"곡","nl-NL":"Nummer"},"Song details":{"de-DE":"Lieddetails","es-VE":"Detalles de canción","fi-FI":"Kappaleen tiedot","ko-KR":"곡 정보","nl-NL":"Nummerdetails"},"Songs":{"de-DE":"Lieder","es-VE":"Canciones","fi-FI":"Kappaleet","ko-KR":"곡","nl-NL":"Nummers"},"Sorry, your MPD version is too old":{"de-DE":"Entschuldige, deine MPD version ist zu alt","es-VE":"Su versión de MPD es muy vieja","fi-FI":"Liian vanha MPD versio","ko-KR":"MPD 버전이 낮음","nl-NL":"Sorry, je MPD-versie is te oud"},"Sort by":{"de-DE":"Sortieren","es-VE":"Ordenar por","fi-FI":"Järjestä","ko-KR":"정렬","nl-NL":"Sorteer op"},"Sort by tag":{"de-DE":"Sortiere nach Tag","es-VE":"Ordenar por etiqueta","fi-FI":"Lahittele tagin mukaan","ko-KR":"태그로 정렬","nl-NL":"Sorteer op tag"},"Sort order of the script, 0 disables listing in main menu":{"de-DE":"Sortierreihenfolge der Skripts, 0 deaktiviert die Anzeige im Hauptmenü","ko-KR":"스크립트 분류 순서, 0은 주 메뉴에 안 보임","nl-NL":"Sorteervolgorde van het script, 0 schakelt lijst in hoofdmenu uit"},"Sort playlist":{"de-DE":"Wiedergabeliste sortieren","es-VE":"Ordenar lista de reproducción","fi-FI":"Järjestä soittolista","ko-KR":"연주목록 정렬","nl-NL":"Sorteer afspeellijst"},"Sorted playlist succesfully":{"de-DE":"Wiedergabeliste erfolgreich sortiert","es-VE":"Lista de reproducción ordenada","fi-FI":"Soittolista järjestetty onnistuneesti","ko-KR":"연주목록 정렬함","nl-NL":"Afspeellijst gesorteerd"},"Specify":{"de-DE":"Manuell","es-VE":"Especificar","fi-FI":"Määritä","ko-KR":"지정","nl-NL":"Specifiek"},"Start":{"de-DE":"Start","es-VE":"Iniciar","fi-FI":"Aloita","ko-KR":"시작","nl-NL":"Start"},"Start playback":{"de-DE":"Wiedergabe starten","es-VE":"Iniciar reproducción","fi-FI":"Aloita toisto","ko-KR":"연주 시작","nl-NL":"Start afspelen"},"State":{"de-DE":"Status","ko-KR":"상태","nl-NL":"Status"},"Statistics":{"de-DE":"Statistiken","es-VE":"Estadísticas","fi-FI":"Tilastot","ko-KR":"통계","nl-NL":"Gegevens"},"Sticker":{"de-DE":"Sticker","es-VE":"Sticker","fi-FI":"Sticker","ko-KR":"스티커","nl-NL":"Sticker"},"Sticker cache is NULL":{"de-DE":"Sticker Cache ist leer","ko-KR":"Sticker 캐시가 없음","nl-NL":"Sticker cache is leeg"},"Stickers are disabled":{"de-DE":"Sticker sind deaktiviert","es-VE":"Los Stickers están deshabilitados","fi-FI":"Stickerit on poistettu käytöstä","ko-KR":"스티커 사용 안 함","nl-NL":"Stickers uitgeschakeld"},"Stop playback":{"de-DE":"Wiedergabe anhalten","es-VE":"Detener reproducción","fi-FI":"Pysäytä toisto","ko-KR":"연주 정지","nl-NL":"Stop afspelen"},"Stop playing":{"de-DE":"Stop","es-VE":"Stop","fi-FI":"Stop","ko-KR":"정지","nl-NL":"Stop"},"Stream URI":{"de-DE":"Stream URL","es-VE":"URL Streaming","fi-FI":"Stream URI","ko-KR":"스트리밍 주소","nl-NL":"Streaming url"},"Successfully cleared covercache":{"de-DE":"Covercache erfolgreich geleert","es-VE":"Covercache limpiado exitosamente","fi-FI":"Covercache tyhjennetty onnistuneesti","ko-KR":"표지 캐시 지우기 완료","nl-NL":"Covercache gewist"},"Successfully croped covercache":{"de-DE":"Covercache erfolgreich bereinigt","es-VE":"Covercache cortado exitosamente","fi-FI":"Covercache rajattu onnistuneesti","ko-KR":"표지 캐시 잘라내기 완료","nl-NL":"Covercache opgeschoond"},"Successfully execute cmd %{cmd}":{"de-DE":"Systembefehl %{cmd} erfolgreich ausgeführt","es-VE":"Ejecutado %{cmd} exitosamente","fi-FI":"Komennon  %{cmd} suorittaminen onnistui","ko-KR":"%{cmd} 명령어 실행함","nl-NL":"Systeemcommando %{cmd} uitgevoerd"},"Sucessfully added random songs to queue":{"de-DE":"Zufällige Lieder wurden zur Warteschlange hinzugefügt","es-VE":"Agregadas canciones aleatorias a la cola de reproducción exitosamente","fi-FI":"Satunnaisten kappaleiden lisääminen jonoon onnistui","ko-KR":"무작위 곡을 순서에 추가함","nl-NL":"Willekeurig nummer aan wachtrij toegevoegd"},"Sucessfully renamed playlist":{"de-DE":"Wiedergabeliste erfolgreich umbenannt","es-VE":"Lista de reproducción renombrada exitosamente","fi-FI":"Soittolista nimeäminen onnistui","ko-KR":"연주목록 이름 바꿈","nl-NL":"Afspeellijst is hernoemd"},"Sun":{"de-DE":"So","es-VE":"Dom","fi-FI":"Sun","ko-KR":"일","nl-NL":"Zo"},"Switch to":{"de-DE":"Wechsle zu","ko-KR":"바꿈","nl-NL":"Schakel over naar"},"System command":{"de-DE":"Systembefehl","es-VE":"Comando de sistema","fi-FI":"Järjestelmä komento","ko-KR":"시스템 명령어","nl-NL":"Systeemcommando"},"System command not defined":{"de-DE":"Systembefehl nicht definiert","es-VE":"Comando del sistema no definido","fi-FI":"Järjestelmäkomentoa ei ole määritetty","ko-KR":"시스템 명령어 정의 안됨","nl-NL":"Systeemcommando niet bekend"},"System commands":{"de-DE":"Systembefehle","es-VE":"Comandos de sistema","fi-FI":"Järjestelmäkomennot","ko-KR":"시스템 명령어","nl-NL":"Systemcommando"},"System commands are disabled":{"de-DE":"Systembefehle sind deaktiviert","es-VE":"Comandos del sistema deshabilitados","fi-FI":"Järjestelmäkomennot on poistettu käytöstä","ko-KR":"시스템 명령어 사용 안 함","nl-NL":"Systeemcommando's uitgeschakeld"},"Tag":{"de-DE":"Tag","es-VE":"Etiqueta","fi-FI":"Tag","ko-KR":"태그","nl-NL":"Tag"},"Tags":{"de-DE":"Tags","es-VE":"Etiquetas","fi-FI":"Tagit","ko-KR":"태그","nl-NL":"Tags"},"Tags to browse":{"de-DE":"Tags für die Datenbankanzeige","es-VE":"Etiquetas para explorar","fi-FI":"Selattavat tagit","ko-KR":"열 태그","nl-NL":"Tags om te browsen"},"Tags to search":{"de-DE":"Tags für die Suche","es-VE":"Etiquetas para buscar","fi-FI":"Etsittävät tagit","ko-KR":"찾을 태그","nl-NL":"Tags om te zoeken"},"Tags to use":{"de-DE":"Genutzte Tags","es-VE":"Etiquetas para usar","fi-FI":"Käytettävät tagit","ko-KR":"쓸 태그","nl-NL":"Te gebruiken tags"},"Theme":{"de-DE":"Design","es-VE":"Tema","fi-FI":"Teema","ko-KR":"테마","nl-NL":"Thema"},"Thu":{"de-DE":"Do","es-VE":"Jue","fi-FI":"To","ko-KR":"목","nl-NL":"Do"},"Timer":{"de-DE":"Timer","es-VE":"Temporizador","fi-FI":"Ajastin","ko-KR":"타이머","nl-NL":"Timer"},"Timer with given id not found":{"de-DE":"Timer nicht gefunden","es-VE":"Temporizador no se encontró con ese ID","fi-FI":"Ajastinta annetulla tunnuksella ei löydy","ko-KR":"타이머를 찾을 수 없음","nl-NL":"Timer niet gevonden"},"Timerange (days)":{"de-DE":"Tage","es-VE":"Tiempo (días)","fi-FI":"Aikaväli (päiviä)","ko-KR":"시간 범위 (날짜)","nl-NL":"Dagen"},"Title":{"de-DE":"Titel","es-VE":"Título","fi-FI":"Nimi","ko-KR":"제목","nl-NL":"Titel"},"To":{"de-DE":"Zu","es-VE":"Para","fi-FI":"Mihin","ko-KR":"바꿈","nl-NL":"Naar"},"To top":{"de-DE":"Nach oben","es-VE":"Arriba","fi-FI":"Huipulle","ko-KR":"위로","nl-NL":"Omhoog"},"Toggle play / pause":{"de-DE":"Play / Pause","es-VE":"Play / Pausa","fi-FI":"Play / Pause","ko-KR":"연주 / 잠시 멈춤","nl-NL":"Play / Pause"},"Track":{"de-DE":"Liednummer","es-VE":"# Pista","fi-FI":"Kappalenumero","ko-KR":"트랙","nl-NL":"Track"},"Trigger":{"de-DE":"Trigger","ko-KR":"트리거","nl-NL":"Trigger"},"Trigger name":{"de-DE":"Trigger Name","ko-KR":"트리거 이름","nl-NL":"Naam trigger"},"Trigger not found":{"de-DE":"Trigger nicht gefunden","ko-KR":"트리거를 찾을 수 없음","nl-NL":"Trigger niet gevonden"},"Tue":{"de-DE":"Di","es-VE":"Mar","fi-FI":"Ti","ko-KR":"화","nl-NL":"Di"},"Type":{"de-DE":"Typ","es-VE":"Tipo","fi-FI":"Tyyppi","ko-KR":"형식","nl-NL":"Type"},"URI":{"de-DE":"URL","es-VE":"URL","fi-FI":"URL","ko-KR":"주소","nl-NL":"Url"},"Unknown album":{"de-DE":"Unbekanntes Album","es-VE":"Álbum desconocido","fi-FI":"Tuntematon albumi","ko-KR":"모르는 음반","nl-NL":"Onbekend album"},"Unknown artist":{"de-DE":"Unbekannter Künstler","es-VE":"Artista desconocido","fi-FI":"Tuntematon artisti","ko-KR":"모르는 연주자","nl-NL":"Onbekende artiest"},"Unknown request":{"de-DE":"Unbekannter Befehl","es-VE":"Solicitud desconocida","fi-FI":"Tuntematon pyyntö","ko-KR":"알 수 없는 요구","nl-NL":"Onbekend verzoek"},"Unknown smart playlist type":{"de-DE":"Unbekannter intelligenter Wiedergabenlisten Typ","es-VE":"Tipo de lista de reproducción inteligente desconocido","fi-FI":"Älykkään soittolistan tyyppi tuntematon","ko-KR":"스마트 연주목록 형식을 알 수 없음","nl-NL":"Onbekend type afspeellijst"},"Unknown table %{table}":{"de-DE":"Unbekannte Tabelle %{table}","es-VE":"Tabla desconocida: %{table}","fi-FI":"Tuntematon taulu %{table}","ko-KR":"%{table} 테이블 알 수 없음","nl-NL":"Onbekende tabel %{table}"},"Unmount":{"de-DE":"Aushängen","es-VE":"Desmontar","fi-FI":"Poista liityntä","ko-KR":"언마운트","nl-NL":"Ontkoppelen"},"Update":{"de-DE":"Aktualisieren","es-VE":"Actualizar","fi-FI":"Päivitä","ko-KR":"업데이트","nl-NL":"Updaten"},"Update database":{"de-DE":"Datenbank aktualisieren","es-VE":"Actualizar base de datos","fi-FI":"Päivitä tietokanta","ko-KR":"데이터베이스 업데이트","nl-NL":"Update database"},"Update directory":{"de-DE":"Verzeichnis aktualisieren","es-VE":"Actualizar directorio","fi-FI":"Päivitä kansio","ko-KR":"디렉터리 업데이트","nl-NL":"Update map"},"Update smart playlist":{"de-DE":"Intelligente Wiedergabeliste aktualisieren","es-VE":"Actualizar lista de reproducción inteligente","fi-FI":"Päivitä alykäs soittolista","ko-KR":"스마트 연주목록 업데이트","nl-NL":"Update slimme afspeellijst"},"Update smart playlists":{"de-DE":"Intelligente Wiedergabelisten aktualisieren","es-VE":"Actualizar listas de reproducción inteligentes","fi-FI":"Päivitä älykkäät soittolistat","ko-KR":"스마트 연주목록 업데이트","nl-NL":"Update slimme afspeellijsten"},"Update smart playlists (hours)":{"de-DE":"Intelligente Wiedergabelisten aktualisieren (Stunden)","es-VE":"Actualizar listas de reproducción inteligentes (horas)","fi-FI":"Älykkäiden soittolistojen päivitys (tunteja)","ko-KR":"스마트 연주목록 업데이트 (시간)","nl-NL":"Update slimme afspeellijsten (uren)"},"Updating MPD database":{"de-DE":"MPD Datenbank wird aktualisiert","es-VE":"Actualizando base de datos MPD","fi-FI":"Päivitetään MPD tietokantaa","ko-KR":"MPD 데이터베이스 업데이트 중","nl-NL":"MPD-database wordt geüpdatet"},"Updating of smart playlist %{playlist} failed":{"de-DE":"Intelligente Wiedergabeliste %{playlist} konnte nicht aktualisiert werden","es-VE":"Error actualizando de lista de reproducción inteligente %{playlist} ","fi-FI":"Älykkään soittolistan %{playlist} päivitys epäonnistui","ko-KR":"%{playlist} 스마트 연주목록 업데이트 안 됨","nl-NL":"Updaten slimmme afspeellijst %{playlist} mislukt "},"Version":{"de-DE":"Version","es-VE":"Versión","fi-FI":"Versio","ko-KR":"버전","nl-NL":"Versie"},"View playlist":{"de-DE":"Wiedergabeliste anzeigen","es-VE":"Ver lista de reproducción","fi-FI":"Näytä soittolista","ko-KR":"연주목록 보기","nl-NL":"Bekijk afspeellijst"},"Volume":{"de-DE":"Lautstärke","es-VE":"Volumen","fi-FI":"Äänenvoimakkuus","ko-KR":"음량","nl-NL":"Volume"},"Volume down":{"de-DE":"Leiser","es-VE":"Volumen -","fi-FI":"Pienemmälle","ko-KR":"소리 작게","nl-NL":"Volume min"},"Volume up":{"de-DE":"Lauter","es-VE":"Volumen +","fi-FI":"Isommalle","ko-KR":"소리 크게","nl-NL":"Volume plus"},"Volumecontrol disabled":{"de-DE":"Lautstärkeregelung deaktiviert","es-VE":"Control de volumen deshabilitado","fi-FI":"Äänenvoimakkuuden säätö pois käytöstä","ko-KR":"음량 조절 안 함","nl-NL":"Volumeregeling uitgeschakeld"},"Web notifications":{"de-DE":"Systemhinweise","es-VE":"Notificaciones Web","fi-FI":"Web ilmoitukset","ko-KR":"웹 알림","nl-NL":"Webmeldingen"},"Webserver":{"de-DE":"Webserver","es-VE":"Servidor Web","fi-FI":"Webserver","ko-KR":"웹서버","nl-NL":"Webserver"},"Websocket connection failed":{"de-DE":"Websocket Verbindung fehlgeschlagen","es-VE":"Error en la conexión con el Websocket","fi-FI":"Websocket yhteys epäonnistui","ko-KR":"웹소켓 연결 안 됨","nl-NL":"Websocket Verbinding mislukt"},"Websocket connection failed, trying to reconnect":{"de-DE":"Websocket Verbindung fehlgeschlagen, versuche neue Verbindung","es-VE":"Error en la conexión Websocket, intentando reconectar","fi-FI":"Websocket yhteys epäonnistui, yritetään uudelleen","ko-KR":"웹소켓 연결이 안 되어, 다시 시도하는 중","nl-NL":"Websocket Verbinding mislukt, nieuwe poging"},"Websocket is disconnected":{"de-DE":"Websockt ist nicht verbunden","es-VE":"Websocket está desconectado","fi-FI":"Websocket yhteys on katkaistu","ko-KR":"웹소켓 연결 안 됨","nl-NL":"Websocket niet verbonden"},"Wed":{"de-DE":"Mit","es-VE":"Mié","fi-FI":"Ke","ko-KR":"수","nl-NL":"Wo"},"Weekdays":{"de-DE":"Wochentage","es-VE":"Días de semana","fi-FI":"Viikonpäivät","ko-KR":"주일","nl-NL":"Weekdagen"},"Work":{"de-DE":"Werk","es-VE":"Trabajo","fi-FI":"Työ","ko-KR":"작품","nl-NL":"Werk"},"Zoom":{"de-DE":"Zoom","nl-NL":"Zoom"},"bits":{"de-DE":"Bits","es-VE":"Bits","fi-FI":"bittiä","ko-KR":"비트","nl-NL":"bits"},"contains":{"de-DE":"enthält","es-VE":"contiene","fi-FI":"sisältää","ko-KR":"내용","nl-NL":"bevat"},"current":{"de-DE":"aktive","ko-KR":"현재","nl-NL":"huidige"},"disabled":{"de-DE":"deaktiviert","ko-KR":"사용 안 함","nl-NL":"uitgeschakeld"},"enabled":{"de-DE":"aktiviert","ko-KR":"사용함","nl-NL":"ingeschakeld"},"folder.jpg":{"de-DE":"folder.jpg","es-VE":"carpeta.jpg","fi-FI":"folder.jpg","ko-KR":"folder.jpg","nl-NL":"folder.jpg"},"http://uri.to/stream.mp3":{"de-DE":"http://url.zum/stream.mp3","es-VE":"http://url.to/stream.mp3","fi-FI":"http://url.to/stream.mp3","ko-KR":"http://주소/stream.mp3","nl-NL":"http://url.naar/stream.mp3"},"kHz":{"de-DE":"kHz","es-VE":"kHz","fi-FI":"kHz","ko-KR":"kHz","nl-NL":"kHz"},"myMPD CA":{"de-DE":"myMPD Stammzertifikat","es-VE":"myMPD CA","fi-FI":"myMPD Sertifikaatti","ko-KR":"myMPD 인증서","nl-NL":"myMPD CA"},"myMPD installed as app":{"de-DE":"myMPD wurde als App installiert","es-VE":"myMPD instalado como aplicación","fi-FI":"myMPD asennettu sovelluksena","ko-KR":"myMPD가 앱으로 설치됨","nl-NL":"myMPD werd als app geïnstalleerd "},"myMPD is in readonly mode":{"de-DE":"myMPD ist im Readonly Modus","es-VE":"myMPD está en modo solo lectura","fi-FI":"myMPD on vain luku tilassa","ko-KR":"읽기 전용 모드임","nl-NL":"myMPD is in alleen lezen modus"},"myMPD uptime":{"de-DE":"myMPD Uptime","es-VE":"Tiempo de actividad myMPD","fi-FI":"myMPD Uptime","ko-KR":"myMPD 가동 시간","nl-NL":"myMPD uptime"},"never":{"de-DE":"noch nie","es-VE":"nunca","fi-FI":"Ei koskaan","ko-KR":"안 함","nl-NL":"nooit"},"newest":{"de-DE":"Neueste Lieder","es-VE":"más reciente","fi-FI":"Uusin","ko-KR":"최신","nl-NL":"Nieuwste nummers"},"on":{"de-DE":"an","es-VE":"on","fi-FI":"Päällä","ko-KR":"켜기","nl-NL":"aan"},"search":{"de-DE":"Suche","es-VE":"buscar","fi-FI":"haku","ko-KR":"찾기","nl-NL":"Zoek"},"sticker":{"de-DE":"Sticker","es-VE":"Sticker","fi-FI":"Sticker","ko-KR":"스티커","nl-NL":"Sticker"}};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
var keymap = {
    "ArrowLeft": {"cmd": "clickPrev", "options": [], "desc": "Previous song", "key": "keyboard_arrow_left"},
    "ArrowRight": {"cmd": "clickNext", "options": [], "desc": "Next song", "key": "keyboard_arrow_right"},
    " ": {"cmd": "clickPlay", "options": [], "desc": "Toggle play / pause", "key": "space_bar"},
    "s": {"cmd": "clickStop", "options": [], "desc": "Stop playing"},
    "-": {"cmd": "volumeStep", "options": ["down"], "desc": "Volume down"},
    "+": {"cmd": "volumeStep", "options": ["up"], "desc": "Volume up"},
    "c": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_CLEAR"}], "desc": "Clear queue"},
    "u": {"cmd": "updateDB", "options": ["", true], "desc": "Update database"},
    "r": {"cmd": "rescanDB", "options": ["", true], "desc": "Rescan database"},
    "p": {"cmd": "updateSmartPlaylists", "options": [false], "desc": "Update smart playlists", "req": "featSmartpls"},
    "a": {"cmd": "showAddToPlaylist", "options": ["stream", ""], "desc": "Add stream"},
    "t": {"cmd": "openModal", "options": ["modalSettings"], "desc": "Open settings"},
    "i": {"cmd": "clickTitle", "options": [], "desc": "Open song details"},
    "l": {"cmd": "openDropdown", "options": ["dropdownLocalPlayer"], "desc": "Open local player"},
    "0": {"cmd": "appGoto", "options": ["Playback"], "desc": "Goto playback"},
    "1": {"cmd": "appGoto", "options": ["Queue", "Current"], "desc": "Goto queue"},
    "2": {"cmd": "appGoto", "options": ["Queue", "LastPlayed"], "desc": "Goto last played"},
    "3": {"cmd": "appGoto", "options": ["Browse", "Database"], "desc": "Goto browse database", "req": "featTags"},
    "4": {"cmd": "appGoto", "options": ["Browse", "Playlists"], "desc": "Goto browse playlists", "req": "featPlaylists"},
    "5": {"cmd": "appGoto", "options": ["Browse", "Filesystem"], "desc": "Goto browse filesystem"},
    "6": {"cmd": "appGoto", "options": ["Search"], "desc": "Goto search"},
    "m": {"cmd": "openDropdown", "options": ["dropdownMainMenu"], "desc": "Open main menu"},
    "v": {"cmd": "openDropdown", "options": ["dropdownVolumeMenu"], "desc": "Open volume menu"},
    "S": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_SHUFFLE"}], "desc": "Shuffle queue"},
    "C": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_CROP"}], "desc": "Crop queue"},
    "?": {"cmd": "openModal", "options": ["modalAbout"], "desc": "Open about"},
    "/": {"cmd": "focusSearch", "options": [], "desc": "Focus search"},
    "n": {"cmd": "focusTable", "options": [], "desc": "Focus table"},
    "q": {"cmd": "queueSelectedItem", "options": [true], "desc": "Append item to queue"},
    "Q": {"cmd": "queueSelectedItem", "options": [false], "desc": "Replace queue with item"},
    "d": {"cmd": "dequeueSelectedItem", "options": [], "desc": "Remove item from queue"},
    "x": {"cmd": "addSelectedItemToPlaylist", "options": [], "desc": "Append item to playlist"},
    "F": {"cmd": "openFullscreen", "options": [], "desc": "Open fullscreen"}
};
var $jscomp=$jscomp||{};$jscomp.scope={};$jscomp.ASSUME_ES5=!1;$jscomp.ASSUME_NO_NATIVE_MAP=!1;$jscomp.ASSUME_NO_NATIVE_SET=!1;$jscomp.defineProperty=$jscomp.ASSUME_ES5||"function"==typeof Object.defineProperties?Object.defineProperty:function(a,b,c){a!=Array.prototype&&a!=Object.prototype&&(a[b]=c.value)};$jscomp.getGlobal=function(a){return"undefined"!=typeof window&&window===a?a:"undefined"!=typeof global&&null!=global?global:a};$jscomp.global=$jscomp.getGlobal(this);$jscomp.SYMBOL_PREFIX="jscomp_symbol_";
$jscomp.initSymbol=function(){$jscomp.initSymbol=function(){};$jscomp.global.Symbol||($jscomp.global.Symbol=$jscomp.Symbol)};$jscomp.Symbol=function(){var a=0;return function(b){return $jscomp.SYMBOL_PREFIX+(b||"")+a++}}();
$jscomp.initSymbolIterator=function(){$jscomp.initSymbol();var a=$jscomp.global.Symbol.iterator;a||(a=$jscomp.global.Symbol.iterator=$jscomp.global.Symbol("iterator"));"function"!=typeof Array.prototype[a]&&$jscomp.defineProperty(Array.prototype,a,{configurable:!0,writable:!0,value:function(){return $jscomp.arrayIterator(this)}});$jscomp.initSymbolIterator=function(){}};$jscomp.arrayIterator=function(a){var b=0;return $jscomp.iteratorPrototype(function(){return b<a.length?{done:!1,value:a[b++]}:{done:!0}})};
$jscomp.iteratorPrototype=function(a){$jscomp.initSymbolIterator();a={next:a};a[$jscomp.global.Symbol.iterator]=function(){return this};return a};$jscomp.makeIterator=function(a){$jscomp.initSymbolIterator();var b=a[Symbol.iterator];return b?b.call(a):$jscomp.arrayIterator(a)};$jscomp.arrayFromIterator=function(a){for(var b,c=[];!(b=a.next()).done;)c.push(b.value);return c};$jscomp.arrayFromIterable=function(a){return a instanceof Array?a:$jscomp.arrayFromIterator($jscomp.makeIterator(a))};
$jscomp.polyfill=function(a,b,c,d){if(b){c=$jscomp.global;a=a.split(".");for(d=0;d<a.length-1;d++){var f=a[d];f in c||(c[f]={});c=c[f]}a=a[a.length-1];d=c[a];b=b(d);b!=d&&null!=b&&$jscomp.defineProperty(c,a,{configurable:!0,writable:!0,value:b})}};$jscomp.polyfill("Object.is",function(a){return a?a:function(a,c){return a===c?0!==a||1/a===1/c:a!==a&&c!==c}},"es6","es3");
$jscomp.polyfill("Array.prototype.includes",function(a){return a?a:function(a,c){var b=this;b instanceof String&&(b=String(b));var f=b.length;c=c||0;for(0>c&&(c=Math.max(c+f,0));c<f;c++){var g=b[c];if(g===a||Object.is(g,a))return!0}return!1}},"es7","es3");
$jscomp.checkStringArgs=function(a,b,c){if(null==a)throw new TypeError("The 'this' value for String.prototype."+c+" must not be null or undefined");if(b instanceof RegExp)throw new TypeError("First argument to String.prototype."+c+" must not be a regular expression");return a+""};$jscomp.polyfill("String.prototype.includes",function(a){return a?a:function(a,c){return-1!==$jscomp.checkStringArgs(this,a,"includes").indexOf(a,c||0)}},"es6","es3");
$jscomp.iteratorFromArray=function(a,b){$jscomp.initSymbolIterator();a instanceof String&&(a+="");var c=0,d={next:function(){if(c<a.length){var f=c++;return{value:b(f,a[f]),done:!1}}d.next=function(){return{done:!0,value:void 0}};return d.next()}};d[Symbol.iterator]=function(){return d};return d};$jscomp.polyfill("Array.prototype.keys",function(a){return a?a:function(){return $jscomp.iteratorFromArray(this,function(a){return a})}},"es6","es3");
$jscomp.owns=function(a,b){return Object.prototype.hasOwnProperty.call(a,b)};$jscomp.assign="function"==typeof Object.assign?Object.assign:function(a,b){for(var c=1;c<arguments.length;c++){var d=arguments[c];if(d)for(var f in d)$jscomp.owns(d,f)&&(a[f]=d[f])}return a};$jscomp.polyfill("Object.assign",function(a){return a||$jscomp.assign},"es6","es3");
$jscomp.polyfill("String.prototype.repeat",function(a){return a?a:function(a){var b=$jscomp.checkStringArgs(this,null,"repeat");if(0>a||1342177279<a)throw new RangeError("Invalid count value");a|=0;for(var d="";a;)if(a&1&&(d+=b),a>>>=1)b+=b;return d}},"es6","es3");
function sendAPI(a,b,c,d){var f={jsonrpc:"2.0",id:0,method:a,params:b},g=new XMLHttpRequest;g.open("POST",subdir+"/api",!0);g.setRequestHeader("Content-type","application/json");g.onreadystatechange=function(){if(4===g.readyState)if(""!==g.responseText){var a=JSON.parse(g.responseText);if(a.error)showNotification(t(a.error.message,a.error.data),"","","danger"),logError(JSON.stringify(a.error));else if(a.result&&a.result.message&&"ok"!==a.result.message)logDebug("Got API response: "+JSON.stringify(a.result)),
showNotification(t(a.result.message,a.result.data),"","","success");else if(a.result&&a.result.message&&"ok"===a.result.message)logDebug("Got API response: "+JSON.stringify(a.result));else if(a.result&&a.result.method)logDebug("Got API response of type: "+a.result.method);else if(logError("Got invalid API response: "+JSON.stringify(a)),!0!==d)return;void 0!==c&&"function"===typeof c&&(void 0!==a.result||!0===d?(logDebug("Calling "+c.name),c(a)):logDebug("Undefined resultset, skip calling "+c.name))}else logError("Empty response for request: "+
JSON.stringify(f)),!0===d&&void 0!==c&&"function"===typeof c&&(logDebug("Got empty API response calling "+c.name),c(""))};g.send(JSON.stringify(f));logDebug("Send API request: "+a)}
function webSocketConnect(){if(null!==socket&&socket.readyState===WebSocket.OPEN)logInfo("Socket already connected"),websocketConnected=!0,socketRetry=0;else if(null!==socket&&socket.readyState===WebSocket.CONNECTING)logInfo("Socket connection in progress"),websocketConnected=!1,socketRetry++,20<socketRetry&&(logError("Socket connection timed out"),webSocketClose(),setTimeout(function(){webSocketConnect()},1E3),socketRetry=0);else{websocketConnected=!1;var a=getWsUrl();socket=new WebSocket(a);socketRetry=
0;logInfo("Connecting to "+a);try{socket.onopen=function(){logInfo("Websocket is connected");websocketConnected=!0;null!==websocketTimer&&(clearTimeout(websocketTimer),websocketTimer=null)},socket.onmessage=function(b){try{var c=JSON.parse(b.data);logDebug("Websocket notification: "+JSON.stringify(c))}catch(d){logError("Invalid JSON data received: "+b.data);return}if(c.error)showNotification(t(c.error.message,c.error.data),"","","danger");else if(c.result)showNotification(t(c.result.message,c.result.data),
"","","success");else switch(c.method){case "welcome":websocketConnected=!0;showNotification(t("Connected to myMPD"),a,"","success");appRoute();sendAPI("MPD_API_PLAYER_STATE",{},parseState,!0);break;case "update_state":c.result=c.params;parseState(c);break;case "mpd_disconnected":progressTimer&&clearTimeout(progressTimer);getSettings(!0);break;case "mpd_connected":showNotification(t("Connected to MPD"),"","","success");sendAPI("MPD_API_PLAYER_STATE",{},parseState);getSettings(!0);break;case "update_queue":"Queue"===
app.current.app&&getQueue();c.result=c.params;parseUpdateQueue(c);break;case "update_options":getSettings();break;case "update_outputs":sendAPI("MPD_API_PLAYER_OUTPUT_LIST",{},parseOutputs);break;case "update_started":updateDBstarted(!1);break;case "update_database":case "update_finished":updateDBfinished(c.method);break;case "update_volume":c.result=c.params;parseVolume(c);break;case "update_stored_playlist":"Browse"===app.current.app&&"Playlists"===app.current.tab&&"All"===app.current.view?sendAPI("MPD_API_PLAYLIST_LIST",
{offset:app.current.page,searchstr:app.current.search},parsePlaylists):"Browse"===app.current.app&&"Playlists"===app.current.tab&&"Detail"===app.current.view&&sendAPI("MPD_API_PLAYLIST_CONTENT_LIST",{offset:app.current.page,searchstr:app.current.search,uri:app.current.search,cols:settings.colsBrowsePlaylistsDetail},parsePlaylists);break;case "update_lastplayed":"Queue"===app.current.app&&"LastPlayed"===app.current.tab&&sendAPI("MPD_API_QUEUE_LAST_PLAYED",{offset:app.current.page,cols:settings.colsQueueLastPlayed},
parseLastPlayed);break;case "error":document.getElementById("alertMpdState").classList.contains("hide")&&showNotification(t(c.params.message),"","","danger");break;case "warn":document.getElementById("alertMpdState").classList.contains("hide")&&showNotification(t(c.params.message),"","","warning");break;case "info":document.getElementById("alertMpdState").classList.contains("hide")&&showNotification(t(c.params.message),"","","success")}},socket.onclose=function(){logError("Websocket is disconnected");
websocketConnected=!1;!0===appInited?(toggleUI(),progressTimer&&clearTimeout(progressTimer)):(showAppInitAlert(t("Websocket connection failed")),logError("Websocket connection failed."));null!==websocketTimer&&(clearTimeout(websocketTimer),websocketTimer=null);websocketTimer=setTimeout(function(){logInfo("Reconnecting websocket");toggleAlert("alertMympdState",!0,t("Websocket connection failed, trying to reconnect")+'&nbsp;&nbsp;<div class="spinner-border spinner-border-sm"></div>');webSocketConnect()},
3E3);socket=null}}catch(b){logError(b)}}}function webSocketClose(){null!==websocketTimer&&(clearTimeout(websocketTimer),websocketTimer=null);null!==socket&&(socket.onclose=function(){},socket.close(),socket=null);websocketConnected=!1}function getWsUrl(){var a=window.location.hostname,b=window.location.protocol,c=window.location.port;return("https:"===b?"wss://":"ws://")+a+(""!==c?":"+c:"")+subdir+"/ws/"}
function navBrowseHandler(a){"BUTTON"===a.target.nodeName&&(a=a.target.getAttribute("data-tag"),"Playlists"===a||"Filesystem"===a?appGoto("Browse",a,void 0):"Browse"===app.current.app&&"Database"!==app.current.tab?appGoto("Browse","Database",app.apps.Browse.tabs.Database.active):("Album"!==a&&(app.current.filter=a,app.current.sort=a),app.current.search="",document.getElementById("searchDatabaseMatch").value="contains",appGoto(app.current.app,app.current.tab,app.current.view,"0",app.current.filter,
app.current.sort,a,app.current.search)))}function gotoBrowse(){var a=event.target,b=a.getAttribute("data-tag"),c=decodeURI(a.getAttribute("data-name"));null===b&&(b=a.parentNode.getAttribute("data-tag"),c=decodeURI(a.parentNode.getAttribute("data-name")));""!==b&&""!==c&&"-"!==c&&settings.browsetags.includes(b)&&appGoto("Browse","Database","List","0",b,"AlbumArtist","Album",c)}
function parseFilesystem(a){var b=app.current.app+("Filesystem"===app.current.tab?app.current.tab:""),c=document.getElementById(app.current.app+(void 0===app.current.tab?"":app.current.tab)+"List"),d=c.getElementsByTagName("tbody")[0],f=settings["cols"+b].length;f--;if(a.error)d.innerHTML='<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+f+'">'+t(a.error.message)+"</td></tr>";else{if("Browse"===app.current.app&&"Filesystem"===app.current.tab){var g=document.getElementById("BrowseFilesystemImages");
g.innerHTML="";0===a.result.images.length&&""===a.result.bookletPath||!1===settings.publish?g.classList.add("hide"):g.classList.remove("hide");if(""!==a.result.bookletPath&&!0===settings.publish){var h=document.createElement("div");h.style.backgroundImage='url("'+subdir+'/assets/coverimage-booklet.svg")';h.classList.add("booklet");h.setAttribute("data-href",subdir+"/browse/music/"+a.result.bookletPath);h.title=t("Booklet");g.appendChild(h)}for(h=0;h<a.result.images.length;h++){var k=document.createElement("div");
k.style.backgroundImage='url("'+subdir+"/browse/music/"+a.result.images[h]+'"),url("assets/coverimage-loading.svg")';g.appendChild(k)}}g=a.result.returnedEntities;h=d.getElementsByTagName("tr");c=document.activeElement.parentNode.parentNode===c?!0:!1;for(var l=k=0;l<g;l++){var m=encodeURI(a.result.data[l].uri),p=document.createElement("tr"),n="";p.setAttribute("data-type",a.result.data[l].Type);p.setAttribute("data-uri",m);p.setAttribute("tabindex",0);"song"===a.result.data[l].Type?p.setAttribute("data-name",
a.result.data[l].Title):p.setAttribute("data-name",a.result.data[l].name);switch(a.result.data[l].Type){case "dir":case "smartpls":case "plist":for(m=0;m<settings["cols"+b].length;m++)n+='<td data-col="'+settings["cols"+b][m]+'">',"Type"===settings["cols"+b][m]?n="dir"===a.result.data[l].Type?n+'<span class="material-icons">folder_open</span>':n+('<span class="material-icons">'+("smartpls"===a.result.data[l].Type?"queue_music":"list")+"</span>"):"Title"===settings["cols"+b][m]&&(n+=e(a.result.data[l].name)),
n+="</td>";n+='<td data-col="Action"><a href="#" class="material-icons color-darkgrey">'+ligatureMore+"</a></td>";p.innerHTML=n;break;case "song":a.result.data[l].Duration=beautifySongDuration(a.result.data[l].Duration);for(m=0;m<settings["cols"+b].length;m++)n+='<td data-col="'+settings["cols"+b][m]+'">',n="Type"===settings["cols"+b][m]?n+'<span class="material-icons">music_note</span>':n+e(a.result.data[l][settings["cols"+b][m]]),n+="</td>";n+='<td data-col="Action"><a href="#" class="material-icons color-darkgrey">'+
ligatureMore+"</a></td>";p.innerHTML=n}l<h.length?k=!0===replaceTblRow(h[l],p)?l:k:d.append(p)}for(b=h.length-1;b>=g;b--)h[b].remove();!0===c&&focusTable(0);setPagination(a.result.totalEntities,a.result.returnedEntities);0===g&&(d.innerHTML='<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+f+'">'+t("Empty list")+"</td></tr>")}document.getElementById(app.current.app+(void 0===app.current.tab?"":app.current.tab)+"List").classList.remove("opacity05")}
function addAllFromBrowseFilesystem(){sendAPI("MPD_API_QUEUE_ADD_TRACK",{uri:app.current.search});showNotification(t("Added all songs"),"","","success")}function addAllFromBrowseDatabasePlist(a){2<=app.current.search.length&&sendAPI("MPD_API_DATABASE_SEARCH",{plist:a,filter:app.current.view,searchstr:app.current.search,offset:0,cols:settings.colsSearch,replace:!1})}
function parseBookmarks(a){for(var b='<table class="table table-sm table-dark table-borderless mb-0">',c=0;c<a.result.returnedEntities;c++)b+='<tr data-id="'+a.result.data[c].id+'" data-type="'+a.result.data[c].type+'" data-uri="'+encodeURI(a.result.data[c].uri)+'"><td class="nowrap"><a class="text-light" href="#" data-href="goto">'+e(a.result.data[c].name)+'</a></td><td><a class="text-light material-icons material-icons-small" href="#" data-href="edit">edit</a></td><td><a class="text-light material-icons material-icons-small" href="#" data-href="delete">delete</a></td></tr>';
0===a.result.returnedEntities&&(b+='<tr><td class="text-light nowrap">'+t("No bookmarks found")+"</td></tr>");b+="</table>";document.getElementById("BrowseFilesystemBookmarks").innerHTML=b}
function showBookmarkSave(a,b,c,d){document.getElementById("saveBookmarkName").classList.remove("is-invalid");document.getElementById("saveBookmarkId").value=a;document.getElementById("saveBookmarkName").value=b;document.getElementById("saveBookmarkUri").value=c;document.getElementById("saveBookmarkType").value=d;modalSaveBookmark.show()}
function saveBookmark(){var a=parseInt(document.getElementById("saveBookmarkId").value),b=document.getElementById("saveBookmarkName").value,c=document.getElementById("saveBookmarkUri").value,d=document.getElementById("saveBookmarkType").value;""!==b?(sendAPI("MYMPD_API_BOOKMARK_SAVE",{id:a,name:b,uri:c,type:d}),modalSaveBookmark.hide()):document.getElementById("saveBookmarkName").classList.add("is-invalid")}
function parseDatabase(a){var b=a.result.returnedEntities,c=document.getElementById("BrowseDatabaseCards"),d=c.getElementsByClassName("col"),f="IntersectionObserver"in window?!0:!1;0===d.length&&(c.innerHTML="");for(var g=0;g<b;g++){var h=document.createElement("div");h.classList.add("col","px-0","flex-grow-0");""===a.result.data[g].AlbumArtist&&(a.result.data[g].AlbumArtist=t("Unknown artist"));""===a.result.data[g].Album&&(a.result.data[g].Album=t("Unknown album"));if("Album"===a.result.tag){var k=
genId("database"+a.result.data[g].Album+a.result.data[g].AlbumArtist);var l=subdir+"/albumart/"+encodeURI(a.result.data[g].FirstSongUri);k='<div class="card card-grid clickable" data-picture="'+l+'" data-uri="'+encodeURI(a.result.data[g].FirstSongUri.replace(/\/[^/]+$/,""))+'" data-type="dir" data-name="'+encodeURI(a.result.data[g].Album)+'" data-album="'+encodeURI(a.result.data[g].Album)+'" data-albumartist="'+encodeURI(a.result.data[g].AlbumArtist)+'" tabindex="0"><div class="card-body album-cover-loading album-cover-grid bg-white" id="'+
k+'"></div><div class="card-footer card-footer-grid p-2" title="'+e(a.result.data[g].AlbumArtist)+": "+e(a.result.data[g].Album)+'">'+e(a.result.data[g].Album)+"<br/><small>"+e(a.result.data[g].AlbumArtist)+"</small></div></div>"}else k=genId("database"+a.result.data[g].value),l=subdir+"/tagpics/"+a.result.tag+"/"+encodeURI(a.result.data[g].value),k='<div class="card card-grid clickable" data-picture="'+l+'" data-tag="'+encodeURI(a.result.data[g].value)+'" tabindex="0">'+(!0===a.result.pics?'<div class="card-body album-cover-loading album-cover-grid bg-white" id="'+
k+'"></div>':"")+'<div class="card-footer card-footer-grid p-2" title="'+e(a.result.data[g].value)+'">'+e(a.result.data[g].value)+"<br/></div></div>";h.innerHTML=k;k=!1;g<d.length?d[g].firstChild.getAttribute("data-picture")!==h.firstChild.getAttribute("data-picture")&&(d[g].replaceWith(h),k=!0):(c.append(h),k=!0);!0===k&&(!0===f?(new IntersectionObserver(setGridImage,{root:null,rootMargin:"0px"})).observe(h):h.firstChild.firstChild.style.backgroundImage=l)}for(f=d.length-1;f>=b;f--)d[f].remove();
setPagination(a.result.totalEntities,a.result.returnedEntities);0===b&&(c.innerHTML='<div><span class="material-icons">error_outline</span>&nbsp;'+t("Empty list")+"</div>")}function setGridImage(a,b){a.forEach(function(a){if(0<a.intersectionRatio){b.unobserve(a.target);var c=decodeURI(a.target.firstChild.getAttribute("data-picture"));if(a=a.target.firstChild.getElementsByClassName("card-body")[0])a.style.backgroundImage='url("'+c+'"), url("'+subdir+'/assets/coverimage-loading.svg")'}})}
function parseAlbumDetails(a){var b=document.getElementById("viewDetailDatabaseCover");b.style.backgroundImage='url("'+subdir+"/albumart/"+a.result.data[0].uri+'"), url("'+subdir+'/assets/coverimage-loading.svg")';b.setAttribute("data-images",a.result.images.join(";;"));document.getElementById("viewDetailDatabaseInfo").innerHTML="<h1>"+e(a.result.Album)+"</h1><small> "+t("AlbumArtist")+"</small><p>"+e(a.result.AlbumArtist)+"</p>"+(""===a.result.bookletPath||!1===settings.featBrowse?"":'<span class="text-light material-icons">description</span>&nbsp;<a class="text-light" target="_blank" href="'+
subdir+"/browse/music/"+e(a.result.bookletPath)+'">'+t("Download booklet")+"</a>")+"</p>";b=document.getElementById("BrowseDatabaseDetailList").getElementsByTagName("tbody")[0];var c=settings.colsBrowseDatabaseDetail.length,d="";1<a.result.Discs&&(d='<tr class="not-clickable"><td><span class="material-icons">album</span></td><td colspan="'+c+'">'+t("Disc 1")+"</td></tr>");for(var f=a.result.returnedEntities,g=parseInt(a.result.data[0].Disc),h=0;h<f;h++){g<parseInt(a.result.data[h].Disc)&&(d+='<tr class="not-clickable"><td><span class="material-icons">album</span></td><td colspan="'+
c+'">'+t("Disc")+" "+e(a.result.data[h].Disc)+"</td></tr>");a.result.data[h].Duration&&(a.result.data[h].Duration=beautifySongDuration(a.result.data[h].Duration));d+='<tr tabindex="0" data-type="song" data-name="'+a.result.data[h].Title+'" data-uri="'+encodeURI(a.result.data[h].uri)+'">';for(g=0;g<settings.colsBrowseDatabaseDetail.length;g++)d+='<td data-col="'+settings.colsBrowseDatabaseDetail[g]+'">'+e(a.result.data[h][settings.colsBrowseDatabaseDetail[g]])+"</td>";d+='<td data-col="Action"><a href="#" class="material-icons color-darkgrey">'+
ligatureMore+"</a></td></tr>";g=a.result.data[h].Disc}b.innerHTML=d;document.getElementById("BrowseDatabaseDetailList").classList.remove("opacity05")}function backToAlbumGrid(){appGoto("Browse","Database","List")}
function addAlbum(a){var b=decodeURI(app.current.tag),c=decodeURI(app.current.search);b="((Album == '"+b+"') AND (AlbumArtist == '"+c+"'))";"appendQueue"===a?addAllFromSearchPlist("queue",b,!1):"replaceQueue"===a?addAllFromSearchPlist("queue",b,!0):"addPlaylist"===a&&showAddToPlaylist("ALBUM",b)}
function searchAlbumgrid(a){for(var b="",c=document.getElementById("searchDatabaseCrumb").children,d=0;d<c.length;d++)0<d&&(b+=" AND "),b+="("+decodeURI(c[d].getAttribute("data-filter"))+")";""!==a&&(""!==b&&(b+=" AND "),c=document.getElementById("searchDatabaseMatch"),b+="("+app.current.filter+" "+c.options[c.selectedIndex].value+" '"+a+"')");2>=b.length&&(b="");appGoto(app.current.app,app.current.tab,app.current.view,"0",app.current.filter,app.current.sort,app.current.tag,b)}
function navigateGrid(a,b){var c=!1;"Enter"===b?"Browse"===app.current.app&&"Database"===app.current.tab&&"List"===app.current.view?("Album"===app.current.tag?appGoto("Browse","Database","Detail","0","Album","AlbumArtist",decodeURI(a.getAttribute("data-album")),decodeURI(a.getAttribute("data-albumartist"))):(app.current.search="",document.getElementById("searchDatabaseStr").value="",appGoto(app.current.app,app.current.card,void 0,"0","Album","AlbumArtist","Album","("+app.current.tag+" == '"+decodeURI(a.getAttribute("data-tag"))+
"')")),c=!0):"Home"===app.current.app&&(a=event.target.getAttribute("data-href"),null!==a&&parseCmd(event,a)):" "===b?"Browse"===app.current.app&&"Database"===app.current.tab&&"List"===app.current.view?("Album"===app.current.tag&&showMenu(a.getElementsByClassName("card-footer")[0],event),c=!0):"Home"===app.current.app&&showMenu(a.getElementsByClassName("card-footer")[0],event):"ArrowDown"===b||"ArrowUp"===b?(b="ArrowDown"===b?null!==a.parentNode.nextElementSibling?a.parentNode.nextElementSibling.firstChild:
null:null!==a.parentNode.previousElementSibling?a.parentNode.previousElementSibling.firstChild:null,null!==b&&(b.focus(),a.classList.remove("selected"),b.classList.add("selected"),c=!0,scrollFocusIntoView())):"Escape"===b&&(a.blur(),a.classList.remove("selected"),c=!0);!0===c&&(event.stopPropagation(),event.preventDefault())}
function parseHome(a){var b=a.result.returnedEntities,c=document.getElementById("HomeCards"),d=c.getElementsByClassName("col");0===d.length&&(c.innerHTML="");for(var f=0;f<b;f++){var g=document.createElement("div");g.classList.add("col","px-0","flex-grow-0");""===a.result.data[f].AlbumArtist&&(a.result.data[f].AlbumArtist=t("Unknown artist"));""===a.result.data[f].Album&&(a.result.data[f].Album=t("Unknown album"));var h=JSON.stringify({cmd:a.result.data[f].cmd,options:a.result.data[f].options});h=
'<div class="card home-icons clickable" draggable="true" tabindex="0" data-pos="'+f+"\" data-href='"+h+"'  title=\""+e(a.result.data[f].name)+'">'+(""!==a.result.data[f].ligature?'<div class="card-body material-icons home-icons-ligature">'+e(a.result.data[f].ligature)+"</div>":'<div class="card-body home-icons-image"></div>')+'<div class="card-footer card-footer-grid p-2">'+e(a.result.data[f].name)+"</div></div>";g.innerHTML=h;f<d.length?d[f].replaceWith(g):c.append(g);(h=g.getElementsByClassName("home-icons-image")[0])?
h.style.backgroundImage='url("'+subdir+"/browse/pics/"+a.result.data[f].image+'")':""!==a.result.data[f].bgcolor&&(g.getElementsByClassName("home-icons-ligature")[0].style.backgroundColor=a.result.data[f].bgcolor)}for(a=d.length-1;a>=b;a--)d[a].remove();0===b&&(c.innerHTML="<div>You have not added any Home Icons yet. You can add views, playlists and scripts.</div>")}
function dragAndDropHome(){var a=document.getElementById("HomeCards");a.addEventListener("dragstart",function(a){a.target.classList.contains("home-icons")&&(a.target.classList.add("opacity05"),a.dataTransfer.setDragImage(a.target,0,0),a.dataTransfer.effectAllowed="move",dragSrc=a.target,dragEl=a.target.cloneNode(!0))},!1);a.addEventListener("dragleave",function(a){a.preventDefault();!1!==dragEl.classList.contains("home-icons")&&"DIV"===a.target.nodeName&&a.target.classList.contains("home-icons")&&
a.target.classList.remove("dragover-icon")},!1);a.addEventListener("dragover",function(b){b.preventDefault();if(!1!==dragEl.classList.contains("home-icons")){for(var c=a.getElementsByClassName("dragover-icon"),d=c.length,f=0;f<d;f++)c[f].classList.remove("dragover-icon");"DIV"===b.target.nodeName&&b.target.classList.contains("home-icons")?b.target.classList.add("dragover-icon"):"DIV"===b.target.nodeName&&b.target.parentNode.classList.contains("home-icons")&&b.target.parentNode.classList.add("dragover-icon");
b.dataTransfer.dropEffect="move"}},!1);a.addEventListener("dragend",function(b){b.preventDefault();if(!1!==dragEl.classList.contains("home-icons")){b=a.getElementsByClassName("dragover-icon");for(var c=b.length,d=0;d<c;d++)b[d].classList.remove("dragover-icon");dragSrc.classList.remove("opacity05")}},!1);a.addEventListener("drop",function(b){b.preventDefault();b.stopPropagation();if(!1!==dragEl.classList.contains("home-icons")){b=b.target;if("DIV"===b.nodeName&&(b.classList.contains("card-body")&&
(b=b.parentNode),b.classList.contains("home-icons"))){dragEl.classList.remove("opacity05");b=parseInt(b.getAttribute("data-pos"));var c=parseInt(dragSrc.getAttribute("data-pos"));!1===isNaN(b)&&!1===isNaN(c)&&c!==b&&sendAPI("MYMPD_API_HOME_ICON_MOVE",{from:c,to:b},function(a){parseHome(a)})}b=a.getElementsByClassName("dragover-icon");c=b.length;for(var d=0;d<c;d++)b[d].classList.remove("dragover-icon")}},!1)}
function executeHomeIcon(a){a=document.getElementById("HomeCards").children[a].firstChild;parseCmd(null,a.getAttribute("data-href"))}function addViewToHome(){_addHomeIcon("appGoto","","preview",[app.current.app,app.current.tab,app.current.view,app.current.page,app.current.filter,app.current.sort,app.current.tag,app.current.search])}function addScriptToHome(a,b){b=JSON.parse(b);b=[b.script,b.arguments.join(",")];_addHomeIcon("execScriptFromOptions",a,"description",b)}
function addPlistToHome(a,b){_addHomeIcon("replaceQueue",b,"list",["plist",a,b])}
function _addHomeIcon(a,b,c,d){document.getElementById("modalEditHomeIconTitle").innerHTML=t("Add to homescreen");document.getElementById("inputHomeIconReplace").value="false";document.getElementById("inputHomeIconOldpos").value="0";document.getElementById("inputHomeIconName").value=b;document.getElementById("inputHomeIconLigature").value=c;document.getElementById("inputHomeIconBgcolor").value="#28a745";document.getElementById("inputHomeIconImage").value="";document.getElementById("selectHomeIconCmd").value=
a;showHomeIconCmdOptions(d);modalEditHomeIcon.show()}function duplicateHomeIcon(a){_editHomeIcon(a,!1,"Duplicate home icon")}function editHomeIcon(a){_editHomeIcon(a,!0,"Edit home icon")}
function _editHomeIcon(a,b,c){document.getElementById("modalEditHomeIconTitle").innerHTML=t(c);sendAPI("MYMPD_API_HOME_ICON_GET",{pos:a},function(c){document.getElementById("inputHomeIconReplace").value=b;document.getElementById("inputHomeIconOldpos").value=a;document.getElementById("inputHomeIconName").value=c.result.data[0].name;document.getElementById("inputHomeIconLigature").value=c.result.data[0].ligature;document.getElementById("inputHomeIconBgcolor").value=c.result.data[0].bgcolor;document.getElementById("inputHomeIconImage").value=
c.result.data[0].image;document.getElementById("selectHomeIconCmd").value=c.result.data[0].cmd;showHomeIconCmdOptions(c.result.data[0].options);modalEditHomeIcon.show()})}
function saveHomeIcon(){var a=!0,b=document.getElementById("inputHomeIconName");validateNotBlank(b)||(a=!1);if(!0===a){a=[];for(var c=document.getElementById("divHomeIconOptions").getElementsByTagName("input"),d=0;d<c.length;d++)a.push(c[d].value);sendAPI("MYMPD_API_HOME_ICON_SAVE",{replace:"true"===document.getElementById("inputHomeIconReplace").value?!0:!1,oldpos:parseInt(document.getElementById("inputHomeIconOldpos").value),name:b.value,ligature:document.getElementById("inputHomeIconLigature").value,
bgcolor:document.getElementById("inputHomeIconBgcolor").value,image:document.getElementById("inputHomeIconImage").value,cmd:document.getElementById("selectHomeIconCmd").value,options:a},function(){modalEditHomeIcon.hide();sendAPI("MYMPD_API_HOME_LIST",{},function(a){parseHome(a)})})}}function deleteHomeIcon(a){sendAPI("MYMPD_API_HOME_ICON_DELETE",{pos:a},function(a){parseHome(a)})}
function showHomeIconCmdOptions(a){for(var b=JSON.parse(getSelectedOptionAttribute("selectHomeIconCmd","data-options")),c="",d=0;d<b.options.length;d++){var f=void 0!==a?void 0!==a[d]?a[d]:"":"";c+='<div class="form-group row"><label class="col-sm-4 col-form-label">'+t(b.options[d])+'</label><div class="col-sm-8"><input class="form-control border-secondary" value="'+e(f)+'"></div></div>'}document.getElementById("divHomeIconOptions").innerHTML=c}
var keymap={ArrowLeft:{cmd:"clickPrev",options:[],desc:"Previous song",key:"keyboard_arrow_left"},ArrowRight:{cmd:"clickNext",options:[],desc:"Next song",key:"keyboard_arrow_right"}," ":{cmd:"clickPlay",options:[],desc:"Toggle play / pause",key:"space_bar"},s:{cmd:"clickStop",options:[],desc:"Stop playing"},"-":{cmd:"volumeStep",options:["down"],desc:"Volume down"},"+":{cmd:"volumeStep",options:["up"],desc:"Volume up"},c:{cmd:"sendAPI",options:[{cmd:"MPD_API_QUEUE_CLEAR"}],desc:"Clear queue"},u:{cmd:"updateDB",
options:["",!0],desc:"Update database"},r:{cmd:"rescanDB",options:["",!0],desc:"Rescan database"},p:{cmd:"updateSmartPlaylists",options:[!1],desc:"Update smart playlists",req:"featSmartpls"},a:{cmd:"showAddToPlaylist",options:["stream",""],desc:"Add stream"},t:{cmd:"openModal",options:["modalSettings"],desc:"Open settings"},i:{cmd:"clickTitle",options:[],desc:"Open song details"},l:{cmd:"openDropdown",options:["dropdownLocalPlayer"],desc:"Open local player"},0:{cmd:"appGoto",options:["Playback"],
desc:"Goto playback"},1:{cmd:"appGoto",options:["Queue","Current"],desc:"Goto queue"},2:{cmd:"appGoto",options:["Queue","LastPlayed"],desc:"Goto last played"},3:{cmd:"appGoto",options:["Browse","Database"],desc:"Goto browse database",req:"featTags"},4:{cmd:"appGoto",options:["Browse","Playlists"],desc:"Goto browse playlists",req:"featPlaylists"},5:{cmd:"appGoto",options:["Browse","Filesystem"],desc:"Goto browse filesystem"},6:{cmd:"appGoto",options:["Search"],desc:"Goto search"},m:{cmd:"openDropdown",
options:["dropdownMainMenu"],desc:"Open main menu"},v:{cmd:"openDropdown",options:["dropdownVolumeMenu"],desc:"Open volume menu"},S:{cmd:"sendAPI",options:[{cmd:"MPD_API_QUEUE_SHUFFLE"}],desc:"Shuffle queue"},C:{cmd:"sendAPI",options:[{cmd:"MPD_API_QUEUE_CROP"}],desc:"Crop queue"},"?":{cmd:"openModal",options:["modalAbout"],desc:"Open about"},"/":{cmd:"focusSearch",options:[],desc:"Focus search"},n:{cmd:"focusTable",options:[],desc:"Focus table"},q:{cmd:"queueSelectedItem",options:[!0],desc:"Append item to queue"},
Q:{cmd:"queueSelectedItem",options:[!1],desc:"Replace queue with item"},d:{cmd:"dequeueSelectedItem",options:[],desc:"Remove item from queue"},x:{cmd:"addSelectedItemToPlaylist",options:[],desc:"Append item to playlist"},F:{cmd:"openFullscreen",options:[],desc:"Open fullscreen"}};
function e(a){return isNaN(a)?a.replace(/([<>"'])/g,function(a,c){if("<"===c)return"&lt;";if(">"===c)return"&gt;";if('"'===c)return"&quot;";if("'"===c)return"&apos;"}).replace(/\\u(003C|003E|0022|0027)/gi,function(a,c){if("003C"===c)return"&lt;";if("003E"===c)return"&gt;";if("0022"===c)return"&quot;";if("0027"===c)return"&apos;"}):a}
function t(a,b,c){var d=void 0;isNaN(b)&&(c=b);phrases[a]&&(d=phrases[a][locale],void 0===d&&("en-US"!==locale&&logWarn('Phrase "'+a+'" for locale '+locale+" not found"),d=phrases[a]["en-US"]));void 0===d&&(d=a);!1===isNaN(b)&&(a=d.split(" |||| "),1<a.length&&(d=a[smartCount(b)]),d=d.replace("%{smart_count}",b));null!==c&&(d=d.replace(/%\{(\w+)\}/g,function(a,b){return c[b]}));return e(d)}function smartCount(a){return 0===a?1:1===a?0:1}
function localeDate(a){return(void 0===a?new Date:new Date(1E3*a)).toLocaleString(locale)}function beautifyDuration(a){var b=Math.floor(a/86400),c=Math.floor(a/3600)-24*b,d=Math.floor(a/60)-60*c-1440*b;a=a-86400*b-3600*c-60*d;return(0<b?b+"\u2009"+t("Days")+" ":"")+(0<c?c+"\u2009"+t("Hours")+" "+(10>d?"0":""):"")+d+"\u2009"+t("Minutes")+" "+(10>a?"0":"")+a+"\u2009"+t("Seconds")}
function beautifySongDuration(a){var b=Math.floor(a/3600),c=Math.floor(a/60)-60*b;a=a-3600*b-60*c;return(0<b?b+":"+(10>c?"0":""):"")+c+":"+(10>a?"0":"")+a}function gtPage(a,b,c){return-1<c?t(a,c):b+app.current.page<settings.maxElementsPerPage?t(a,b):"> "+t(a,settings.maxElementsPerPage)}
function i18nHtml(a){for(var b=[["data-phrase","innerText"],["data-title-phrase","title"],["data-placeholder-phrase","placeholder"]],c=0;c<b.length;c++)for(var d=a.querySelectorAll("["+b[c][0]+"]"),f=d.length,g=0;g<f;g++)d[g][b[c][1]]=t(d[g].getAttribute(b[c][0]))}
function setLocalPlayerUrl(){"https:"===window.location.protocol?(document.getElementById("infoLocalplayer").classList.remove("hide"),document.getElementById("selectStreamMode").options[0].setAttribute("data-phrase","HTTPS Port")):(document.getElementById("infoLocalplayer").classList.add("hide"),document.getElementById("selectStreamMode").options[0].setAttribute("data-phrase","HTTP Port"));""===settings.streamUrl?(settings.mpdstream=window.location.protocol+"//",null!==settings.mpdHost.match(/^127\./)||
"localhost"===settings.mpdHost||null!==settings.mpdHost.match(/^\//)?settings.mpdstream+=window.location.hostname:settings.mpdstream+=settings.mpdHost,settings.mpdstream+=":"+settings.streamPort+"/"):settings.mpdstream=settings.streamUrl;var a=document.getElementById("localPlayer");a.src!==settings.mpdstream&&(a.pause(),a.src=settings.mpdstream,a.load(),setTimeout(function(){checkLocalPlayerState()},500))}
function clickCheckLocalPlayerState(a){var b=a.target;b.classList.add("disabled");a=document.getElementById("localPlayer").parentNode;document.getElementById("localPlayer").remove();var c=document.createElement("audio");c.setAttribute("preload","none");c.setAttribute("controls","");c.setAttribute("id","localPlayer");c.classList.add("mx-4");a.appendChild(c);setLocalPlayerUrl();setTimeout(function(){b.classList.remove("disabled");c.play()},500)}
function checkLocalPlayerState(){var a=document.getElementById("localPlayer");document.getElementById("errorLocalPlayback").classList.add("hide");document.getElementById("alertLocalPlayback").classList.add("hide");0===a.networkState?(logDebug("localPlayer networkState: "+a.networkState),document.getElementById("alertLocalPlayback").classList.remove("hide")):1<=a.networkState&&logDebug("localPlayer networkState: "+a.networkState);3===a.networkState&&(logError("localPlayer networkState: "+a.networkState),
document.getElementById("errorLocalPlayback").classList.remove("hide"))}function logError(a){logLog(0,"ERROR: "+a)}function logWarn(a){logLog(1,"WARN: "+a)}function logInfo(a){logLog(2,"INFO: "+a)}function logVerbose(a){logLog(3,"VERBOSE: "+a)}function logDebug(a){logLog(4,"DEBUG: "+a)}function logLog(a,b){settings.loglevel>=a&&(0===a?console.error(b):1===a?console.warn(b):4===a?console.debug(b):console.log(b))}
function openFullscreen(){var a=document.documentElement;a.requestFullscreen?a.requestFullscreen():a.mozRequestFullScreen?a.mozRequestFullScreen():a.webkitRequestFullscreen?a.webkitRequestFullscreen():a.msRequestFullscreen&&a.msRequestFullscreen()}
function setViewport(a){document.querySelector("meta[name=viewport]").setAttribute("content","width=device-width, initial-scale="+scale+", maximum-scale="+scale);if(!0===a)try{localStorage.setItem("scale-ratio",scale)}catch(b){logError("Can not save scale-ratio in localStorage: "+b.message)}}
function addStream(){var a=document.getElementById("streamUrl");!0===validateStream(a)&&(sendAPI("MPD_API_QUEUE_ADD_TRACK",{uri:a.value}),modalAddToPlaylist.hide(),showNotification(t("Added stream %{streamUri} to queue",{streamUri:a.value}),"","","success"))}function seekRelativeForward(){seekRelative(5)}function seekRelativeBackward(){seekRelative(-5)}function seekRelative(a){sendAPI("MPD_API_SEEK_CURRENT",{seek:a,relative:!0})}
function clickPlay(){"play"!==playstate?sendAPI("MPD_API_PLAYER_PLAY",{}):!0===settings.footerStop?sendAPI("MPD_API_PLAYER_STOP",{}):sendAPI("MPD_API_PLAYER_PAUSE",{})}function clickStop(){sendAPI("MPD_API_PLAYER_STOP",{})}function clickPrev(){sendAPI("MPD_API_PLAYER_PREV",{})}function clickNext(){sendAPI("MPD_API_PLAYER_NEXT",{})}function execSyscmd(a){sendAPI("MYMPD_API_SYSCMD",{cmd:a})}function clearCovercache(){sendAPI("MYMPD_API_COVERCACHE_CLEAR",{})}
function cropCovercache(){sendAPI("MYMPD_API_COVERCACHE_CROP",{})}function updateDB(a,b){sendAPI("MPD_API_DATABASE_UPDATE",{uri:a});updateDBstarted(b)}function rescanDB(a,b){sendAPI("MPD_API_DATABASE_RESCAN",{uri:a});updateDBstarted(b)}
function updateDBstarted(a){!0===a&&(document.getElementById("updateDBfinished").innerText="",document.getElementById("updateDBfooter").classList.add("hide"),a=document.getElementById("updateDBprogress"),a.style.width="20px",a.style.marginLeft="-20px",modalUpdateDB.show(),a.classList.add("updateDBprogressAnimate"));showNotification(t("Database update started"),"","","success")}
function updateDBfinished(a){document.getElementById("modalUpdateDB").classList.contains("show")?_updateDBfinished(a):setTimeout(function(){_updateDBfinished(a)},100)}
function _updateDBfinished(a){var b=document.getElementById("spinnerUpdateProgress");if(b){var c=b.parentNode;b.remove();for(b=0;b<c.children.length;b++)c.children[b].classList.remove("hide")}document.getElementById("modalUpdateDB").classList.contains("show")&&("update_database"===a?document.getElementById("updateDBfinished").innerText=t("Database successfully updated"):"update_finished"===a&&(document.getElementById("updateDBfinished").innerText=t("Database update finished")),c=document.getElementById("updateDBprogress"),
c.classList.remove("updateDBprogressAnimate"),c.style.width="100%",c.style.marginLeft="0px",document.getElementById("updateDBfooter").classList.remove("hide"));"update_database"===a?showNotification(t("Database successfully updated"),"","","success"):"update_finished"===a&&showNotification(t("Database update finished"),"","","success")}
function zoomPicture(a){if(a.classList.contains("booklet"))window.open(a.getAttribute("data-href"));else{if(a.classList.contains("carousel")){var b=null!==a.getAttribute("data-images")?a.getAttribute("data-images").split(";;"):lastSongObj.images.slice();if(0<b.length){for(a=0;a<b.length;a++)b[a]=subdir+"/browse/music/"+b[a];a=document.getElementById("modalPictureImg");a.style.paddingTop=0;createImgCarousel(a,"picsCarousel",b);document.getElementById("modalPictureZoom").classList.add("hide");modalPicture.show();
return}}""!==a.style.backgroundImage&&(b=document.getElementById("modalPictureImg"),b.innerHTML="",b.style.paddingTop="100%",b.style.backgroundImage=a.style.backgroundImage,document.getElementById("modalPictureZoom").classList.remove("hide"),modalPicture.show())}}function zoomZoomPicture(){window.open(document.getElementById("modalPictureImg").style.backgroundImage.match(/^url\(["']?([^"']*)["']?\)/)[1])}
function createImgCarousel(a,b,c){for(var d='<div id="'+b+'" class="carousel slide" data-ride="carousel"><ol class="carousel-indicators">',f=0;f<c.length;f++)d+='<li data-target="#'+b+'" data-slide-to="'+f+'"'+(0===f?' class="active"':"")+"></li>";d+='</ol><div class="carousel-inner" role="listbox">';for(f=0;f<c.length;f++)d+='<div class="carousel-item'+(0===f?" active":"")+'"><div></div></div>';a.innerHTML=d+('</div><a class="carousel-control-prev" href="#'+b+'" data-slide="prev"><span class="carousel-control-prev-icon"></span></a><a class="carousel-control-next" href="#'+
b+'" data-slide="next"><span class="carousel-control-next-icon"></span></a></div>');a=a.getElementsByClassName("carousel-item");for(d=0;d<a.length;d++)a[d].children[0].style.backgroundImage='url("'+encodeURI(c[d])+'")';b=document.getElementById(b);new BSN.Carousel(b,{interval:!1,pause:!1})}function unmountMount(a){sendAPI("MPD_API_MOUNT_UNMOUNT",{mountPoint:a},showListMounts)}
function mountMount(){document.getElementById("errorMount").classList.add("hide");sendAPI("MPD_API_MOUNT_MOUNT",{mountUrl:getSelectValue("selectMountUrlhandler")+document.getElementById("inputMountUrl").value,mountPoint:document.getElementById("inputMountPoint").value},showListMounts,!0)}
function updateMount(a,b){for(var c=a.parentNode,d=0;d<c.children.length;d++)c.children[d].classList.add("hide");c=document.createElement("div");c.setAttribute("id","spinnerUpdateProgress");c.classList.add("spinner-border","spinner-border-sm");a.parentNode.insertBefore(c,a);updateDB(b,!1)}
function showEditMount(a,b){document.getElementById("listMounts").classList.remove("active");document.getElementById("editMount").classList.add("active");document.getElementById("listMountsFooter").classList.add("hide");document.getElementById("editMountFooter").classList.remove("hide");document.getElementById("errorMount").classList.add("hide");a=a.match(/^(\w+:\/\/)(.+)$/);null!==a&&2<a.length?(document.getElementById("selectMountUrlhandler").value=a[1],document.getElementById("inputMountUrl").value=
a[2],document.getElementById("inputMountPoint").value=b):(document.getElementById("inputMountUrl").value="",document.getElementById("inputMountPoint").value="");document.getElementById("inputMountUrl").focus();document.getElementById("inputMountUrl").classList.remove("is-invalid");document.getElementById("inputMountPoint").classList.remove("is-invalid")}
function showListMounts(a){if(a&&a.error&&a.error.message){var b=document.getElementById("errorMount");b.innerText=a.error.message;b.classList.remove("hide")}else document.getElementById("listMounts").classList.add("active"),document.getElementById("editMount").classList.remove("active"),document.getElementById("listMountsFooter").classList.remove("hide"),document.getElementById("editMountFooter").classList.add("hide"),sendAPI("MPD_API_MOUNT_LIST",{},parseListMounts)}
function parseListMounts(a){for(var b=document.getElementById("listMounts").getElementsByTagName("tbody")[0],c=b.getElementsByTagName("tr"),d=0,f=0;f<a.result.returnedEntities;f++){var g=document.createElement("tr");g.setAttribute("data-url",encodeURI(a.result.data[f].mountUrl));g.setAttribute("data-point",encodeURI(a.result.data[f].mountPoint));""===a.result.data[f].mountPoint&&g.classList.add("not-clickable");var h="<td>"+(""===a.result.data[f].mountPoint?'<span class="material-icons">home</span>':
e(a.result.data[f].mountPoint))+"</td><td>"+e(a.result.data[f].mountUrl)+"</td>";h=""!==a.result.data[f].mountPoint?h+('<td data-col="Action"><a href="#" title="'+t("Unmount")+'" data-action="unmount" class="material-icons color-darkgrey">delete</a><a href="#" title="'+t("Update")+'" data-action="update"class="material-icons color-darkgrey">refresh</a></td>'):h+"<td>&nbsp;</td>";g.innerHTML=h;f<c.length?d=!0===replaceTblRow(c[f],g)?f:d:b.append(g)}for(d=c.length-1;d>=a.result.returnedEntities;d--)c[d].remove();
0===a.result.returnedEntities&&(b.innerHTML='<tr><td><span class="material-icons">error_outline</span></td><td colspan="4">'+t("Empty list")+"</td></tr>")}
function parseNeighbors(a){var b="";if(a.error)b='<div class="list-group-item"><span class="material-icons">error_outline</span> '+t(a.error.message)+"</div>";else{for(var c=0;c<a.result.returnedEntities;c++)b+='<a href="#" class="list-group-item list-group-item-action" data-value="'+a.result.data[c].uri+'">'+a.result.data[c].uri+"<br/><small>"+a.result.data[c].displayName+"</small></a>";0===a.result.returnedEntities&&(b='<div class="list-group-item"><span class="material-icons">error_outline</span>&nbsp;'+
t("Empty list")+"</div>")}document.getElementById("dropdownNeighbors").children[0].innerHTML=b}
var socket=null,websocketConnected=!1,websocketTimer=null,socketRetry=0,lastSong="",lastSongObj={},lastState,currentSong={},playstate="",settingsLock=!1,settingsParsed=!1,settingsNew={},settings={loglevel:2},alertTimeout=null,progressTimer=null,deferredA2HSprompt,dragSrc,dragEl,appInited=!1,subdir="",uiEnabled=!0,locale=navigator.language||navigator.userLanguage,scale="1.0",isMobile=/iPhone|iPad|iPod|Android/i.test(navigator.userAgent),ligatureMore="menu",progressBarTransition="width 1s linear",app=
{apps:{Home:{page:0,filter:"-",sort:"-",tag:"-",search:"",scrollPos:0},Playback:{page:0,filter:"-",sort:"-",tag:"-",search:"",scrollPos:0},Queue:{active:"Current",tabs:{Current:{page:0,filter:"any",sort:"-",tag:"-",search:"",scrollPos:0},LastPlayed:{page:0,filter:"any",sort:"-",tag:"-",search:"",scrollPos:0}}},Browse:{active:"Database",tabs:{Filesystem:{page:0,filter:"-",sort:"-",tag:"-",search:"",scrollPos:0},Playlists:{active:"All",views:{All:{page:0,filter:"-",sort:"-",tag:"-",search:"",scrollPos:0},
Detail:{page:0,filter:"-",sort:"-",tag:"-",search:"",scrollPos:0}}},Database:{active:"List",views:{List:{page:0,filter:"AlbumArtist",sort:"AlbumArtist",tag:"Album",search:"",scrollPos:0},Detail:{page:0,filter:"-",sort:"-",tag:"-",search:"",scrollPos:0}}}}},Search:{page:0,filter:"any",sort:"-",tag:"-",search:"",scrollPos:0}},current:{app:"Home",tab:void 0,view:void 0,page:0,filter:"",search:"",sort:"",tag:"",scrollPos:0},last:{app:void 0,tab:void 0,view:void 0,filter:"",search:"",sort:"",tag:"",scrollPos:0}},
domCache={};domCache.navbarBtns=document.getElementById("navbar-main").getElementsByTagName("div");domCache.navbarBtnsLen=domCache.navbarBtns.length;domCache.counter=document.getElementById("counter");domCache.volumePrct=document.getElementById("volumePrct");domCache.volumeControl=document.getElementById("volumeControl");domCache.volumeMenu=document.getElementById("volumeMenu");domCache.btnsPlay=document.getElementsByClassName("btnPlay");domCache.btnsPlayLen=domCache.btnsPlay.length;
domCache.btnPrev=document.getElementById("btnPrev");domCache.btnNext=document.getElementById("btnNext");domCache.progress=document.getElementById("footerProgress");domCache.progressBar=document.getElementById("footerProgressBar");domCache.progressPos=document.getElementById("footerProgressPos");domCache.volumeBar=document.getElementById("volumeBar");domCache.outputs=document.getElementById("outputs");domCache.btnA2HS=document.getElementById("nav-add2homescreen");domCache.currentCover=document.getElementById("currentCover");
domCache.currentTitle=document.getElementById("currentTitle");domCache.footerTitle=document.getElementById("footerTitle");domCache.footerArtist=document.getElementById("footerArtist");domCache.footerAlbum=document.getElementById("footerAlbum");domCache.footerCover=document.getElementById("footerCover");domCache.btnVoteUp=document.getElementById("btnVoteUp");domCache.btnVoteDown=document.getElementById("btnVoteDown");domCache.badgeQueueItems=document.getElementById("badgeQueueItems");
domCache.searchstr=document.getElementById("searchstr");domCache.searchCrumb=document.getElementById("searchCrumb");domCache.body=document.getElementsByTagName("body")[0];domCache.footer=document.getElementsByTagName("footer")[0];domCache.header=document.getElementById("header");domCache.mainMenu=document.getElementById("mainMenu");
var modalConnection=new BSN.Modal(document.getElementById("modalConnection")),modalSettings=new BSN.Modal(document.getElementById("modalSettings")),modalAbout=new BSN.Modal(document.getElementById("modalAbout")),modalSaveQueue=new BSN.Modal(document.getElementById("modalSaveQueue")),modalAddToQueue=new BSN.Modal(document.getElementById("modalAddToQueue")),modalSongDetails=new BSN.Modal(document.getElementById("modalSongDetails")),modalAddToPlaylist=new BSN.Modal(document.getElementById("modalAddToPlaylist")),
modalRenamePlaylist=new BSN.Modal(document.getElementById("modalRenamePlaylist")),modalUpdateDB=new BSN.Modal(document.getElementById("modalUpdateDB")),modalSaveSmartPlaylist=new BSN.Modal(document.getElementById("modalSaveSmartPlaylist")),modalDeletePlaylist=new BSN.Modal(document.getElementById("modalDeletePlaylist")),modalSaveBookmark=new BSN.Modal(document.getElementById("modalSaveBookmark")),modalTimer=new BSN.Modal(document.getElementById("modalTimer")),modalMounts=new BSN.Modal(document.getElementById("modalMounts")),
modalExecScript=new BSN.Modal(document.getElementById("modalExecScript")),modalScripts=new BSN.Modal(document.getElementById("modalScripts")),modalPartitions=new BSN.Modal(document.getElementById("modalPartitions")),modalPartitionOutputs=new BSN.Modal(document.getElementById("modalPartitionOutputs")),modalTrigger=new BSN.Modal(document.getElementById("modalTrigger")),modalOutputAttributes=new BSN.Modal(document.getElementById("modalOutputAttributes")),modalPicture=new BSN.Modal(document.getElementById("modalPicture")),
modalEditHomeIcon=new BSN.Modal(document.getElementById("modalEditHomeIcon")),dropdownMainMenu=new BSN.Dropdown(document.getElementById("mainMenu")),dropdownVolumeMenu=new BSN.Dropdown(document.getElementById("volumeMenu")),dropdownBookmarks=new BSN.Dropdown(document.getElementById("BrowseFilesystemBookmark")),dropdownLocalPlayer=new BSN.Dropdown(document.getElementById("localPlaybackMenu")),dropdownPlay=new BSN.Dropdown(document.getElementById("btnPlayDropdown")),dropdownDatabaseSort=new BSN.Dropdown(document.getElementById("btnDatabaseSortDropdown")),
dropdownNeighbors=new BSN.Dropdown(document.getElementById("btnDropdownNeighbors")),collapseDBupdate=new BSN.Collapse(document.getElementById("navDBupdate")),collapseSettings=new BSN.Collapse(document.getElementById("navSettings")),collapseSyscmds=new BSN.Collapse(document.getElementById("navSyscmds")),collapseScripting=new BSN.Collapse(document.getElementById("navScripting")),collapseJukeboxMode=new BSN.Collapse(document.getElementById("labelJukeboxMode"));
function appPrepare(a){if(app.current.app!==app.last.app||app.current.tab!==app.last.tab||app.current.view!==app.last.view){for(var b=0;b<domCache.navbarBtnsLen;b++)domCache.navbarBtns[b].classList.remove("active");document.getElementById("cardHome").classList.add("hide");document.getElementById("cardPlayback").classList.add("hide");document.getElementById("cardQueue").classList.add("hide");document.getElementById("cardBrowse").classList.add("hide");document.getElementById("cardSearch").classList.add("hide");
document.getElementById("cardQueueCurrent").classList.add("hide");document.getElementById("cardQueueLastPlayed").classList.add("hide");document.getElementById("cardBrowsePlaylists").classList.add("hide");document.getElementById("cardBrowseFilesystem").classList.add("hide");document.getElementById("cardBrowseDatabase").classList.add("hide");document.getElementById("card"+app.current.app).classList.remove("hide");document.getElementById("nav"+app.current.app)&&document.getElementById("nav"+app.current.app).classList.add("active");
void 0!==app.current.tab&&document.getElementById("card"+app.current.app+app.current.tab).classList.remove("hide");scrollToPosY(a)}(a=document.getElementById(app.current.app+(void 0===app.current.tab?"":app.current.tab)+(void 0===app.current.view?"":app.current.view)+"List"))&&a.classList.add("opacity05")}
function appGoto(a,b,c,d,f,g,h,k){var l=document.body.scrollTop?document.body.scrollTop:document.documentElement.scrollTop;void 0!==app.apps[app.current.app].scrollPos?app.apps[app.current.app].scrollPos=l:void 0!==app.apps[app.current.app].tabs[app.current.tab].scrollPos?app.apps[app.current.app].tabs[app.current.tab].scrollPos=l:void 0!==app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos&&(app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos=
l);app.apps[a].tabs?(void 0===b&&(b=app.apps[a].active),app.apps[a].tabs[b].views?(void 0===c&&(c=app.apps[a].tabs[b].active),a="/"+encodeURIComponent(a)+"/"+encodeURIComponent(b)+"/"+encodeURIComponent(c)+"!"+encodeURIComponent(void 0===d?app.apps[a].tabs[b].views[c].page:d)+"/"+encodeURIComponent(void 0===f?app.apps[a].tabs[b].views[c].filter:f)+"/"+encodeURIComponent(void 0===g?app.apps[a].tabs[b].views[c].sort:g)+"/"+encodeURIComponent(void 0===h?app.apps[a].tabs[b].views[c].tag:h)+"/"+encodeURIComponent(void 0===
k?app.apps[a].tabs[b].views[c].search:k)):a="/"+encodeURIComponent(a)+"/"+encodeURIComponent(b)+"!"+encodeURIComponent(void 0===d?app.apps[a].tabs[b].page:d)+"/"+encodeURIComponent(void 0===f?app.apps[a].tabs[b].filter:f)+"/"+encodeURIComponent(void 0===g?app.apps[a].tabs[b].sort:g)+"/"+encodeURIComponent(void 0===h?app.apps[a].tabs[b].tag:h)+"/"+encodeURIComponent(void 0===k?app.apps[a].tabs[b].search:k)):a="/"+encodeURIComponent(a)+"!"+encodeURIComponent(void 0===d?app.apps[a].page:d)+"/"+encodeURIComponent(void 0===
f?app.apps[a].filter:f)+"/"+encodeURIComponent(void 0===g?app.apps[a].sort:g)+"/"+encodeURIComponent(void 0===h?app.apps[a].tag:h)+"/"+encodeURIComponent(void 0===k?app.apps[a].search:k);location.hash=a}
function appRoute(){if(!1===settingsParsed)appInitStart();else{var a=location.hash.match(/^#\/(\w+)\/?(\w+)?\/?(\w+)?!(\d+)\/([^/]+)\/([^/]+)\/([^/]+)\/(.*)$/);if(a){app.current.app=decodeURIComponent(a[1]);app.current.tab=void 0!==a[2]?decodeURIComponent(a[2]):void 0;app.current.view=void 0!==a[3]?decodeURIComponent(a[3]):void 0;app.current.page=decodeURIComponent(parseInt(a[4]));app.current.filter=decodeURIComponent(a[5]);app.current.sort=decodeURIComponent(a[6]);app.current.tag=decodeURIComponent(a[7]);
app.current.search=decodeURIComponent(a[8]);void 0!==app.apps[app.current.app].page?(app.apps[app.current.app].page=app.current.page,app.apps[app.current.app].filter=app.current.filter,app.apps[app.current.app].sort=app.current.sort,app.apps[app.current.app].tag=app.current.tag,app.apps[app.current.app].search=app.current.search,app.current.scrollPos=app.apps[app.current.app].scrollPos):void 0!==app.apps[app.current.app].tabs[app.current.tab].page?(app.apps[app.current.app].tabs[app.current.tab].page=
app.current.page,app.apps[app.current.app].tabs[app.current.tab].filter=app.current.filter,app.apps[app.current.app].tabs[app.current.tab].sort=app.current.sort,app.apps[app.current.app].tabs[app.current.tab].tag=app.current.tag,app.apps[app.current.app].tabs[app.current.tab].search=app.current.search,app.apps[app.current.app].active=app.current.tab,app.current.scrollPos=app.apps[app.current.app].tabs[app.current.tab].scrollPos):void 0!==app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].page&&
(app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].page=app.current.page,app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].filter=app.current.filter,app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].sort=app.current.sort,app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].tag=app.current.tag,app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].search=app.current.search,app.apps[app.current.app].active=
app.current.tab,app.apps[app.current.app].tabs[app.current.tab].active=app.current.view,app.current.scrollPos=app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos);appPrepare(app.current.scrollPos);if("Home"===app.current.app)sendAPI("MYMPD_API_HOME_LIST",{},parseHome);else if("Playback"===app.current.app)sendAPI("MPD_API_PLAYER_CURRENT_SONG",{},songChange);else if("Queue"===app.current.app&&"Current"===app.current.tab)selectTag("searchqueuetags","searchqueuetagsdesc",
app.current.filter),getQueue();else if("Queue"===app.current.app&&"LastPlayed"===app.current.tab)sendAPI("MPD_API_QUEUE_LAST_PLAYED",{offset:app.current.page,cols:settings.colsQueueLastPlayed},parseLastPlayed);else if("Browse"===app.current.app&&"Playlists"===app.current.tab&&"All"===app.current.view)sendAPI("MPD_API_PLAYLIST_LIST",{offset:app.current.page,searchstr:app.current.search},parsePlaylists),a=document.getElementById("searchPlaylistsStr"),""===a.value&&""!==app.current.search&&(a.value=
app.current.search);else if("Browse"===app.current.app&&"Playlists"===app.current.tab&&"Detail"===app.current.view)sendAPI("MPD_API_PLAYLIST_CONTENT_LIST",{offset:app.current.page,searchstr:app.current.search,uri:app.current.filter,cols:settings.colsBrowsePlaylistsDetail},parsePlaylists),a=document.getElementById("searchPlaylistsStr"),""===a.value&&""!==app.current.search&&(a.value=app.current.search);else if("Browse"===app.current.app&&"Filesystem"===app.current.tab){sendAPI("MPD_API_DATABASE_FILESYSTEM_LIST",
{offset:app.current.page,path:app.current.search?app.current.search:"/",searchstr:"-"!==app.current.filter?app.current.filter:"",cols:settings.colsBrowseFilesystem},parseFilesystem,!0);app.current.search?(document.getElementById("BrowseFilesystemAddAllSongs").removeAttribute("disabled"),document.getElementById("BrowseFilesystemAddAllSongsBtn").removeAttribute("disabled")):(document.getElementById("BrowseFilesystemAddAllSongs").setAttribute("disabled","disabled"),document.getElementById("BrowseFilesystemAddAllSongsBtn").setAttribute("disabled",
"disabled"));a='<li class="breadcrumb-item"><a data-uri="" class="text-body material-icons">home</a></li>';for(var b=app.current.search.split("/"),c=b.length,d="",f=0;f<c;f++){if(c-1===f){a+='<li class="breadcrumb-item active">'+e(b[f])+"</li>";break}d+=b[f];a+='<li class="breadcrumb-item"><a class="text-body" href="#" data-uri="'+encodeURI(d)+'">'+e(b[f])+"</a></li>";d+="/"}document.getElementById("BrowseBreadcrumb").innerHTML=a;a=document.getElementById("searchFilesystemStr");""===a.value&&"-"!==
app.current.filter&&(a.value=app.current.filter)}else if("Browse"===app.current.app&&"Database"===app.current.tab&&"List"===app.current.view)if(document.getElementById("viewListDatabase").classList.remove("hide"),document.getElementById("viewDetailDatabase").classList.add("hide"),selectTag("searchDatabaseTags","searchDatabaseTagsDesc",app.current.filter),selectTag("BrowseDatabaseByTagDropdown","btnBrowseDatabaseByTagDesc",app.current.tag),a=app.current.sort,b=!1,"-"===app.current.sort.charAt(0)?(b=
!0,a=app.current.sort.substr(1),toggleBtnChk("databaseSortDesc",!0)):toggleBtnChk("databaseSortDesc",!1),selectTag("databaseSortTags",void 0,a),"Album"===app.current.tag){c=document.getElementById("searchDatabaseCrumb");d=document.getElementById("searchDatabaseStr");f="";for(var g=app.current.search.split(" AND "),h=0;h<g.length-1;h++){var k=g[h].substring(1,g[h].length-1);f+='<button data-filter="'+encodeURI(k)+'" class="btn btn-light mr-2">'+e(k)+'<span class="badge badge-secondary">&times</span></button>'}c.innerHTML=
f;""===d.value&&1<=g.length&&(f=g[g.length-1].substring(1,g[g.length-1].length-1),g=f.substring(f.indexOf("'")+1,f.length-1),d.value!==g&&(c.innerHTML+='<button data-filter="'+encodeURI(f)+'" class="btn btn-light mr-2">'+e(f)+'<span class="badge badge-secondary">&times;</span></button>'),document.getElementById("searchDatabaseMatch").value="contains");c.classList.remove("hide");document.getElementById("searchDatabaseMatch").classList.remove("hide");document.getElementById("btnDatabaseSortDropdown").removeAttribute("disabled");
document.getElementById("btnDatabaseSearchDropdown").removeAttribute("disabled");sendAPI("MPD_API_DATABASE_GET_ALBUMS",{offset:app.current.page,searchstr:app.current.search,filter:app.current.filter,sort:a,sortdesc:b},parseDatabase)}else document.getElementById("searchDatabaseCrumb").classList.add("hide"),document.getElementById("searchDatabaseMatch").classList.add("hide"),document.getElementById("btnDatabaseSortDropdown").setAttribute("disabled","disabled"),document.getElementById("btnDatabaseSearchDropdown").setAttribute("disabled",
"disabled"),document.getElementById("searchDatabaseStr").value=app.current.search,sendAPI("MPD_API_DATABASE_TAG_LIST",{offset:app.current.page,searchstr:app.current.search,filter:app.current.filter,sort:a,sortdesc:b,tag:app.current.tag},parseDatabase);else if("Browse"===app.current.app&&"Database"===app.current.tab&&"Detail"===app.current.view)document.getElementById("viewListDatabase").classList.add("hide"),document.getElementById("viewDetailDatabase").classList.remove("hide"),"Album"===app.current.filter&&
(a=settings.colsBrowseDatabaseDetail.slice(),!1===a.includes("Disc")&&a.push("Disc"),sendAPI("MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST",{album:app.current.tag,searchstr:app.current.search,tag:app.current.sort,cols:a},parseAlbumDetails));else if("Search"===app.current.app){domCache.searchstr.focus();if(settings.featAdvsearch){a="";b=app.current.search.substring(1,app.current.search.length-1).split(" AND ");for(c=0;c<b.length-1;c++)d=b[c].substring(1,b[c].length-1),a+='<button data-filter="'+encodeURI(d)+
'" class="btn btn-light mr-2">'+e(d)+'<span class="badge badge-secondary">&times</span></button>';domCache.searchCrumb.innerHTML=a;""===domCache.searchstr.value&&1<=b.length&&(a=b[b.length-1].substring(1,b[b.length-1].length-1),b=a.substring(a.indexOf("'")+1,a.length-1),domCache.searchstr.value!==b&&(domCache.searchCrumb.innerHTML+='<button data-filter="'+encodeURI(a)+'" class="btn btn-light mr-2">'+e(a)+'<span class="ml-2 badge badge-secondary">&times;</span></button>'),a=a.substring(a.indexOf(" ")+
1),a=a.substring(0,a.indexOf(" ")),""===a&&(a="contains"),document.getElementById("searchMatch").value=a)}else""===domCache.searchstr.value&&""!==app.current.search&&(domCache.searchstr.value=app.current.search);app.last.app!==app.current.app&&""!==app.current.search&&(a=settings["cols"+app.current.app].length,a--,document.getElementById("SearchList").getElementsByTagName("tbody")[0].innerHTML='<tr><td><span class="material-icons">search</span></td><td colspan="'+a+'">'+t("Searching...")+"</td></tr>");
2<=domCache.searchstr.value.length||0<domCache.searchCrumb.children.length?settings.featAdvsearch?(a=app.current.sort,b=!1,"-"===a?(a=settings.tags.includes("Title")?"Title":"-",document.getElementById("SearchList").setAttribute("data-sort",a)):0===a.indexOf("-")&&(b=!0,a=a.substring(1)),sendAPI("MPD_API_DATABASE_SEARCH_ADV",{plist:"",offset:app.current.page,sort:a,sortdesc:b,expression:app.current.search,cols:settings.colsSearch,replace:!1},parseSearch)):sendAPI("MPD_API_DATABASE_SEARCH",{plist:"",
offset:app.current.page,filter:app.current.filter,searchstr:app.current.search,cols:settings.colsSearch,replace:!1},parseSearch):(document.getElementById("SearchList").getElementsByTagName("tbody")[0].innerHTML="",document.getElementById("searchAddAllSongs").setAttribute("disabled","disabled"),document.getElementById("searchAddAllSongsBtn").setAttribute("disabled","disabled"),document.getElementById("SearchList").classList.remove("opacity05"),setPagination(0,0));selectTag("searchtags","searchtagsdesc",
app.current.filter)}else appGoto("Home");app.last.app=app.current.app;app.last.tab=app.current.tab;app.last.view=app.current.view}else appPrepare(0),!0===settings.featHome?appGoto("Home"):appGoto("Playback")}}
function showAppInitAlert(a){document.getElementById("splashScreenAlert").innerHTML='<p class="text-danger">'+t(a)+'</p><p><a id="appReloadBtn" class="btn btn-danger text-light clickable">'+t("Reload")+"</a></p>";document.getElementById("appReloadBtn").addEventListener("click",function(){clearAndReload()},!1)}function clearAndReload(){"serviceWorker"in navigator&&caches.keys().then(function(a){a.forEach(function(a){caches.delete(a)})});location.reload()}
function a2hsInit(){window.addEventListener("beforeinstallprompt",function(a){logDebug("Event: beforeinstallprompt");a.preventDefault();deferredA2HSprompt=a;domCache.btnA2HS.classList.remove("hide")});domCache.btnA2HS.addEventListener("click",function(){domCache.btnA2HS.classList.add("hide");deferredA2HSprompt.prompt();deferredA2HSprompt.userChoice.then(function(a){"accepted"===a.outcome?logDebug("User accepted the A2HS prompt"):logDebug("User dismissed the A2HS prompt");deferredA2HSprompt=null})});
window.addEventListener("appinstalled",function(){logInfo("myMPD installed as app");showNotification(t("myMPD installed as app"),"","","success")})}
function appInitStart(){window.addEventListener("hashchange",appRoute,!1);if(!0===isMobile)scale=localStorage.getItem("scale-ratio"),null===scale&&(scale="1.0"),setViewport(!1);else for(var a=document.getElementsByClassName("featMobile"),b=0;b<a.length;b++)a[b].classList.add("hide");subdir=window.location.pathname.replace("/index.html","").replace(/\/$/,"");a='<option value="default" data-phrase="Browser default"></option>';for(b=0;b<locales.length;b++)a+='<option value="'+e(locales[b].code)+'">'+
e(locales[b].desc)+" ("+e(locales[b].code)+")</option>";document.getElementById("selectLocale").innerHTML=a;i18nHtml(document.getElementById("splashScreenAlert"));a=document.getElementsByTagName("script")[0].src.replace(/^.*[/]/,"");"combined.js"!==a&&(settings.loglevel=4);"serviceWorker"in navigator&&"https:"===window.location.protocol&&"localhost"!==window.location.hostname&&"combined.js"===a&&window.addEventListener("load",function(){navigator.serviceWorker.register("/sw.js",{scope:"/"}).then(function(a){logInfo("ServiceWorker registration successful.");
a.update()},function(a){logError("ServiceWorker registration failed: "+a)})});appInited=!1;document.getElementById("splashScreen").classList.remove("hide");document.getElementsByTagName("body")[0].classList.add("overflow-hidden");document.getElementById("splashScreenAlert").innerText=t("Fetch myMPD settings");a2hsInit();getSettings(!0);appInitWait()}
function appInitWait(){setTimeout(function(){if("true"===settingsParsed&&!0===websocketConnected)document.getElementById("splashScreenAlert").innerText=t("Applying settings"),document.getElementById("splashScreen").classList.add("hide-fade"),setTimeout(function(){document.getElementById("splashScreen").classList.add("hide");document.getElementById("splashScreen").classList.remove("hide-fade");document.getElementsByTagName("body")[0].classList.remove("overflow-hidden")},500),appInit(),appInited=!0;
else{if("true"===settingsParsed)document.getElementById("splashScreenAlert").innerText=t("Connect to websocket"),webSocketConnect();else if("error"===settingsParsed)return;appInitWait()}},500)}
function appInit(){document.getElementById("btnChVolumeDown").addEventListener("click",function(a){a.stopPropagation()},!1);document.getElementById("btnChVolumeUp").addEventListener("click",function(a){a.stopPropagation()},!1);domCache.volumeBar.addEventListener("click",function(a){a.stopPropagation()},!1);domCache.volumeBar.addEventListener("change",function(){sendAPI("MPD_API_PLAYER_VOLUME_SET",{volume:domCache.volumeBar.value})},!1);domCache.progress.addEventListener("click",function(a){currentSong&&
0<=currentSong.currentSongId&&0<currentSong.totalTime&&(domCache.progressBar.style.transition="none",domCache.progressBar.style.width=a.clientX+"px",setTimeout(function(){domCache.progressBar.style.transition=progressBarTransition},10),sendAPI("MPD_API_PLAYER_SEEK",{songid:currentSong.currentSongId,seek:Math.ceil(currentSong.totalTime*a.clientX/a.target.offsetWidth)}))},!1);domCache.progress.addEventListener("mousemove",function(a){if(("pause"===playstate||"play"===playstate)&&0<currentSong.totalTime){domCache.progressPos.innerText=
beautifySongDuration(Math.ceil(currentSong.totalTime/a.target.offsetWidth*a.clientX));domCache.progressPos.style.display="block";var b=domCache.progressPos.offsetWidth/2;domCache.progressPos.style.left=(a.clientX<b?a.clientX:a.clientX<window.innerWidth-b?a.clientX-b:a.clientX-2*b)+"px"}},!1);domCache.progress.addEventListener("mouseout",function(){domCache.progressPos.style.display="none"},!1);for(var a=document.querySelectorAll(".subMenu"),b=a.length,c=0;c<b;c++)a[c].addEventListener("click",function(a){a.stopPropagation();
a.preventDefault();a=this.getElementsByTagName("span")[0];a.innerText="keyboard_arrow_right"===a.innerText?"keyboard_arrow_down":"keyboard_arrow_right"},!1);document.getElementById("volumeMenu").parentNode.addEventListener("show.bs.dropdown",function(){sendAPI("MPD_API_PLAYER_OUTPUT_LIST",{},parseOutputs)});document.getElementById("btnDropdownNeighbors").parentNode.addEventListener("show.bs.dropdown",function(){!0===settings.featNeighbors?sendAPI("MPD_API_MOUNT_NEIGHBOR_LIST",{},parseNeighbors,!0):
document.getElementById("dropdownNeighbors").children[0].innerHTML='<div class="list-group-item"><span class="material-icons">warning</span> '+t("Neighbors are disabled")+"</div>"});document.getElementById("dropdownNeighbors").children[0].addEventListener("click",function(a){a.preventDefault();"A"===a.target.nodeName&&(a=a.target.getAttribute("data-value").match(/^(\w+:\/\/)(.+)$/),document.getElementById("selectMountUrlhandler").value=a[1],document.getElementById("inputMountUrl").value=a[2])});document.getElementById("BrowseFilesystemBookmark").parentNode.addEventListener("show.bs.dropdown",
function(){sendAPI("MYMPD_API_BOOKMARK_LIST",{offset:0},parseBookmarks)});document.getElementById("playDropdown").parentNode.addEventListener("show.bs.dropdown",function(){showPlayDropdown()});document.getElementById("playDropdown").addEventListener("click",function(a){a.preventDefault();a.stopPropagation()});a=document.querySelectorAll(".dropdown-toggle");for(b=0;b<a.length;b++)a[b].parentNode.addEventListener("show.bs.dropdown",function(){alignDropdown(this)});document.getElementById("modalTimer").addEventListener("shown.bs.modal",
function(){showListTimer()});document.getElementById("modalMounts").addEventListener("shown.bs.modal",function(){showListMounts()});document.getElementById("modalScripts").addEventListener("shown.bs.modal",function(){showListScripts()});document.getElementById("modalTrigger").addEventListener("shown.bs.modal",function(){showListTrigger()});document.getElementById("modalPartitions").addEventListener("shown.bs.modal",function(){showListPartitions()});document.getElementById("modalPartitionOutputs").addEventListener("shown.bs.modal",
function(){sendAPI("MPD_API_PLAYER_OUTPUT_LIST",{partition:"default"},parsePartitionOutputsList,!1)});document.getElementById("modalAbout").addEventListener("shown.bs.modal",function(){sendAPI("MPD_API_DATABASE_STATS",{},parseStats);getServerinfo();var a="",b;for(b in keymap)if(void 0===keymap[b].req||!0===settings[keymap[b].req])a+='<tr><td><div class="key'+(keymap[b].key&&1<keymap[b].key.length?" material-icons material-icons-small":"")+'">'+(void 0!==keymap[b].key?keymap[b].key:b)+"</div></td><td>"+
t(keymap[b].desc)+"</td></tr>";document.getElementById("tbodyShortcuts").innerHTML=a});document.getElementById("modalAddToPlaylist").addEventListener("shown.bs.modal",function(){document.getElementById("addStreamFrm").classList.contains("hide")?document.getElementById("addToPlaylistPlaylist").focus():(document.getElementById("streamUrl").focus(),document.getElementById("streamUrl").value="")});document.getElementById("inputTimerVolume").addEventListener("change",function(){document.getElementById("textTimerVolume").innerHTML=
this.value+"&nbsp;%"},!1);document.getElementById("selectTimerAction").addEventListener("change",function(){selectTimerActionChange()},!1);document.getElementById("selectTriggerScript").addEventListener("change",function(){selectTriggerActionChange()},!1);a="";for(b=0;24>b;b++)a+='<option value="'+b+'">'+zeroPad(b,2)+"</option>";document.getElementById("selectTimerHour").innerHTML=a;a="";for(b=0;60>b;b+=5)a+='<option value="'+b+'">'+zeroPad(b,2)+"</option>";document.getElementById("selectTimerMinute").innerHTML=
a;document.getElementById("inputHighlightColor").addEventListener("change",function(){document.getElementById("highlightColorPreview").style.backgroundColor=this.value},!1);document.getElementById("inputBgColor").addEventListener("change",function(){document.getElementById("bgColorPreview").style.backgroundColor=this.value},!1);document.getElementById("modalAddToQueue").addEventListener("shown.bs.modal",function(){document.getElementById("inputAddToQueueQuantity").classList.remove("is-invalid");document.getElementById("warnJukeboxPlaylist2").classList.add("hide");
!0===settings.featPlaylists&&sendAPI("MPD_API_PLAYLIST_LIST_ALL",{searchstr:""},function(a){getAllPlaylists(a,"selectAddToQueuePlaylist")})});document.getElementById("modalUpdateDB").addEventListener("hidden.bs.modal",function(){document.getElementById("updateDBprogress").classList.remove("updateDBprogressAnimate")});document.getElementById("modalSaveQueue").addEventListener("shown.bs.modal",function(){var a=document.getElementById("saveQueueName");a.focus();a.value="";a.classList.remove("is-invalid")});
document.getElementById("modalSettings").addEventListener("shown.bs.modal",function(){getSettings();document.getElementById("inputCrossfade").classList.remove("is-invalid");document.getElementById("inputMixrampdb").classList.remove("is-invalid");document.getElementById("inputMixrampdelay").classList.remove("is-invalid");document.getElementById("inputScaleRatio").classList.remove("is-invalid")});document.getElementById("modalConnection").addEventListener("shown.bs.modal",function(){getSettings();document.getElementById("inputMpdHost").classList.remove("is-invalid");
document.getElementById("inputMpdPort").classList.remove("is-invalid");document.getElementById("inputMpdPass").classList.remove("is-invalid")});document.getElementById("btnJukeboxModeGroup").addEventListener("mouseup",function(){setTimeout(function(){var a=document.getElementById("btnJukeboxModeGroup").getElementsByClassName("active")[0].getAttribute("data-value");"0"===a?(document.getElementById("inputJukeboxQueueLength").setAttribute("disabled","disabled"),document.getElementById("selectJukeboxPlaylist").setAttribute("disabled",
"disabled")):"2"===a?(document.getElementById("inputJukeboxQueueLength").setAttribute("disabled","disabled"),document.getElementById("selectJukeboxPlaylist").setAttribute("disabled","disabled"),document.getElementById("selectJukeboxPlaylist").value="Database"):"1"===a&&(document.getElementById("inputJukeboxQueueLength").removeAttribute("disabled"),document.getElementById("selectJukeboxPlaylist").removeAttribute("disabled"));"0"!==a&&toggleBtnChk("btnConsume",!0);checkConsume()},100)});document.getElementById("btnConsume").addEventListener("mouseup",
function(){setTimeout(function(){checkConsume()},100)});document.getElementById("btnStickers").addEventListener("mouseup",function(){setTimeout(function(){document.getElementById("btnStickers").classList.contains("active")?(document.getElementById("warnPlaybackStatistics").classList.add("hide"),document.getElementById("inputJukeboxLastPlayed").removeAttribute("disabled")):(document.getElementById("warnPlaybackStatistics").classList.remove("hide"),document.getElementById("inputJukeboxLastPlayed").setAttribute("disabled",
"disabled"))},100)});document.getElementById("selectAddToQueueMode").addEventListener("change",function(){var a=this.options[this.selectedIndex].value;"2"===a?(document.getElementById("inputAddToQueueQuantity").setAttribute("disabled","disabled"),document.getElementById("inputAddToQueueQuantity").value="1",document.getElementById("selectAddToQueuePlaylist").setAttribute("disabled","disabled"),document.getElementById("selectAddToQueuePlaylist").value="Database"):"1"===a&&(document.getElementById("inputAddToQueueQuantity").removeAttribute("disabled"),
document.getElementById("selectAddToQueuePlaylist").removeAttribute("disabled"))});document.getElementById("addToPlaylistPlaylist").addEventListener("change",function(){"new"===this.options[this.selectedIndex].value?(document.getElementById("addToPlaylistNewPlaylistDiv").classList.remove("hide"),document.getElementById("addToPlaylistNewPlaylist").focus()):document.getElementById("addToPlaylistNewPlaylistDiv").classList.add("hide")},!1);document.getElementById("selectMusicDirectory").addEventListener("change",
function(){"auto"===this.options[this.selectedIndex].value?(document.getElementById("inputMusicDirectory").value=settings.musicDirectoryValue,document.getElementById("inputMusicDirectory").setAttribute("readonly","readonly")):"none"===this.options[this.selectedIndex].value?(document.getElementById("inputMusicDirectory").value="",document.getElementById("inputMusicDirectory").setAttribute("readonly","readonly")):(document.getElementById("inputMusicDirectory").value="",document.getElementById("inputMusicDirectory").removeAttribute("readonly"))},
!1);document.getElementById("syscmds").addEventListener("click",function(a){"A"===a.target.nodeName&&parseCmd(a,a.target.getAttribute("data-href"))},!1);document.getElementById("scripts").addEventListener("click",function(a){"A"===a.target.nodeName&&execScript(a.target.getAttribute("data-href"))},!1);a=document.querySelectorAll("[data-href]");b=a.length;for(c=0;c<b;c++){!1===a[c].classList.contains("notclickable")&&a[c].classList.add("clickable");var d=a[c].parentNode.classList.contains("noInitChilds")?
!0:!1;!1===d&&(d=a[c].parentNode.parentNode.classList.contains("noInitChilds")?!0:!1);!0!==d&&a[c].addEventListener("click",function(a){parseCmd(a,this.getAttribute("data-href"))},!1)}document.getElementById("HomeCards").addEventListener("click",function(a){if(a.target.classList.contains("card-body")){var b=a.target.parentNode.getAttribute("data-href");null!==b&&parseCmd(a,b)}else if(a.target.classList.contains("card-footer")){b=document.getElementById("HomeCards").getElementsByClassName("selected");
for(var c=0;c<b.length;c++)b[c].classList.remove("selected");a.target.parentNode.classList.add("selected");showMenu(a.target,a);a.stopPropagation()}},!1);document.getElementById("HomeCards").addEventListener("keydown",function(a){navigateGrid(a.target,a.key)},!1);dragAndDropHome();document.getElementById("selectHomeIconCmd").addEventListener("change",function(){showHomeIconCmdOptions()},!1);a=document.getElementsByClassName("pages");b=a.length;for(c=0;c<b;c++)a[c].addEventListener("click",function(a){"BUTTON"===
a.target.nodeName&&gotoPage(a.target.getAttribute("data-page"))},!1);document.getElementById("cardPlaybackTags").addEventListener("click",function(a){"P"===a.target.nodeName&&gotoBrowse()},!1);document.getElementById("BrowseBreadcrumb").addEventListener("click",function(a){"A"===a.target.nodeName&&(a.preventDefault(),appGoto("Browse","Filesystem",void 0,"0",app.current.filter,app.current.sort,"-",decodeURI(a.target.getAttribute("data-uri"))))},!1);document.getElementById("tbodySongDetails").addEventListener("click",
function(a){if("A"===a.target.nodeName)if("calcFingerprint"===a.target.id){sendAPI("MPD_API_DATABASE_FINGERPRINT",{uri:decodeURI(a.target.getAttribute("data-uri"))},parseFingerprint);a.preventDefault();var b=a.target.parentNode,c=document.createElement("div");c.classList.add("spinner-border","spinner-border-sm");a.target.classList.add("hide");b.appendChild(c)}else null!==a.target.parentNode.getAttribute("data-tag")&&(modalSongDetails.hide(),a.preventDefault(),gotoBrowse());else"BUTTON"===a.target.nodeName&&
a.target.getAttribute("data-href")&&parseCmd(a,a.target.getAttribute("data-href"))},!1);document.getElementById("outputs").addEventListener("click",function(a){"BUTTON"===a.target.nodeName?(a.stopPropagation(),a.preventDefault(),sendAPI("MPD_API_PLAYER_TOGGLE_OUTPUT",{output:a.target.getAttribute("data-output-id"),state:a.target.classList.contains("active")?0:1}),toggleBtn(a.target.id)):"A"===a.target.nodeName&&(a.preventDefault(),showListOutputAttributes(decodeURI(a.target.parentNode.getAttribute("data-output-name"))))},
!1);document.getElementById("listTimerList").addEventListener("click",function(a){a.stopPropagation();a.preventDefault();"TD"===a.target.nodeName?a.target.parentNode.classList.contains("not-clickable")||showEditTimer(a.target.parentNode.getAttribute("data-id")):"A"===a.target.nodeName?deleteTimer(a.target.parentNode.parentNode.getAttribute("data-id")):"BUTTON"===a.target.nodeName&&toggleTimer(a.target,a.target.parentNode.parentNode.getAttribute("data-id"))},!1);document.getElementById("listMountsList").addEventListener("click",
function(a){a.stopPropagation();a.preventDefault();if("TD"===a.target.nodeName){if(""===a.target.parentNode.getAttribute("data-point"))return!1;showEditMount(decodeURI(a.target.parentNode.getAttribute("data-url")),decodeURI(a.target.parentNode.getAttribute("data-point")))}else if("A"===a.target.nodeName){var b=a.target.getAttribute("data-action"),c=decodeURI(a.target.parentNode.parentNode.getAttribute("data-point"));"unmount"===b?unmountMount(c):"update"===b&&updateMount(a.target,c)}},!1);document.getElementById("listScriptsList").addEventListener("click",
function(a){a.stopPropagation();a.preventDefault();if("TD"===a.target.nodeName){if(!1===settings.featScripteditor||""===a.target.parentNode.getAttribute("data-script"))return!1;showEditScript(decodeURI(a.target.parentNode.getAttribute("data-script")))}else if("A"===a.target.nodeName){var b=a.target.getAttribute("data-action"),c=decodeURI(a.target.parentNode.parentNode.getAttribute("data-script"));"delete"===b?deleteScript(c):"execute"===b?execScript(a.target.getAttribute("data-href")):"add2home"===
b&&addScriptToHome(c,a.target.getAttribute("data-href"))}},!1);document.getElementById("listTriggerList").addEventListener("click",function(a){a.stopPropagation();a.preventDefault();if("TD"===a.target.nodeName){var b=decodeURI(a.target.parentNode.getAttribute("data-trigger-id"));showEditTrigger(b)}else"A"===a.target.nodeName&&(b=a.target.getAttribute("data-action"),a=decodeURI(a.target.parentNode.parentNode.getAttribute("data-trigger-id")),"delete"===b&&deleteTrigger(a))},!1);document.getElementById("listPartitionsList").addEventListener("click",
function(a){a.stopPropagation();a.preventDefault();if("A"===a.target.nodeName){var b=a.target.getAttribute("data-action");a=decodeURI(a.target.parentNode.parentNode.getAttribute("data-partition"));"delete"===b?deletePartition(a):"switch"===b&&switchPartition(a)}},!1);document.getElementById("partitionOutputsList").addEventListener("click",function(a){a.stopPropagation();a.preventDefault();"TD"===a.target.nodeName&&(a=decodeURI(a.target.parentNode.getAttribute("data-output")),moveOutput(a),modalPartitionOutputs.hide())},
!1);document.getElementById("QueueCurrentList").addEventListener("click",function(a){"TD"===a.target.nodeName?sendAPI("MPD_API_PLAYER_PLAY_TRACK",{track:a.target.parentNode.getAttribute("data-trackid")}):"A"===a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("QueueLastPlayedList").addEventListener("click",function(a){"A"===a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("BrowseFilesystemList").addEventListener("click",function(a){if("TD"===a.target.nodeName)switch(a.target.parentNode.getAttribute("data-type")){case "parentDir":case "dir":appGoto("Browse",
"Filesystem",void 0,"0",app.current.filter,app.current.sort,"-",decodeURI(a.target.parentNode.getAttribute("data-uri")));break;case "song":appendQueue("song",decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name"));break;case "plist":appendQueue("plist",decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name"))}else"A"===a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("BrowseFilesystemBookmarks").addEventListener("click",
function(a){if("A"===a.target.nodeName){var b=a.target.parentNode.parentNode.getAttribute("data-id"),c=a.target.parentNode.parentNode.getAttribute("data-type"),d=decodeURI(a.target.parentNode.parentNode.getAttribute("data-uri")),g=a.target.parentNode.parentNode.firstChild.innerText,f=a.target.getAttribute("data-href");"delete"===f?(sendAPI("MYMPD_API_BOOKMARK_RM",{id:b},function(){sendAPI("MYMPD_API_BOOKMARK_LIST",{offset:0},parseBookmarks)}),a.preventDefault(),a.stopPropagation()):"edit"===f?showBookmarkSave(b,
g,d,c):"goto"===f&&appGoto("Browse","Filesystem",void 0,"0","-","-","-",d)}},!1);document.getElementById("BrowsePlaylistsAllList").addEventListener("click",function(a){"TD"===a.target.nodeName?appendQueue("plist",decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name")):"A"===a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("BrowsePlaylistsDetailList").addEventListener("click",function(a){"TD"===a.target.nodeName?appendQueue("plist",
decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name")):"A"===a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("SearchList").addEventListener("click",function(a){"TD"===a.target.nodeName?appendQueue("song",decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name")):"A"===a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("BrowseDatabaseCards").addEventListener("click",function(a){"Album"===
app.current.tag?a.target.classList.contains("card-body")?appGoto("Browse","Database","Detail","0","Album","AlbumArtist",decodeURI(a.target.parentNode.getAttribute("data-album")),decodeURI(a.target.parentNode.getAttribute("data-albumartist"))):a.target.classList.contains("card-footer")&&showMenu(a.target,a):(app.current.search="",document.getElementById("searchDatabaseStr").value="",appGoto(app.current.app,app.current.card,void 0,"0","Album","AlbumArtist","Album","("+app.current.tag+" == '"+decodeURI(a.target.parentNode.getAttribute("data-tag"))+
"')"))},!1);document.getElementById("BrowseDatabaseCards").addEventListener("keydown",function(a){navigateGrid(a.target,a.key)},!1);document.getElementById("BrowseDatabaseDetailList").addEventListener("click",function(a){"TD"===a.target.nodeName?appendQueue("song",decodeURI(a.target.parentNode.getAttribute("data-uri")),a.target.parentNode.getAttribute("data-name")):"A"===a.target.nodeName&&showMenu(a.target,a)},!1);document.getElementById("BrowseFilesystemAddAllSongsDropdown").addEventListener("click",
function(a){"BUTTON"===a.target.nodeName&&("Add all to queue"===a.target.getAttribute("data-phrase")?addAllFromBrowseFilesystem():"Add all to playlist"===a.target.getAttribute("data-phrase")&&showAddToPlaylist(app.current.search,""))},!1);document.getElementById("searchAddAllSongsDropdown").addEventListener("click",function(a){"BUTTON"===a.target.nodeName&&("Add all to queue"===a.target.getAttribute("data-phrase")?addAllFromSearchPlist("queue",null,!1):"Add all to playlist"===a.target.getAttribute("data-phrase")?
showAddToPlaylist("SEARCH",""):"Save as smart playlist"===a.target.getAttribute("data-phrase")&&saveSearchAsSmartPlaylist())},!1);document.getElementById("searchtags").addEventListener("click",function(a){"BUTTON"===a.target.nodeName&&(app.current.filter=a.target.getAttribute("data-tag"),search(domCache.searchstr.value))},!1);document.getElementById("searchDatabaseTags").addEventListener("click",function(a){"BUTTON"===a.target.nodeName&&(app.current.filter=a.target.getAttribute("data-tag"),appGoto(app.current.app,
app.current.tab,app.current.view,"0",app.current.filter,app.current.sort,app.current.tag,app.current.search))},!1);document.getElementById("databaseSortDesc").addEventListener("click",function(a){toggleBtnChk(this);a.stopPropagation();a.preventDefault();"-"===app.current.sort.charAt(0)?app.current.sort=app.current.sort.substr(1):app.current.sort="-"+app.current.sort;appGoto(app.current.app,app.current.tab,app.current.view,"0",app.current.filter,app.current.sort,app.current.tag,app.current.search)},
!1);document.getElementById("databaseSortTags").addEventListener("click",function(a){"BUTTON"===a.target.nodeName&&(a.preventDefault(),a.stopPropagation(),app.current.sort=a.target.getAttribute("data-tag"),appGoto(app.current.app,app.current.tab,app.current.view,"0",app.current.filter,app.current.sort,app.current.tag,app.current.search))},!1);document.getElementById("BrowseDatabaseByTagDropdown").addEventListener("click",function(a){navBrowseHandler(a)},!1);document.getElementById("BrowseNavPlaylistsDropdown").addEventListener("click",
function(a){navBrowseHandler(a)},!1);document.getElementById("BrowseNavFilesystemDropdown").addEventListener("click",function(a){navBrowseHandler(a)},!1);document.getElementById("dropdownSortPlaylistTags").addEventListener("click",function(a){"BUTTON"===a.target.nodeName&&(a.preventDefault(),playlistSort(a.target.getAttribute("data-tag")))},!1);document.getElementById("searchqueuestr").addEventListener("keyup",function(a){"Escape"===a.key?this.blur():appGoto(app.current.app,app.current.tab,app.current.view,
"0",app.current.filter,app.current.sort,"-",this.value)},!1);document.getElementById("searchqueuetags").addEventListener("click",function(a){"BUTTON"===a.target.nodeName&&appGoto(app.current.app,app.current.tab,app.current.view,app.current.page,a.target.getAttribute("data-tag"),app.current.sort,"-",app.current.search)},!1);document.getElementById("searchFilesystemStr").addEventListener("keyup",function(a){"Escape"===a.key?this.blur():appGoto(app.current.app,app.current.tab,app.current.view,"0",""!==
this.value?this.value:"-",app.current.sort,"-",app.current.search)},!1);document.getElementById("searchPlaylistsStr").addEventListener("keyup",function(a){"Escape"===a.key?this.blur():appGoto(app.current.app,app.current.tab,app.current.view,"0",app.current.filter,app.current.sort,"-",this.value)},!1);a=["PlaybackColsDropdown"];for(b=0;b<a.length;b++)document.getElementById(a[b]).addEventListener("click",function(a){"BUTTON"===a.target.nodeName&&a.target.classList.contains("material-icons")&&(a.stopPropagation(),
a.preventDefault(),toggleBtnChk(a.target))},!1);document.getElementById("search").addEventListener("submit",function(){return!1},!1);document.getElementById("searchqueue").addEventListener("submit",function(){return!1},!1);document.getElementById("searchdatabase").addEventListener("submit",function(){return!1},!1);document.getElementById("searchDatabaseStr").addEventListener("keyup",function(a){if("Escape"===a.key)this.blur();else if("Enter"===a.key&&"Album"===app.current.tag)if(""!==this.value){a=
document.getElementById("searchDatabaseMatch");var b=document.createElement("button");b.classList.add("btn","btn-light","mr-2");b.setAttribute("data-filter",encodeURI(app.current.filter+" "+a.options[a.selectedIndex].value+" '"+this.value+"'"));b.innerHTML=e(app.current.filter)+" "+a.options[a.selectedIndex].value+" '"+e(this.value)+'\'<span class="ml-2 badge badge-secondary">&times;</span>';this.value="";document.getElementById("searchDatabaseCrumb").appendChild(b)}else searchAlbumgrid(this.value);
else"Album"===app.current.tag?searchAlbumgrid(this.value):appGoto(app.current.app,app.current.tab,app.current.view,"0",app.current.filter,app.current.sort,app.current.tag,this.value)},!1);document.getElementById("searchDatabaseCrumb").addEventListener("click",function(a){a.preventDefault();a.stopPropagation();if("SPAN"===a.target.nodeName)a.target.parentNode.remove(),searchAlbumgrid("");else if("BUTTON"===a.target.nodeName){var b=decodeURI(a.target.getAttribute("data-filter"));document.getElementById("searchDatabaseStr").value=
b.substring(b.indexOf("'")+1,b.length-1);var c=b.substring(b.indexOf(" ")+1);c=c.substring(0,c.indexOf(" "));document.getElementById("searchDatabaseMatch").value=c;b=b.substring(0,b.indexOf(" "));selectTag("searchDatabaseTags","searchDatabaseTagsDesc",b);a.target.remove();searchAlbumgrid(document.getElementById("searchDatabaseStr").value)}},!1);domCache.searchstr.addEventListener("keyup",function(a){if("Escape"===a.key)this.blur();else if("Enter"===a.key&&settings.featAdvsearch)if(""!==this.value){a=
document.getElementById("searchMatch");var b=document.createElement("button");b.classList.add("btn","btn-light","mr-2");b.setAttribute("data-filter",encodeURI(app.current.filter+" "+a.options[a.selectedIndex].value+" '"+this.value+"'"));b.innerHTML=e(app.current.filter)+" "+e(a.options[a.selectedIndex].value)+" '"+e(this.value)+'\'<span class="ml-2 badge badge-secondary">&times;</span>';this.value="";domCache.searchCrumb.appendChild(b)}else search(this.value);else search(this.value)},!1);domCache.searchCrumb.addEventListener("click",
function(a){a.preventDefault();a.stopPropagation();if("SPAN"===a.target.nodeName)a.target.parentNode.remove(),search("");else if("BUTTON"===a.target.nodeName){var b=decodeURI(a.target.getAttribute("data-filter"));domCache.searchstr.value=b.substring(b.indexOf("'")+1,b.length-1);var c=b.substring(0,b.indexOf(" "));selectTag("searchtags","searchtagsdesc",c);b=b.substring(b.indexOf(" ")+1);b=b.substring(0,b.indexOf(" "));document.getElementById("searchMatch").value=b;a.target.remove();search(domCache.searchstr.value)}},
!1);document.getElementById("searchMatch").addEventListener("change",function(){search(domCache.searchstr.value)},!1);document.getElementById("SearchList").getElementsByTagName("tr")[0].addEventListener("click",function(a){if(settings.featAdvsearch&&"TH"===a.target.nodeName&&""!==a.target.innerHTML){var b=a.target.getAttribute("data-col");if("Duration"!==b){var c=app.current.sort,d=!0;if(c===b||c==="-"+b)0===c.indexOf("-")?(d=!0,b=c.substring(1)):d=!1;!1===d?(c="-"+b,d=!0):(d=!1,c=b);for(var f=document.getElementById("SearchList").getElementsByClassName("sort-dir"),
g=0;g<f.length;g++)f[g].remove();app.current.sort=c;a.target.innerHTML=t(b)+'<span class="sort-dir material-icons pull-right">'+(!0===d?"arrow_drop_up":"arrow_drop_down")+"</span>";appGoto(app.current.app,app.current.tab,app.current.view,app.current.page,app.current.filter,app.current.sort,"-",app.current.search)}}},!1);document.getElementById("inputScriptArgument").addEventListener("keyup",function(a){"Enter"===a.key&&(a.preventDefault(),a.stopPropagation(),addScriptArgument())},!1);document.getElementById("selectScriptArguments").addEventListener("click",
function(a){"OPTION"===a.target.nodeName&&removeScriptArgument(a)},!1);document.getElementsByTagName("body")[0].addEventListener("click",function(){hideMenu()},!1);dragAndDropTable("QueueCurrentList");dragAndDropTable("BrowsePlaylistsDetailList");dragAndDropTableHeader("QueueCurrent");dragAndDropTableHeader("QueueLastPlayed");dragAndDropTableHeader("Search");dragAndDropTableHeader("BrowseFilesystem");dragAndDropTableHeader("BrowsePlaylistsDetail");dragAndDropTableHeader("BrowseDatabaseDetail");window.addEventListener("focus",
function(){sendAPI("MPD_API_PLAYER_STATE",{},parseState)},!1);document.addEventListener("keydown",function(a){if("INPUT"!==a.target.tagName&&"SELECT"!==a.target.tagName&&"TEXTAREA"!==a.target.tagName&&!a.ctrlKey&&!a.altKey){var b=keymap[a.key];b&&"function"===typeof window[b.cmd]&&(void 0===keymap[a.key].req||!0===settings[keymap[a.key].req])&&parseCmd(a,b)}},!1);a=document.getElementsByTagName("table");for(b=0;b<a.length;b++)a[b].setAttribute("tabindex",0),a[b].addEventListener("keydown",function(a){navigateTable(this,
a.key)},!1);var f="";Object.keys(themes).forEach(function(a){f+='<option value="'+e(a)+'">'+t(themes[a])+"</option>"});document.getElementById("selectTheme").innerHTML=f;window.addEventListener("beforeunload",function(){webSocketClose()});document.getElementById("alertLocalPlayback").getElementsByTagName("a")[0].addEventListener("click",function(a){a.stopPropagation();a.preventDefault();clickCheckLocalPlayerState(a)},!1);document.getElementById("errorLocalPlayback").getElementsByTagName("a")[0].addEventListener("click",
function(a){a.stopPropagation();a.preventDefault();clickCheckLocalPlayerState(a)},!1);document.getElementById("localPlayer").addEventListener("click",function(a){a.stopPropagation()});document.getElementById("localPlayer").addEventListener("canplay",function(){logDebug("localPlayer event: canplay");document.getElementById("alertLocalPlayback").classList.add("hide");document.getElementById("errorLocalPlayback").classList.add("hide")});document.getElementById("localPlayer").addEventListener("error",
function(){logError("localPlayer event: error");document.getElementById("errorLocalPlayback").classList.remove("hide")})}window.onerror=function(a,b,c){logError("JavaScript error: "+a+" ("+b+": "+c+")");4<=settings.loglevel&&(!0===appInited?showNotification(t("JavaScript error"),a+" ("+b+": "+c+")","","danger"):showAppInitAlert(t("JavaScript error")+": "+a+" ("+b+": "+c+")"));return!0};appInitStart();
function setStateIcon(){!1===websocketConnected||!1===settings.mpdConnected?(domCache.mainMenu.classList.add("text-light"),domCache.mainMenu.classList.remove("connected")):(domCache.mainMenu.classList.add("connected"),domCache.mainMenu.classList.remove("text-light"))}function toggleAlert(a,b,c){a=document.getElementById(a);!1===b?(a.innerHTML="",a.classList.add("hide")):(a.innerHTML=c,a.classList.remove("hide"))}
function showNotification(a,b,c,d){if(!0===settings.notificationWeb){var f=new Notification(a,{icon:"assets/favicon.ico",body:b});setTimeout(f.close.bind(f),3E3)}if(!0===settings.notificationPage||"danger"===d||"warning"===d){alertTimeout&&clearTimeout(alertTimeout);document.getElementById("alertBox")?f=document.getElementById("alertBox"):(f=document.createElement("div"),f.setAttribute("id","alertBox"),f.classList.add("toast"));var g='<div class="toast-header">';g=("success"===d?g+'<span class="material-icons text-success mr-2">info</span>':
"warning"===d?g+'<span class="material-icons text-warning mr-2">warning</span>':g+'<span class="material-icons text-danger mr-2">error</span>')+('<strong class="mr-auto">'+e(a)+'</strong><button type="button" class="ml-2 mb-1 close">&times;</button></div>');if(""!==c||""!==b)g+='<div class="toast-body">'+(""===c?e(b):c)+"</div>";f.innerHTML=g+"</div>";document.getElementById("alertBox")||(document.getElementsByTagName("main")[0].append(f),requestAnimationFrame(function(){var a=document.getElementById("alertBox");
a&&a.classList.add("alertBoxActive")}));f.getElementsByTagName("button")[0].addEventListener("click",function(){hideNotification()},!1);alertTimeout=setTimeout(function(){hideNotification()},3E3)}setStateIcon();logMessage(a,b,c,d)}
function logMessage(a,b,c,d){"success"===d?d="Info":"warning"===d?d="Warning":"danger"===d&&(d="Error");var f=document.getElementById("logOverview"),g=!0,h=f.firstElementChild;h&&h.getAttribute("data-title")===a&&(g=!1);var k=document.createElement("div");k.classList.add("text-light");k.setAttribute("data-title",a);var l=1;!1===g&&(l+=parseInt(h.getAttribute("data-occurence")));k.setAttribute("data-occurence",l);k.innerHTML="<small>"+localeDate()+"&nbsp;&ndash;&nbsp;"+t(d)+(1<l?"&nbsp;("+l+")":"")+
"</small><p>"+e(a)+(""===c&&""===b?"":"<br/>"+(""===c?e(b):c))+"</p>";!0===g?f.insertBefore(k,f.firstElementChild):f.replaceChild(k,h);a=f.getElementsByTagName("div");10<a.length&&a[10].remove()}function clearLogOverview(){for(var a=document.getElementById("logOverview").getElementsByTagName("div"),b=a.length-1;0<=b;b--)a[b].remove();setStateIcon()}
function hideNotification(){alertTimeout&&clearTimeout(alertTimeout);document.getElementById("alertBox")&&(document.getElementById("alertBox").classList.remove("alertBoxActive"),setTimeout(function(){var a=document.getElementById("alertBox");a&&a.remove()},750))}function notificationsSupported(){return"Notification"in window}
function setElsState(a,b,c){a="tag"===c?document.getElementsByTagName(a):document.getElementsByClassName(a);c=a.length;for(var d=0;d<c;d++)a[d].classList.contains("close")||("disabled"===b?!1===a[d].classList.contains("alwaysEnabled")&&null===a[d].getAttribute("disabled")&&(a[d].setAttribute("disabled","disabled"),a[d].classList.add("disabled")):a[d].classList.contains("disabled")&&(a[d].removeAttribute("disabled"),a[d].classList.remove("disabled")))}
function toggleUI(){var a="disabled",b=document.getElementById("top-alerts");if(!0===websocketConnected&&!0===settings.mpdConnected)b.classList.add("hide"),a="enabled";else{var c=0;window.innerWidth<window.innerHeight&&(c=domCache.header.offsetHeight);b.style.paddingTop=c+"px";b.classList.remove("hide")}b="disabled"===a?!1:!0;b!==uiEnabled&&(logDebug("Setting ui state to "+a),setElsState("a",a,"tag"),setElsState("input",a,"tag"),setElsState("button",a,"tag"),setElsState("clickable",a,"class"),uiEnabled=
b);!0===settings.mpdConnected?toggleAlert("alertMpdState",!1,""):(toggleAlert("alertMpdState",!0,t("MPD disconnected")),logMessage(t("MPD disconnected"),"","","danger"));!0===websocketConnected?toggleAlert("alertMympdState",!1,""):(toggleAlert("alertMympdState",!0,t("Websocket is disconnected")),logMessage(t("Websocket is disconnected"),"","","danger"));setStateIcon()}function moveOutput(a){sendAPI("MPD_API_PARTITION_OUTPUT_MOVE",{name:a})}
function parsePartitionOutputsList(a){for(var b=document.getElementById("outputs").getElementsByTagName("button"),c=[],d=0;d<b.length;d++)c.push(parseInt(b[d].getAttribute("data-output-id")));b="";for(var f=d=0;f<a.result.data.length;f++)!1===c.includes(a.result.data[f].id)&&(b+='<tr data-output="'+encodeURI(a.result.data[f].name)+'"><td>'+e(a.result.data[f].name)+"</td></tr>",d++);0===d&&(b='<tr class="not-clickable"><td><span class="material-icons">error_outline</span>&nbsp;'+t("Empty list")+"</td></tr>");
document.getElementById("partitionOutputsList").innerHTML=b}function savePartition(){var a=!0,b=document.getElementById("inputPartitionName");validatePlnameEl(b)||(a=!1);!0===a&&sendAPI("MPD_API_PARTITION_NEW",{name:b.value},showListPartitions,!1)}
function showNewPartition(){document.getElementById("listPartitions").classList.remove("active");document.getElementById("newPartition").classList.add("active");document.getElementById("listPartitionsFooter").classList.add("hide");document.getElementById("newPartitionFooter").classList.remove("hide");var a=document.getElementById("inputPartitionName");a.classList.remove("is-invalid");a.value="";a.focus()}
function showListPartitions(){document.getElementById("listPartitions").classList.add("active");document.getElementById("newPartition").classList.remove("active");document.getElementById("listPartitionsFooter").classList.remove("hide");document.getElementById("newPartitionFooter").classList.add("hide");document.getElementById("errorPartition").classList.add("hide");sendAPI("MPD_API_PARTITION_LIST",{},parsePartitionList,!1)}
function deletePartition(a){sendAPI("MPD_API_PARTITION_RM",{name:a},function(a){if(a.error){var b=document.getElementById("errorPartition");b.innerText=t(a.error.message);b.classList.remove("hide")}sendAPI("MPD_API_PARTITION_LIST",{},parsePartitionList,!1)},!0)}
function switchPartition(a){sendAPI("MPD_API_PARTITION_SWITCH",{name:a},function(a){if(a.error){var b=document.getElementById("errorPartition");b.innerText=t(a.error.message);b.classList.remove("hide")}sendAPI("MPD_API_PARTITION_LIST",{},parsePartitionList,!1);sendAPI("MPD_API_PLAYER_STATE",{},parseState)},!0)}
function parsePartitionList(a){if(0<a.result.data.length){for(var b="",c=0;c<a.result.data.length;c++)b+='<tr data-partition="'+encodeURI(a.result.data[c].name)+'"><td class="'+(a.result.data[c].name===settings.partition?"font-weight-bold":"")+'">'+e(a.result.data[c].name)+(a.result.data[c].name===settings.partition?"&nbsp;("+t("current")+")":"")+'</td><td data-col="Action">'+("default"===a.result.data[c].name||a.result.data[c].name===settings.partition?"":'<a href="#" title="'+t("Delete")+'" data-action="delete" class="material-icons color-darkgrey">delete</a>')+
(a.result.data[c].name!==settings.partition?'<a href="#" title="'+t("Switch to")+'" data-action="switch" class="material-icons color-darkgrey">check_circle</a>':"")+"</td></tr>";document.getElementById("listPartitionsList").innerHTML=b}else document.getElementById("listPartitionsList").innerHTML='<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td><td colspan="2">'+t("Empty list")+"</td></tr>"}
function parsePlaylists(a){"All"===app.current.view?(document.getElementById("BrowsePlaylistsAllList").classList.remove("hide"),document.getElementById("BrowsePlaylistsDetailList").classList.add("hide"),document.getElementById("btnBrowsePlaylistsAll").parentNode.classList.add("hide"),document.getElementById("playlistContentBtns").classList.add("hide"),document.getElementById("smartPlaylistContentBtns").classList.add("hide"),document.getElementById("btnAddSmartpls").parentNode.classList.remove("hide"),
document.getElementById("BrowseNavPlaylists").parentNode.classList.remove("hide")):(-1<a.result.uri.indexOf(".")||!0===a.result.smartpls?(document.getElementById("BrowsePlaylistsDetailList").setAttribute("data-ro","true"),document.getElementById("playlistContentBtns").classList.add("hide"),document.getElementById("smartPlaylistContentBtns").classList.remove("hide")):(document.getElementById("BrowsePlaylistsDetailList").setAttribute("data-ro","false"),document.getElementById("playlistContentBtns").classList.remove("hide"),
document.getElementById("smartPlaylistContentBtns").classList.add("hide")),document.getElementById("BrowsePlaylistsDetailList").setAttribute("data-uri",a.result.uri),document.getElementById("BrowsePlaylistsDetailList").getElementsByTagName("caption")[0].innerHTML=(!0===a.result.smartpls?t("Smart playlist"):t("Playlist"))+": "+a.result.uri,document.getElementById("BrowsePlaylistsDetailList").classList.remove("hide"),document.getElementById("BrowsePlaylistsAllList").classList.add("hide"),document.getElementById("btnBrowsePlaylistsAll").parentNode.classList.remove("hide"),
document.getElementById("btnAddSmartpls").parentNode.classList.add("hide"),document.getElementById("BrowseNavPlaylists").parentNode.classList.add("hide"));var b=a.result.returnedEntities,c=document.getElementById(app.current.app+app.current.tab+app.current.view+"List"),d=c.getElementsByTagName("tbody")[0],f=d.getElementsByTagName("tr");c=document.activeElement.parentNode.parentNode===c?!0:!1;var g=0;if("All"===app.current.view)for(var h=0;h<b;h++){var k=encodeURI(a.result.data[h].uri),l=document.createElement("tr");
l.setAttribute("data-uri",k);l.setAttribute("data-type",a.result.data[h].Type);l.setAttribute("data-name",a.result.data[h].name);l.setAttribute("tabindex",0);l.innerHTML='<td data-col="Type"><span class="material-icons">'+("smartpls"===a.result.data[h].Type?"queue_music":"list")+"</span></td><td>"+e(a.result.data[h].name)+"</td><td>"+localeDate(a.result.data[h].last_modified)+'</td><td data-col="Action"><a href="#" class="material-icons color-darkgrey">'+ligatureMore+"</a></td>";h<f.length?g=!0===
replaceTblRow(f[h],l)?h:g:d.append(l)}else if("Detail"===app.current.view)for(h=0;h<b;h++){l=encodeURI(a.result.data[h].uri);k=document.createElement("tr");!1===a.result.smartpls&&k.setAttribute("draggable","true");k.setAttribute("id","playlistTrackId"+a.result.data[h].Pos);k.setAttribute("data-type",a.result.data[h].Type);k.setAttribute("data-uri",l);k.setAttribute("data-name",a.result.data[h].Title);k.setAttribute("data-songpos",a.result.data[h].Pos);k.setAttribute("tabindex",0);a.result.data[h].Duration=
beautifySongDuration(a.result.data[h].Duration);l="";for(var m=0;m<settings.colsBrowsePlaylistsDetail.length;m++)l+='<td data-col="'+settings.colsBrowsePlaylistsDetail[m]+'">'+e(a.result.data[h][settings.colsBrowsePlaylistsDetail[m]])+"</td>";l+='<td data-col="Action"><a href="#" class="material-icons color-darkgrey">'+ligatureMore+"</a></td>";k.innerHTML=l;h<f.length?g=!0===replaceTblRow(f[h],k)?h:g:d.append(k)}for(g=f.length-1;g>=b;g--)f[g].remove();!0===c&&focusTable(0);setPagination(a.result.totalEntities,
a.result.returnedEntities);0===b&&(d.innerHTML="All"===app.current.view?'<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td><td colspan="3">'+t("No playlists found")+"</td></tr>":'<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td><td colspan="'+settings.colsBrowsePlaylistsDetail.length+'">'+t("Empty playlist")+"</td></tr>");document.getElementById(app.current.app+app.current.tab+app.current.view+"List").classList.remove("opacity05")}
function playlistDetails(a){document.getElementById("BrowsePlaylistsAllList").classList.add("opacity05");appGoto("Browse","Playlists","Detail","0",a,"-","-","")}function playlistClear(){var a=document.getElementById("BrowsePlaylistsDetailList").getAttribute("data-uri");sendAPI("MPD_API_PLAYLIST_CLEAR",{uri:a});document.getElementById("BrowsePlaylistsDetailList").classList.add("opacity05")}
function playlistShuffle(){var a=document.getElementById("BrowsePlaylistsDetailList").getAttribute("data-uri");sendAPI("MPD_API_PLAYLIST_SHUFFLE",{uri:a});document.getElementById("BrowsePlaylistsDetailList").classList.add("opacity05")}function playlistSort(a){var b=document.getElementById("BrowsePlaylistsDetailList").getAttribute("data-uri");sendAPI("MPD_API_PLAYLIST_SORT",{uri:b,tag:a});document.getElementById("BrowsePlaylistsDetailList").classList.add("opacity05")}
function getAllPlaylists(a,b,c){var d=a.result.returnedEntities,f="";if("addToPlaylistPlaylist"===b)f='<option value=""></option><option value="new">'+t("New playlist")+"</option>";else if("selectJukeboxPlaylist"===b||"selectAddToQueuePlaylist"===b||"selectTimerPlaylist"===b)f='<option value="Database">'+t("Database")+"</option>";for(var g=0;g<d;g++)if("addToPlaylistPlaylist"!==b||"smartpls"!==a.result.data[g].Type)f+='<option value="'+e(a.result.data[g].uri)+'"',null!==c&&a.result.data[g].uri===
c&&(f+=" selected"),f+=">"+e(a.result.data[g].uri)+"</option>";document.getElementById(b).innerHTML=f}function updateSmartPlaylists(a){sendAPI("MPDWORKER_API_SMARTPLS_UPDATE_ALL",{force:a})}function removeFromPlaylist(a,b){b--;sendAPI("MPD_API_PLAYLIST_RM_TRACK",{uri:a,track:b});document.getElementById("BrowsePlaylistsDetailList").classList.add("opacity05")}
function toggleAddToPlaylistFrm(){var a=document.getElementById("toggleAddToPlaylistBtn");toggleBtn("toggleAddToPlaylistBtn");a.classList.contains("active")?(document.getElementById("addToPlaylistFrm").classList.remove("hide"),document.getElementById("addStreamFooter").classList.add("hide"),document.getElementById("addToPlaylistFooter").classList.remove("hide")):(document.getElementById("addToPlaylistFrm").classList.add("hide"),document.getElementById("addStreamFooter").classList.remove("hide"),document.getElementById("addToPlaylistFooter").classList.add("hide"))}
function parseSmartPlaylist(a){var b=document.getElementById("saveSmartPlaylistName");b.value=a.result.playlist;b.classList.remove("is-invalid");document.getElementById("saveSmartPlaylistType").value=t(a.result.type);document.getElementById("saveSmartPlaylistType").setAttribute("data-value",a.result.type);document.getElementById("saveSmartPlaylistSearch").classList.add("hide");document.getElementById("saveSmartPlaylistSticker").classList.add("hide");document.getElementById("saveSmartPlaylistNewest").classList.add("hide");
var c;settings.featTags&&(c='<option value="any">'+t("Any Tag")+"</option>");c+='<option value="filename">'+t("Filename")+"</option>";for(var d=0;d<settings.searchtags.length;d++)c+='<option value="'+settings.searchtags[d]+'">'+t(settings.searchtags[d])+"</option>";d=document.getElementById("selectSaveSmartPlaylistTag");d.innerHTML=c;"search"===a.result.type?(document.getElementById("saveSmartPlaylistSearch").classList.remove("hide"),document.getElementById("selectSaveSmartPlaylistTag").value=a.result.tag,
document.getElementById("inputSaveSmartPlaylistSearchstr").value=a.result.searchstr,!0===settings.featAdvsearch&&"expression"===a.result.tag?(d.parentNode.parentNode.classList.add("hide"),d.innerHTML='<option value="expression">expression</option>',d.value="expression"):document.getElementById("selectSaveSmartPlaylistTag").parentNode.parentNode.classList.remove("hide")):"sticker"===a.result.type?(document.getElementById("saveSmartPlaylistSticker").classList.remove("hide"),document.getElementById("selectSaveSmartPlaylistSticker").value=
a.result.sticker,document.getElementById("inputSaveSmartPlaylistStickerMaxentries").value=a.result.maxentries,document.getElementById("inputSaveSmartPlaylistStickerMinvalue").value=a.result.minvalue):"newest"===a.result.type&&(document.getElementById("saveSmartPlaylistNewest").classList.remove("hide"),a=a.result.timerange/24/60/60,document.getElementById("inputSaveSmartPlaylistNewestTimerange").value=a);modalSaveSmartPlaylist.show();b.focus()}
function saveSmartPlaylist(){var a=document.getElementById("saveSmartPlaylistName").value,b=document.getElementById("saveSmartPlaylistType").getAttribute("data-value"),c=document.getElementById("saveSmartPlaylistSort");c=c.options[c.selectedIndex].value;if(!0===validatePlname(a)){if("search"===b){var d=document.getElementById("selectSaveSmartPlaylistTag");d=d.options[d.selectedIndex].value;var f=document.getElementById("inputSaveSmartPlaylistSearchstr").value;sendAPI("MPD_API_SMARTPLS_SAVE",{type:b,
playlist:a,tag:d,searchstr:f,sort:c})}else if("sticker"===b){d=document.getElementById("selectSaveSmartPlaylistSticker");d=d.options[d.selectedIndex].value;f=document.getElementById("inputSaveSmartPlaylistStickerMaxentries");if(!validateInt(f))return;var g=document.getElementById("inputSaveSmartPlaylistStickerMinvalue");if(!validateInt(g))return;sendAPI("MPD_API_SMARTPLS_SAVE",{type:b,playlist:a,sticker:d,maxentries:parseInt(f.value),minvalue:parseInt(g.value),sort:c})}else if("newest"===b){d=document.getElementById("inputSaveSmartPlaylistNewestTimerange");
if(!validateInt(d))return;d=86400*parseInt(d.value);sendAPI("MPD_API_SMARTPLS_SAVE",{type:b,playlist:a,timerange:d,sort:c})}else{document.getElementById("saveSmartPlaylistType").classList.add("is-invalid");return}modalSaveSmartPlaylist.hide();showNotification(t("Saved smart playlist %{name}",{name:a}),"","","success")}else document.getElementById("saveSmartPlaylistName").classList.add("is-invalid")}
function addSmartpls(a){var b={jsonrpc:"2.0",id:0,result:{method:"MPD_API_SMARTPLS_GET"}};"mostPlayed"===a?(b.result.playlist=settings.smartplsPrefix+(""!==settings.smartplsPrefix?"-":"")+"mostPlayed",b.result.type="sticker",b.result.sticker="playCount",b.result.maxentries=200,b.result.minvalue=10):"newest"===a?(b.result.playlist=settings.smartplsPrefix+(""!==settings.smartplsPrefix?"-":"")+"newestSongs",b.result.type="newest",b.result.timerange=1209600):"bestRated"===a&&(b.result.playlist=settings.smartplsPrefix+
(""!==settings.smartplsPrefix?"-":"")+"bestRated",b.result.type="sticker",b.result.sticker="like",b.result.maxentries=200,b.result.minvalue=2);parseSmartPlaylist(b)}function deletePlaylists(){var a=document.getElementById("selectDeletePlaylists"),b=document.getElementById("btnDeletePlaylists");btnWaiting(b,!0);sendAPI("MPD_API_PLAYLIST_RM_ALL",{type:a.options[a.selectedIndex].value},function(){btnWaiting(b,!1)})}
function showAddToPlaylistCurrentSong(){var a=document.getElementById("currentTitle").getAttribute("data-uri");""!==a&&showAddToPlaylist(a,"")}
function showAddToPlaylist(a,b){document.getElementById("addToPlaylistUri").value=a;document.getElementById("addToPlaylistSearch").value=b;document.getElementById("addToPlaylistPlaylist").innerHTML="";document.getElementById("addToPlaylistNewPlaylist").value="";document.getElementById("addToPlaylistNewPlaylistDiv").classList.add("hide");document.getElementById("addToPlaylistNewPlaylist").classList.remove("is-invalid");toggleBtn("toggleAddToPlaylistBtn",0);b=document.getElementById("streamUrl");b.focus();
b.value="";b.classList.remove("is-invalid");"stream"!==a?(document.getElementById("addStreamFooter").classList.add("hide"),document.getElementById("addStreamFrm").classList.add("hide"),document.getElementById("addToPlaylistFooter").classList.remove("hide"),document.getElementById("addToPlaylistFrm").classList.remove("hide"),document.getElementById("addToPlaylistCaption").innerText=t("Add to playlist")):(document.getElementById("addStreamFooter").classList.remove("hide"),document.getElementById("addStreamFrm").classList.remove("hide"),
document.getElementById("addToPlaylistFooter").classList.add("hide"),document.getElementById("addToPlaylistFrm").classList.add("hide"),document.getElementById("addToPlaylistCaption").innerText=t("Add stream"));modalAddToPlaylist.show();settings.featPlaylists&&sendAPI("MPD_API_PLAYLIST_LIST_ALL",{searchstr:""},function(a){getAllPlaylists(a,"addToPlaylistPlaylist")})}
function addToPlaylist(){var a=decodeURI(document.getElementById("addToPlaylistUri").value);if("stream"===a&&(a=document.getElementById("streamUrl").value,""===a||-1===a.indexOf("http"))){document.getElementById("streamUrl").classList.add("is-invalid");return}var b=document.getElementById("addToPlaylistPlaylist");b=b.options[b.selectedIndex].value;if("new"===b&&(b=document.getElementById("addToPlaylistNewPlaylist").value,!0!==validatePlname(b))){document.getElementById("addToPlaylistNewPlaylist").classList.add("is-invalid");
return}""!==b?("SEARCH"===a&&addAllFromSearchPlist(b,null,!1),"ALBUM"===a?(a=document.getElementById("addToPlaylistSearch").value,addAllFromSearchPlist(b,a,!1)):"DATABASE"===a?addAllFromBrowseDatabasePlist(b):sendAPI("MPD_API_PLAYLIST_ADD_TRACK",{uri:a,plist:b}),modalAddToPlaylist.hide()):document.getElementById("addToPlaylistPlaylist").classList.add("is-invalid")}
function showRenamePlaylist(a){document.getElementById("renamePlaylistTo").classList.remove("is-invalid");modalRenamePlaylist.show();document.getElementById("renamePlaylistFrom").value=a;document.getElementById("renamePlaylistTo").value=""}
function renamePlaylist(){var a=document.getElementById("renamePlaylistFrom").value,b=document.getElementById("renamePlaylistTo").value;b!==a&&!0===validatePlname(b)?(sendAPI("MPD_API_PLAYLIST_RENAME",{from:a,to:b}),modalRenamePlaylist.hide()):document.getElementById("renamePlaylistTo").classList.add("is-invalid")}function showSmartPlaylist(a){sendAPI("MPD_API_SMARTPLS_GET",{playlist:a},parseSmartPlaylist)}function updateSmartPlaylist(a){sendAPI("MPDWORKER_API_SMARTPLS_UPDATE",{playlist:a})}
function updateSmartPlaylistClick(){var a=document.getElementById("BrowsePlaylistsDetailList").getAttribute("data-uri");sendAPI("MPDWORKER_API_SMARTPLS_UPDATE",{playlist:a});document.getElementById("BrowsePlaylistsDetailList").classList.add("opacity05")}function showDelPlaylist(a){document.getElementById("deletePlaylist").value=a;modalDeletePlaylist.show()}
function delPlaylist(){var a=document.getElementById("deletePlaylist").value;sendAPI("MPD_API_PLAYLIST_RM",{uri:a});modalDeletePlaylist.hide()}function playlistMoveTrack(a,b){sendAPI("MPD_API_PLAYLIST_MOVE_TRACK",{plist:app.current.search,from:a,to:b})}function addSelectedItemToPlaylist(){var a=document.activeElement;a&&"BrowsePlaylistsAllList"!==a.parentNode.parentNode.id&&showAddToPlaylist(a.getAttribute("data-uri"),"")}
function b64EncodeUnicode(a){return btoa(encodeURIComponent(a).replace(/%([0-9A-F]{2})/g,function(a,c){return String.fromCharCode("0x"+c)}))}function b64DecodeUnicode(a){return decodeURIComponent(atob(a).split("").map(function(a){return"%"+("00"+a.charCodeAt(0).toString(16)).slice(-2)}).join(""))}function addMenuItem(a,b){return'<a class="dropdown-item" href="#" data-href=\''+b64EncodeUnicode(JSON.stringify(a))+"'>"+b+"</a>"}
function hideMenu(){var a=document.querySelector("[data-popover]");a&&((new BSN.Popover(a,{})).hide(),a.removeAttribute("data-popover"),a.parentNode.parentNode.classList.contains("selected")?focusTable(void 0,a.parentNode.parentNode.parentNode.parentNode):"Browse"===app.current.app&&"Database"===app.current.tab?focusTable(void 0,a.parentNode.parentNode.parentNode.parentNode):"Home"===app.current.app&&focusTable(void 0,a.parentNode.parentNode.parentNode.parentNode))}
function showMenu(a,b){b.preventDefault();b.stopPropagation();hideMenu();"TH"===a.parentNode.nodeName?showMenuTh(a):showMenuTd(a)}
function showMenuTh(a){var b=app.current.app+(void 0!==app.current.tab?app.current.tab:"")+(void 0!==app.current.view?app.current.view:"");var c='<form class="p-2" id="colChecklist'+b+'">'+setColsChecklist(b);c+='<button class="btn btn-success btn-block btn-sm mt-2">'+t("Apply")+"</button>";new BSN.Popover(a,{trigger:"click",delay:0,dismissible:!0,template:'<div class="popover" role="tooltip"><div class="arrow"></div><div class="popover-content" id="'+b+'ColsDropdown">'+(c+"</form>")+"</div></div>",
content:" "});c=a.Popover;null===a.getAttribute("data-init")&&(a.setAttribute("data-init","true"),a.addEventListener("shown.bs.popover",function(a){a.target.setAttribute("data-popover","true");document.getElementById("colChecklist"+b).addEventListener("click",function(a){"BUTTON"===a.target.nodeName&&a.target.classList.contains("material-icons")?(toggleBtnChk(a.target),a.preventDefault(),a.stopPropagation()):"BUTTON"===a.target.nodeName&&(a.preventDefault(),saveCols(b))},!1)},!1));c.show()}
function showMenuTd(a){var b=a.getAttribute("data-type"),c=decodeURI(a.getAttribute("data-uri")),d=decodeURI(a.getAttribute("data-name")),f=0;if(null===b||""===c)b=a.parentNode.getAttribute("data-type"),c=decodeURI(a.parentNode.getAttribute("data-uri")),d=a.parentNode.getAttribute("data-name");if(null===b||""===c)b=a.parentNode.parentNode.getAttribute("data-type"),c=decodeURI(a.parentNode.parentNode.getAttribute("data-uri")),d=a.parentNode.parentNode.getAttribute("data-name");lastState&&(f=lastState.nextSongPos);
var g="";"Browse"===app.current.app&&"Filesystem"===app.current.tab||"Search"===app.current.app||"Browse"===app.current.app&&"Database"===app.current.tab?(g+=addMenuItem({cmd:"appendQueue",options:[b,c,d]},t("Append to queue"))+("song"===b?addMenuItem({cmd:"appendAfterQueue",options:[b,c,f,d]},t("Add after current playing song")):"")+addMenuItem({cmd:"replaceQueue",options:[b,c,d]},t("Replace queue"))+("plist"!==b&&"smartpls"!==b&&settings.featPlaylists?addMenuItem({cmd:"showAddToPlaylist",options:[c,
""]},t("Add to playlist")):"")+("song"===b?addMenuItem({cmd:"songDetails",options:[c]},t("Song details")):"")+("plist"===b||"smartpls"===b?addMenuItem({cmd:"playlistDetails",options:[c]},t("View playlist")):"")+("plist"!==b&&"smartpls"!==b||!0!==settings.featHome?"":addMenuItem({cmd:"addPlistToHome",options:[c,d]},t("Add to homescreen")))+("dir"===b&&settings.featBookmarks?addMenuItem({cmd:"showBookmarkSave",options:[-1,d,c,b]},t("Add bookmark")):""),"Filesystem"===app.current.tab&&(g+=("dir"===b?
addMenuItem({cmd:"updateDB",options:[dirname(c),!0]},t("Update directory")):"")+("dir"===b?addMenuItem({cmd:"rescanDB",options:[dirname(c),!0]},t("Rescan directory")):"")),"Search"===app.current.app&&(c=dirname(c),g+='<div class="dropdown-divider"></div><a class="dropdown-item" id="advancedMenuLink" data-toggle="collapse" href="#advancedMenu"><span class="material-icons material-icons-small-left">keyboard_arrow_right</span>Album actions</a><div class="collapse" id="advancedMenu">'+addMenuItem({cmd:"appendQueue",
options:[b,c,d]},t("Append to queue"))+addMenuItem({cmd:"appendAfterQueue",options:[b,c,f,d]},t("Add after current playing song"))+addMenuItem({cmd:"replaceQueue",options:[b,c,d]},t("Replace queue"))+(settings.featPlaylists?addMenuItem({cmd:"showAddToPlaylist",options:[c,""]},t("Add to playlist")):"")+"</div>")):"Browse"===app.current.app&&"Playlists"===app.current.tab&&"All"===app.current.view?g+=addMenuItem({cmd:"appendQueue",options:[b,c,d]},t("Append to queue"))+addMenuItem({cmd:"replaceQueue",
options:[b,c,d]},t("Replace queue"))+(!0===settings.smartpls&&"smartpls"===b?addMenuItem({cmd:"playlistDetails",options:[c]},t("View playlist")):addMenuItem({cmd:"playlistDetails",options:[c]},t("Edit playlist")))+(!0===settings.smartpls&&"smartpls"===b?addMenuItem({cmd:"showSmartPlaylist",options:[c]},t("Edit smart playlist")):"")+(!0===settings.smartpls&&"smartpls"===b?addMenuItem({cmd:"updateSmartPlaylist",options:[c]},t("Update smart playlist")):"")+addMenuItem({cmd:"showRenamePlaylist",options:[c]},
t("Rename playlist"))+addMenuItem({cmd:"showDelPlaylist",options:[c]},t("Delete playlist"))+(!0===settings.featHome?addMenuItem({cmd:"addPlistToHome",options:[c,d]},t("Add to homescreen")):""):"Browse"===app.current.app&&"Playlists"===app.current.tab&&"Detail"===app.current.view?(f=document.getElementById("BrowsePlaylistsDetailList"),g+=addMenuItem({cmd:"appendQueue",options:[b,c,d]},t("Append to queue"))+addMenuItem({cmd:"replaceQueue",options:[b,c,d]},t("Replace queue"))+("false"===f.getAttribute("data-ro")?
addMenuItem({cmd:"removeFromPlaylist",options:[f.getAttribute("data-uri"),a.parentNode.parentNode.getAttribute("data-songpos")]},t("Remove")):"")+(settings.featPlaylists?addMenuItem({cmd:"showAddToPlaylist",options:[c,""]},t("Add to playlist")):"")+(-1===c.indexOf("http")?addMenuItem({cmd:"songDetails",options:[c]},t("Song details")):"")):"Queue"===app.current.app&&"Current"===app.current.tab?g+=addMenuItem({cmd:"delQueueSong",options:["single",a.parentNode.parentNode.getAttribute("data-trackid")]},
t("Remove"))+addMenuItem({cmd:"delQueueSong",options:["range",0,a.parentNode.parentNode.getAttribute("data-songpos")]},t("Remove all upwards"))+addMenuItem({cmd:"delQueueSong",options:["range",parseInt(a.parentNode.parentNode.getAttribute("data-songpos"))-1,-1]},t("Remove all downwards"))+(-1===c.indexOf("http")?addMenuItem({cmd:"songDetails",options:[c]},t("Song details")):""):"Queue"===app.current.app&&"LastPlayed"===app.current.tab?g+=addMenuItem({cmd:"appendQueue",options:[b,c,d]},t("Append to queue"))+
addMenuItem({cmd:"replaceQueue",options:[b,c,d]},t("Replace queue"))+(settings.featPlaylists?addMenuItem({cmd:"showAddToPlaylist",options:[c,""]},t("Add to playlist")):"")+(-1===c.indexOf("http")?addMenuItem({cmd:"songDetails",options:[c]},t("Song details")):""):"Home"===app.current.app&&(b=parseInt(a.parentNode.getAttribute("data-pos")),g+=addMenuItem({cmd:"executeHomeIcon",options:[b]},t("Execute home icon action"))+addMenuItem({cmd:"editHomeIcon",options:[b]},t("Edit home icon"))+addMenuItem({cmd:"duplicateHomeIcon",
options:[b]},t("Duplicate home icon"))+addMenuItem({cmd:"deleteHomeIcon",options:[b]},t("Delete home icon")));new BSN.Popover(a,{trigger:"click",delay:0,dismissible:!0,template:'<div class="popover" role="tooltip"><div class="arrow"></div><div class="popover-content">'+g+"</div></div>",content:" "});g=a.Popover;null===a.getAttribute("data-init")&&(a.setAttribute("data-init","true"),a.addEventListener("shown.bs.popover",function(a){a.target.setAttribute("data-popover","true");document.getElementsByClassName("popover-content")[0].addEventListener("click",
function(b){b.preventDefault();b.stopPropagation();"A"===b.target.nodeName&&(b=b.target.getAttribute("data-href"))&&(b=JSON.parse(b64DecodeUnicode(b)),parseCmd(a,b),hideMenu())},!1);document.getElementsByClassName("popover-content")[0].addEventListener("keydown",function(a){a.preventDefault();a.stopPropagation();if("ArrowDown"===a.key||"ArrowUp"===a.key){var b=this.getElementsByTagName("a");b=Array.prototype.slice.call(b);var c=b.indexOf(document.activeElement);do if(c="ArrowUp"===a.key?1<c?c-1:0:
"ArrowDown"===a.key?c<b.length-1?c+1:c:c,0===c||c===b.length-1)break;while(!b[c].offsetHeight);b[c]&&b[c].focus()}else"Enter"===a.key?a.target.click():"Escape"===a.key&&hideMenu()},!1);var b=document.getElementById("advancedMenuLink");b&&(b.addEventListener("click",function(){var a=this.getElementsByTagName("span")[0];a.innerText="keyboard_arrow_right"===a.innerText?"keyboard_arrow_down":"keyboard_arrow_right"},!1),new BSN.Collapse(b));document.getElementsByClassName("popover-content")[0].firstChild.focus()},
!1));g.show()}
function parseUpdateQueue(a){if(1===a.result.state){for(var b=0;b<domCache.btnsPlayLen;b++)domCache.btnsPlay[b].innerText="play_arrow";playstate="stop";domCache.progressBar.style.transition="none";domCache.progressBar.style.width="0px";setTimeout(function(){domCache.progressBar.style.transition=progressBarTransition},10)}else if(2===a.result.state){for(b=0;b<domCache.btnsPlayLen;b++)domCache.btnsPlay[b].innerText=!0===settings.footerStop?"stop":"pause";playstate="play"}else{for(b=0;b<domCache.btnsPlayLen;b++)domCache.btnsPlay[b].innerText=
"play_arrow";playstate="pause"}if(0===a.result.queueLength)for(b=0;b<domCache.btnsPlayLen;b++)domCache.btnsPlay[b].setAttribute("disabled","disabled");else for(b=0;b<domCache.btnsPlayLen;b++)domCache.btnsPlay[b].removeAttribute("disabled");mediaSessionSetState();mediaSessionSetPositionState(a.result.totalTime,a.result.elapsedTime);domCache.badgeQueueItems.innerText=a.result.queueLength;-1===a.result.nextSongPos&&!1===settings.jukeboxMode?domCache.btnNext.setAttribute("disabled","disabled"):domCache.btnNext.removeAttribute("disabled");
0>=a.result.songPos?domCache.btnPrev.setAttribute("disabled","disabled"):domCache.btnPrev.removeAttribute("disabled")}function getQueue(){2<=app.current.search.length?sendAPI("MPD_API_QUEUE_SEARCH",{filter:app.current.filter,offset:app.current.page,searchstr:app.current.search,cols:settings.colsQueueCurrent},parseQueue,!1):sendAPI("MPD_API_QUEUE_LIST",{offset:app.current.page,cols:settings.colsQueueCurrent},parseQueue,!1)}
function parseQueue(a){if(a.result.offset<app.current.page)gotoPage(a.result.offset);else{a.result.totalEntities>settings.maxElementsPerPage?document.getElementById("btnQueueGotoPlayingSong").parentNode.classList.remove("hide"):document.getElementById("btnQueueGotoPlayingSong").parentNode.classList.add("hide");var b=a.result.returnedEntities,c=document.getElementById("QueueCurrentList"),d=document.activeElement.parentNode.parentNode===c?!0:!1,f=0;c.setAttribute("data-version",a.result.queueVersion);
c=c.getElementsByTagName("tbody")[0];for(var g=c.getElementsByTagName("tr"),h=0;h<b;h++){a.result.data[h].Duration=beautifySongDuration(a.result.data[h].Duration);a.result.data[h].Pos++;var k=document.createElement("tr");k.setAttribute("draggable","true");k.setAttribute("data-trackid",a.result.data[h].id);k.setAttribute("id","queueTrackId"+a.result.data[h].id);k.setAttribute("data-songpos",a.result.data[h].Pos);k.setAttribute("data-duration",a.result.data[h].Duration);k.setAttribute("data-uri",a.result.data[h].uri);
k.setAttribute("tabindex",0);for(var l="",m=0;m<settings.colsQueueCurrent.length;m++)l+='<td data-col="'+settings.colsQueueCurrent[m]+'">'+e(a.result.data[h][settings.colsQueueCurrent[m]])+"</td>";l+='<td data-col="Action"><a href="#" class="material-icons color-darkgrey">'+ligatureMore+"</a></td>";k.innerHTML=l;h<g.length?f=!0===replaceTblRow(g[h],k)?h:f:c.append(k)}for(h=g.length-1;h>=b;h--)g[h].remove();g=settings.colsQueueCurrent.length;g--;"MPD_API_QUEUE_SEARCH"===a.result.method&&0===b?c.innerHTML=
'<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+g+'">'+t("No results, please refine your search")+"</td></tr>":"MPD_API_QUEUE_ADD_TRACK"===a.result.method&&0===b&&(c.innerHTML='<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+g+'">'+t("Empty queue")+"</td></tr>");!0===d&&focusTable(f);setPagination(a.result.totalEntities,a.result.returnedEntities);document.getElementById("QueueCurrentList").classList.remove("opacity05")}}
function parseLastPlayed(a){var b=a.result.returnedEntities,c=document.getElementById("QueueLastPlayedList"),d=document.activeElement.parentNode.parentNode===c?!0:!1,f=0;c=c.getElementsByTagName("tbody")[0];for(var g=c.getElementsByTagName("tr"),h=0;h<b;h++){a.result.data[h].Duration=beautifySongDuration(a.result.data[h].Duration);a.result.data[h].LastPlayed=localeDate(a.result.data[h].LastPlayed);var k=document.createElement("tr");k.setAttribute("data-uri",a.result.data[h].uri);k.setAttribute("data-name",
a.result.data[h].Title);k.setAttribute("data-type","song");k.setAttribute("tabindex",0);for(var l="",m=0;m<settings.colsQueueLastPlayed.length;m++)l+='<td data-col="'+settings.colsQueueLastPlayed[m]+'">'+e(a.result.data[h][settings.colsQueueLastPlayed[m]])+"</td>";l+='<td data-col="Action">';""!==a.result.data[h].uri&&(l+='<a href="#" class="material-icons color-darkgrey">'+ligatureMore+"</a>");l+="</td>";k.innerHTML=l;h<g.length?f=!0===replaceTblRow(g[h],k)?h:f:c.append(k)}for(h=g.length-1;h>=b;h--)g[h].remove();
g=settings.colsQueueLastPlayed.length;g--;0===b&&(c.innerHTML='<tr><td><span class="material-icons">error_outline</span></td><td colspan="'+g+'">'+t("Empty list")+"</td></tr>");!0===d&&focusTable(f);setPagination(a.result.totalEntities,a.result.returnedEntities);document.getElementById("QueueLastPlayedList").classList.remove("opacity05")}
function queueSelectedItem(a){var b=document.activeElement;b&&"QueueCurrentList"!==b.parentNode.parentNode.id&&(!0===a?appendQueue(b.getAttribute("data-type"),b.getAttribute("data-uri"),b.getAttribute("data-name")):replaceQueue(b.getAttribute("data-type"),b.getAttribute("data-uri"),b.getAttribute("data-name")))}function dequeueSelectedItem(){var a=document.activeElement;a&&"QueueCurrentList"===a.parentNode.parentNode.id&&delQueueSong("single",a.getAttribute("data-trackid"))}
function appendQueue(a,b,c){switch(a){case "song":case "dir":sendAPI("MPD_API_QUEUE_ADD_TRACK",{uri:b});showNotification(t("%{name} added to queue",{name:c}),"","","success");break;case "plist":sendAPI("MPD_API_QUEUE_ADD_PLAYLIST",{plist:b}),showNotification(t("%{name} added to queue",{name:c}),"","","success")}}
function appendAfterQueue(a,b,c,d){switch(a){case "song":sendAPI("MPD_API_QUEUE_ADD_TRACK_AFTER",{uri:b,to:c}),c++,showNotification(t("%{name} added to queue position %{to}",{name:d,to:c}),"","","success")}}
function replaceQueue(a,b,c){switch(a){case "song":case "dir":sendAPI("MPD_API_QUEUE_REPLACE_TRACK",{uri:b});showNotification(t("Queue replaced with %{name}",{name:c}),"","","success");break;case "plist":sendAPI("MPD_API_QUEUE_REPLACE_PLAYLIST",{plist:b}),showNotification(t("Queue replaced with %{name}",{name:c}),"","","success")}}
function addToQueue(){var a=!0,b=document.getElementById("inputAddToQueueQuantity");validateInt(b)||(a=!1);b=document.getElementById("selectAddToQueueMode");b=b.options[b.selectedIndex].value;var c=document.getElementById("selectAddToQueuePlaylist");c=c.options[c.selectedIndex].value;"1"===b&&!1===settings.featSearchwindow&&"Database"===c&&(document.getElementById("warnJukeboxPlaylist2").classList.remove("hide"),a=!1);!0===a&&(sendAPI("MPD_API_QUEUE_ADD_RANDOM",{mode:b,playlist:c,quantity:document.getElementById("inputAddToQueueQuantity").value}),
modalAddToQueue.hide())}function saveQueue(){var a=document.getElementById("saveQueueName").value;!0===validatePlname(a)?(sendAPI("MPD_API_QUEUE_SAVE",{plist:a}),modalSaveQueue.hide()):document.getElementById("saveQueueName").classList.add("is-invalid")}function delQueueSong(a,b,c){"range"===a?sendAPI("MPD_API_QUEUE_RM_RANGE",{start:b,end:c}):"single"===a&&sendAPI("MPD_API_QUEUE_RM_TRACK",{track:b})}
function gotoPlayingSong(){var a=lastState.songPos<settings.maxElementsPerPage?0:Math.floor(lastState.songPos/settings.maxElementsPerPage)*settings.maxElementsPerPage;console.log(a);gotoPage(a)}
function saveScript(){var a=!0,b=document.getElementById("inputScriptName");validatePlnameEl(b)||(a=!1);var c=document.getElementById("inputScriptOrder");validateInt(c)||(a=!1);if(!0===a){a=[];for(var d=document.getElementById("selectScriptArguments"),f=0;f<d.options.length;f++)a.push(d.options[f].text);sendAPI("MYMPD_API_SCRIPT_SAVE",{oldscript:document.getElementById("inputOldScriptName").value,script:b.value,order:parseInt(c.value),content:document.getElementById("textareaScriptContent").value,
arguments:a},showListScripts,!1)}}function addScriptArgument(){var a=document.getElementById("inputScriptArgument");if(validatePlnameEl(a)){var b=document.createElement("option");b.text=a.value;document.getElementById("selectScriptArguments").appendChild(b);a.value=""}}function removeScriptArgument(a){var b=document.getElementById("inputScriptArgument");b.value=a.target.text;a.target.remove();b.focus()}
function showEditScript(a){document.getElementById("listScripts").classList.remove("active");document.getElementById("editScript").classList.add("active");document.getElementById("listScriptsFooter").classList.add("hide");document.getElementById("editScriptFooter").classList.remove("hide");document.getElementById("inputScriptName").classList.remove("is-invalid");document.getElementById("inputScriptOrder").classList.remove("is-invalid");document.getElementById("inputScriptArgument").classList.remove("is-invalid");
""!==a?sendAPI("MYMPD_API_SCRIPT_GET",{script:a},parseEditScript,!1):(document.getElementById("inputOldScriptName").value="",document.getElementById("inputScriptName").value="",document.getElementById("inputScriptOrder").value="1",document.getElementById("inputScriptArgument").value="",document.getElementById("selectScriptArguments").innerText="",document.getElementById("textareaScriptContent").value="")}
function parseEditScript(a){document.getElementById("inputOldScriptName").value=a.result.script;document.getElementById("inputScriptName").value=a.result.script;document.getElementById("inputScriptOrder").value=a.result.metadata.order;document.getElementById("inputScriptArgument").value="";var b=document.getElementById("selectScriptArguments");b.innerText="";for(var c=0;c<a.result.metadata.arguments.length;c++){var d=document.createElement("option");d.innerText=a.result.metadata.arguments[c];b.appendChild(d)}document.getElementById("textareaScriptContent").value=
a.result.content}function showListScripts(){document.getElementById("listScripts").classList.add("active");document.getElementById("editScript").classList.remove("active");document.getElementById("listScriptsFooter").classList.remove("hide");document.getElementById("editScriptFooter").classList.add("hide");sendAPI("MYMPD_API_SCRIPT_LIST",{all:!0},parseScriptList)}function deleteScript(a){sendAPI("MYMPD_API_SCRIPT_DELETE",{script:a},function(){getScriptList(!0)},!1)}
function getScriptList(a){sendAPI("MYMPD_API_SCRIPT_LIST",{all:a},parseScriptList,!1)}
function parseScriptList(a){var b=document.createElement("optgroup");b.setAttribute("data-value","script");b.setAttribute("label",t("Script"));var c="",d="",f=a.result.data.length;if(0<f){a.result.data.sort(function(a,b){return a.metadata.order-b.metadata.order});for(var g=0,h=0;h<f;h++){var k="";if(0<a.result.data[h].metadata.arguments.length){for(k=0;k<a.result.data[h].metadata.arguments.length;k++)a.result.data[h].metadata.arguments[k]=e(a.result.data[h].metadata.arguments[k]);k='"'+a.result.data[h].metadata.arguments.join('","')+
'"'}0<a.result.data[h].metadata.order&&(0===g&&(c=4<f?"":'<div class="dropdown-divider"></div>'),g++,c+='<a class="dropdown-item text-light alwaysEnabled" href="#" data-href=\'{"script": "'+e(a.result.data[h].name)+'", "arguments": ['+k+"]}'>"+e(a.result.data[h].name)+"</a>");d+='<tr data-script="'+encodeURI(a.result.data[h].name)+'"><td>'+e(a.result.data[h].name)+'</td><td data-col="Action">'+(!0===settings.featScripteditor?'<a href="#" title="'+t("Delete")+'" data-action="delete" class="material-icons color-darkgrey">delete</a>':
"")+'<a href="#" title="'+t("Execute")+'" data-action="execute" class="material-icons color-darkgrey"  data-href=\'{"script": "'+e(a.result.data[h].name)+'", "arguments": ['+k+']}\'>play_arrow</a><a href="#" title="'+t("Add to homescreen")+'" data-action="add2home" class="material-icons color-darkgrey"  data-href=\'{"script": "'+e(a.result.data[h].name)+'", "arguments": ['+k+"]}'>add_to_home_screen</a></td></tr>";b.innerHTML+='<option data-arguments=\'{"arguments":['+k+"]}' value=\""+e(a.result.data[h].name)+
'">'+e(a.result.data[h].name)+"</option>"}document.getElementById("listScriptsList").innerHTML=d}else document.getElementById("listScriptsList").innerHTML='<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td><td colspan="2">'+t("Empty list")+"</td></tr>";document.getElementById("scripts").innerHTML=c;4<f?(document.getElementById("navScripting").classList.remove("hide"),document.getElementById("scripts").classList.add("collapse","menu-indent")):(document.getElementById("navScripting").classList.add("hide"),
document.getElementById("scripts").classList.remove("collapse","menu-indent"));document.getElementById("selectTriggerScript").innerHTML=b.innerHTML;(a=document.getElementById("selectTimerAction").querySelector('optgroup[data-value="script"]'))?a.replaceWith(b):document.getElementById("selectTimerAction").appendChild(b)}function execScriptFromOptions(a,b){b=void 0!==b?b.split(","):[];execScript(JSON.stringify({script:a,arguments:b}))}
function execScript(a){a=JSON.parse(a);if(0===a.arguments.length)sendAPI("MYMPD_API_SCRIPT_EXECUTE",{script:a.script,arguments:{}});else{for(var b="",c=0;c<a.arguments.length;c++)b+='<div class="form-group row"><label class="col-sm-4 col-form-label" for="inputScriptArg'+c+'">'+e(a.arguments[c])+'</label><div class="col-sm-8"><input name="'+e(a.arguments[c])+'" id="inputScriptArg'+c+'" type="text" class="form-control border-secondary" value=""></div></div>';document.getElementById("execScriptArguments").innerHTML=
b;document.getElementById("modalExecScriptScriptname").value=a.script;modalExecScript.show()}}function execScriptArgs(){for(var a=document.getElementById("modalExecScriptScriptname").value,b={},c=document.getElementById("execScriptArguments").getElementsByTagName("input"),d=0;d<c.length;d++)b[c[d].name]=c[d].value;sendAPI("MYMPD_API_SCRIPT_EXECUTE",{script:a,arguments:b});modalExecScript.hide()}
function search(a){if(settings.featAdvsearch){for(var b="(",c=domCache.searchCrumb.children,d=0;d<c.length;d++)b+="("+decodeURI(c[d].getAttribute("data-filter"))+")",""!==a&&(b+=" AND ");""!==a?(c=document.getElementById("searchMatch"),b+="("+app.current.filter+" "+c.options[c.selectedIndex].value+" '"+a+"'))"):b+=")";2>=b.length&&(b="");appGoto("Search",void 0,void 0,"0",app.current.filter,app.current.sort,"-",b)}else appGoto("Search",void 0,void 0,"0",app.current.filter,app.current.sort,"-",a)}
function parseSearch(a){0<a.result.returnedEntities?(document.getElementById("searchAddAllSongs").removeAttribute("disabled"),document.getElementById("searchAddAllSongsBtn").removeAttribute("disabled")):(document.getElementById("searchAddAllSongs").setAttribute("disabled","disabled"),document.getElementById("searchAddAllSongsBtn").setAttribute("disabled","disabled"));parseFilesystem(a)}
function saveSearchAsSmartPlaylist(){parseSmartPlaylist({jsonrpc:"2.0",id:0,result:{method:"MPD_API_SMARTPLS_GET",playlist:"",type:"search",tag:!0===settings.featAdvsearch?"expression":app.current.filter,searchstr:app.current.search}})}
function addAllFromSearchPlist(a,b,c){null===b&&(b=app.current.search);settings.featAdvsearch?sendAPI("MPD_API_DATABASE_SEARCH_ADV",{plist:a,sort:"",sortdesc:!1,expression:b,offset:0,cols:settings.colsSearch,replace:c}):sendAPI("MPD_API_DATABASE_SEARCH",{plist:a,filter:app.current.filter,searchstr:b,offset:0,cols:settings.colsSearch,replace:c})}
function saveConnection(){var a=!0,b=document.getElementById("inputMpdHost"),c=document.getElementById("inputMpdPort"),d=document.getElementById("inputMpdPass"),f=document.getElementById("selectMusicDirectory");f=f.options[f.selectedIndex].value;"custom"===f&&(f=document.getElementById("inputMusicDirectory"),validatePath(f)||(a=!1),f=f.value);""===c.value&&(c.value="6600");0!==b.value.indexOf("/")&&(validateInt(c)||(a=!1),validateHost(b)||(a=!1));!0===a&&(sendAPI("MYMPD_API_CONNECTION_SAVE",{mpdHost:b.value,
mpdPort:c.value,mpdPass:d.value,musicDirectory:f},getSettings),modalConnection.hide())}function getSettings(a){!1===settingsLock&&(settingsLock=!0,sendAPI("MYMPD_API_SETTINGS_GET",{},getMpdSettings,a))}
function getMpdSettings(a){if(""!==a&&a.result)settingsNew=a.result,document.getElementById("splashScreenAlert").innerText=t("Fetch MPD settings"),sendAPI("MPD_API_SETTINGS_GET",{},joinSettings,!0);else return settingsParsed="error",!1===appInited&&showAppInitAlert(""===a?t("Can not parse settings"):t(a.error.message)),!1}
function joinSettings(a){if(""!==a&&a.result)for(var b in a.result)settingsNew[b]=a.result[b];else settingsParsed="error",!1===appInited&&showAppInitAlert(""===a?t("Can not parse settings"):t(a.error.message)),settingsNew.mpdConnected=!1;settings=Object.assign({},settingsNew);settingsLock=!1;parseSettings();toggleUI();!0===settings.mpdConnected&&sendAPI("MPD_API_URLHANDLERS",{},parseUrlhandlers,!1);btnWaiting(document.getElementById("btnApplySettings"),!1)}
function parseUrlhandlers(a){for(var b="",c=0;c<a.result.data.length;c++)switch(a.result.data[c]){case "http://":case "https://":case "nfs://":case "smb://":b+='<option value="'+a.result.data[c]+'">'+a.result.data[c]+"</option>"}document.getElementById("selectMountUrlhandler").innerHTML=b}
function checkConsume(){var a=document.getElementById("btnConsume").classList.contains("active")?!0:!1;0<getBtnGroupValue("btnJukeboxModeGroup")&&!1===a?document.getElementById("warnConsume").classList.remove("hide"):document.getElementById("warnConsume").classList.add("hide")}
function parseSettings(){locale="default"===settings.locale?navigator.language||navigator.userLanguage:settings.locale;!0===isMobile&&(document.getElementById("inputScaleRatio").value=scale);var a=settings.theme;"theme-autodetect"===settings.theme&&(a=window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?"theme-dark":"theme-default");Object.keys(themes).forEach(function(b){b===a?domCache.body.classList.add(b):domCache.body.classList.remove(b)});document.getElementById("selectTheme").value=
settings.theme;!0===settings.mpdConnected&&parseMPDSettings();0!==settings.mpdHost.indexOf("/")?document.getElementById("mpdInfo_host").innerText=settings.mpdHost+":"+settings.mpdPort:document.getElementById("mpdInfo_host").innerText=settings.mpdHost;document.getElementById("inputMpdHost").value=settings.mpdHost;document.getElementById("inputMpdPort").value=settings.mpdPort;document.getElementById("inputMpdPass").value=settings.mpdPass;var b=document.getElementById("btnNotifyWeb");document.getElementById("warnNotifyWeb").classList.add("hide");
notificationsSupported()?("granted"!==Notification.permission&&(!0===settings.notificationWeb&&document.getElementById("warnNotifyWeb").classList.remove("hide"),settings.notificationWeb=!1),"denied"===Notification.permission&&document.getElementById("warnNotifyWeb").classList.remove("hide"),toggleBtnChk("btnNotifyWeb",settings.notificationWeb),b.removeAttribute("disabled")):(b.setAttribute("disabled","disabled"),toggleBtnChk("btnNotifyWeb",!1));toggleBtnChk("btnNotifyPage",settings.notificationPage);
toggleBtnChk("btnMediaSession",settings.mediaSession);toggleBtnChkCollapse("btnFeatLocalplayer","collapseLocalplayer",settings.featLocalplayer);toggleBtnChk("btnFeatTimer",settings.featTimer);toggleBtnChk("btnBookmarks",settings.featBookmarks);toggleBtnChk("btnFeatLyrics",settings.featLyrics);""===settings.streamUrl?(document.getElementById("selectStreamMode").value="port",document.getElementById("inputStreamUrl").value=settings.streamPort):(document.getElementById("selectStreamMode").value="url",
document.getElementById("inputStreamUrl").value=settings.streamUrl);toggleBtnChkCollapse("btnCoverimage","collapseAlbumart",settings.coverimage);document.getElementById("inputBookletName").value=settings.bookletName;document.getElementById("selectLocale").value=settings.locale;document.getElementById("inputCoverimageName").value=settings.coverimageName;document.getElementById("inputCoverimageSize").value=settings.coverimageSize;document.getElementById("inputCoverimageSizeSmall").value=settings.coverimageSizeSmall;
document.documentElement.style.setProperty("--mympd-coverimagesize",settings.coverimageSize+"px");document.documentElement.style.setProperty("--mympd-coverimagesizesmall",settings.coverimageSizeSmall+"px");document.documentElement.style.setProperty("--mympd-highlightcolor",settings.highlightColor);document.getElementById("inputHighlightColor").value=settings.highlightColor;document.getElementById("inputBgColor").value=settings.bgColor;document.getElementsByTagName("body")[0].style.backgroundColor=
settings.bgColor;document.getElementById("highlightColorPreview").style.backgroundColor=settings.highlightColor;document.getElementById("bgColorPreview").style.backgroundColor=settings.bgColor;toggleBtnChkCollapse("btnBgCover","collapseBackground",settings.bgCover);document.getElementById("inputBgCssFilter").value=settings.bgCssFilter;b=document.querySelectorAll(".albumartbg");for(var c=0;c<b.length;c++)b[c].style.filter=settings.bgCssFilter;toggleBtnChkCollapse("btnLoveEnable","collapseLove",settings.love);
document.getElementById("inputLoveChannel").value=settings.loveChannel;document.getElementById("inputLoveMessage").value=settings.loveMessage;document.getElementById("inputMaxElementsPerPage").value=settings.maxElementsPerPage;toggleBtnChk("btnStickers",settings.stickers);document.getElementById("inputLastPlayedCount").value=settings.lastPlayedCount;toggleBtnChkCollapse("btnSmartpls","collapseSmartpls",settings.smartpls);b="featLocalplayer featSyscmds featMixramp featCacert featBookmarks featRegex featTimer featLyrics featScripting featScripteditor featHome".split(" ");
for(c=0;c<b.length;c++)for(var d=document.getElementsByClassName(b[c]),f=d.length,g=!0===settings[b[c]]?"":"none",h=0;h<f;h++)d[h].style.display=g;b=document.getElementsByClassName("warnReadonly");for(c=0;c<b.length;c++)!1===settings.readonly?b[c].classList.add("hide"):b[c].classList.remove("hide");!0===settings.readonly?(document.getElementById("btnBookmarks").setAttribute("disabled","disabled"),document.getElementsByClassName("groupClearCovercache")[0].classList.add("hide")):(document.getElementById("btnBookmarks").removeAttribute("disabled"),
document.getElementsByClassName("groupClearCovercache")[0].classList.remove("hide"));b='<optgroup data-value="player" label="'+t("Playback")+'"><option value="startplay">'+t("Start playback")+'</option><option value="stopplay">'+t("Stop playback")+"</option></optgroup>";if(!0===settings.featSyscmds){c="";d=settings.syscmdList.length;if(0<d)for(b+='<optgroup data-value="syscmd" label="'+t("System command")+'">',c=4<d?"":'<div class="dropdown-divider"></div>',f=0;f<d;f++)"HR"===settings.syscmdList[f]?
c+='<div class="dropdown-divider"></div>':(c+='<a class="dropdown-item text-light alwaysEnabled" href="#" data-href=\'{"cmd": "execSyscmd", "options": ["'+e(settings.syscmdList[f])+"\"]}'>"+e(settings.syscmdList[f])+"</a>",b+='<option value="'+e(settings.syscmdList[f])+'">'+e(settings.syscmdList[f])+"</option>");document.getElementById("syscmds").innerHTML=c;b+="</optgroup>";4<d?(document.getElementById("navSyscmds").classList.remove("hide"),document.getElementById("syscmds").classList.add("collapse",
"menu-indent")):(document.getElementById("navSyscmds").classList.add("hide"),document.getElementById("syscmds").classList.remove("collapse","menu-indent"))}else document.getElementById("syscmds").innerHTML="";!0===settings.featScripting?getScriptList(!0):document.getElementById("scripts").innerHTML="";document.getElementById("selectTimerAction").innerHTML=b;toggleBtnGroupValueCollapse(document.getElementById("btnJukeboxModeGroup"),"collapseJukeboxMode",settings.jukeboxMode);document.getElementById("selectJukeboxUniqueTag").value=
settings.jukeboxUniqueTag;document.getElementById("inputJukeboxQueueLength").value=settings.jukeboxQueueLength;document.getElementById("inputJukeboxLastPlayed").value=settings.jukeboxLastPlayed;0===settings.jukeboxMode?(document.getElementById("inputJukeboxQueueLength").setAttribute("disabled","disabled"),document.getElementById("selectJukeboxPlaylist").setAttribute("disabled","disabled")):2===settings.jukeboxMode?(document.getElementById("inputJukeboxQueueLength").setAttribute("disabled","disabled"),
document.getElementById("selectJukeboxPlaylist").setAttribute("disabled","disabled"),document.getElementById("selectJukeboxPlaylist").value="Database"):1===settings.jukeboxMode&&(document.getElementById("inputJukeboxQueueLength").removeAttribute("disabled"),document.getElementById("selectJukeboxPlaylist").removeAttribute("disabled"));document.getElementById("inputSmartplsPrefix").value=settings.smartplsPrefix;document.getElementById("inputSmartplsInterval").value=settings.smartplsInterval/60/60;document.getElementById("selectSmartplsSort").value=
settings.smartplsSort;!0===settings.featLocalplayer&&setLocalPlayerUrl();"auto"===settings.musicDirectory?(document.getElementById("selectMusicDirectory").value=settings.musicDirectory,document.getElementById("inputMusicDirectory").value=void 0!==settings.musicDirectoryValue?settings.musicDirectoryValue:"",document.getElementById("inputMusicDirectory").setAttribute("readonly","readonly")):"none"===settings.musicDirectory?(document.getElementById("selectMusicDirectory").value=settings.musicDirectory,
document.getElementById("inputMusicDirectory").value="",document.getElementById("inputMusicDirectory").setAttribute("readonly","readonly")):(document.getElementById("selectMusicDirectory").value="custom",document.getElementById("inputMusicDirectory").value=settings.musicDirectoryValue,document.getElementById("inputMusicDirectory").removeAttribute("readonly"));"Queue"===app.current.app&&"Current"===app.current.tab?getQueue():"Queue"===app.current.app&&"LastPlayed"===app.current.tab?appRoute():"Search"===
app.current.app?appRoute():"Browse"===app.current.app&&"Filesystem"===app.current.tab?appRoute():"Browse"===app.current.app&&"Playlists"===app.current.tab&&"Detail"===app.current.view?appRoute():"Browse"===app.current.app&&"Database"===app.current.tab&&""!==app.current.search&&appRoute();i18nHtml(document.getElementsByTagName("body")[0]);checkConsume();!0===settings.mediaSession&&"mediaSession"in navigator?(navigator.mediaSession.setActionHandler("play",clickPlay),navigator.mediaSession.setActionHandler("pause",
clickPlay),navigator.mediaSession.setActionHandler("stop",clickStop),navigator.mediaSession.setActionHandler("seekbackward",seekRelativeBackward),navigator.mediaSession.setActionHandler("seekforward",seekRelativeForward),navigator.mediaSession.setActionHandler("previoustrack",clickPrev),navigator.mediaSession.setActionHandler("nexttrack",clickNext),navigator.mediaSession.setPositionState||logDebug("mediaSession.setPositionState not supported by browser")):logDebug("mediaSession not supported by browser");
settingsParsed="true"}
function parseMPDSettings(){toggleBtnChk("btnRandom",settings.random);toggleBtnChk("btnConsume",settings.consume);toggleBtnChk("btnRepeat",settings.repeat);toggleBtnChk("btnAutoPlay",settings.autoPlay);toggleBtnGroupValue(document.getElementById("btnSingleGroup"),settings.single);toggleBtnGroupValue(document.getElementById("btnReplaygainGroup"),settings.replaygain);document.getElementById("partitionName").innerText=settings.partition;document.getElementById("inputCrossfade").value=settings.crossfade;
document.getElementById("inputMixrampdb").value=settings.mixrampdb;document.getElementById("inputMixrampdelay").value=settings.mixrampdelay;settings.featBrowse=!0===settings.featLibrary&&!0===settings.publish?!0:!1;for(var a="featStickers featSmartpls featPlaylists featTags featCoverimage featAdvsearch featLove featSingleOneshot featBrowse featMounts featNeighbors featPartitions".split(" "),b=0;b<a.length;b++){var c=document.getElementsByClassName(a[b]),d=c.length,f=!0===settings[a[b]]?"":"none";
"featCoverimage"===a[b]&&!1===settings.coverimage&&(f="none");for(var g=0;g<d;g++)c[g].style.display=f}!1===settings.featPlaylists&&!0===settings.smartpls?document.getElementById("warnSmartpls").classList.remove("hide"):document.getElementById("warnSmartpls").classList.add("hide");!0===settings.featPlaylists&&!1===settings.readonly?document.getElementById("btnSmartpls").removeAttribute("disabled"):document.getElementById("btnSmartpls").setAttribute("disabled","disabled");!1===settings.featStickers&&
!0===settings.stickers?document.getElementById("warnStickers").classList.remove("hide"):document.getElementById("warnStickers").classList.add("hide");!1===settings.featStickers||!1===settings.stickers||!1===settings.featStickerCache?(document.getElementById("warnPlaybackStatistics").classList.remove("hide"),document.getElementById("inputJukeboxLastPlayed").setAttribute("disabled","disabled")):(document.getElementById("warnPlaybackStatistics").classList.add("hide"),document.getElementById("inputJukeboxLastPlayed").removeAttribute("disabled"));
!1===settings.featLove&&!0===settings.love?document.getElementById("warnScrobbler").classList.remove("hide"):document.getElementById("warnScrobbler").classList.add("hide");!1===settings.featLibrary&&!0===settings.coverimage?document.getElementById("warnAlbumart").classList.remove("hide"):document.getElementById("warnAlbumart").classList.add("hide");""===settings.musicDirectoryValue&&"none"!==settings.musicDirectory?document.getElementById("warnMusicDirectory").classList.remove("hide"):document.getElementById("warnMusicDirectory").classList.add("hide");
document.getElementById("warnJukeboxPlaylist").classList.add("hide");!0===settings.bgCover&&!0===settings.featCoverimage&&!0===settings.coverimage?setBackgroundImage(lastSongObj.uri):clearBackgroundImage();var h="";Object.keys(settings.triggers).forEach(function(a){h+='<option value="'+e(settings.triggers[a])+'">'+t(a)+"</option>"});document.getElementById("selectTriggerEvent").innerHTML=h;settings.tags.sort();settings.searchtags.sort();settings.browsetags.sort();filterCols("colsSearch");filterCols("colsQueueCurrent");
filterCols("colsQueueLastPlayed");filterCols("colsBrowsePlaylistsDetail");filterCols("colsBrowseFilesystem");filterCols("colsBrowseDatabaseDetail");filterCols("colsPlayback");if(!1===settings.featTags)app.apps.Browse.active="Filesystem",app.apps.Search.state="0/filename/-/-/",app.apps.Queue.state="0/filename/-/-/",settings.colsQueueCurrent=["Pos","Title","Duration"],settings.colsQueueLastPlayed=["Pos","Title","LastPlayed"],settings.colsSearch=["Title","Duration"],settings.colsBrowseFilesystem=["Type",
"Title","Duration"],settings.colsBrowseDatabase=["Track","Title","Duration"],settings.colsPlayback=[];else{a="";for(b=0;b<settings.colsPlayback.length;b++)a+='<div id="current'+settings.colsPlayback[b]+'" data-tag="'+settings.colsPlayback[b]+'" '+("Lyrics"===settings.colsPlayback[b]?"":'data-name="'+(lastSongObj[settings.colsPlayback[b]]?encodeURI(lastSongObj[settings.colsPlayback[b]]):"")+'"')+"><small>"+t(settings.colsPlayback[b])+"</small><p",settings.browsetags.includes(settings.colsPlayback[b])&&
(a+=' class="clickable"'),a+=">",a="Duration"===settings.colsPlayback[b]?a+(lastSongObj[settings.colsPlayback[b]]?beautifySongDuration(lastSongObj[settings.colsPlayback[b]]):""):"LastModified"===settings.colsPlayback[b]?a+(lastSongObj[settings.colsPlayback[b]]?localeDate(lastSongObj[settings.colsPlayback[b]]):""):"Fileformat"===settings.colsPlayback[b]?a+(lastState?fileformat(lastState.audioFormat):""):a+(lastSongObj[settings.colsPlayback[b]]?e(lastSongObj[settings.colsPlayback[b]]):""),a+="</p></div>";
document.getElementById("cardPlaybackTags").innerHTML=a;(a=document.getElementById("currentLyrics"))&&lastSongObj.uri&&(b=a.getElementsByTagName("small")[0],b.classList.add("clickable"),b.addEventListener("click",function(a){a.target.parentNode.children[1].classList.toggle("expanded")},!1),getLyrics(lastSongObj.uri,a.getElementsByTagName("p")[0]))}settings.tags.includes("Title")&&(app.apps.Search.state="0/any/Title/-/");settings.tags.includes("AlbumArtist")||(app.apps.Browse.tabs.Database.state="0/Artist/Artist/"+
settings.dbDefaultTag+"/");!0===settings.featPlaylists?sendAPI("MPD_API_PLAYLIST_LIST_ALL",{searchstr:""},function(a){getAllPlaylists(a,"selectJukeboxPlaylist",settings.jukeboxPlaylist)}):document.getElementById("selectJukeboxPlaylist").innerHTML='<option value="Database">'+t("Database")+"</option>";setCols("QueueCurrent");setCols("Search");setCols("QueueLastPlayed");setCols("BrowseFilesystem");setCols("BrowsePlaylistsDetail");setCols("BrowseDatabaseDetail");setCols("Playback");addTagList("BrowseDatabaseByTagDropdown",
"browsetags");addTagList("BrowseNavPlaylistsDropdown","browsetags");addTagList("BrowseNavFilesystemDropdown","browsetags");addTagList("searchqueuetags","searchtags");addTagList("searchtags","searchtags");addTagList("searchDatabaseTags","browsetags");addTagList("databaseSortTagsList","browsetags");addTagList("dropdownSortPlaylistTags","tags");addTagList("saveSmartPlaylistSort","tags");addTagListSelect("selectSmartplsSort","tags");addTagListSelect("saveSmartPlaylistSort","tags");addTagListSelect("selectJukeboxUniqueTag",
"browsetags");initTagMultiSelect("inputEnabledTags","listEnabledTags",settings.allmpdtags,settings.tags);initTagMultiSelect("inputSearchTags","listSearchTags",settings.tags,settings.searchtags);initTagMultiSelect("inputBrowseTags","listBrowseTags",settings.tags,settings.browsetags);initTagMultiSelect("inputGeneratePlsTags","listGeneratePlsTags",settings.browsetags,settings.generatePlsTags)}function resetSettings(){sendAPI("MYMPD_API_SETTINGS_RESET",{},getSettings)}
function saveSettings(a){var b=!0,c=document.getElementById("inputCrossfade");c.getAttribute("disabled")||validateInt(c)||(b=!1);c=document.getElementById("inputJukeboxQueueLength");validateInt(c)||(b=!1);c=document.getElementById("inputJukeboxLastPlayed");validateInt(c)||(b=!1);var d=document.getElementById("selectStreamMode"),f=c="",g=document.getElementById("inputStreamUrl");"port"===d.options[d.selectedIndex].value?(f=g.value,validateInt(g)||(b=!1)):(c=g.value,validateStream(g)||(b=!1));d=document.getElementById("inputCoverimageSizeSmall");
validateInt(d)||(b=!1);d=document.getElementById("inputCoverimageSize");validateInt(d)||(b=!1);d=document.getElementById("inputCoverimageName");validateFilenameList(d)||(b=!1);d=document.getElementById("inputBookletName");validateFilename(d)||(b=!1);d=document.getElementById("inputMaxElementsPerPage");validateInt(d)||(b=!1);!0===isMobile&&(g=document.getElementById("inputScaleRatio"),validateFloat(g)?(scale=parseFloat(g.value),setViewport(!0)):b=!1);200<parseInt(d.value)&&(b=!1);d=document.getElementById("inputLastPlayedCount");
validateInt(d)||(b=!1);document.getElementById("btnLoveEnable").classList.contains("active")&&(d=document.getElementById("inputLoveChannel"),g=document.getElementById("inputLoveMessage"),validateNotBlank(d)&&validateNotBlank(g)||(b=!1));!0===settings.featMixramp&&(d=document.getElementById("inputMixrampdb"),d.getAttribute("disabled")||validateFloat(d)||(b=!1),d=document.getElementById("inputMixrampdelay"),d.getAttribute("disabled")||("nan"===d.value&&(d.value="-1"),validateFloat(d)||(b=!1)));d=document.getElementById("inputSmartplsInterval");
validateInt(d)||(b=!1);d=3600*document.getElementById("inputSmartplsInterval").value;g=getBtnGroupValue("btnSingleGroup");var h=getBtnGroupValue("btnJukeboxModeGroup"),k=getBtnGroupValue("btnReplaygainGroup"),l=document.getElementById("selectJukeboxUniqueTag");l=l.options[l.selectedIndex].value;var m=document.getElementById("selectJukeboxPlaylist");m=m.options[m.selectedIndex].value;"2"===h&&(l="Album");"1"===h&&!1===settings.featSearchwindow&&"Database"===m&&(b=!1,document.getElementById("warnJukeboxPlaylist").classList.remove("hide"));
if(!0===b){b=document.getElementById("selectLocale");var p=document.getElementById("selectTheme");sendAPI("MYMPD_API_SETTINGS_SET",{consume:document.getElementById("btnConsume").classList.contains("active")?1:0,random:document.getElementById("btnRandom").classList.contains("active")?1:0,single:parseInt(g),repeat:document.getElementById("btnRepeat").classList.contains("active")?1:0,replaygain:k,crossfade:document.getElementById("inputCrossfade").value,mixrampdb:!0===settings.featMixramp?document.getElementById("inputMixrampdb").value:
settings.mixrampdb,mixrampdelay:!0===settings.featMixramp?document.getElementById("inputMixrampdelay").value:settings.mixrampdelay,notificationWeb:document.getElementById("btnNotifyWeb").classList.contains("active")?!0:!1,notificationPage:document.getElementById("btnNotifyPage").classList.contains("active")?!0:!1,mediaSession:document.getElementById("btnMediaSession").classList.contains("active")?!0:!1,jukeboxMode:parseInt(h),jukeboxPlaylist:m,jukeboxQueueLength:parseInt(document.getElementById("inputJukeboxQueueLength").value),
jukeboxLastPlayed:parseInt(document.getElementById("inputJukeboxLastPlayed").value),jukeboxUniqueTag:l,autoPlay:document.getElementById("btnAutoPlay").classList.contains("active")?!0:!1,bgCover:document.getElementById("btnBgCover").classList.contains("active")?!0:!1,bgColor:document.getElementById("inputBgColor").value,bgCssFilter:document.getElementById("inputBgCssFilter").value,featLocalplayer:document.getElementById("btnFeatLocalplayer").classList.contains("active")?!0:!1,streamUrl:c,streamPort:parseInt(f),
coverimage:document.getElementById("btnCoverimage").classList.contains("active")?!0:!1,coverimageName:document.getElementById("inputCoverimageName").value,coverimageSize:document.getElementById("inputCoverimageSize").value,coverimageSizeSmall:document.getElementById("inputCoverimageSizeSmall").value,locale:b.options[b.selectedIndex].value,love:document.getElementById("btnLoveEnable").classList.contains("active")?!0:!1,loveChannel:document.getElementById("inputLoveChannel").value,loveMessage:document.getElementById("inputLoveMessage").value,
bookmarks:document.getElementById("btnBookmarks").classList.contains("active")?!0:!1,maxElementsPerPage:document.getElementById("inputMaxElementsPerPage").value,stickers:document.getElementById("btnStickers").classList.contains("active")?!0:!1,lastPlayedCount:document.getElementById("inputLastPlayedCount").value,smartpls:document.getElementById("btnSmartpls").classList.contains("active")?!0:!1,smartplsPrefix:document.getElementById("inputSmartplsPrefix").value,smartplsInterval:d,smartplsSort:document.getElementById("selectSmartplsSort").value,
taglist:getTagMultiSelectValues(document.getElementById("listEnabledTags"),!1),searchtaglist:getTagMultiSelectValues(document.getElementById("listSearchTags"),!1),browsetaglist:getTagMultiSelectValues(document.getElementById("listBrowseTags"),!1),generatePlsTags:getTagMultiSelectValues(document.getElementById("listGeneratePlsTags"),!1),theme:p.options[p.selectedIndex].value,highlightColor:document.getElementById("inputHighlightColor").value,timer:document.getElementById("btnFeatTimer").classList.contains("active")?
!0:!1,bookletName:document.getElementById("inputBookletName").value,lyrics:document.getElementById("btnFeatLyrics").classList.contains("active")?!0:!1},getSettings);!0===a?modalSettings.hide():btnWaiting(document.getElementById("btnApplySettings"),!0)}}function getTagMultiSelectValues(a,b){var c=[];a=a.getElementsByTagName("button");for(var d=0;d<a.length;d++)a[d].classList.contains("active")&&(!0===b?c.push(t(a[d].name)):c.push(a[d].name));return!0===b?c.join(", "):c.join(",")}
function initTagMultiSelect(a,b,c,d){for(var f=[],g="",h=0;h<c.length;h++)d.includes(c[h])&&f.push(t(c[h])),g+='<div class="form-check"><button class="btn btn-secondary btn-xs clickable material-icons material-icons-small'+(d.includes(c[h])?" active":"")+'" name="'+c[h]+'">'+(d.includes(c[h])?"check":"radio_button_unchecked")+'</button><label class="form-check-label" for="'+c[h]+'">&nbsp;&nbsp;'+t(c[h])+"</label></div>";document.getElementById(b).innerHTML=g;a=document.getElementById(a);a.value=f.join(", ");
"true"!==a.getAttribute("data-init")&&(a.setAttribute("data-init","true"),document.getElementById(b).addEventListener("click",function(a){a.stopPropagation();a.preventDefault();"BUTTON"===a.target.nodeName&&(toggleBtnChk(a.target),a.target.parentNode.parentNode.parentNode.previousElementSibling.value=getTagMultiSelectValues(a.target.parentNode.parentNode,!0))}))}
function filterCols(a){var b=settings.tags.slice();!1===settings.featTags&&b.push("Title");b.push("Duration");"colsQueueCurrent"===a||"colsBrowsePlaylistsDetail"===a||"colsQueueLastPlayed"===a?b.push("Pos"):"colsBrowseFilesystem"===a&&b.push("Type");"colsQueueLastPlayed"===a&&b.push("LastPlayed");"colsPlayback"===a&&(b.push("Filetype"),b.push("Fileformat"),b.push("LastModified"),!0===settings.featLyrics&&b.push("Lyrics"));for(var c=[],d=0;d<settings[a].length;d++)b.includes(settings[a][d])&&c.push(settings[a][d]);
settings[a]=c;logDebug("Columns for "+a+": "+c)}
function toggleBtnNotifyWeb(){var a=document.getElementById("btnNotifyWeb").classList.contains("active")?!0:!1;notificationsSupported()?!1===a?Notification.requestPermission(function(a){"permission"in Notification||(Notification.permission=a);"granted"===a?(toggleBtnChk("btnNotifyWeb",!0),settings.notificationWeb=!0,document.getElementById("warnNotifyWeb").classList.add("hide")):(toggleBtnChk("btnNotifyWeb",!1),settings.notificationWeb=!1,document.getElementById("warnNotifyWeb").classList.remove("hide"))}):(toggleBtnChk("btnNotifyWeb",
!1),settings.notificationWeb=!1,document.getElementById("warnNotifyWeb").classList.add("hide")):(toggleBtnChk("btnNotifyWeb",!1),settings.notificationWeb=!1)}
function setPlaySettings(a){a.parentNode.classList.contains("btn-group")?toggleBtnGroup(a):toggleBtnChk(a);"playDropdownBtnJukeboxModeGroup"===a.parentNode.id?"0"!==a.parentNode.getElementsByClassName("active")[0].getAttribute("data-value")&&toggleBtnChk("playDropdownBtnConsume",!0):"playDropdownBtnConsume"===a.id&&!1===a.classList.contains("active")&&toggleBtnGroupValue(document.getElementById("playDropdownBtnJukeboxModeGroup"),0);savePlaySettings()}
function showPlayDropdown(){toggleBtnChk(document.getElementById("playDropdownBtnRandom"),settings.random);toggleBtnChk(document.getElementById("playDropdownBtnConsume"),settings.consume);toggleBtnChk(document.getElementById("playDropdownBtnRepeat"),settings.repeat);toggleBtnChk(document.getElementById("playDropdownBtnRandom"),settings.random);toggleBtnGroupValue(document.getElementById("playDropdownBtnSingleGroup"),settings.single);toggleBtnGroupValue(document.getElementById("playDropdownBtnJukeboxModeGroup"),
settings.jukeboxMode)}
function savePlaySettings(){var a=document.getElementById("playDropdownBtnSingleGroup").getElementsByClassName("active")[0].getAttribute("data-value"),b=document.getElementById("playDropdownBtnJukeboxModeGroup").getElementsByClassName("active")[0].getAttribute("data-value");sendAPI("MYMPD_API_SETTINGS_SET",{consume:document.getElementById("playDropdownBtnConsume").classList.contains("active")?1:0,random:document.getElementById("playDropdownBtnRandom").classList.contains("active")?1:0,single:parseInt(a),
repeat:document.getElementById("playDropdownBtnRepeat").classList.contains("active")?1:0,jukeboxMode:parseInt(b)},getSettings)}function songDetails(a){sendAPI("MPD_API_DATABASE_SONGDETAILS",{uri:a},parseSongDetails);modalSongDetails.show()}function parseFingerprint(a){var b=document.createElement("textarea");b.value=a.result.fingerprint;b.classList.add("form-control","text-monospace","small");a=document.getElementById("fingerprint");a.innerHTML="";a.appendChild(b)}
function parseSongDetails(a){var b=document.getElementById("modalSongDetails");b.getElementsByClassName("album-cover")[0].style.backgroundImage='url("'+subdir+"/albumart/"+a.result.uri+'"), url("'+subdir+'/assets/coverimage-loading.svg")';b=b.getElementsByTagName("h1");for(var c=0;c<b.length;c++)b[c].innerText=a.result.Title;b="";for(c=0;c<settings.tags.length;c++)"Title"!==settings.tags[c]&&"-"!==a.result[settings.tags[c]]&&(b+="<tr><th>"+t(settings.tags[c])+'</th><td data-tag="'+settings.tags[c]+
'" data-name="'+encodeURI(a.result[settings.tags[c]])+'">',b=settings.browsetags.includes(settings.tags[c])&&"-"!==a.result[settings.tags[c]]?b+('<a class="text-success" href="#">'+e(a.result[settings.tags[c]])+"</a>"):b+a.result[settings.tags[c]],b+="</td></tr>");b+="<tr><th>"+t("Duration")+"</th><td>"+beautifyDuration(a.result.Duration)+"</td></tr>";b=!0===settings.featLibrary&&!0===settings.publish?b+("<tr><th>"+t("Filename")+'</th><td><a class="breakAll text-success" href="/browse/music/'+encodeURI(a.result.uri)+
'" target="_blank" title="'+e(a.result.uri)+'">'+e(basename(a.result.uri,!0))+"</a></td></tr>"):b+("<tr><th>"+t("Filename")+'</th><td class="breakAll"><span title="'+e(a.result.uri)+'">'+e(basename(a.result.uri,!0))+"</span></td></tr>");b+="<tr><th>"+t("Filetype")+"</th><td>"+filetype(a.result.uri)+"</td></tr>";b+="<tr><th>"+t("LastModified")+"</th><td>"+localeDate(a.result.LastModified)+"</td></tr>";!0===settings.featFingerprint&&(b+="<tr><th>"+t("Fingerprint")+'</th><td class="breakAll" id="fingerprint"><a class="text-success" data-uri="'+
encodeURI(a.result.uri)+'" id="calcFingerprint" href="#">'+t("Calculate")+"</a></td></tr>");""!==a.result.bookletPath&&!0===settings.publish&&(b+="<tr><th>"+t("Booklet")+'</th><td><a class="text-success" href="'+subdir+"/browse/music/"+dirname(a.result.uri)+"/"+settings.bookletName+'" target="_blank">'+t("Download")+"</a></td></tr>");!0===settings.featStickers&&(b+='<tr><th colspan="2" class="pt-3"><h5>'+t("Statistics")+"</h5></th></tr><tr><th>"+t("Play count")+"</th><td>"+a.result.playCount+"</td></tr><tr><th>"+
t("Skip count")+"</th><td>"+a.result.skipCount+"</td></tr><tr><th>"+t("Last played")+"</th><td>"+(0===a.result.lastPlayed?t("never"):localeDate(a.result.lastPlayed))+"</td></tr><tr><th>"+t("Last skipped")+"</th><td>"+(0===a.result.lastSkipped?t("never"):localeDate(a.result.lastSkipped))+"</td></tr><tr><th>"+t("Like")+'</th><td><div class="btn-group btn-group-sm"><button title="'+t("Dislike song")+'" id="btnVoteDown2" data-href=\'{"cmd": "voteSong", "options": [0]}\' class="btn btn-sm btn-light material-icons">thumb_down</button><button title="'+
t("Like song")+'" id="btnVoteUp2" data-href=\'{"cmd": "voteSong", "options": [2]}\' class="btn btn-sm btn-light material-icons">thumb_up</button></div></td></tr>');document.getElementById("tbodySongDetails").innerHTML=b;setVoteSongBtns(a.result.like,a.result.uri);!0===settings.featLyrics&&getLyrics(a.result.uri,document.getElementById("lyricsText"));b=!1;0<a.result.images.length&&!0===settings.featLibrary&&!0===settings.publish?b=!0:!0===settings.coverimage&&(b=!0);c=document.getElementsByClassName("featPictures");
for(var d=0;d<c.length;d++)!0===b?c[d].classList.remove("hide"):c[d].classList.add("hide");if(!0===b){b=[subdir+"/albumart/"+a.result.uri];for(c=0;c<a.result.images.length;c++)!1===isCoverfile(a.result.images[c])&&b.push(subdir+"/browse/music/"+a.result.images[c]);a=document.getElementById("tabSongPics");createImgCarousel(a,"songPicsCarousel",b)}else document.getElementById("tabSongPics").innerText=""}
function isCoverfile(a){a=basename(a).toLowerCase();for(var b=a.split("."),c="png jpg jpeg svg webp tiff bmp".split(" "),d=settings.coverimageName.split(","),f=0;f<d.length;f++){var g=d[f].trim();if(a===g||b[1]&&g===b[0]&&c.includes(b[1]))return!0}return!1}
function getLyrics(a,b){b.classList.add("opacity05");var c=new XMLHttpRequest;c.open("GET",subdir+"/lyrics/"+a,!0);c.onreadystatechange=function(){4===c.readyState&&(b.innerText="No lyrics found"===c.responseText?t(c.responseText):c.responseText,b.classList.remove("opacity05"))};c.send()}function loveSong(){sendAPI("MPD_API_LOVE",{})}
function voteSong(a){var b=decodeURI(domCache.currentTitle.getAttribute("data-uri"));""!==b&&(2===a&&domCache.btnVoteUp.classList.contains("highlight")?a=1:0===a&&domCache.btnVoteDown.classList.contains("highlight")&&(a=1),sendAPI("MPD_API_LIKE",{uri:b,like:a}),setVoteSongBtns(a,b))}
function setVoteSongBtns(a,b){domCache.btnVoteUp2=document.getElementById("btnVoteUp2");domCache.btnVoteDown2=document.getElementById("btnVoteDown2");""===b||-1<b.indexOf("://")?(domCache.btnVoteUp.setAttribute("disabled","disabled"),domCache.btnVoteDown.setAttribute("disabled","disabled"),domCache.btnVoteUp2&&(domCache.btnVoteUp2.setAttribute("disabled","disabled"),domCache.btnVoteDown2.setAttribute("disabled","disabled"))):(domCache.btnVoteUp.removeAttribute("disabled"),domCache.btnVoteDown.removeAttribute("disabled"),
domCache.btnVoteUp2&&(domCache.btnVoteUp2.removeAttribute("disabled"),domCache.btnVoteDown2.removeAttribute("disabled")));0===a?(domCache.btnVoteUp.classList.remove("highlight"),domCache.btnVoteDown.classList.add("highlight"),domCache.btnVoteUp2&&(domCache.btnVoteUp2.classList.remove("highlight"),domCache.btnVoteDown2.classList.add("highlight"))):1===a?(domCache.btnVoteUp.classList.remove("highlight"),domCache.btnVoteDown.classList.remove("highlight"),domCache.btnVoteUp2&&(domCache.btnVoteUp2.classList.remove("highlight"),
domCache.btnVoteDown2.classList.remove("highlight"))):2===a&&(domCache.btnVoteUp.classList.add("highlight"),domCache.btnVoteDown.classList.remove("highlight"),domCache.btnVoteUp2&&(domCache.btnVoteUp2.classList.add("highlight"),domCache.btnVoteDown2.classList.remove("highlight")))}
function parseStats(a){document.getElementById("mpdstats_artists").innerText=a.result.artists;document.getElementById("mpdstats_albums").innerText=a.result.albums;document.getElementById("mpdstats_songs").innerText=a.result.songs;document.getElementById("mpdstats_dbPlaytime").innerText=beautifyDuration(a.result.dbPlaytime);document.getElementById("mpdstats_playtime").innerText=beautifyDuration(a.result.playtime);document.getElementById("mpdstats_uptime").innerText=beautifyDuration(a.result.uptime);
document.getElementById("mpdstats_mympd_uptime").innerText=beautifyDuration(a.result.myMPDuptime);document.getElementById("mpdstats_dbUpdated").innerText=localeDate(a.result.dbUpdated);document.getElementById("mympdVersion").innerText=a.result.mympdVersion;document.getElementById("mpdInfo_version").innerText=a.result.mpdVersion;document.getElementById("mpdInfo_libmpdclientVersion").innerText=a.result.libmpdclientVersion;document.getElementById("mpdInfo_libmympdclientVersion").innerText=a.result.libmympdclientVersion}
function getServerinfo(){var a=new XMLHttpRequest;a.open("GET",subdir+"/api/serverinfo",!0);a.onreadystatechange=function(){if(4===a.readyState){var b=JSON.parse(a.responseText);document.getElementById("wsIP").innerText=b.result.ip;document.getElementById("wsMongooseVersion").innerText=b.result.version}};a.send()}
function parseOutputs(a){for(var b="",c=0,d=0;d<a.result.numOutputs;d++)"dummy"!==a.result.data[d].plugin&&(c++,b+='<button id="btnOutput'+a.result.data[d].id+'" data-output-name="'+encodeURI(a.result.data[d].name)+'" data-output-id="'+a.result.data[d].id+'" class="btn btn-secondary btn-block',1===a.result.data[d].state&&(b+=" active"),b+='"><span class="material-icons float-left">volume_up</span> '+e(a.result.data[d].name),b=0<Object.keys(a.result.data[d].attributes).length?b+('<a class="material-icons float-right text-white" title="'+
t("Edit attributes")+'">settings</a>'):b+('<a class="material-icons float-right text-white" title="'+t("Show attributes")+'">settings</a>'),b+="</button>");0===c&&(b='<span class="material-icons">error_outline</span> '+t("No outputs"));domCache.outputs.innerHTML=b}
function showListOutputAttributes(a){sendAPI("MPD_API_PLAYER_OUTPUT_LIST",{},function(b){modalOutputAttributes.show();for(var c,d=0;d<b.result.data.length;d++)if(b.result.data[d].name===a){c=b.result.data[d];break}document.getElementById("modalOutputAttributesId").value=e(c.id);var f="<tr><td>"+t("Name")+"</td><td>"+e(c.name)+"</td></tr><tr><td>"+t("State")+"</td><td>"+(1===c.state?t("enabled"):t("disabled"))+"</td></tr><tr><td>"+t("Plugin")+"</td><td>"+e(c.plugin)+"</td></tr>",g=0;Object.keys(c.attributes).forEach(function(a){g++;
f+="<tr><td>"+e(a)+'</td><td><input name="'+e(a)+'" class="form-control border-secondary" type="text" value="'+e(c.attributes[a])+'"/></td></tr>'});0<g?document.getElementById("btnOutputAttributesSave").removeAttribute("disabled"):document.getElementById("btnOutputAttributesSave").setAttribute("disabled","disabled");document.getElementById("outputAttributesList").innerHTML=f})}
function saveOutputAttributes(){var a={};a.outputId=parseInt(document.getElementById("modalOutputAttributesId").value);a.attributes={};for(var b=document.getElementById("outputAttributesList").getElementsByTagName("input"),c=0;c<b.length;c++)a.attributes[b[c].name]=b[c].value;sendAPI("MPD_API_PLAYER_OUTPUT_ATTRIBUTS_SET",a);modalOutputAttributes.hide()}
function setCounter(a,b,c){currentSong.totalTime=b;currentSong.elapsedTime=c;currentSong.currentSongId=a;var d=0<b?Math.ceil(domCache.progress.offsetWidth*c/b):0;0===d&&(domCache.progressBar.style.transition="none");domCache.progressBar.style.width=d+"px";0===d&&setTimeout(function(){domCache.progressBar.style.transition=progressBarTransition},10);domCache.progress.style.cursor=0>=b?"default":"pointer";b=beautifySongDuration(c)+"&nbsp;/&nbsp;"+beautifySongDuration(b);domCache.counter.innerHTML=b;
if(lastState&&lastState.currentSongId!==a&&(c=document.getElementById("queueTrackId"+lastState.currentSongId))){if(d=c.querySelector("[data-col=Duration]"))d.innerText=c.getAttribute("data-duration");if(d=c.querySelector("[data-col=Pos]"))d.classList.remove("material-icons"),d.innerText=c.getAttribute("data-songpos");c.classList.remove("font-weight-bold")}if(a=document.getElementById("queueTrackId"+a)){if(c=a.querySelector("[data-col=Duration]"))c.innerHTML=b;(b=a.querySelector("[data-col=Pos]"))&&
!b.classList.contains("material-icons")&&(b.classList.add("material-icons"),b.innerText="play_arrow");a.classList.add("font-weight-bold")}progressTimer&&clearTimeout(progressTimer);"play"===playstate&&(progressTimer=setTimeout(function(){currentSong.elapsedTime++;requestAnimationFrame(function(){setCounter(currentSong.currentSongId,currentSong.totalTime,currentSong.elapsedTime)})},1E3))}
function parseState(a){if(JSON.stringify(a.result)===JSON.stringify(lastState))toggleUI();else{parseUpdateQueue(a);parseVolume(a);setCounter(a.result.currentSongId,a.result.totalTime,a.result.elapsedTime);lastState&&lastState.currentSongId===a.result.currentSongId&&lastState.queueVersion===a.result.queueVersion||sendAPI("MPD_API_PLAYER_CURRENT_SONG",{},songChange);if("-1"===a.result.songPos){domCache.currentTitle.innerText="Not playing";document.title="myMPD";domCache.footerTitle.innerText="";domCache.footerTitle.removeAttribute("title");
domCache.footerTitle.classList.remove("clickable");clearCurrentCover();!0===settings.bgCover&&clearBackgroundImage();for(var b=document.getElementById("cardPlaybackTags").getElementsByTagName("p"),c=0;c<b.length;c++)b[c].innerText=""}else if(b=document.getElementById("currentFileformat"))b.getElementsByTagName("p")[0].innerText=fileformat(a.result.audioFormat);lastState=a.result;!1!==settings.mpdConnected&&!1!==uiEnabled||getSettings(!0)}}
function parseVolume(a){-1===a.result.volume?(domCache.volumePrct.innerText=t("Volumecontrol disabled"),domCache.volumeControl.classList.add("hide")):(domCache.volumeControl.classList.remove("hide"),domCache.volumePrct.innerText=a.result.volume+" %",domCache.volumeMenu.firstChild.innerText=0===a.result.volume?"volume_off":50>a.result.volume?"volume_down":"volume_up");domCache.volumeBar.value=a.result.volume}
function setBackgroundImage(a){if(void 0===a)clearBackgroundImage();else{for(var b=document.querySelectorAll(".albumartbg"),c=0;c<b.length;c++)"-10"===b[c].style.zIndex?b[c].remove():(b[c].style.zIndex="-10",b[c].style.opacity="0");b=document.createElement("div");b.classList.add("albumartbg");b.style.filter=settings.bgCssFilter;b.style.backgroundImage='url("'+subdir+"/albumart/"+a+'")';b.style.opacity=0;c=document.getElementsByTagName("body")[0];c.insertBefore(b,c.firstChild);b=new Image;b.onload=
function(){document.querySelector(".albumartbg").style.opacity=1};b.src=subdir+"/albumart/"+a}}function clearBackgroundImage(){for(var a=document.querySelectorAll(".albumartbg"),b=0;b<a.length;b++)"-10"===a[b].style.zIndex?a[b].remove():(a[b].style.zIndex="-10",a[b].style.opacity="0")}function setCurrentCover(a){_setCurrentCover(a,domCache.currentCover);_setCurrentCover(a,domCache.footerCover)}
function _setCurrentCover(a,b){if(void 0===a)clearCurrentCover();else{for(var c=b.querySelectorAll(".coverbg"),d=0;d<c.length;d++)"2"===c[d].style.zIndex?c[d].remove():c[d].style.zIndex="2";c=document.createElement("div");c.classList.add("coverbg","carousel");c.style.backgroundImage='url("'+subdir+"/albumart/"+a+'")';c.style.opacity=0;b.insertBefore(c,b.firstChild);c=new Image;c.onload=function(){b.querySelector(".coverbg").style.opacity=1};c.src=subdir+"/albumart/"+a}}
function clearCurrentCover(){_clearCurrentCover(domCache.currentCover);_clearCurrentCover(domCache.footerCover)}function _clearCurrentCover(a){a=a.querySelectorAll(".coverbg");for(var b=0;b<a.length;b++)"2"===a[b].style.zIndex?a[b].remove():(a[b].style.zIndex="2",a[b].style.opacity="0")}
function songChange(a){var b=a.result.Title+":"+a.result.Artist+":"+a.result.Album+":"+a.result.uri+":"+a.result.currentSongId;if(lastSong!==b){var c="",d="",f="";mediaSessionSetMetadata(a.result.Title,a.result.Artist,a.result.Album,a.result.uri);setCurrentCover(a.result.uri);!0===settings.bgCover&&!0===settings.featCoverimage&&setBackgroundImage(a.result.uri);void 0!==a.result.Artist&&0<a.result.Artist.length&&"-"!==a.result.Artist?(c+=a.result.Artist,d+=a.result.Artist,f+=a.result.Artist+" - ",
domCache.footerArtist.innerText=a.result.Artist,domCache.footerArtist.setAttribute("data-name",encodeURI(a.result.Artist)),domCache.footerArtist.classList.add("clickable")):(domCache.footerArtist.innerText="",domCache.footerArtist.setAttribute("data-name",""),domCache.footerArtist.classList.remove("clickable"));void 0!==a.result.Album&&0<a.result.Album.length&&"-"!==a.result.Album?(c+=" - "+a.result.Album,d+="<br/>"+a.result.Album,domCache.footerAlbum.innerText=a.result.Album,domCache.footerAlbum.setAttribute("data-name",
encodeURI(a.result.Album)),domCache.footerAlbum.classList.add("clickable")):(domCache.footerAlbum.innerText="",domCache.footerAlbum.setAttribute("data-name",""),domCache.footerAlbum.classList.remove("clickable"));void 0!==a.result.Title&&0<a.result.Title.length?(f+=a.result.Title,domCache.currentTitle.innerText=a.result.Title,domCache.currentTitle.setAttribute("data-uri",encodeURI(a.result.uri)),domCache.footerTitle.innerText=a.result.Title,domCache.footerTitle.classList.add("clickable")):(domCache.currentTitle.innerText=
"",domCache.currentTitle.setAttribute("data-uri",""),domCache.footerTitle.innerText="",domCache.footerTitle.setAttribute("data-name",""),domCache.footerTitle.classList.remove("clickable"));document.title="myMPD: "+f;domCache.footerCover.title=f;void 0!==a.result.uri&&""!==a.result.uri&&-1===a.result.uri.indexOf("://")?domCache.footerTitle.classList.add("clickable"):domCache.footerTitle.classList.remove("clickable");void 0!==a.result.uri?(!0===settings.featStickers&&setVoteSongBtns(a.result.like,a.result.uri),
a.result.Filetype=filetype(a.result.uri)):a.result.Filetype="";a.result.Fileformat=lastState?fileformat(lastState.audioFormat):"";for(f=0;f<settings.colsPlayback.length;f++){var g=document.getElementById("current"+settings.colsPlayback[f]);if(g&&"Lyrics"===settings.colsPlayback[f])getLyrics(a.result.uri,g.getElementsByTagName("p")[0]);else if(g){var h=a.result[settings.colsPlayback[f]];void 0===h&&(h="");"Duration"===settings.colsPlayback[f]?h=beautifySongDuration(h):"LastModified"===settings.colsPlayback[f]&&
(h=localeDate(h));g.getElementsByTagName("p")[0].innerText=h;g.setAttribute("data-name",encodeURI(h))}}document.getElementById("currentBooklet").innerHTML=""===a.result.bookletPath||void 0===a.result.bookletPath||!1===settings.featBrowse?"":'<span class="text-light material-icons">description</span>&nbsp;<a class="text-light" target="_blank" href="'+subdir+"/browse/music/"+e(a.result.bookletPath)+'">'+t("Download booklet")+"</a>";if(f=document.getElementById("queueTrackId"+a.result.currentSongId))f.getElementsByTagName("td")[1].innerText=
a.result.Title;"play"===playstate&&showNotification(a.result.Title,c,d,"success");lastSong=b;lastSongObj=a.result}}function gotoTagList(){appGoto(app.current.app,app.current.tab,app.current.view,"0","-","-","-","")}function volumeStep(a){chVolume("up"===a?settings.volumeStep:0-settings.volumeStep)}function chVolume(a){a=parseInt(domCache.volumeBar.value)+a;0>a?a=0:100<a&&(a=100);domCache.volumeBar.value=a;sendAPI("MPD_API_PLAYER_VOLUME_SET",{volume:a})}
function clickTitle(){var a=decodeURI(domCache.currentTitle.getAttribute("data-uri"));""!==a&&-1===a.indexOf("://")&&songDetails(a)}function mediaSessionSetPositionState(a,b){!0===settings.mediaSession&&"mediaSession"in navigator&&navigator.mediaSession.setPositionState&&b<a&&navigator.mediaSession.setPositionState({duration:a,position:b})}
function mediaSessionSetState(){!0===settings.mediaSession&&"mediaSession"in navigator&&(navigator.mediaSession.playbackState="play"===playstate?"playing":"paused")}
function mediaSessionSetMetadata(a,b,c,d){if(!0===settings.mediaSession&&"mediaSession"in navigator){var f=window.location.port;d=window.location.protocol+"//"+window.location.hostname+(""!==f?":"+f:"")+subdir+"/albumart/"+d;navigator.mediaSession.metadata=!0===settings.coverimage?new MediaMetadata({title:a,artist:b,album:c,artwork:[{src:d}]}):new MediaMetadata({title:a,artist:b,album:c})}}
function focusTable(a,b){void 0===b&&(b=document.getElementById(app.current.app+(void 0!==app.current.tab?app.current.tab:"")+(void 0!==app.current.view?app.current.view:"")+"List"));if("Browse"===app.current.app&&"Database"===app.current.tab&&"List"===app.current.view){if(a=document.getElementsByClassName("card-grid"),0!==a.length){b=a[0];for(var c=0;c<a.length;c++)if(a[c].classList.contains("selected")){b=a[c];break}b.focus()}}else if("Home"===app.current.app){if(a=document.getElementsByClassName("home-icons"),
0!==a.length){b=a[0];for(c=0;c<a.length;c++)if(a[c].classList.contains("selected")){b=a[c];break}b.focus()}}else if(null!==b){c=b.getElementsByClassName("selected");if(void 0===a)0===c.length?(a=b.getElementsByTagName("tbody")[0].rows[0],a.classList.contains("not-clickable")&&(a=b.getElementsByTagName("tbody")[0].rows[1]),a.focus(),a.classList.add("selected")):c[0].focus();else{c&&0<c.length&&c[0].classList.remove("selected");c=b.getElementsByTagName("tbody")[0].rows;var d=c.length;d<a&&(a=0);d>a&&
(c[a].focus(),c[a].classList.add("selected"))}"BrowseFilesystemList"===b.id&&(a=b.getElementsByTagName("tbody")[0],0<a.rows.length&&"parentDir"!==a.rows[0].getAttribute("data-type")&&""!==app.current.search&&(b=b.getElementsByTagName("thead")[0].rows[0].cells.length,c=app.current.search.replace(/\/?([^/]+)$/,""),a=a.insertRow(0),a.setAttribute("data-type","parentDir"),a.setAttribute("tabindex",0),a.setAttribute("data-uri",encodeURI(c)),a.innerHTML='<td colspan="'+b+'">..</td>'));scrollFocusIntoView()}}
function scrollFocusIntoView(){var a=document.activeElement,b=a.getBoundingClientRect().top,c=a.offsetHeight;a=a.parentNode.parentNode.offsetTop;window.innerHeight>window.innerWidth&&(a+=domCache.header.offsetHeight);var d=window.innerHeight-a-domCache.footer.offsetHeight,f=c/2;b<=a+f?window.scrollBy(0,-c):b+c>d-f&&window.scrollBy(0,c)}
function navigateTable(a,b){if(a=document.activeElement){var c=null,d=!1;"ArrowDown"===b?(c=a.nextElementSibling,c.classList.contains("not-clickable")&&(c=c.nextElementSibling),d=!0):"ArrowUp"===b?(c=a.previousElementSibling,c.classList.contains("not-clickable")&&(c=c.previousElementSibling),d=!0):" "===b?(b=a.lastChild.firstChild,"A"===b.nodeName&&b.click(),d=!0):"Enter"===b?(a.firstChild.click(),d=!0):"Escape"===b&&(a.blur(),a.classList.remove("selected"),d=!0);!0===d&&(event.preventDefault(),event.stopPropagation());
c&&(a.classList.remove("selected"),c.classList.add("selected"),c.focus(),scrollFocusIntoView())}}
function dragAndDropTable(a){var b=document.getElementById(a).getElementsByTagName("tbody")[0];b.addEventListener("dragstart",function(a){"TR"===a.target.nodeName&&(a.target.classList.add("opacity05"),a.dataTransfer.setDragImage(a.target,0,0),a.dataTransfer.effectAllowed="move",a.dataTransfer.setData("Text",a.target.getAttribute("id")),dragEl=a.target.cloneNode(!0))},!1);b.addEventListener("dragleave",function(a){a.preventDefault();if("TR"===dragEl.nodeName){var b=a.target;"TD"===a.target.nodeName&&
(b=a.target.parentNode);"TR"===b.nodeName&&b.classList.remove("dragover")}},!1);b.addEventListener("dragover",function(a){a.preventDefault();if("TR"===dragEl.nodeName){for(var c=b.getElementsByClassName("dragover"),f=c.length,g=0;g<f;g++)c[g].classList.remove("dragover");c=a.target;"TD"===a.target.nodeName&&(c=a.target.parentNode);"TR"===c.nodeName&&c.classList.add("dragover");a.dataTransfer.dropEffect="move"}},!1);b.addEventListener("dragend",function(a){a.preventDefault();if("TR"===dragEl.nodeName){for(var c=
b.getElementsByClassName("dragover"),f=c.length,g=0;g<f;g++)c[g].classList.remove("dragover");document.getElementById(a.dataTransfer.getData("Text"))&&document.getElementById(a.dataTransfer.getData("Text")).classList.remove("opacity05")}},!1);b.addEventListener("drop",function(c){c.stopPropagation();c.preventDefault();if("TR"===dragEl.nodeName){var d=c.target;"TD"===c.target.nodeName&&(d=c.target.parentNode);var f=document.getElementById(c.dataTransfer.getData("Text")).getAttribute("data-songpos"),
g=d.getAttribute("data-songpos");document.getElementById(c.dataTransfer.getData("Text")).remove();dragEl.classList.remove("opacity05");b.insertBefore(dragEl,d);c=b.getElementsByClassName("dragover");d=c.length;for(var h=0;h<d;h++)c[h].classList.remove("dragover");document.getElementById(a).classList.add("opacity05");"Queue"===app.current.app&&"Current"===app.current.tab?sendAPI("MPD_API_QUEUE_MOVE_TRACK",{from:f,to:g}):"Browse"===app.current.app&&"Playlists"===app.current.tab&&"Detail"===app.current.view&&
playlistMoveTrack(f,g)}},!1)}
function dragAndDropTableHeader(a){if(document.getElementById(a+"List"))var b=document.getElementById(a+"List").getElementsByTagName("tr")[0];else b=a.getElementsByTagName("tr")[0],a="BrowseDatabase";b.addEventListener("dragstart",function(a){"TH"===a.target.nodeName&&(a.target.classList.add("opacity05"),a.dataTransfer.setDragImage(a.target,0,0),a.dataTransfer.effectAllowed="move",a.dataTransfer.setData("Text",a.target.getAttribute("data-col")),dragEl=a.target.cloneNode(!0))},!1);b.addEventListener("dragleave",
function(a){a.preventDefault();"TH"===dragEl.nodeName&&"TH"===a.target.nodeName&&a.target.classList.remove("dragover-th")},!1);b.addEventListener("dragover",function(a){a.preventDefault();if("TH"===dragEl.nodeName){for(var c=b.getElementsByClassName("dragover-th"),f=c.length,g=0;g<f;g++)c[g].classList.remove("dragover-th");"TH"===a.target.nodeName&&a.target.classList.add("dragover-th");a.dataTransfer.dropEffect="move"}},!1);b.addEventListener("dragend",function(a){a.preventDefault();if("TH"===dragEl.nodeName){for(var c=
b.getElementsByClassName("dragover-th"),f=c.length,g=0;g<f;g++)c[g].classList.remove("dragover-th");this.querySelector("[data-col="+a.dataTransfer.getData("Text")+"]")&&this.querySelector("[data-col="+a.dataTransfer.getData("Text")+"]").classList.remove("opacity05")}},!1);b.addEventListener("drop",function(c){c.stopPropagation();c.preventDefault();if("TH"===dragEl.nodeName){this.querySelector("[data-col="+c.dataTransfer.getData("Text")+"]").remove();dragEl.classList.remove("opacity05");b.insertBefore(dragEl,
c.target);c=b.getElementsByClassName("dragover-th");for(var d=c.length,f=0;f<d;f++)c[f].classList.remove("dragover-th");document.getElementById(a+"List")?(document.getElementById(a+"List").classList.add("opacity05"),saveCols(a)):saveCols(a,this.parentNode.parentNode)}},!1)}
function setColTags(a){var b=settings.tags.slice();!1===settings.featTags&&b.push("Title");b.push("Duration");"QueueCurrent"!==a&&"BrowsePlaylistsDetail"!==a&&"QueueLastPlayed"!==a||b.push("Pos");"BrowseFilesystem"===a&&b.push("Type");"QueueLastPlayed"===a&&b.push("LastPlayed");"Playback"===a&&(b.push("Filetype"),b.push("Fileformat"),b.push("LastModified"),!0===settings.featLyrics&&b.push("Lyrics"));b.sort();return b}
function setColsChecklist(a){for(var b="",c=setColTags(a),d=0;d<c.length;d++)if("Playback"!==a||"Title"!==c[d])b+='<div><button class="btn btn-secondary btn-xs clickable material-icons material-icons-small'+(settings["cols"+a].includes(c[d])?" active":"")+'" name="'+c[d]+'">'+(settings["cols"+a].includes(c[d])?"check":"radio_button_unchecked")+'</button><label class="form-check-label" for="'+c[d]+'">&nbsp;&nbsp;'+t(c[d])+"</label></div>";return b}
function setCols(a,b){var c=document.getElementById(a+"ColsDropdown");c&&(c.firstChild.innerHTML=setColsChecklist(a));var d=app.current.sort;"Search"===a&&"0/any/Title/-/"===app.apps.Search.state&&(d=settings.tags.includes("Title")?"Title":!1===settings.featTags?"Filename":"-");if("Playback"!==a){c="";for(var f=0;f<settings["cols"+a].length;f++){var g=settings["cols"+a][f];c+='<th draggable="true" data-col="'+g+'">';if("Track"===g||"Pos"===g)g="#";c+=t(g);"Search"!==a||g!==d&&"-"+g!==d||(g=!1,0===
app.current.sort.indexOf("-")&&(g=!0),c+='<span class="sort-dir material-icons pull-right">'+(!0===g?"arrow_drop_up":"arrow_drop_down")+"</span>");c+="</th>"}c=!0===settings.featTags?c+'<th data-col="Action"><a href="#" class="text-secondary align-middle material-icons material-icons-small">settings</a></th>':c+"<th></th>";if(void 0===b)document.getElementById(a+"List").getElementsByTagName("tr")[0].innerHTML=c;else for(a=document.querySelectorAll(b),b=0;b<a.length;b++)a[b].getElementsByTagName("tr")[0].innerHTML=
c}}
function saveCols(a,b){var c=document.getElementById(a+"ColsDropdown");b=void 0===b?document.getElementById(a+"List").getElementsByTagName("tr")[0]:"string"===typeof b?document.querySelector(b).getElementsByTagName("tr")[0]:b.getElementsByTagName("tr")[0];if(c){c=c.firstChild.getElementsByTagName("button");for(var d=0;d<c.length;d++)if(null!==c[d].getAttribute("name")){var f=b.querySelector("[data-col="+c[d].name+"]");!1===c[d].classList.contains("active")?f&&f.remove():f||(f=document.createElement("th"),f.innerText=
c[d].name,f.setAttribute("data-col",c[d].name),b.insertBefore(f,b.lastChild))}}a={table:"cols"+a,cols:[]};b=b.getElementsByTagName("th");for(c=0;c<b.length;c++)d=b[c].getAttribute("data-col"),"Action"!==d&&null!==d&&a.cols.push(d);sendAPI("MYMPD_API_COLS_SAVE",a,getSettings)}
function saveColsPlayback(a){for(var b=document.getElementById(a+"ColsDropdown").firstChild.getElementsByTagName("button"),c=document.getElementById("cardPlaybackTags"),d=0;d<b.length-1;d++){var f=document.getElementById("current"+b[d].name);!1===b[d].classList.contains("active")?f&&f.remove():f||(f=document.createElement("div"),f.innerHTML="<small>"+t(b[d].name)+"</small><p></p>",f.setAttribute("id","current"+b[d].name),f.setAttribute("data-tag",b[d].name),c.appendChild(f))}a={table:"cols"+a,cols:[]};
c=c.getElementsByTagName("div");for(b=0;b<c.length;b++)(d=c[b].getAttribute("data-tag"))&&a.cols.push(d);sendAPI("MYMPD_API_COLS_SAVE",a,getSettings)}function replaceTblRow(a,b){var c=!1;a.querySelector("[data-popover]")&&hideMenu();a.classList.contains("selected")&&(b.classList.add("selected"),b.focus(),c=!0);a.replaceWith(b);return c}var themes={"theme-autodetect":"Autodetect","theme-default":"Default","theme-dark":"Dark","theme-light":"Light"};
function deleteTimer(a){sendAPI("MYMPD_API_TIMER_RM",{timerid:a},showListTimer)}function toggleTimer(a,b){a.classList.contains("active")?(a.classList.remove("active"),sendAPI("MYMPD_API_TIMER_TOGGLE",{timerid:b,enabled:!1},showListTimer)):(a.classList.add("active"),sendAPI("MYMPD_API_TIMER_TOGGLE",{timerid:b,enabled:!0},showListTimer))}
function saveTimer(){var a=!0,b=document.getElementById("inputTimerName");validateNotBlank(b)||(a=!1);for(var c=!1,d="btnTimerMon btnTimerTue btnTimerWed btnTimerThu btnTimerFri btnTimerSat btnTimerSun".split(" "),f=[],g=0;g<d.length;g++){var h=document.getElementById(d[g]).classList.contains("active")?!0:!1;f.push(h);!0===h&&(c=!0)}!1===c?(a=!1,document.getElementById("invalidTimerWeekdays").style.display="block"):document.getElementById("invalidTimerWeekdays").style.display="none";c=document.getElementById("selectTimerAction");
d=document.getElementById("selectTimerPlaylist");g=document.getElementById("selectTimerHour");h=document.getElementById("selectTimerMinute");var k=document.getElementById("btnTimerJukeboxModeGroup").getElementsByClassName("active")[0].getAttribute("data-value");-1===c.selectedIndex&&(a=!1,c.classList.add("is-invalid"));"0"===k&&"Database"===d.options[d.selectedIndex].value&&"startplay"===c.options[c.selectedIndex].value&&(a=!1,document.getElementById("btnTimerJukeboxModeGroup").classList.add("is-invalid"));
if(!0===a){a={};for(var l=document.getElementById("timerActionScriptArguments").getElementsByTagName("input"),m=0;m<l.length;m++)a[l[m].getAttribute("data-name")]=l[m].value;sendAPI("MYMPD_API_TIMER_SAVE",{timerid:parseInt(document.getElementById("inputTimerId").value),name:b.value,enabled:document.getElementById("btnTimerEnabled").classList.contains("active")?!0:!1,startHour:parseInt(g.options[g.selectedIndex].value),startMinute:parseInt(h.options[h.selectedIndex].value),weekdays:f,action:c.options[c.selectedIndex].parentNode.getAttribute("data-value"),
subaction:c.options[c.selectedIndex].value,volume:parseInt(document.getElementById("inputTimerVolume").value),playlist:d.options[d.selectedIndex].value,jukeboxMode:parseInt(k),arguments:a},showListTimer)}}
function showEditTimer(a){document.getElementById("timerActionPlay").classList.add("hide");document.getElementById("timerActionScript").classList.add("hide");document.getElementById("listTimer").classList.remove("active");document.getElementById("editTimer").classList.add("active");document.getElementById("listTimerFooter").classList.add("hide");document.getElementById("editTimerFooter").classList.remove("hide");if(0!==a)sendAPI("MYMPD_API_TIMER_GET",{timerid:a},parseEditTimer);else{sendAPI("MPD_API_PLAYLIST_LIST_ALL",
{searchstr:""},function(a){getAllPlaylists(a,"selectTimerPlaylist","Database")});document.getElementById("inputTimerId").value="0";document.getElementById("inputTimerName").value="";toggleBtnChk("btnTimerEnabled",!0);document.getElementById("selectTimerHour").value="12";document.getElementById("selectTimerMinute").value="0";document.getElementById("selectTimerAction").value="startplay";document.getElementById("inputTimerVolume").value="50";document.getElementById("selectTimerPlaylist").value="Database";
toggleBtnGroupValue(document.getElementById("btnTimerJukeboxModeGroup"),1);a="btnTimerMon btnTimerTue btnTimerWed btnTimerThu btnTimerFri btnTimerSat btnTimerSun".split(" ");for(var b=0;b<a.length;b++)toggleBtnChk(a[b],!1);document.getElementById("timerActionPlay").classList.remove("hide")}document.getElementById("inputTimerName").focus();removeIsInvalid(document.getElementById("editTimerForm"));document.getElementById("invalidTimerWeekdays").style.display="none"}
function parseEditTimer(a){var b=a.result.playlist;sendAPI("MPD_API_PLAYLIST_LIST_ALL",{searchstr:""},function(a){getAllPlaylists(a,"selectTimerPlaylist",b)});document.getElementById("inputTimerId").value=a.result.timerid;document.getElementById("inputTimerName").value=a.result.name;toggleBtnChk("btnTimerEnabled",a.result.enabled);document.getElementById("selectTimerHour").value=a.result.startHour;document.getElementById("selectTimerMinute").value=a.result.startMinute;document.getElementById("selectTimerAction").value=
a.result.subaction;selectTimerActionChange(a.result.arguments);document.getElementById("inputTimerVolume").value=a.result.volume;toggleBtnGroupValue(document.getElementById("btnTimerJukeboxModeGroup"),a.result.jukeboxMode);for(var c="btnTimerMon btnTimerTue btnTimerWed btnTimerThu btnTimerFri btnTimerSat btnTimerSun".split(" "),d=0;d<c.length;d++)toggleBtnChk(c[d],a.result.weekdays[d])}
function selectTimerActionChange(a){var b=document.getElementById("selectTimerAction");"startplay"===b.options[b.selectedIndex].value?(document.getElementById("timerActionPlay").classList.remove("hide"),document.getElementById("timerActionScript").classList.add("hide")):"script"===b.options[b.selectedIndex].parentNode.getAttribute("data-value")?(document.getElementById("timerActionScript").classList.remove("hide"),document.getElementById("timerActionPlay").classList.add("hide"),showTimerScriptArgs(b.options[b.selectedIndex],
a)):(document.getElementById("timerActionPlay").classList.add("hide"),document.getElementById("timerActionScript").classList.add("hide"))}
function showTimerScriptArgs(a,b){void 0===b&&(b={});a=JSON.parse(a.getAttribute("data-arguments"));for(var c="",d=0;d<a.arguments.length;d++)c+='<div class="form-group row"><label class="col-sm-4 col-form-label" for="timerActionScriptArguments'+d+'">'+e(a.arguments[d])+'</label><div class="col-sm-8"><input name="timerActionScriptArguments'+d+'" class="form-control border-secondary" type="text" value="'+(b[a.arguments[d]]?e(b[a.arguments[d]]):"")+'"data-name="'+a.arguments[d]+'"></div></div>';0===
a.arguments.length&&(c="No arguments");document.getElementById("timerActionScriptArguments").innerHTML=c}function showListTimer(){document.getElementById("listTimer").classList.add("active");document.getElementById("editTimer").classList.remove("active");document.getElementById("listTimerFooter").classList.remove("hide");document.getElementById("editTimerFooter").classList.add("hide");sendAPI("MYMPD_API_TIMER_LIST",{},parseListTimer)}
function parseListTimer(a){for(var b=document.getElementById("listTimer").getElementsByTagName("tbody")[0],c=b.getElementsByTagName("tr"),d=0,f="Mon Tue Wed Thu Fri Sat Sun".split(" "),g=0;g<a.result.returnedEntities;g++){var h=document.createElement("tr");h.setAttribute("data-id",a.result.data[g].timerid);for(var k="<td>"+e(a.result.data[g].name)+'</td><td><button name="enabled" class="btn btn-secondary btn-xs clickable material-icons material-icons-small'+(!0===a.result.data[g].enabled?" active":
"")+'">'+(!0===a.result.data[g].enabled?"check":"radio_button_unchecked")+"</button></td><td>"+zeroPad(a.result.data[g].startHour,2)+":"+zeroPad(a.result.data[g].startMinute,2)+" "+t("on")+" ",l=[],m=0;7>m;m++)!0===a.result.data[g].weekdays[m]&&l.push(t(f[m]));k+=l.join(", ")+"</td><td>"+prettyTimerAction(a.result.data[g].action,a.result.data[g].subaction)+'</td><td data-col="Action"><a href="#" class="material-icons color-darkgrey">delete</a></td>';h.innerHTML=k;g<c.length?d=!0===replaceTblRow(c[g],
h)?g:d:b.append(h)}for(d=c.length-1;d>=a.result.returnedEntities;d--)c[d].remove();0===a.result.returnedEntities&&(b.innerHTML='<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td><td colspan="4">'+t("Empty list")+"</td></tr>")}function prettyTimerAction(a,b){return"player"===a&&"startplay"===b?t("Start playback"):"player"===a&&"stopplay"===b?t("Stop playback"):"syscmd"===a?t("System command")+": "+e(b):"script"===a?t("Script")+": "+e(b):e(a)+": "+e(b)}
function saveTrigger(){var a=!0,b=document.getElementById("inputTriggerName");validatePlnameEl(b)||(a=!1);if(!0===a){a={};for(var c=document.getElementById("triggerActionScriptArguments").getElementsByTagName("input"),d=0;d<c.length;d++)a[c[d].getAttribute("data-name")]=c[d].value;sendAPI("MPD_API_TRIGGER_SAVE",{id:parseInt(document.getElementById("inputTriggerId").value),name:b.value,event:getSelectValue("selectTriggerEvent"),script:getSelectValue("selectTriggerScript"),arguments:a},showListTrigger,
!1)}}
function showEditTrigger(a){document.getElementById("listTrigger").classList.remove("active");document.getElementById("newTrigger").classList.add("active");document.getElementById("listTriggerFooter").classList.add("hide");document.getElementById("newTriggerFooter").classList.remove("hide");var b=document.getElementById("inputTriggerName");b.classList.remove("is-invalid");b.value="";b.focus();document.getElementById("inputTriggerId").value="-1";document.getElementById("selectTriggerEvent").selectedIndex=0;
document.getElementById("selectTriggerScript").selectedIndex=0;-1<a?sendAPI("MPD_API_TRIGGER_GET",{id:a},parseTriggerEdit,!1):selectTriggerActionChange()}function parseTriggerEdit(a){document.getElementById("inputTriggerId").value=a.result.id;document.getElementById("inputTriggerName").value=a.result.name;document.getElementById("selectTriggerEvent").value=a.result.event;document.getElementById("selectTriggerScript").value=a.result.script;selectTriggerActionChange(a.result.arguments)}
function selectTriggerActionChange(a){var b=document.getElementById("selectTriggerScript");showTriggerScriptArgs(b.options[b.selectedIndex],a)}
function showTriggerScriptArgs(a,b){void 0===b&&(b={});a=JSON.parse(a.getAttribute("data-arguments"));for(var c="",d=0;d<a.arguments.length;d++)c+='<div class="form-group row"><label class="col-sm-4 col-form-label" for="triggerActionScriptArguments'+d+'">'+e(a.arguments[d])+'</label><div class="col-sm-8"><input name="triggerActionScriptArguments'+d+'" class="form-control border-secondary" type="text" value="'+(b[a.arguments[d]]?e(b[a.arguments[d]]):"")+'"data-name="'+a.arguments[d]+'"></div></div>';
0===a.arguments.length&&(c="No arguments");document.getElementById("triggerActionScriptArguments").innerHTML=c}function showListTrigger(){document.getElementById("listTrigger").classList.add("active");document.getElementById("newTrigger").classList.remove("active");document.getElementById("listTriggerFooter").classList.remove("hide");document.getElementById("newTriggerFooter").classList.add("hide");sendAPI("MPD_API_TRIGGER_LIST",{},parseTriggerList,!1)}
function deleteTrigger(a){sendAPI("MPD_API_TRIGGER_DELETE",{id:a},function(){sendAPI("MPD_API_TRIGGER_LIST",{},parseTriggerList,!1)},!0)}
function parseTriggerList(a){if(0<a.result.data.length){for(var b="",c=0;c<a.result.data.length;c++)b+='<tr data-trigger-id="'+encodeURI(a.result.data[c].id)+'"><td class="'+(a.result.data[c].name===settings.trigger?"font-weight-bold":"")+'">'+e(a.result.data[c].name)+"</td><td>"+t(a.result.data[c].eventName)+"</td><td>"+e(a.result.data[c].script)+'</td><td data-col="Action">'+("default"===a.result.data[c].name||a.result.data[c].name===settings.trigger?"":'<a href="#" title="'+t("Delete")+'" data-action="delete" class="material-icons color-darkgrey">delete</a>')+
"</td></tr>";document.getElementById("listTriggerList").innerHTML=b}else document.getElementById("listTriggerList").innerHTML='<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td><td colspan="2">'+t("Empty list")+"</td></tr>"}function removeIsInvalid(a){a=a.querySelectorAll(".is-invalid");for(var b=0;b<a.length;b++)a[b].classList.remove("is-invalid")}function getSelectValue(a){a=document.getElementById(a);return a.options[a.selectedIndex].value}
function getSelectedOptionAttribute(a,b){a=document.getElementById(a);return a.options[a.selectedIndex].getAttribute(b)}
function alignDropdown(a){getXpos(a.children[0])<.66*domCache.body.offsetWidth?"navState"===a.id?(a.classList.remove("dropdown"),a.classList.add("dropright")):a.getElementsByClassName("dropdown-menu")[0].classList.remove("dropdown-menu-right"):(a.getElementsByClassName("dropdown-menu")[0].classList.add("dropdown-menu-right"),a.classList.add("dropdown"),a.classList.remove("dropright"))}function getXpos(a){for(var b=0;a;)b+=a.offsetLeft-a.scrollLeft+a.clientLeft,a=a.offsetParent;return b}
function zeroPad(a,b){b=b-a.toString().length+1;return Array(+(0<b&&b)).join("0")+a}function dirname(a){return a.replace(/\/[^/]*$/,"")}function basename(a,b){return!0===b?a.split("/").reverse()[0].split(/[?#]/)[0]:a.split("/").reverse()[0]}
function filetype(a){if(void 0===a)return"";a=a.split(".").pop().toUpperCase();switch(a){case "MP3":return a+" - MPEG-1 Audio Layer III";case "FLAC":return a+" - Free Lossless Audio Codec";case "OGG":return a+" - Ogg Vorbis";case "OPUS":return a+" - Opus Audio";case "WAV":return a+" - WAVE Audio File";case "WV":return a+" - WavPack";case "AAC":return a+" - Advancded Audio Coding";case "MPC":return a+" - Musepack";case "MP4":return a+" - MPEG-4";case "APE":return a+" - Monkey Audio ";case "WMA":return a+
" - Windows Media Audio";default:return a}}function fileformat(a){return a.bits+t("bits")+" - "+a.sampleRate/1E3+t("kHz")}function scrollToPosY(a){document.body.scrollTop=a;document.documentElement.scrollTop=a}
function selectTag(a,b,c){a=document.getElementById(a);var d=a.querySelector(".active");d&&d.classList.remove("active");if(d=a.querySelector("[data-tag="+c+"]"))d.classList.add("active"),void 0!==b&&(document.getElementById(b).innerText=d.innerText,document.getElementById(b).setAttribute("data-phrase",d.innerText))}
function addTagList(a,b){var c="";"searchtags"===b&&(!0===settings.featTags&&(c+='<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="any">'+t("Any Tag")+"</button>"),c+='<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="filename">'+t("Filename")+"</button>");for(var d=0;d<settings[b].length;d++)c+='<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="'+settings[b][d]+'">'+t(settings[b][d])+"</button>";if("BrowseNavFilesystemDropdown"===
a||"BrowseNavPlaylistsDropdown"===a)c='<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Database">Database</button>';"BrowseDatabaseByTagDropdown"===a||"BrowseNavFilesystemDropdown"===a||"BrowseNavPlaylistsDropdown"===a?("BrowseDatabaseByTagDropdown"===a&&(c+='<div class="dropdown-divider"></div>'),c+='<button type="button" class="btn btn-secondary btn-sm btn-block'+("BrowseNavPlaylistsDropdown"===a?" active":"")+'" data-tag="Playlists">'+t("Playlists")+'</button><button type="button" class="btn btn-secondary btn-sm btn-block'+
("BrowseNavFilesystemDropdown"===a?" active":"")+'" data-tag="Filesystem">'+t("Filesystem")+"</button>"):"databaseSortTagsList"===a&&(settings.tags.includes("Date")&&(c+='<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Date">'+t("Date")+"</button>"),c+='<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Last-Modified">'+t("Last modified")+"</button>");document.getElementById(a).innerHTML=c}
function addTagListSelect(a,b){var c="";"saveSmartPlaylistSort"===a||"selectSmartplsSort"===a?(c+='<option value="">'+t("Disabled")+"</option>",c+='<option value="shuffle">'+t("Shuffle")+"</option>",c+='<optgroup label="'+t("Sort by tag")+'">',c+='<option value="filename">'+t("Filename")+"</option>"):"selectJukeboxUniqueTag"===a&&!1===settings.browsetags.includes("Title")&&(c='<option value="Title">'+t("Song")+"</option>");for(var d=0;d<settings[b].length;d++)c+='<option value="'+settings[b][d]+'">'+
t(settings[b][d])+"</option>";if("saveSmartPlaylistSort"===a||"selectSmartplsSort"===a)c+="</optgroup>";document.getElementById(a).innerHTML=c}function openModal(a){window[a].show()}function openDropdown(a){window[a].toggle()}function focusSearch(){"Queue"===app.current.app?document.getElementById("searchqueuestr").focus():"Search"===app.current.app?domCache.searchstr.focus():appGoto("Search")}
function btnWaiting(a,b){!0===b?(b=document.createElement("span"),b.classList.add("spinner-border","spinner-border-sm","mr-2"),a.insertBefore(b,a.firstChild),a.setAttribute("disabled","disabled")):(a.removeAttribute("disabled"),"SPAN"===a.firstChild.nodeName&&a.firstChild.remove())}
function toggleBtnGroupValue(a,b){a=a.getElementsByTagName("button");var c=a[0],d=b;!1===isNaN(b)&&(d=b.toString());for(b=0;b<a.length;b++)a[b].getAttribute("data-value")===d?(a[b].classList.add("active"),c=a[b]):a[b].classList.remove("active");return c}function toggleBtnGroupValueCollapse(a,b,c){"show"===toggleBtnGroupValue(a,c).getAttribute("data-collapse")?document.getElementById(b).classList.add("show"):document.getElementById(b).classList.remove("show")}
function toggleBtnGroup(a){var b=a;"string"===typeof a&&(b=document.getElementById(a));a=b.parentNode.getElementsByTagName("button");for(var c=0;c<a.length;c++)a[c]===b?a[c].classList.add("active"):a[c].classList.remove("active");return b}function getBtnGroupValue(a){var b=document.getElementById(a).getElementsByClassName("active");0===b.length&&(b=document.getElementById(a).getElementsByTagName("button"));return b[0].getAttribute("data-value")}
function toggleBtnGroupCollapse(a,b){"show"===toggleBtnGroup(a).getAttribute("data-collapse")?!1===document.getElementById(b).classList.contains("show")&&window[b].show():window[b].hide()}function toggleBtn(a,b){var c=a;"string"===typeof a&&(c=document.getElementById(a));c&&(void 0===b&&(b=c.classList.contains("active")?!1:!0),!0===b||1===b?c.classList.add("active"):c.classList.remove("active"))}
function toggleBtnChk(a,b){var c=a;"string"===typeof a&&(c=document.getElementById(a));if(c){void 0===b&&(b=c.classList.contains("active")?!1:!0);if(!0===b||1===b)return c.classList.add("active"),c.innerText="check",!0;c.classList.remove("active");c.innerText="radio_button_unchecked";return!1}}function toggleBtnChkCollapse(a,b,c){!0===toggleBtnChk(a,c)?document.getElementById(b).classList.add("show"):document.getElementById(b).classList.remove("show")}
function setPagination(a,b){var c=app.current.app+(void 0===app.current.tab?"":app.current.tab),d=Math.ceil(a/settings.maxElementsPerPage);0===d&&(d=1);for(var f=[document.getElementById(c+"PaginationTop"),document.getElementById(c+"PaginationBottom")],g=0;g<f.length;g++){var h=f[g].children[0],k=f[g].children[1].children[0],l=f[g].children[1].children[1],m=f[g].children[2];k.innerText=app.current.page/settings.maxElementsPerPage+1+" / "+d;if(1<d){k.removeAttribute("disabled");for(var p="",n=0;n<
d;n++)p+='<button data-page="'+n*settings.maxElementsPerPage+'" type="button" class="mr-1 mb-1 btn-sm btn btn-secondary">'+(n+1)+"</button>";l.innerHTML=p;k.classList.remove("nodropdown")}else-1===a?(k.setAttribute("disabled","disabled"),k.innerText=app.current.page/settings.maxElementsPerPage+1):k.setAttribute("disabled","disabled"),k.classList.add("nodropdown");a>app.current.page+settings.maxElementsPerPage||-1===a&&b>=settings.maxElementsPerPage?(m.removeAttribute("disabled"),f[g].classList.remove("hide"),
document.getElementById(c+"ButtonsBottom").classList.remove("hide")):(m.setAttribute("disabled","disabled"),f[g].classList.add("hide"),document.getElementById(c+"ButtonsBottom").classList.add("hide"));0<app.current.page?(h.removeAttribute("disabled"),f[g].classList.remove("hide"),document.getElementById(c+"ButtonsBottom").classList.remove("hide")):h.setAttribute("disabled","disabled")}}function genId(a){return"id"+a.replace(/[^\w-]/g,"")}
function parseCmd(a,b){null!==a&&a.preventDefault();var c=b;"string"===typeof b&&(c=JSON.parse(b));if("function"===typeof window[c.cmd])switch(c.cmd){case "sendAPI":sendAPI(c.options[0].cmd,{});break;case "toggleBtn":case "toggleBtnChk":case "toggleBtnGroup":case "toggleBtnGroupCollapse":case "zoomPicture":case "setPlaySettings":window[c.cmd].apply(null,[a.target].concat($jscomp.arrayFromIterable(c.options)));break;case "toggleBtnChkCollapse":window[c.cmd].apply(null,[a.target,void 0].concat($jscomp.arrayFromIterable(c.options)));
break;default:window[c.cmd].apply(null,$jscomp.arrayFromIterable(c.options))}else logError("Can not execute cmd: "+c)}function gotoPage(a){switch(a){case "next":app.current.page+=settings.maxElementsPerPage;break;case "prev":app.current.page-=settings.maxElementsPerPage;0>app.current.page&&(app.current.page=0);break;default:app.current.page=a}appGoto(app.current.app,app.current.tab,app.current.view,app.current.page,app.current.filter,app.current.sort,app.current.tag,app.current.search)}
function validateFilenameString(a){return""===a?!1:null!==a.match(/^[\w-.]+$/)?!0:!1}function validateFilename(a){if(!1===validateFilenameString(a.value))return a.classList.add("is-invalid"),!1;a.classList.remove("is-invalid");return!0}function validateFilenameList(a){a.classList.remove("is-invalid");for(var b=a.value.split(","),c=0;c<b.length;c++)if(!1===validateFilenameString(b[c].trim()))return a.classList.add("is-invalid"),!1;return!0}
function validatePath(a){if(""===a.value)return a.classList.add("is-invalid"),!1;if(null!==a.value.match(/^\/[/.\w-]+$/))return a.classList.remove("is-invalid"),!0;a.classList.add("is-invalid");return!1}function validatePlnameEl(a){if(!1===validatePlname(a.value))return a.classList.add("is-invalid"),!1;a.classList.remove("is-invalid");return!0}function validatePlname(a){return""===a?!1:null===a.match(/\/|\r|\n|"|'/)?!0:!1}
function validateNotBlank(a){if(""===a.value.replace(/\s/g,""))return a.classList.add("is-invalid"),!1;a.classList.remove("is-invalid");return!0}function validateInt(a){if(""!==a.value.replace(/\d/g,""))return a.classList.add("is-invalid"),!1;a.classList.remove("is-invalid");return!0}function validateFloat(a){if(""!==a.value.replace(/[\d-.]/g,""))return a.classList.add("is-invalid"),!1;a.classList.remove("is-invalid");return!0}
function validateStream(a){if(-1<a.value.indexOf("://"))return a.classList.remove("is-invalid"),!0;a.classList.add("is-invalid");return!1}function validateHost(a){if(null!==a.value.match(/^([\w-.]+)$/))return a.classList.remove("is-invalid"),!0;a.classList.add("is-invalid");return!1};
